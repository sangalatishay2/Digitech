// DigiTech Business OS — Domain types (provider agnostic)

export type UUID = string;
export type ISODate = string; // timestamptz ISO string

export const CUSTOMER_STATUS = ['lead', 'active', 'vip', 'inactive', 'blocked', 'lost'] as const;
export type CustomerStatus = (typeof CUSTOMER_STATUS)[number];

export const ORDER_STATUS = [
  'new',
  'awaiting_payment',
  'paid',
  'processing',
  'activation_pending',
  'activated',
  'delivered',
  'completed',
  'cancelled',
  'refunded',
] as const;
export type OrderStatus = (typeof ORDER_STATUS)[number];

export const PAYMENT_STATUS = [
  'pending',
  'partial',
  'paid',
  'failed',
  'refunded',
  'partially_refunded',
] as const;
export type PaymentStatus = (typeof PAYMENT_STATUS)[number];

export const PAYMENT_METHOD = [
  'upi',
  'bank_transfer',
  'cash',
  'credit_card',
  'debit_card',
  'gateway',
  'wallet',
  'other',
] as const;
export type PaymentMethod = (typeof PAYMENT_METHOD)[number];

export const ACTIVATION_STATUS = [
  'waiting_payment',
  'ready',
  'processing',
  'waiting_supplier',
  'activated',
  'delivered',
  'failed',
  'cancelled',
] as const;
export type ActivationStatus = (typeof ACTIVATION_STATUS)[number];

export const SUBSCRIPTION_STATUS = [
  'pending',
  'active',
  'expiring',
  'expired',
  'renewed',
  'cancelled',
  'paused',
] as const;
export type SubscriptionStatus = (typeof SUBSCRIPTION_STATUS)[number];

export const LEAD_STATUS = [
  'new',
  'contacted',
  'qualified',
  'interested',
  'negotiation',
  'won',
  'lost',
  'follow_up',
] as const;
export type LeadStatus = (typeof LEAD_STATUS)[number];

export const SUPPORT_STATUS = [
  'open',
  'in_progress',
  'waiting_customer',
  'waiting_supplier',
  'resolved',
  'closed',
] as const;
export type SupportStatus = (typeof SUPPORT_STATUS)[number];

export const TASK_STATUS = ['open', 'in_progress', 'done', 'cancelled'] as const;
export type TaskStatus = (typeof TASK_STATUS)[number];

export const PRIORITY = ['low', 'medium', 'high', 'urgent'] as const;
export type Priority = (typeof PRIORITY)[number];

export const ROLES = ['owner', 'admin', 'sales', 'support', 'accounts', 'operations', 'viewer'] as const;
export type Role = (typeof ROLES)[number];

export const APPROVAL_STATUS = ['pending', 'approved', 'rejected', 'cancelled', 'executed', 'expired'] as const;
export type ApprovalStatus = (typeof APPROVAL_STATUS)[number];

export const APPROVAL_RISK = ['low', 'medium', 'high', 'critical'] as const;
export type ApprovalRisk = (typeof APPROVAL_RISK)[number];

export const APPROVAL_TYPES = [
  'refund', 'discount', 'expense', 'supplier_payment', 'bulk_message',
  'secret_access', 'data_export', 'account_change', 'ai_action', 'other',
] as const;
export type ApprovalType = (typeof APPROVAL_TYPES)[number];

export const EXPENSE_CATEGORY = [
  'advertising',
  'software',
  'salary',
  'supplier',
  'office',
  'internet',
  'freelancers',
  'tools',
  'subscriptions',
  'taxes',
  'refunds',
  'miscellaneous',
] as const;
export type ExpenseCategory = (typeof EXPENSE_CATEGORY)[number];

export interface BaseRecord {
  id: UUID;
  organization_id: UUID;
  created_at: ISODate;
  updated_at: ISODate;
  deleted_at?: ISODate | null;
}

export interface Organization {
  id: UUID;
  name: string;
  currency: string;
  timezone: string;
  gstin?: string | null;
  address?: string | null;
  email?: string | null;
  phone?: string | null;
  expiry_threshold_days: number;
  created_at: ISODate;
  updated_at: ISODate;
}

export interface Profile extends BaseRecord {
  /** Nullable — standalone-first. Populated only when Supabase Auth is connected. */
  auth_user_id: string | null;
  full_name: string;
  email: string;
  phone?: string | null;
  role: Role;
  is_active: boolean;
  avatar_color?: string;
}

export interface Customer extends BaseRecord {
  customer_code: string;
  name: string;
  email?: string | null;
  phone?: string | null;
  whatsapp?: string | null;
  company?: string | null;
  city?: string | null;
  state?: string | null;
  status: CustomerStatus;
  source?: string | null;
  owner_id?: UUID | null;
  notes?: string | null;
  tags: string[];
}

export interface CustomerNote extends BaseRecord {
  customer_id: UUID;
  author_id: UUID | null;
  body: string;
}

export interface ProductCategory extends BaseRecord {
  name: string;
  slug: string;
  description?: string | null;
}

export type DeliveryType = 'email_activation' | 'account_activation' | 'license_key' | 'invite_link' | 'manual';
export type ProductType = 'subscription' | 'license' | 'digital_product' | 'service';

export interface Product extends BaseRecord {
  name: string;
  code: string;
  category_id: UUID | null;
  brand?: string | null;
  description?: string | null;
  product_type: ProductType;
  delivery_type: DeliveryType;
  duration_days: number; // 0 = one-time
  cost_price: number;
  selling_price: number;
  supplier_id: UUID | null;
  stock: number | null; // null = unlimited
  /** Units committed to unfulfilled orders. available = stock - reserved_stock. */
  reserved_stock?: number | null;
  low_stock_threshold: number;
  is_active: boolean;
  notes?: string | null;
}

export interface Supplier extends BaseRecord {
  name: string;
  contact_person?: string | null;
  email?: string | null;
  phone?: string | null;
  website?: string | null;
  payment_terms?: string | null;
  notes?: string | null;
  is_active: boolean;
}

export interface SupplierPayment extends BaseRecord {
  supplier_id: UUID;
  amount: number;
  method: PaymentMethod;
  paid_at: ISODate;
  reference?: string | null;
  notes?: string | null;
}

/** Immutable financial snapshot per line item. */
export interface OrderItem {
  id: UUID;
  order_id: UUID;
  product_id: UUID | null;
  product_name: string;
  product_code: string;
  supplier_id: UUID | null;
  supplier_name: string | null;
  delivery_type: DeliveryType;
  product_type: ProductType;
  duration_days: number;
  quantity: number;
  unit_cost: number; // snapshot
  unit_price: number; // snapshot (may be custom)
  discount: number;
  line_total: number;
  line_cost: number;
  line_profit: number;
}

export interface Order extends BaseRecord {
  order_number: string;
  customer_id: UUID;
  status: OrderStatus;
  payment_status: PaymentStatus;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  total_cost: number;
  profit: number;
  margin: number;
  amount_paid: number;
  amount_refunded: number;
  outstanding: number;
  notes?: string | null;
  source?: string | null;
  renewal_of_subscription_id?: UUID | null;
  assigned_to?: UUID | null;
  ordered_at: ISODate;
  items: OrderItem[];
}

export interface Payment extends BaseRecord {
  order_id: UUID;
  customer_id: UUID;
  amount: number; // negative for refunds
  method: PaymentMethod;
  status: PaymentStatus;
  reference?: string | null;
  is_refund: boolean;
  paid_at: ISODate;
  notes?: string | null;
}

export interface Activation extends BaseRecord {
  order_id: UUID;
  order_item_id: UUID;
  customer_id: UUID;
  product_name: string;
  status: ActivationStatus;
  priority: Priority;
  assigned_to?: UUID | null;
  supplier_id?: UUID | null;
  activation_email?: string | null;
  activation_details?: string | null;
  internal_instructions?: string | null;
  proof_url?: string | null;
  activated_at?: ISODate | null;
  delivered_at?: ISODate | null;
  expiry_date?: ISODate | null;
}

export interface Subscription extends BaseRecord {
  /** Unique linkage to the fulfilment event that created this subscription.
   *  Enforced unique in SQL so a replayed completion cannot duplicate it. */
  source_activation_id?: UUID | null;
  order_item_id?: UUID | null;
  customer_id: UUID;
  product_id: UUID | null;
  order_id: UUID;
  product_name: string;
  start_date: ISODate;
  expiry_date: ISODate;
  duration_days: number;
  purchase_amount: number;
  cost_amount: number;
  profit: number;
  supplier_id: UUID | null;
  status: SubscriptionStatus;
  reminder_state: 'none' | 'contacted' | 'interested' | 'follow_up' | 'not_interested' | 'lost';
  last_contacted_at?: ISODate | null;
  assigned_to?: UUID | null;
  previous_subscription_id?: UUID | null;
  renewed_to_subscription_id?: UUID | null;
  notes?: string | null;
}

export interface Lead extends BaseRecord {
  name: string;
  phone?: string | null;
  email?: string | null;
  company?: string | null;
  source?: string | null;
  interested_product_id?: UUID | null;
  value: number;
  probability: number;
  status: LeadStatus;
  assigned_to?: UUID | null;
  follow_up_at?: ISODate | null;
  notes?: string | null;
  converted_customer_id?: UUID | null;
}

export interface SupportTicket extends BaseRecord {
  ticket_number: string;
  customer_id: UUID;
  order_id?: UUID | null;
  product_id?: UUID | null;
  category: string;
  subject: string;
  description: string;
  priority: Priority;
  status: SupportStatus;
  assigned_to?: UUID | null;
  first_response_at?: ISODate | null;
  resolved_at?: ISODate | null;
  due_at?: ISODate | null;
}

export interface TicketMessage extends BaseRecord {
  ticket_id: UUID;
  author_id: UUID | null;
  author_type: 'agent' | 'customer';
  body: string;
}

export type TaskEntity = 'customer' | 'lead' | 'order' | 'subscription' | 'supplier' | 'ticket' | 'general';

export interface Task extends BaseRecord {
  title: string;
  description?: string | null;
  entity_type: TaskEntity;
  entity_id?: UUID | null;
  priority: Priority;
  status: TaskStatus;
  assigned_to?: UUID | null;
  due_at?: ISODate | null;
  reminder_at?: ISODate | null;
  completed_at?: ISODate | null;
}

export interface Expense extends BaseRecord {
  category: ExpenseCategory;
  description: string;
  amount: number;
  vendor?: string | null;
  spent_at: ISODate;
  method: PaymentMethod;
  is_recurring: boolean;
  attachment_url?: string | null;
  created_by?: UUID | null;
}

export interface InvoiceItem {
  id: UUID;
  description: string;
  quantity: number;
  unit_price: number;
  total: number;
}

export interface Invoice extends BaseRecord {
  invoice_number: string;
  customer_id: UUID;
  order_id: UUID | null;
  issue_date: ISODate;
  due_date: ISODate;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  amount_paid: number;
  status: 'draft' | 'sent' | 'paid' | 'partial' | 'overdue' | 'void';
  items: InvoiceItem[];
  notes?: string | null;
}

export interface Notification extends BaseRecord {
  type: string;
  title: string;
  body: string;
  severity: 'info' | 'warning' | 'critical' | 'success';
  entity_type?: string | null;
  entity_id?: UUID | null;
  read_at?: ISODate | null;
}

export interface MessageTemplate extends BaseRecord {
  name: string;
  channel: 'whatsapp' | 'email' | 'sms';
  subject?: string | null;
  body: string;
  variables: string[];
  is_active: boolean;
}

export interface CommunicationLog extends BaseRecord {
  channel: 'whatsapp' | 'email' | 'sms' | 'call';
  direction: 'outbound' | 'inbound';
  customer_id?: UUID | null;
  template_id?: UUID | null;
  to_address: string;
  body: string;
  status: 'queued' | 'sent' | 'failed' | 'delivered';
  provider: string;
  error?: string | null;
}

export interface AutomationRule extends BaseRecord {
  name: string;
  description?: string | null;
  trigger_event: string;
  conditions: Record<string, unknown>;
  action_type: 'notification' | 'whatsapp' | 'email' | 'task' | 'webhook';
  action_config: Record<string, unknown>;
  is_active: boolean;
  last_run_at?: ISODate | null;
  run_count: number;
}

export interface AutomationLog extends BaseRecord {
  rule_id: UUID;
  event: string;
  status: 'success' | 'failed' | 'skipped';
  message: string;
}

export interface ApprovalRequest extends BaseRecord {
  request_type: ApprovalType;
  title: string;
  description: string;
  reason: string;
  risk_level: ApprovalRisk;
  status: ApprovalStatus;
  entity_type?: string | null;
  entity_id?: UUID | null;
  financial_impact: number;
  payload: Record<string, unknown>;
  requested_by: UUID;
  reviewed_by?: UUID | null;
  reviewed_at?: ISODate | null;
  review_note?: string | null;
  expires_at?: ISODate | null;
  executed_at?: ISODate | null;
}

export interface ActionJob extends BaseRecord {
  approval_id?: UUID | null;
  job_type: string;
  payload: Record<string, unknown>;
  status: 'queued' | 'processing' | 'succeeded' | 'failed' | 'dead_letter' | 'cancelled';
  idempotency_key: string;
  attempts: number;
  max_attempts: number;
  available_at: ISODate;
  locked_at?: ISODate | null;
  locked_by?: string | null;
  last_error?: string | null;
  result?: Record<string, unknown> | null;
  completed_at?: ISODate | null;
}

export interface ActivityLog extends BaseRecord {
  actor_id: UUID | null;
  actor_name: string;
  action: string;
  record_type: string;
  record_id: UUID;
  summary: string;
  old_values?: Record<string, unknown> | null;
  new_values?: Record<string, unknown> | null;
}

export interface Attachment extends BaseRecord {
  entity_type: string;
  entity_id: UUID;
  file_name: string;
  file_url: string;
  mime_type: string;
  size_bytes: number;
}

export interface Database {
  organizations: Organization[];
  profiles: Profile[];
  customers: Customer[];
  customer_notes: CustomerNote[];
  product_categories: ProductCategory[];
  products: Product[];
  suppliers: Supplier[];
  supplier_payments: SupplierPayment[];
  orders: Order[];
  payments: Payment[];
  activations: Activation[];
  subscriptions: Subscription[];
  leads: Lead[];
  support_tickets: SupportTicket[];
  ticket_messages: TicketMessage[];
  tasks: Task[];
  expenses: Expense[];
  invoices: Invoice[];
  notifications: Notification[];
  message_templates: MessageTemplate[];
  communication_logs: CommunicationLog[];
  automation_rules: AutomationRule[];
  automation_logs: AutomationLog[];
  approval_requests: ApprovalRequest[];
  activity_logs: ActivityLog[];
  attachments: Attachment[];
}
