/**
 * Runtime mode + capability gating.
 *
 * The application has two mutually exclusive modes:
 *
 *   demo       — LocalProvider, browser persistence, in-app user switching.
 *                Suitable for evaluation ONLY. No real customer data.
 *   production — Supabase provider with real auth/session and server-enforced
 *                RBAC + RLS.
 *
 * Production mode stays *explicitly disabled* until the Supabase repository
 * layer is implemented and credentials exist. That is deliberate: silently
 * falling back to a browser-persisted store when someone sets
 * NEXT_PUBLIC_DATA_PROVIDER=supabase would be the most dangerous possible
 * failure mode (real customer data in localStorage, no auth, no RLS).
 */
export type RuntimeMode = 'demo' | 'production';

export interface ModeStatus {
  mode: RuntimeMode;
  requested: string;
  supabaseConfigured: boolean;
  /** True when production was requested but cannot be served safely. */
  degraded: boolean;
  reason: string | null;
}

export function supabaseConfigured(): boolean {
  return Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  );
}

/**
 * True once SupabaseProvider implements real per-entity repository mutations
 * (not whole-database save) AND auth/session handling is wired.
 *
 * Both are now in place:
 *   - src/lib/data/supabase-provider.ts  — per-entity select/insert/update/
 *     archive/remove; save() diffs snapshots into individual row mutations and
 *     applies them atomically. The whole-database write path throws.
 *   - src/lib/auth/server-session.ts + src/middleware.ts — verified sessions,
 *     profile/org/role resolved server-side from the database.
 *
 * Production mode still requires credentials; without them resolveMode()
 * degrades to demo rather than pretending.
 */
export const SUPABASE_REPOSITORY_IMPLEMENTED = true;

export function resolveMode(): ModeStatus {
  const requested = process.env.NEXT_PUBLIC_DATA_PROVIDER ?? 'local';
  const configured = supabaseConfigured();

  if (requested === 'supabase') {
    if (!configured) {
      return {
        mode: 'demo', requested, supabaseConfigured: false, degraded: true,
        reason:
          'NEXT_PUBLIC_DATA_PROVIDER=supabase but NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY are missing.',
      };
    }
    if (!SUPABASE_REPOSITORY_IMPLEMENTED) {
      return {
        mode: 'demo', requested, supabaseConfigured: true, degraded: true,
        reason:
          'Supabase repository layer is not implemented yet. Refusing to run production mode on browser-persisted storage.',
      };
    }
    return { mode: 'production', requested, supabaseConfigured: true, degraded: false, reason: null };
  }

  return { mode: 'demo', requested, supabaseConfigured: configured, degraded: false, reason: null };
}

export const isDemoMode = () => resolveMode().mode === 'demo';
export const isProductionMode = () => resolveMode().mode === 'production';

/** In-app user switching is a demo affordance and must never ship enabled. */
export const allowUserSwitching = () => isDemoMode();

/**
 * Whether it is safe to write the database (including activation secrets) to
 * browser storage.
 *
 * This is deliberately STRICTER than `isDemoMode()`. When production is
 * requested but degraded — bad credentials, repository not implemented — the
 * effective mode falls back to demo so the app still renders. That fallback
 * must NOT re-enable secret persistence: the operator pointed this build at a
 * real project, so the data in front of them may be real customer data.
 *
 * Persistence is therefore allowed only when demo mode was genuinely intended.
 */
export function allowBrowserPersistence(): boolean {
  const m = resolveMode();
  return m.mode === 'demo' && !m.degraded && m.requested !== 'supabase';
}

/**
 * Fields that carry customer-delivered secrets. They must never be written to
 * browser storage outside demo mode.
 */
export const SENSITIVE_ACTIVATION_FIELDS = [
  'activation_email',
  'activation_details',
  'internal_instructions',
] as const;
