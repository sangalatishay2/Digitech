import { createClient, type SupabaseClient } from '@supabase/supabase-js';

/**
 * Supabase client construction.
 *
 * Two distinct clients, and the difference matters:
 *
 *   browser / anon — carries the signed-in user's JWT. Every query is evaluated
 *                    by RLS as that user. This is what the UI uses.
 *   service role   — bypasses RLS entirely. Server-only, used for the few
 *                    operations that legitimately need it (reading activation
 *                    secrets after an explicit permission check). Importing it
 *                    into client code would hand every visitor a master key, so
 *                    it throws if the module is evaluated in a browser.
 */

/** Structural type so tests can inject a fake without pulling in the network. */
export interface SupabaseLike {
  from(table: string): {
    select(cols?: string): QueryBuilder;
    insert(row: unknown): QueryBuilder;
    update(patch: unknown): QueryBuilder;
    delete(): QueryBuilder;
  };
  rpc(fn: string, args?: Record<string, unknown>): Promise<{ data: unknown; error: { message: string } | null }>;
  auth: {
    getUser(): Promise<{ data: { user: { id: string; email?: string | null } | null }; error: unknown }>;
    getSession(): Promise<{ data: { session: { access_token: string } | null }; error: unknown }>;
    signInWithPassword(c: { email: string; password: string }): Promise<{ data: unknown; error: { message: string } | null }>;
    signOut(): Promise<{ error: { message: string } | null }>;
    /** Present on the real client; typed loosely because only the store uses it. */
    onAuthStateChange?(
      cb: (event: string, session: unknown) => void,
    ): { data?: { subscription?: { unsubscribe?: () => void } } };
  };
}

export interface QueryBuilder extends PromiseLike<{ data: unknown[] | null; error: { message: string } | null }> {
  eq(col: string, v: unknown): QueryBuilder;
  neq(col: string, v: unknown): QueryBuilder;
  gt(col: string, v: unknown): QueryBuilder;
  gte(col: string, v: unknown): QueryBuilder;
  lt(col: string, v: unknown): QueryBuilder;
  lte(col: string, v: unknown): QueryBuilder;
  in(col: string, v: unknown[]): QueryBuilder;
  is(col: string, v: unknown): QueryBuilder;
  select(cols?: string): QueryBuilder;
  single(): PromiseLike<{ data: unknown; error: { message: string } | null }>;
}

export function supabaseUrl(): string {
  return process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
}

export function supabaseAnonKey(): string {
  return process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '';
}

export function supabaseConfigured(): boolean {
  return Boolean(supabaseUrl() && supabaseAnonKey());
}

let browserClient: SupabaseClient | null = null;

/**
 * Shared browser client. Persists the session so a reload stays signed in, and
 * refreshes the JWT before it expires.
 */
export function getSupabaseClient(): SupabaseLike | null {
  if (!supabaseConfigured()) return null;
  if (browserClient) return browserClient as unknown as SupabaseLike;
  browserClient = createClient(supabaseUrl(), supabaseAnonKey(), {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      // Cookie storage would be required for SSR reads; the middleware only
      // needs to see that *a* session cookie exists.
      storageKey: 'digitech-os:auth',
    },
  });
  return browserClient as unknown as SupabaseLike;
}

/** Reset memoised state (tests). */
export function __resetSupabaseClient() {
  browserClient = null;
}

/**
 * Service-role client. Bypasses RLS — server only.
 *
 * The key is read from SUPABASE_SERVICE_ROLE_KEY, which is deliberately NOT
 * prefixed NEXT_PUBLIC_, so Next.js will not inline it into the browser bundle.
 */
export function getServiceClient(): SupabaseClient {
  if (typeof window !== 'undefined') {
    throw new Error(
      'getServiceClient() must never run in the browser: the service role key bypasses RLS.',
    );
  }
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl() || !key) {
    throw new Error('SUPABASE_SERVICE_ROLE_KEY and NEXT_PUBLIC_SUPABASE_URL are required server-side.');
  }
  return createClient(supabaseUrl(), key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

/**
 * Build a request-scoped client that acts as the caller.
 *
 * Used by API routes: the user's access token is forwarded so Postgres applies
 * that user's RLS policies rather than the route's own privileges.
 */
export function getRequestClient(accessToken: string): SupabaseClient {
  return createClient(supabaseUrl(), supabaseAnonKey(), {
    global: { headers: { Authorization: `Bearer ${accessToken}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
