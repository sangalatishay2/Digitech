import type { Database } from '@/lib/types';
import { emptyDb } from './seed';
import {
  type Repository,
  type RepositoryContext,
  type MutableTable,
  type QueryFilter,
  type TransactionOp,
  type WriteResult,
  MUTABLE_TABLES,
} from './repository';

/**
 * Supabase repository — per-entity mutations over PostgREST.
 *
 * Deliberately dependency-free: it speaks the PostgREST HTTP API directly, so
 * the project does not have to carry @supabase/supabase-js just to be
 * type-complete. Swapping in the official client later is a drop-in change.
 *
 * Authorization: every request is sent with the caller's access token, so
 * Postgres evaluates the RLS policies from migration 0016 against the real
 * user. The anon key alone grants nothing — `current_org_id()` returns NULL
 * without a session and every policy denies.
 *
 * NOTE: this is written against the documented PostgREST contract but has NOT
 * been executed against a live Supabase project in this environment (no
 * credentials). See BUILD_STATUS.md — it stays gated behind
 * SUPABASE_REPOSITORY_IMPLEMENTED until it has been run against a real project.
 */

export interface SupabaseAuth {
  /** Current user's access token (JWT). Null when signed out. */
  getAccessToken(): Promise<string | null>;
}

const PREFER_RETURN = 'return=representation';

export class SupabaseRepository implements Repository {
  readonly name = 'supabase';

  constructor(
    private readonly url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '',
    private readonly anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '',
    private readonly auth: SupabaseAuth = { getAccessToken: async () => null },
  ) {}

  isReady() {
    return Boolean(this.url && this.anonKey);
  }

  private base() {
    return `${this.url.replace(/\/$/, '')}/rest/v1`;
  }

  private async headers(extra: Record<string, string> = {}) {
    const token = await this.auth.getAccessToken();
    return {
      apikey: this.anonKey,
      // Fall back to the anon key so RLS still evaluates (and denies) rather
      // than the request failing at the gateway with a confusing 401.
      Authorization: `Bearer ${token ?? this.anonKey}`,
      'Content-Type': 'application/json',
      ...extra,
    };
  }

  private static encode(filters: QueryFilter[]): string {
    const parts = filters.map((f) => {
      const v =
        f.op === 'in'
          ? `(${(f.value as unknown[]).map((x) => String(x)).join(',')})`
          : String(f.value);
      return `${encodeURIComponent(f.column)}=${f.op}.${encodeURIComponent(v)}`;
    });
    return parts.join('&');
  }

  private assertTable(table: string): asserts table is MutableTable {
    if (!(MUTABLE_TABLES as readonly string[]).includes(table)) {
      throw new Error(`Refusing to query unknown table "${table}"`);
    }
  }

  async select<T = Record<string, unknown>>(
    table: MutableTable,
    filters: QueryFilter[],
    _ctx: RepositoryContext,
  ): Promise<T[]> {
    this.assertTable(table);
    const qs = SupabaseRepository.encode(filters);
    const res = await fetch(`${this.base()}/${table}?select=*${qs ? `&${qs}` : ''}`, {
      headers: await this.headers(),
    });
    if (!res.ok) throw new Error(`select ${table} failed: ${res.status} ${await res.text()}`);
    return (await res.json()) as T[];
  }

  async loadAll(ctx: RepositoryContext): Promise<Database> {
    const db = emptyDb() as unknown as Record<string, unknown>;
    // RLS scopes each table to the caller's organization, so no explicit
    // organization_id filter is needed (and adding one would not be a security
    // control anyway — the policy is).
    await Promise.all(
      MUTABLE_TABLES.map(async (t) => {
        if (!Array.isArray(db[t])) return;
        try {
          db[t] = await this.select(t, [], ctx);
        } catch {
          // A table the caller cannot read at all yields an empty list rather
          // than failing the whole hydration.
          db[t] = [];
        }
      }),
    );
    return db as unknown as Database;
  }

  async insert<T = Record<string, unknown>>(
    table: MutableTable,
    row: Record<string, unknown>,
    _ctx: RepositoryContext,
  ): Promise<WriteResult<T>> {
    this.assertTable(table);
    const res = await fetch(`${this.base()}/${table}`, {
      method: 'POST',
      headers: await this.headers({ Prefer: PREFER_RETURN }),
      body: JSON.stringify(row),
    });
    if (!res.ok) return { ok: false, error: `insert ${table}: ${res.status} ${await res.text()}` };
    const rows = (await res.json()) as T[];
    return { ok: true, row: rows[0] };
  }

  async update<T = Record<string, unknown>>(
    table: MutableTable,
    id: string,
    patch: Record<string, unknown>,
    _ctx: RepositoryContext,
    opts?: { expectedUpdatedAt?: string },
  ): Promise<WriteResult<T>> {
    this.assertTable(table);
    // Optimistic concurrency: only write if the row has not changed since read.
    const guard = opts?.expectedUpdatedAt
      ? `&updated_at=eq.${encodeURIComponent(opts.expectedUpdatedAt)}`
      : '';
    const res = await fetch(`${this.base()}/${table}?id=eq.${encodeURIComponent(id)}${guard}`, {
      method: 'PATCH',
      headers: await this.headers({ Prefer: PREFER_RETURN }),
      body: JSON.stringify(patch),
    });
    if (!res.ok) return { ok: false, error: `update ${table}: ${res.status} ${await res.text()}` };
    const rows = (await res.json()) as T[];
    if (rows.length === 0) {
      return {
        ok: false,
        conflict: Boolean(opts?.expectedUpdatedAt),
        error: opts?.expectedUpdatedAt
          ? 'Row changed since it was read (concurrent edit). Re-read and retry.'
          : 'Row not found or not permitted.',
      };
    }
    return { ok: true, row: rows[0] };
  }

  async remove(
    table: MutableTable,
    id: string,
    ctx: RepositoryContext,
    opts?: { soft?: boolean },
  ): Promise<WriteResult<{ id: string }>> {
    this.assertTable(table);
    if (opts?.soft !== false) {
      const r = await this.update(table, id, { deleted_at: new Date().toISOString() }, ctx);
      return r.ok ? { ok: true, row: { id } } : r;
    }
    const res = await fetch(`${this.base()}/${table}?id=eq.${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: await this.headers(),
    });
    if (!res.ok) return { ok: false, error: `delete ${table}: ${res.status} ${await res.text()}` };
    return { ok: true, row: { id } };
  }

  /**
   * Atomic multi-row write.
   *
   * PostgREST cannot express a multi-statement transaction, so this delegates to
   * a Postgres function (`public.apply_transaction`) that receives the ops as
   * JSONB and applies them inside a single transaction with an idempotency key.
   * Migration 0017 defines it.
   */
  async transaction(
    ops: TransactionOp[],
    _ctx: RepositoryContext,
    idempotencyKey?: string,
  ): Promise<WriteResult<{ applied: number }>> {
    for (const op of ops) this.assertTable(op.table);
    const res = await fetch(`${this.base()}/rpc/apply_transaction`, {
      method: 'POST',
      headers: await this.headers(),
      body: JSON.stringify({ p_ops: ops, p_idempotency_key: idempotencyKey ?? null }),
    });
    if (!res.ok) return { ok: false, error: `transaction: ${res.status} ${await res.text()}` };
    const applied = (await res.json()) as number;
    return { ok: true, row: { applied: Number(applied) } };
  }
}
