import type {
  Database,
  Order,
  OrderItem,
  Product,
  Customer,
  Subscription,
  UUID,
} from '@/lib/types';
import { addDays, round2 } from '@/lib/utils';

/* Deterministic pseudo-random so demo data is stable across restarts. */
let seedState = 42;
function rnd() {
  seedState = (seedState * 1664525 + 1013904223) % 4294967296;
  return seedState / 4294967296;
}
function pick<T>(arr: T[]): T {
  return arr[Math.floor(rnd() * arr.length)];
}
function int(min: number, max: number) {
  return Math.floor(rnd() * (max - min + 1)) + min;
}

let idc = 0;
export function uid(prefix = 'r'): UUID {
  idc += 1;
  const hex = (n: number, len: number) => n.toString(16).padStart(len, '0');
  return `${hex(idc, 8)}-${hex(prefix.charCodeAt(0), 4)}-4${hex(idc % 4096, 3)}-8${hex(
    idc % 4096,
    3,
  )}-${hex(idc * 7919, 12)}`;
}

const now = () => new Date().toISOString();
const iso = (d: Date) => d.toISOString();

const ORG_ID = '00000000-0000-4000-8000-000000000001';

const FIRST = ['Rahul', 'Priya', 'Amit', 'Sneha', 'Vikram', 'Anjali', 'Rohit', 'Neha', 'Arjun', 'Kavya', 'Karan', 'Divya', 'Sanjay', 'Pooja', 'Manish', 'Ritu', 'Aditya', 'Shreya', 'Nikhil', 'Meera', 'Gaurav', 'Isha', 'Deepak', 'Tanvi', 'Harsh', 'Simran', 'Varun', 'Ananya', 'Suresh', 'Payal'];
const LAST = ['Sharma', 'Verma', 'Gupta', 'Singh', 'Patel', 'Mehta', 'Agarwal', 'Reddy', 'Nair', 'Joshi', 'Kapoor', 'Malhotra', 'Chopra', 'Bansal', 'Jain'];
const CITIES: [string, string][] = [
  ['Meerut', 'Uttar Pradesh'], ['Delhi', 'Delhi'], ['Mumbai', 'Maharashtra'], ['Bengaluru', 'Karnataka'],
  ['Pune', 'Maharashtra'], ['Hyderabad', 'Telangana'], ['Jaipur', 'Rajasthan'], ['Lucknow', 'Uttar Pradesh'],
  ['Ahmedabad', 'Gujarat'], ['Chennai', 'Tamil Nadu'], ['Noida', 'Uttar Pradesh'], ['Indore', 'Madhya Pradesh'],
];
const COMPANIES = ['Skyline Media', 'Nexa Digital', 'BrightEdge Solutions', 'Zenith Marketing', 'Orbit Labs', 'Craftly Studio', 'Vertex Consulting', 'PixelForge', 'Growthly', 'Kalpana Enterprises'];
const SOURCES = ['Instagram', 'WhatsApp', 'Referral', 'Google', 'Website', 'Facebook', 'Walk-in', 'YouTube'];

export function buildSeed(): Database {
  seedState = 42;
  idc = 0;

  const org = {
    id: ORG_ID,
    name: 'DigiTech',
    currency: 'INR',
    timezone: 'Asia/Kolkata',
    gstin: '09ABCDE1234F1Z5',
    address: 'Shop 12, Abu Lane, Meerut, Uttar Pradesh 250001',
    email: 'hello@digitech.in',
    phone: '+91 98765 43210',
    expiry_threshold_days: 15,
    created_at: now(),
    updated_at: now(),
  };

  const base = { organization_id: ORG_ID, created_at: now(), updated_at: now(), deleted_at: null };

  const profileSpecs: [string, string, Parameters<never> extends never ? string : string][] = [
    ['Atishay Sangal', 'atishay@digitech.in', 'owner'],
    ['Ravi Kumar', 'ravi@digitech.in', 'admin'],
    ['Sonia Bhatia', 'sonia@digitech.in', 'sales'],
    ['Imran Khan', 'imran@digitech.in', 'operations'],
    ['Nidhi Rao', 'nidhi@digitech.in', 'support'],
    ['Vivek Jain', 'vivek@digitech.in', 'accounts'],
  ];
  const profiles = profileSpecs.map(([full_name, email, role]) => ({
    ...base,
    id: uid('p'),
    auth_user_id: null,
    full_name,
    email,
    phone: `+9198${int(10000000, 99999999)}`,
    role: role as Profile_Role,
    is_active: true,
  })) as Database['profiles'];

  const categories = ['Design Tools', 'Professional Networking', 'Automation', 'AI Tools', 'Productivity', 'Streaming'].map(
    (name) => ({
      ...base,
      id: uid('c'),
      name,
      slug: name.toLowerCase().replace(/ /g, '-'),
      description: `${name} subscriptions and licenses`,
    }),
  );

  const suppliers = [
    ['Global Digital Supply', 'Ankit Raheja', 'ankit@gdsupply.in'],
    ['CloudKart Wholesale', 'Meena Iyer', 'meena@cloudkart.in'],
    ['SubHub Partners', 'Faisal Ahmed', 'faisal@subhub.io'],
    ['AI Reseller Network', 'Tarun Sethi', 'tarun@airesell.net'],
  ].map(([name, contact_person, email]) => ({
    ...base,
    id: uid('s'),
    name,
    contact_person,
    email,
    phone: `+9199${int(10000000, 99999999)}`,
    website: `https://${name.toLowerCase().split(' ')[0]}.com`,
    payment_terms: pick(['Net 15', 'Net 30', 'Prepaid']),
    notes: null,
    is_active: true,
  }));

  const catId = (n: string) => categories.find((c) => c.name === n)!.id;
  const productSpecs: [string, string, string, number, number, number, Product['product_type'], Product['delivery_type']][] = [
    ['Canva Pro — 12 Months', 'CANVA-12M', 'Design Tools', 365, 450, 1299, 'subscription', 'email_activation'],
    ['Canva Pro — 1 Month', 'CANVA-1M', 'Design Tools', 30, 60, 199, 'subscription', 'email_activation'],
    ['LinkedIn Premium Career — 12 Months', 'LIPC-12M', 'Professional Networking', 365, 1800, 3499, 'subscription', 'account_activation'],
    ['LinkedIn Premium Business — 12 Months', 'LIPB-12M', 'Professional Networking', 365, 2400, 4499, 'subscription', 'account_activation'],
    ['n8n Starter — 12 Months', 'N8N-12M', 'Automation', 365, 3200, 5999, 'subscription', 'invite_link'],
    ['AI Tool Subscription — 1 Month', 'AITOOL-1M', 'AI Tools', 30, 320, 699, 'subscription', 'email_activation'],
    ['ChatGPT Plus — 1 Month', 'GPTP-1M', 'AI Tools', 30, 1450, 1999, 'subscription', 'account_activation'],
    ['Microsoft 365 Personal — 12 Months', 'M365-12M', 'Productivity', 365, 1900, 3299, 'subscription', 'license_key'],
    ['Adobe Creative Cloud — 12 Months', 'ADBCC-12M', 'Design Tools', 365, 21000, 27999, 'subscription', 'account_activation'],
    ['Netflix Premium — 1 Month', 'NFLX-1M', 'Streaming', 30, 190, 349, 'subscription', 'account_activation'],
    ['Spotify Premium — 12 Months', 'SPOT-12M', 'Streaming', 365, 700, 1199, 'subscription', 'account_activation'],
    ['Windows 11 Pro License', 'WIN11-PRO', 'Productivity', 0, 550, 1499, 'license', 'license_key'],
    ['Website Setup Service', 'WEBSVC', 'Productivity', 0, 2000, 7999, 'service', 'manual'],
    ['Grammarly Premium — 12 Months', 'GRAM-12M', 'Productivity', 365, 2100, 3699, 'subscription', 'email_activation'],
  ];
  const products: Product[] = productSpecs.map(([name, code, cat, duration_days, cost_price, selling_price, product_type, delivery_type]) => ({
    ...base,
    id: uid('P'),
    name,
    code,
    category_id: catId(cat),
    brand: name.split(' ')[0],
    description: `${name} — instant digital delivery by DigiTech.`,
    product_type,
    delivery_type,
    duration_days,
    cost_price,
    selling_price,
    supplier_id: pick(suppliers).id,
    stock: rnd() > 0.6 ? int(3, 60) : null,
    low_stock_threshold: 5,
    is_active: true,
    notes: null,
  }));

  // Customers
  const customers: Customer[] = [];
  for (let i = 0; i < 48; i++) {
    const name = `${pick(FIRST)} ${pick(LAST)}`;
    const [city, state] = pick(CITIES);
    const phone = `+9198${int(10000000, 99999999)}`;
    const createdDaysAgo = int(1, 420);
    customers.push({
      ...base,
      id: uid('C'),
      customer_code: `DT-${String(1001 + i)}`,
      name,
      email: `${name.toLowerCase().replace(/ /g, '.')}${int(1, 99)}@gmail.com`,
      phone,
      whatsapp: phone,
      company: rnd() > 0.6 ? pick(COMPANIES) : null,
      city,
      state,
      status: 'active',
      source: pick(SOURCES),
      owner_id: pick(profiles).id,
      notes: null,
      tags: rnd() > 0.7 ? [pick(['repeat', 'agency', 'bulk', 'priority'])] : [],
      created_at: iso(addDays(new Date(), -createdDaysAgo)),
    });
  }
  // Intentional duplicate-warning demo pair
  customers[3].phone = customers[7].phone;
  customers[3].whatsapp = customers[7].phone;

  const orders: Order[] = [];
  const payments: Database['payments'] = [];
  const activations: Database['activations'] = [];
  const subscriptions: Subscription[] = [];
  const invoices: Database['invoices'] = [];
  const activity: Database['activity_logs'] = [];

  let orderSeq = 1000;
  let invSeq = 500;

  const mkOrder = (customer: Customer, daysAgo: number, forceProduct?: Product, prevSub?: Subscription) => {
    const orderId = uid('O');
    const orderedAt = addDays(new Date(), -daysAgo);
    const nItems = forceProduct ? 1 : rnd() > 0.8 ? 2 : 1;
    const items: OrderItem[] = [];
    for (let k = 0; k < nItems; k++) {
      const p = forceProduct ?? pick(products);
      const qty = 1;
      const unit_price = p.selling_price;
      // Cap the discount so it can never exceed ~40% of the line value — an
      // unbounded flat discount could push cheap products to a negative total.
      const maxDiscount = Math.floor((unit_price * qty * 0.4) / 50) * 50;
      const discount = rnd() > 0.75 ? Math.min(int(1, 5) * 50, maxDiscount) : 0;
      const line_total = round2(unit_price * qty - discount);
      const line_cost = round2(p.cost_price * qty);
      const supplier = suppliers.find((s) => s.id === p.supplier_id) ?? null;
      items.push({
        id: uid('I'),
        order_id: orderId,
        product_id: p.id,
        product_name: p.name,
        product_code: p.code,
        supplier_id: p.supplier_id,
        supplier_name: supplier?.name ?? null,
        delivery_type: p.delivery_type,
        product_type: p.product_type,
        duration_days: p.duration_days,
        quantity: qty,
        unit_cost: p.cost_price,
        unit_price,
        discount,
        line_total,
        line_cost,
        line_profit: round2(line_total - line_cost),
      });
    }
    const subtotal = round2(items.reduce((a, i) => a + i.unit_price * i.quantity, 0));
    const discount = round2(items.reduce((a, i) => a + i.discount, 0));
    const total = round2(subtotal - discount);
    const total_cost = round2(items.reduce((a, i) => a + i.line_cost, 0));
    const profit = round2(total - total_cost);

    const roll = rnd();
    let paidPortion = 1;
    let status: Order['status'] = 'completed';
    if (roll > 0.88) {
      paidPortion = 0;
      status = 'awaiting_payment';
    } else if (roll > 0.8) {
      paidPortion = 0.5;
      status = 'activation_pending';
    } else if (roll > 0.72) {
      paidPortion = 1;
      status = 'activation_pending';
    }

    const amount_paid = round2(total * paidPortion);
    const payment_status: Order['payment_status'] =
      amount_paid === 0 ? 'pending' : amount_paid < total ? 'partial' : 'paid';

    const order: Order = {
      ...base,
      id: orderId,
      order_number: `ORD-${++orderSeq}`,
      customer_id: customer.id,
      status,
      payment_status,
      subtotal,
      discount,
      tax: 0,
      total,
      total_cost,
      profit,
      margin: total ? round2((profit / total) * 100) : 0,
      amount_paid,
      amount_refunded: 0,
      outstanding: round2(total - amount_paid),
      notes: null,
      source: customer.source,
      renewal_of_subscription_id: prevSub?.id ?? null,
      assigned_to: pick(profiles).id,
      ordered_at: iso(orderedAt),
      created_at: iso(orderedAt),
      items,
    };
    orders.push(order);

    if (amount_paid > 0) {
      payments.push({
        ...base,
        id: uid('Y'),
        order_id: orderId,
        customer_id: customer.id,
        amount: amount_paid,
        method: pick(['upi', 'upi', 'bank_transfer', 'cash', 'gateway', 'wallet']) as never,
        status: 'paid',
        reference: `UTR${int(100000000, 999999999)}`,
        is_refund: false,
        paid_at: iso(orderedAt),
        notes: null,
        created_at: iso(orderedAt),
      });
    }

    for (const item of items) {
      const actStatus: Database['activations'][number]['status'] =
        status === 'awaiting_payment' ? 'waiting_payment' : status === 'activation_pending' ? pick(['ready', 'processing', 'waiting_supplier']) as never : 'delivered';
      const activatedAt = actStatus === 'delivered' ? iso(orderedAt) : null;
      const expiry = item.duration_days ? iso(addDays(orderedAt, item.duration_days)) : null;
      activations.push({
        ...base,
        id: uid('A'),
        order_id: orderId,
        order_item_id: item.id,
        customer_id: customer.id,
        product_name: item.product_name,
        status: actStatus,
        priority: pick(['low', 'medium', 'medium', 'high']) as never,
        assigned_to: pick(profiles).id,
        supplier_id: item.supplier_id,
        activation_email: customer.email,
        activation_details: null,
        internal_instructions: null,
        proof_url: null,
        activated_at: activatedAt,
        delivered_at: activatedAt,
        expiry_date: expiry,
        created_at: iso(orderedAt),
      });

      if (actStatus === 'delivered' && item.duration_days > 0) {
        const start = orderedAt;
        const exp = addDays(start, item.duration_days);
        const sub: Subscription = {
          ...base,
          id: uid('S'),
          customer_id: customer.id,
          product_id: item.product_id,
          order_id: orderId,
          product_name: item.product_name,
          start_date: iso(start),
          expiry_date: iso(exp),
          duration_days: item.duration_days,
          purchase_amount: item.line_total,
          cost_amount: item.line_cost,
          profit: item.line_profit,
          supplier_id: item.supplier_id,
          status: 'active',
          reminder_state: 'none',
          assigned_to: pick(profiles).id,
          previous_subscription_id: prevSub?.id ?? null,
          renewed_to_subscription_id: null,
          notes: null,
          created_at: iso(start),
        };
        if (prevSub) {
          prevSub.status = 'renewed';
          prevSub.renewed_to_subscription_id = sub.id;
        }
        subscriptions.push(sub);
      }
    }

    if (payment_status !== 'pending') {
      invoices.push({
        ...base,
        id: uid('N'),
        invoice_number: `INV-${++invSeq}`,
        customer_id: customer.id,
        order_id: orderId,
        issue_date: iso(orderedAt),
        due_date: iso(addDays(orderedAt, 7)),
        subtotal,
        discount,
        tax: 0,
        total,
        amount_paid,
        status: amount_paid >= total ? 'paid' : 'partial',
        items: items.map((i) => ({
          id: uid('J'),
          description: i.product_name,
          quantity: i.quantity,
          unit_price: i.unit_price,
          total: i.line_total,
        })),
        notes: null,
        created_at: iso(orderedAt),
      });
    }

    activity.push({
      ...base,
      id: uid('L'),
      actor_id: order.assigned_to ?? null,
      actor_name: profiles.find((p) => p.id === order.assigned_to)?.full_name ?? 'System',
      action: 'created',
      record_type: 'order',
      record_id: orderId,
      summary: `Order ${order.order_number} created for ${customer.name}`,
      old_values: null,
      new_values: null,
      created_at: iso(orderedAt),
    });
    return order;
  };

  // Order dates are recency-weighted (not uniform) so the business looks alive:
  // roughly a quarter of all orders land in the last 30 days and some land today,
  // which is what the default "30 Days" dashboard range reports on.
  const recentDaysAgo = () => Math.floor(Math.pow(rnd(), 1.7) * 365);

  for (const c of customers) {
    const count = rnd() > 0.45 ? int(2, 5) : 1;
    for (let i = 0; i < count; i++) mkOrder(c, recentDaysAgo());
  }

  // Renewal chains: renew a few old subscriptions
  const oldSubs = subscriptions.filter((s) => new Date(s.expiry_date) < new Date()).slice(0, 12);
  for (const s of oldSubs) {
    const cust = customers.find((c) => c.id === s.customer_id)!;
    const prod = products.find((p) => p.id === s.product_id);
    if (prod) mkOrder(cust, Math.max(1, int(1, 25)), prod, s);
  }

  // Derive subscription statuses
  const threshold = org.expiry_threshold_days;
  for (const s of subscriptions) {
    if (s.status === 'renewed') continue;
    const days = Math.ceil((new Date(s.expiry_date).getTime() - Date.now()) / 86_400_000);
    s.status = days < 0 ? 'expired' : days <= threshold ? 'expiring' : 'active';
  }

  // Customer status derivation
  for (const c of customers) {
    const co = orders.filter((o) => o.customer_id === c.id);
    const revenue = co.reduce((a, o) => a + o.total, 0);
    const last = co.map((o) => new Date(o.ordered_at).getTime()).sort().pop() ?? 0;
    const staleDays = (Date.now() - last) / 86_400_000;
    c.status = revenue > 25000 ? 'vip' : staleDays > 300 ? 'inactive' : 'active';
  }

  const leads: Database['leads'] = [];
  const leadStatuses = ['new', 'contacted', 'qualified', 'interested', 'negotiation', 'won', 'lost', 'follow_up'] as const;
  for (let i = 0; i < 26; i++) {
    const name = `${pick(FIRST)} ${pick(LAST)}`;
    const st = pick([...leadStatuses]);
    leads.push({
      ...base,
      id: uid('D'),
      name,
      phone: `+9197${int(10000000, 99999999)}`,
      email: `${name.toLowerCase().replace(/ /g, '')}@gmail.com`,
      company: rnd() > 0.5 ? pick(COMPANIES) : null,
      source: pick(SOURCES),
      interested_product_id: pick(products).id,
      value: int(5, 60) * 500,
      probability: st === 'won' ? 100 : st === 'lost' ? 0 : int(1, 9) * 10,
      status: st,
      assigned_to: pick(profiles).id,
      follow_up_at: iso(addDays(new Date(), int(-8, 14))),
      notes: null,
      converted_customer_id: null,
      created_at: iso(addDays(new Date(), -int(1, 90))),
    });
  }

  const tickets: Database['support_tickets'] = [];
  const ticketMessages: Database['ticket_messages'] = [];
  const subjects = [
    'Canva Pro invite not received',
    'LinkedIn Premium showing expired',
    'Need invoice with GST details',
    'Account activation pending since 2 days',
    'Renewal price clarification',
    'Refund request for duplicate payment',
    'n8n workspace access issue',
    'Change activation email address',
  ];
  for (let i = 0; i < 18; i++) {
    const c = pick(customers);
    const co = orders.filter((o) => o.customer_id === c.id);
    const createdAt = addDays(new Date(), -int(0, 40));
    const st = pick(['open', 'in_progress', 'waiting_customer', 'resolved', 'closed', 'waiting_supplier']) as never;
    const tid = uid('T');
    tickets.push({
      ...base,
      id: tid,
      ticket_number: `TKT-${2000 + i}`,
      customer_id: c.id,
      order_id: co[0]?.id ?? null,
      product_id: pick(products).id,
      category: pick(['Activation', 'Billing', 'Technical', 'Renewal', 'General']),
      subject: pick(subjects),
      description: 'Customer reported an issue via WhatsApp. Follow up and resolve.',
      priority: pick(['low', 'medium', 'high', 'urgent']) as never,
      status: st,
      assigned_to: pick(profiles).id,
      first_response_at: rnd() > 0.3 ? iso(addDays(createdAt, 0)) : null,
      resolved_at: st === 'resolved' || st === 'closed' ? iso(addDays(createdAt, int(1, 4))) : null,
      due_at: iso(addDays(createdAt, 2)),
      created_at: iso(createdAt),
    });
    ticketMessages.push({
      ...base,
      id: uid('M'),
      ticket_id: tid,
      author_id: null,
      author_type: 'customer',
      body: 'Hi, I need help with my subscription. Please check.',
      created_at: iso(createdAt),
    });
  }

  const tasks: Database['tasks'] = [];
  const taskTitles = ['Call customer for renewal', 'Send WhatsApp reminder', 'Follow up supplier activation', 'Collect pending payment', 'Share invoice', 'Verify activation proof'];
  for (let i = 0; i < 22; i++) {
    const st = pick(['open', 'open', 'in_progress', 'done']) as never;
    tasks.push({
      ...base,
      id: uid('K'),
      title: pick(taskTitles),
      description: null,
      entity_type: pick(['customer', 'order', 'subscription', 'lead', 'general']) as never,
      entity_id: pick(customers).id,
      priority: pick(['low', 'medium', 'high']) as never,
      status: st,
      assigned_to: pick(profiles).id,
      due_at: iso(addDays(new Date(), int(-6, 12))),
      reminder_at: null,
      completed_at: st === 'done' ? now() : null,
      created_at: iso(addDays(new Date(), -int(1, 30))),
    });
  }

  const expenses: Database['expenses'] = [];
  const expenseSpecs: [Database['expenses'][number]['category'], string, number][] = [
    ['advertising', 'Meta Ads campaign', 4500],
    ['advertising', 'Google Ads', 3000],
    ['software', 'Hosting & domain', 900],
    ['salary', 'Team salary', 12000],
    ['office', 'Shop rent', 5000],
    ['internet', 'Broadband bill', 1099],
    ['tools', 'Design tool subscription', 799],
    ['freelancers', 'Content writer', 2500],
    ['taxes', 'GST payment', 2500],
    ['miscellaneous', 'Misc expenses', 900],
  ];
  // Operating expenses scale with each month's actual gross profit so the demo
  // business reads as sustainably profitable in every date range, instead of
  // billing a flat cost base against wildly varying monthly revenue.
  const monthlyGrossProfit = (monthsAgo: number) => {
    const hi = Date.now() - monthsAgo * 30 * 86_400_000;
    const lo = hi - 30 * 86_400_000;
    return orders
      .filter((o) => {
        const t = new Date(o.ordered_at).getTime();
        return t > lo && t <= hi && o.status !== 'cancelled';
      })
      .reduce((a, o) => a + (o.total - o.total_cost), 0);
  };

  const specWeight = expenseSpecs.reduce((a, [, , amt]) => a + amt, 0);

  for (let m = 0; m < 13; m++) {
    // Target ~55% of gross profit as opex, with a small floor so quiet months
    // still show the fixed costs a real business keeps paying.
    const target = Math.max(9000, monthlyGrossProfit(m) * 0.55);
    for (const [category, description, amount] of expenseSpecs) {
      const recurring = category === 'office' || category === 'salary';
      if (!recurring && rnd() > 0.75) continue;
      const share = (amount / specWeight) * target;
      expenses.push({
        ...base,
        id: uid('E'),
        category,
        description,
        amount: round2(Math.max(299, share * (0.85 + rnd() * 0.3))),
        vendor: pick(['Meta', 'Google', 'Hostinger', 'Internal', 'Airtel', 'Local Vendor']),
        spent_at: iso(addDays(new Date(), -(m * 30 + int(1, 25)))),
        method: pick(['upi', 'bank_transfer', 'credit_card']) as never,
        is_recurring: recurring,
        attachment_url: null,
        created_by: profiles[0].id,
      });
    }
  }

  const supplier_payments: Database['supplier_payments'] = suppliers.flatMap((s) =>
    Array.from({ length: int(2, 5) }, () => ({
      ...base,
      id: uid('U'),
      supplier_id: s.id,
      amount: int(10, 90) * 1000,
      method: 'bank_transfer' as const,
      paid_at: iso(addDays(new Date(), -int(1, 200))),
      reference: `NEFT${int(100000, 999999)}`,
      notes: null,
    })),
  );

  const message_templates: Database['message_templates'] = [
    {
      ...base,
      id: uid('W'),
      name: 'Subscription Expiry Reminder',
      channel: 'whatsapp',
      subject: null,
      body: 'Hi {{customer_name}}, your {{product_name}} expires on {{expiry_date}} ({{days_remaining}} days left). Renew at ₹{{renewal_price}} to stay active. — DigiTech',
      variables: ['customer_name', 'product_name', 'expiry_date', 'days_remaining', 'renewal_price'],
      is_active: true,
    },
    {
      ...base,
      id: uid('W'),
      name: 'Payment Reminder',
      channel: 'whatsapp',
      subject: null,
      body: 'Hi {{customer_name}}, a payment of ₹{{payment_due}} is pending for order {{order_id}}. Please complete it to start activation. — DigiTech',
      variables: ['customer_name', 'payment_due', 'order_id'],
      is_active: true,
    },
    {
      ...base,
      id: uid('W'),
      name: 'Activation Delivered',
      channel: 'whatsapp',
      subject: null,
      body: 'Hi {{customer_name}}, your {{product_name}} is activated and valid till {{expiry_date}}. Thanks for choosing DigiTech!',
      variables: ['customer_name', 'product_name', 'expiry_date'],
      is_active: true,
    },
  ];

  const automation_rules: Database['automation_rules'] = [
    ['Subscription expiry reminder (7 days)', 'subscription.expiring', 'whatsapp'],
    ['Payment reminder (48h overdue)', 'payment.overdue', 'whatsapp'],
    ['Lead follow-up reminder', 'lead.followup_due', 'task'],
    ['Activation overdue escalation', 'activation.overdue', 'notification'],
    ['Support escalation (SLA breach)', 'support.sla_breach', 'notification'],
    ['Low stock alert', 'product.low_stock', 'notification'],
    ['Supplier payment reminder', 'supplier.payment_due', 'notification'],
    ['Customer reactivation campaign', 'customer.inactive_90d', 'whatsapp'],
  ].map(([name, trigger_event, action_type]) => ({
    ...base,
    id: uid('R'),
    name: name as string,
    description: null,
    trigger_event: trigger_event as string,
    conditions: {},
    action_type: action_type as never,
    action_config: { template: 'Subscription Expiry Reminder' },
    is_active: true,
    last_run_at: null,
    run_count: int(0, 120),
  }));

  const db: Database = {
    organizations: [org],
    profiles,
    customers,
    customer_notes: [],
    product_categories: categories,
    products,
    suppliers,
    supplier_payments,
    orders,
    payments,
    activations,
    subscriptions,
    leads,
    support_tickets: tickets,
    ticket_messages: ticketMessages,
    tasks,
    expenses,
    invoices,
    notifications: [],
    message_templates,
    communication_logs: [],
    automation_rules,
    automation_logs: [],
    approval_requests: [],
    activity_logs: activity.slice(-120),
    attachments: [],
  };

  return db;
}

type Profile_Role = Database['profiles'][number]['role'];

export const DEMO_ORG_ID = ORG_ID;

export function emptyDb(): Database {
  return {
    organizations: [
      {
        id: ORG_ID,
        name: 'DigiTech',
        currency: 'INR',
        timezone: 'Asia/Kolkata',
        gstin: null,
        address: null,
        email: null,
        phone: null,
        expiry_threshold_days: 15,
        created_at: now(),
        updated_at: now(),
      },
    ],
    profiles: [],
    customers: [],
    customer_notes: [],
    product_categories: [],
    products: [],
    suppliers: [],
    supplier_payments: [],
    orders: [],
    payments: [],
    activations: [],
    subscriptions: [],
    leads: [],
    support_tickets: [],
    ticket_messages: [],
    tasks: [],
    expenses: [],
    invoices: [],
    notifications: [],
    message_templates: [],
    communication_logs: [],
    automation_rules: [],
    automation_logs: [],
    approval_requests: [],
    activity_logs: [],
    attachments: [],
  };
}
