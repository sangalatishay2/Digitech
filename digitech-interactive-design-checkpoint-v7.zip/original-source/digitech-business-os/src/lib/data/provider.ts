import type { Database } from '@/lib/types';

/**
 * Data provider contract.
 *
 * The UI never talks to a database directly — it talks to a DataProvider.
 * Implementations:
 *  - LocalProvider   (standalone-first, browser persistence)  → src/lib/data/local-provider.ts
 *  - SupabaseProvider (drop-in, when credentials exist)       → src/lib/data/supabase-provider.ts
 */
export interface DataProvider {
  readonly name: string;
  load(): Promise<Database>;
  save(db: Database): Promise<void>;
  reset(mode: 'demo' | 'empty'): Promise<Database>;
  isReady(): boolean;
}

export type ProviderName = 'local' | 'supabase';

export function activeProviderName(): ProviderName {
  const v = process.env.NEXT_PUBLIC_DATA_PROVIDER;
  return v === 'supabase' ? 'supabase' : 'local';
}
