import type { Database } from '@/lib/types';

/**
 * Per-entity repository contract.
 *
 * This replaces the whole-database `save(db)` model for production writes.
 *
 * Why: `save(db)` serialises the entire database and writes it back on every
 * mutation. With two concurrent users, the second write silently discards
 * everything the first user did (last-writer-wins). It also makes row-level
 * authorization impossible to express, because the unit of work is "everything".
 *
 * A repository mutation instead targets a single row, carries the acting user's
 * identity, and is authorized server-side (RBAC in the service layer, RLS in the
 * database) before it is applied.
 */

/** Tables that accept per-entity mutations. */
export const MUTABLE_TABLES = [
  'organizations', 'profiles', 'customers', 'customer_notes', 'product_categories',
  'products', 'suppliers', 'supplier_payments', 'orders', 'order_items', 'payments',
  'activations', 'subscriptions', 'renewals', 'leads', 'lead_activities',
  'support_tickets', 'ticket_messages', 'tasks', 'expenses', 'invoices',
  'invoice_items', 'notifications', 'message_templates', 'communication_logs',
  'automation_rules', 'automation_logs', 'approval_requests', 'activity_logs', 'attachments',
] as const;

export type MutableTable = (typeof MUTABLE_TABLES)[number];

export interface QueryFilter {
  column: string;
  op: 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'in' | 'is';
  value: unknown;
}

export interface RepositoryContext {
  /** The acting profile id. Mutations are attributed and authorized against it. */
  actorId: string | null;
  organizationId: string | null;
}

/**
 * Result of a write. `conflict` is returned when the row was modified by someone
 * else since it was read, so the caller can re-read rather than clobber.
 */
export type WriteResult<T> =
  | { ok: true; row: T }
  | { ok: false; error: string; conflict?: boolean };

export interface Repository {
  readonly name: string;
  isReady(): boolean;

  /** Full snapshot, used to hydrate the client cache. Scoped by RLS. */
  loadAll(ctx: RepositoryContext): Promise<Database>;

  select<T = Record<string, unknown>>(
    table: MutableTable,
    filters: QueryFilter[],
    ctx: RepositoryContext,
  ): Promise<T[]>;

  insert<T = Record<string, unknown>>(
    table: MutableTable,
    row: Record<string, unknown>,
    ctx: RepositoryContext,
  ): Promise<WriteResult<T>>;

  update<T = Record<string, unknown>>(
    table: MutableTable,
    id: string,
    patch: Record<string, unknown>,
    ctx: RepositoryContext,
    opts?: { expectedUpdatedAt?: string },
  ): Promise<WriteResult<T>>;

  remove(
    table: MutableTable,
    id: string,
    ctx: RepositoryContext,
    opts?: { soft?: boolean },
  ): Promise<WriteResult<{ id: string }>>;

  /**
   * Execute several mutations atomically. Required for operations that must not
   * half-apply, e.g. completing an activation (create subscription + decrement
   * stock + mark order delivered).
   */
  transaction(
    ops: TransactionOp[],
    ctx: RepositoryContext,
    idempotencyKey?: string,
  ): Promise<WriteResult<{ applied: number }>>;
}

export type TransactionOp =
  | { kind: 'insert'; table: MutableTable; row: Record<string, unknown> }
  | { kind: 'update'; table: MutableTable; id: string; patch: Record<string, unknown> }
  | { kind: 'delete'; table: MutableTable; id: string };

export function isMutableTable(t: string): t is MutableTable {
  return (MUTABLE_TABLES as readonly string[]).includes(t);
}
