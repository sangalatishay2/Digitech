import type { Database } from '@/lib/types';
import { MUTABLE_TABLES, type MutableTable, type TransactionOp } from './repository';

/**
 * Whole-snapshot → per-entity mutation diffing.
 *
 * The store's public contract is `update(draft => { ... })`: components mutate a
 * plain JavaScript copy of the database. That contract is good ergonomics and is
 * used by ~40 call sites, so it stays.
 *
 * What must NOT stay is persisting the result with a whole-database `save(db)`.
 * That is last-writer-wins: two users editing different customers would each
 * write back their entire snapshot and the second would silently erase the
 * first's work.
 *
 * This module closes that gap. It compares the previous and next snapshots and
 * emits only the rows that actually changed, which the repository then applies
 * as individual INSERT / UPDATE / DELETE statements — each authorized by RLS on
 * its own merits.
 */

/** Tables that live inside the Database snapshot and map to real SQL tables. */
const DIFFABLE: readonly MutableTable[] = MUTABLE_TABLES;

export interface Row {
  id: string;
  updated_at?: string;
  deleted_at?: string | null;
  [k: string]: unknown;
}

export interface TableDiff {
  table: MutableTable;
  inserted: Row[];
  updated: Row[];
  deleted: string[];
}

export interface SnapshotDiff {
  tables: TableDiff[];
  /** Total number of row-level changes. */
  count: number;
}

/**
 * Nested arrays are part of the parent aggregate (e.g. `order.items`), not
 * separate columns on the parent row. They are stripped before comparison and
 * before writing, and handled by their own child-table diff where one exists.
 */
const NESTED_KEYS = new Set(['items']);

/**
 * Activation secret columns, which the generic write path must never carry.
 *
 * These are stored encrypted and are only ever written through
 * /api/activations/[id]/secrets, which encrypts them and checks permissions.
 * If they travelled through the ordinary snapshot diff they would be sent as
 * plaintext from the browser — defeating the encryption entirely and tripping
 * the ciphertext CHECK constraint added in migration 0018.
 *
 * Stripping them here is deliberate defense-in-depth: any existing UI that
 * still binds these fields silently stops persisting them rather than leaking
 * them, and the diff sees no change so no spurious UPDATE is emitted.
 */
const SECRET_KEYS: Record<string, ReadonlySet<string>> = {
  activations: new Set([
    'activation_email',
    'activation_password',
    'activation_details',
    'internal_instructions',
  ]),
};

function stripSecrets(table: string, row: Record<string, unknown>): Record<string, unknown> {
  const secrets = SECRET_KEYS[table];
  if (!secrets) return row;
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(row)) {
    if (secrets.has(k)) continue;
    out[k] = v;
  }
  return out;
}

function stripNested(row: Row): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(row)) {
    if (NESTED_KEYS.has(k) && Array.isArray(v)) continue;
    out[k] = v;
  }
  return out;
}

/** Stable comparison that ignores key order and nested aggregates. */
function sameRow(a: Row, b: Row, table = ''): boolean {
  // Secrets are compared out as well as written out: a UI that still edits them
  // must not produce an UPDATE whose payload has had the secrets stripped,
  // which would be a no-op write that looks like a successful save.
  const sa = stripSecrets(table, stripNested(a));
  const sb = stripSecrets(table, stripNested(b));
  const ka = Object.keys(sa).sort();
  const kb = Object.keys(sb).sort();
  if (ka.length !== kb.length) return false;
  for (let i = 0; i < ka.length; i++) if (ka[i] !== kb[i]) return false;
  for (const k of ka) {
    const va = sa[k];
    const vb = sb[k];
    if (va === vb) continue;
    // Compare structurally for objects/arrays that survived stripping.
    if (JSON.stringify(va) !== JSON.stringify(vb)) return false;
  }
  return true;
}

function rowsOf(db: Database, table: string): Row[] {
  const v = (db as unknown as Record<string, unknown>)[table];
  return Array.isArray(v) ? (v as Row[]) : [];
}

/** Diff two snapshots into per-row changes. */
export function diffSnapshots(prev: Database, next: Database): SnapshotDiff {
  const tables: TableDiff[] = [];
  let count = 0;

  for (const table of DIFFABLE) {
    const before = rowsOf(prev, table);
    const after = rowsOf(next, table);
    // Skip tables absent from the snapshot shape entirely.
    if (before.length === 0 && after.length === 0) continue;

    const beforeById = new Map(before.map((r) => [r.id, r]));
    const afterById = new Map(after.map((r) => [r.id, r]));

    const inserted: Row[] = [];
    const updated: Row[] = [];
    const deleted: string[] = [];

    for (const [id, row] of afterById) {
      const old = beforeById.get(id);
      if (!old) inserted.push(row);
      else if (!sameRow(old, row, table)) updated.push(row);
    }
    for (const id of beforeById.keys()) {
      if (!afterById.has(id)) deleted.push(id);
    }

    if (inserted.length || updated.length || deleted.length) {
      tables.push({ table, inserted, updated, deleted });
      count += inserted.length + updated.length + deleted.length;
    }
  }

  return { tables, count };
}

/**
 * Order matters: parents before children on insert so foreign keys resolve, and
 * the reverse on delete. Anything unlisted keeps its natural order after these.
 */
const WRITE_ORDER: readonly string[] = [
  'organizations', 'profiles', 'product_categories', 'suppliers', 'products',
  'customers', 'customer_notes', 'orders', 'order_items', 'payments',
  'activations', 'subscriptions', 'renewals', 'invoices', 'invoice_items',
  'leads', 'lead_activities', 'support_tickets', 'ticket_messages', 'tasks',
  'expenses', 'supplier_payments', 'notifications', 'message_templates',
  'communication_logs', 'automation_rules', 'automation_logs', 'activity_logs',
  'approval_requests', 'attachments',
];

const orderIndex = (t: string) => {
  const i = WRITE_ORDER.indexOf(t);
  return i === -1 ? WRITE_ORDER.length : i;
};

/** Flatten a diff into ordered transaction operations. */
export function diffToOps(diff: SnapshotDiff): TransactionOp[] {
  const ops: TransactionOp[] = [];

  const inserts = [...diff.tables].sort((a, b) => orderIndex(a.table) - orderIndex(b.table));
  for (const t of inserts) {
    for (const row of t.inserted) {
      ops.push({ kind: 'insert', table: t.table, row: stripSecrets(t.table, stripNested(row)) });
    }
  }
  for (const t of inserts) {
    for (const row of t.updated) {
      const patch = stripSecrets(t.table, stripNested(row));
      delete patch.id;
      ops.push({ kind: 'update', table: t.table, id: row.id, patch });
    }
  }
  // Children first on delete.
  const deletes = [...diff.tables].sort((a, b) => orderIndex(b.table) - orderIndex(a.table));
  for (const t of deletes) {
    for (const id of t.deleted) {
      ops.push({ kind: 'delete', table: t.table, id });
    }
  }
  return ops;
}

/**
 * Rows referencing an organization the caller is not a member of must never be
 * sent. RLS would reject them anyway, but failing here keeps the error close to
 * the cause and avoids a partial batch.
 */
export function assertOrgScope(ops: TransactionOp[], organizationId: string): void {
  for (const op of ops) {
    const row = op.kind === 'insert' ? op.row : op.kind === 'update' ? op.patch : null;
    if (!row) continue;
    const org = row.organization_id;
    if (org !== undefined && org !== null && org !== organizationId) {
      throw new Error(
        `Refusing to write ${op.table}: row belongs to organization ${String(org)}, session is ${organizationId}`,
      );
    }
  }
}
