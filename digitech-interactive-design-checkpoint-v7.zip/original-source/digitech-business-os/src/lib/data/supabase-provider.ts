import type { Database } from '@/lib/types';
import type { DataProvider } from './provider';
import { emptyDb } from './seed';
import { diffSnapshots, diffToOps, assertOrgScope } from './diff';
import {
  MUTABLE_TABLES, type MutableTable, type QueryFilter, type WriteResult,
} from './repository';
import { getSupabaseClient, type SupabaseLike } from './supabase-client';

/**
 * Supabase data provider — per-entity reads and writes.
 *
 * There is deliberately NO whole-database save. `save()` diffs the previous and
 * next snapshots (see ./diff.ts) and applies only the rows that changed, as
 * individual statements. Two users editing different records no longer clobber
 * each other.
 *
 * Organization isolation is enforced in three independent places:
 *   1. RLS policies in Postgres (migration 0016) — the real boundary.
 *   2. `assertOrgScope()` before any write leaves the client.
 *   3. Every read is implicitly scoped, because RLS filters `select *`.
 *
 * Sensitive activation fields are never selected by the browser client; they
 * are fetched on demand through a server route (see src/app/api/activations).
 */

/** Columns that hold customer-delivered secrets. Never selected client-side. */
export const SECRET_ACTIVATION_COLUMNS = [
  'activation_email',
  'activation_password',
  'activation_details',
  'internal_instructions',
] as const;

/** Explicit safe column list for activations, so secrets cannot leak by `*`. */
const ACTIVATION_SAFE_COLUMNS = [
  'id', 'organization_id', 'order_id', 'order_item_id', 'customer_id',
  'customer_name', 'product_id', 'product_name', 'supplier_id', 'supplier_name',
  'delivery_type', 'status', 'assigned_to', 'requested_at', 'delivered_at',
  'expires_at', 'duration_days', 'notes', 'created_at', 'updated_at', 'deleted_at',
].join(',');

function selectListFor(table: MutableTable): string {
  return table === 'activations' ? ACTIVATION_SAFE_COLUMNS : '*';
}

export class SupabaseProvider implements DataProvider {
  readonly name = 'supabase';

  constructor(private readonly client: SupabaseLike | null = getSupabaseClient()) {}

  isReady(): boolean {
    return this.client !== null;
  }

  private require(): SupabaseLike {
    if (!this.client) {
      throw new Error(
        'Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.',
      );
    }
    return this.client;
  }

  /* ---------------------------------------------------------------- */
  /* Reads                                                             */
  /* ---------------------------------------------------------------- */

  async select<T = Record<string, unknown>>(
    table: MutableTable,
    filters: QueryFilter[] = [],
  ): Promise<T[]> {
    let q = this.require().from(table).select(selectListFor(table));
    for (const f of filters) {
      switch (f.op) {
        case 'eq': q = q.eq(f.column, f.value); break;
        case 'neq': q = q.neq(f.column, f.value); break;
        case 'gt': q = q.gt(f.column, f.value); break;
        case 'gte': q = q.gte(f.column, f.value); break;
        case 'lt': q = q.lt(f.column, f.value); break;
        case 'lte': q = q.lte(f.column, f.value); break;
        case 'in': q = q.in(f.column, f.value as unknown[]); break;
        case 'is': q = q.is(f.column, f.value); break;
      }
    }
    const { data, error } = await q;
    if (error) throw new Error(`select ${table}: ${error.message}`);
    return (data ?? []) as T[];
  }

  async getById<T = Record<string, unknown>>(table: MutableTable, id: string): Promise<T | null> {
    const rows = await this.select<T>(table, [{ column: 'id', op: 'eq', value: id }]);
    return rows[0] ?? null;
  }

  /**
   * Hydrate the client cache. RLS scopes every table to the caller's
   * organization, so no explicit organization_id filter is required — and
   * adding one would not be a security control, the policy is.
   */
  async load(): Promise<Database> {
    const db = emptyDb() as unknown as Record<string, unknown>;
    const results = await Promise.all(
      MUTABLE_TABLES.filter((t) => Array.isArray(db[t])).map(async (t) => {
        try {
          return [t, await this.select(t)] as const;
        } catch {
          // A table the caller cannot read yields an empty list rather than
          // failing the whole hydration.
          return [t, []] as const;
        }
      }),
    );
    for (const [t, rows] of results) db[t] = rows;

    // Re-nest order items onto their orders so the existing UI contract holds.
    const orders = (db.orders ?? []) as Record<string, unknown>[];
    const items = (db.order_items ?? []) as Record<string, unknown>[];
    if (orders.length && items.length) {
      const byOrder = new Map<string, Record<string, unknown>[]>();
      for (const it of items) {
        const k = String(it.order_id);
        const list = byOrder.get(k) ?? [];
        list.push(it);
        byOrder.set(k, list);
      }
      for (const o of orders) o.items = byOrder.get(String(o.id)) ?? [];
    }
    const invoices = (db.invoices ?? []) as Record<string, unknown>[];
    const invItems = (db.invoice_items ?? []) as Record<string, unknown>[];
    if (invoices.length && invItems.length) {
      const byInvoice = new Map<string, Record<string, unknown>[]>();
      for (const it of invItems) {
        const k = String(it.invoice_id);
        const list = byInvoice.get(k) ?? [];
        list.push(it);
        byInvoice.set(k, list);
      }
      for (const i of invoices) i.items = byInvoice.get(String(i.id)) ?? [];
    }

    return db as unknown as Database;
  }

  /* ---------------------------------------------------------------- */
  /* Per-entity writes                                                 */
  /* ---------------------------------------------------------------- */

  async insert<T = Record<string, unknown>>(
    table: MutableTable,
    row: Record<string, unknown>,
  ): Promise<WriteResult<T>> {
    const { data, error } = await this.require().from(table).insert(row).select().single();
    if (error) return { ok: false, error: `insert ${table}: ${error.message}` };
    return { ok: true, row: data as T };
  }

  async update<T = Record<string, unknown>>(
    table: MutableTable,
    id: string,
    patch: Record<string, unknown>,
    opts?: { expectedUpdatedAt?: string },
  ): Promise<WriteResult<T>> {
    let q = this.require().from(table).update(patch).eq('id', id);
    // Optimistic concurrency: only write if nobody else changed the row.
    if (opts?.expectedUpdatedAt) q = q.eq('updated_at', opts.expectedUpdatedAt);
    const { data, error } = await q.select();
    if (error) return { ok: false, error: `update ${table}: ${error.message}` };
    const rows = (data ?? []) as T[];
    if (rows.length === 0) {
      return {
        ok: false,
        conflict: Boolean(opts?.expectedUpdatedAt),
        error: opts?.expectedUpdatedAt
          ? 'Row changed since it was read (concurrent edit). Re-read and retry.'
          : 'Row not found or not permitted.',
      };
    }
    return { ok: true, row: rows[0] };
  }

  /** Soft delete by default — history stays auditable. */
  async archive(table: MutableTable, id: string): Promise<WriteResult<{ id: string }>> {
    const r = await this.update(table, id, { deleted_at: new Date().toISOString() });
    return r.ok ? { ok: true, row: { id } } : r;
  }

  async remove(table: MutableTable, id: string): Promise<WriteResult<{ id: string }>> {
    const { error } = await this.require().from(table).delete().eq('id', id);
    if (error) return { ok: false, error: `delete ${table}: ${error.message}` };
    return { ok: true, row: { id } };
  }

  /**
   * Persist a snapshot by writing ONLY what changed.
   *
   * `previous` is required: without it there is no way to know which rows
   * changed, and we would be back to last-writer-wins.
   */
  async saveDiff(
    previous: Database,
    next: Database,
    organizationId: string,
    idempotencyKey?: string,
  ): Promise<{ applied: number }> {
    const diff = diffSnapshots(previous, next);
    if (diff.count === 0) return { applied: 0 };

    const ops = diffToOps(diff);
    assertOrgScope(ops, organizationId);

    // Apply atomically so a partial failure cannot leave inconsistent finances.
    const { data, error } = await this.require().rpc('apply_transaction', {
      p_ops: ops,
      p_idempotency_key: idempotencyKey ?? null,
    });
    if (error) throw new Error(`save failed: ${error.message}`);
    return { applied: Number(data ?? ops.length) };
  }

  /**
   * DataProvider compatibility shim.
   *
   * The interface exposes `save(db)`, but a whole-database overwrite is exactly
   * what must not happen in production. Callers that can supply the previous
   * snapshot should use `saveDiff()`; this throws rather than silently doing
   * something dangerous.
   */
  async save(): Promise<void> {
    throw new Error(
      'SupabaseProvider.save(db) is intentionally unsupported: whole-database writes are ' +
        'last-writer-wins and would discard concurrent users\' work. Use saveDiff(previous, next, orgId).',
    );
  }

  /**
   * Resetting a live multi-tenant database is not a client operation. Seeding a
   * fresh project is done with the SQL migrations (0014_seed_demo.sql).
   */
  async reset(): Promise<Database> {
    throw new Error(
      'Reset is not available in production mode. Use the SQL migrations to seed or clear a project.',
    );
  }

  /** Atomic, race-free business codes (migration 0017). */
  async nextBusinessNumber(kind: 'order' | 'invoice' | 'customer' | 'ticket'): Promise<string> {
    const { data, error } = await this.require().rpc('next_business_number', { p_kind: kind });
    if (error) throw new Error(`next_business_number(${kind}): ${error.message}`);
    return String(data);
  }
}

export const supabaseProvider = new SupabaseProvider();
