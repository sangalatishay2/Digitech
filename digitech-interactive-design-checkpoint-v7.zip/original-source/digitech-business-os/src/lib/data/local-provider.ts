'use client';

import type { Database } from '@/lib/types';
import type { DataProvider } from './provider';
import { buildSeed, emptyDb } from './seed';
import { allowBrowserPersistence, SENSITIVE_ACTIVATION_FIELDS } from '@/lib/runtime/mode';

const KEY = 'digitech-os:db:v1';
const META_KEY = 'digitech-os:db:meta';
export const LOCAL_SCHEMA_VERSION = 3;

export type LocalProviderEvent =
  | { type: 'quota_exceeded'; message: string }
  | { type: 'corrupt'; message: string }
  | { type: 'migrated'; from: number; to: number }
  | { type: 'external_change'; message: string };

type Listener = (e: LocalProviderEvent) => void;

/** Tables every valid Database snapshot must contain. */
const REQUIRED_TABLES = [
  'organizations', 'profiles', 'customers', 'products', 'suppliers', 'orders',
  'payments', 'activations', 'subscriptions', 'leads', 'support_tickets',
  'tasks', 'expenses', 'invoices', 'notifications', 'activity_logs',
] as const;

/**
 * Demo-only persistence adapter.
 *
 * Explicitly NOT for production:
 *  - stores the whole database under a single key (last-writer-wins)
 *  - no auth, no row-level security
 *  - readable by any script on the origin
 *
 * Outside demo mode it refuses to persist and strips secret-bearing fields.
 */
export class LocalProvider implements DataProvider {
  readonly name = 'local';
  private listeners = new Set<Listener>();

  on(fn: Listener) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit(e: LocalProviderEvent) {
    for (const l of this.listeners) l(e);
  }

  isReady() {
    return typeof window !== 'undefined';
  }

  /** Structural validation — a stale snapshot missing tables must not crash pages. */
  private validate(raw: unknown): { ok: true; db: Database } | { ok: false; reason: string } {
    if (!raw || typeof raw !== 'object') return { ok: false, reason: 'not an object' };
    const cand = raw as Record<string, unknown>;
    const missing = REQUIRED_TABLES.filter((t) => !Array.isArray(cand[t]));
    if (missing.length) return { ok: false, reason: `missing/invalid tables: ${missing.join(', ')}` };
    if (!Array.isArray(cand.organizations) || cand.organizations.length === 0)
      return { ok: false, reason: 'no organization present' };
    return { ok: true, db: raw as Database };
  }

  /** Fill in tables added by later versions so old snapshots keep working. */
  private migrate(db: Database): Database {
    const seed = emptyDb();
    const merged = { ...seed, ...db } as Record<string, unknown>;
    for (const [k, v] of Object.entries(seed)) {
      if (!Array.isArray(merged[k]) && Array.isArray(v)) merged[k] = v;
    }
    return merged as unknown as Database;
  }

  /** Never let customer secrets reach browser storage outside demo mode. */
  private redact(db: Database): Database {
    if (allowBrowserPersistence()) return db;
    return {
      ...db,
      activations: db.activations.map((a) => {
        const copy = { ...a } as Record<string, unknown>;
        for (const f of SENSITIVE_ACTIVATION_FIELDS) copy[f] = null;
        return copy as unknown as (typeof db.activations)[number];
      }),
    };
  }

  async load(): Promise<Database> {
    if (!this.isReady()) return buildSeed();
    let raw: string | null = null;
    try {
      raw = window.localStorage.getItem(KEY);
    } catch (err) {
      this.emit({ type: 'corrupt', message: `localStorage unreadable: ${String(err)}` });
      return buildSeed();
    }

    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        const res = this.validate(parsed);
        if (res.ok) {
          const storedVersion = Number(window.localStorage.getItem(META_KEY) ?? '1');
          const db = this.migrate(res.db);
          if (storedVersion !== LOCAL_SCHEMA_VERSION) {
            this.emit({ type: 'migrated', from: storedVersion, to: LOCAL_SCHEMA_VERSION });
            await this.save(db);
          }
          return db;
        }
        this.emit({
          type: 'corrupt',
          message: `Saved demo data was invalid (${res.reason}). It has been reset to a fresh demo dataset.`,
        });
      } catch {
        this.emit({
          type: 'corrupt',
          message: 'Saved demo data could not be parsed. It has been reset to a fresh demo dataset.',
        });
      }
    }

    const db = buildSeed();
    await this.save(db);
    return db;
  }

  async save(db: Database): Promise<void> {
    if (!this.isReady()) return;
    if (!allowBrowserPersistence()) {
      // Production -- and any degraded production attempt -- must go through
      // server-side repositories. Never fall back to browser storage here.
      return;
    }
    try {
      window.localStorage.setItem(KEY, JSON.stringify(this.redact(db)));
      window.localStorage.setItem(META_KEY, String(LOCAL_SCHEMA_VERSION));
    } catch (err) {
      const quota =
        err instanceof DOMException &&
        (err.name === 'QuotaExceededError' || err.name === 'NS_ERROR_DOM_QUOTA_REACHED');
      // Previously swallowed silently, so users lost data with no signal.
      this.emit({
        type: 'quota_exceeded',
        message: quota
          ? 'Browser storage is full — changes are held in memory only and will be lost on reload. Export a backup from Settings.'
          : `Could not persist demo data: ${String(err)}`,
      });
    }
  }

  async reset(mode: 'demo' | 'empty'): Promise<Database> {
    const db = mode === 'demo' ? buildSeed() : emptyDb();
    await this.save(db);
    return db;
  }
}

export const localProvider = new LocalProvider();
