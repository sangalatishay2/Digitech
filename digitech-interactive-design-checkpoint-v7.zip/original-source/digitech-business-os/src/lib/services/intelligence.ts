import type { CommunicationLog, Database, Role, UUID } from '@/lib/types';

export interface InboxThread {
  id: string;
  customerId: UUID | null;
  customerName: string;
  address: string;
  latestAt: string;
  latestBody: string;
  channel: CommunicationLog['channel'];
  inboundCount: number;
  openTickets: number;
  messages: CommunicationLog[];
}

export interface FinanceSignal {
  id: string;
  title: string;
  detail: string;
  amount: number;
  severity: 'critical' | 'high' | 'medium' | 'low';
  href: string;
}

export function buildInboxThreads(db: Database): InboxThread[] {
  const groups = new Map<string, CommunicationLog[]>();
  for (const log of db.communication_logs) {
    if (log.deleted_at) continue;
    const key = log.customer_id || `${log.channel}:${log.to_address.trim().toLowerCase()}`;
    groups.set(key, [...(groups.get(key) ?? []), log]);
  }
  return [...groups.entries()].map(([id, messages]) => {
    messages.sort((a, b) => a.created_at.localeCompare(b.created_at));
    const latest = messages[messages.length - 1];
    const customer = latest.customer_id ? db.customers.find((item) => item.id === latest.customer_id) : undefined;
    return {
      id,
      customerId: latest.customer_id ?? null,
      customerName: customer?.name ?? latest.to_address,
      address: latest.to_address,
      latestAt: latest.created_at,
      latestBody: latest.body,
      channel: latest.channel,
      inboundCount: messages.filter((item) => item.direction === 'inbound').length,
      openTickets: latest.customer_id
        ? db.support_tickets.filter((item) => item.customer_id === latest.customer_id && ['open', 'in_progress'].includes(item.status)).length
        : 0,
      messages,
    };
  }).sort((a, b) => b.latestAt.localeCompare(a.latestAt));
}

export function buildFinanceSignals(db: Database): FinanceSignal[] {
  const signals: FinanceSignal[] = [];
  const customerName = (id: string) => db.customers.find((item) => item.id === id)?.name ?? 'Unknown customer';
  for (const order of db.orders) {
    if (order.deleted_at || ['cancelled', 'refunded'].includes(order.status)) continue;
    if (order.outstanding >= 10_000) signals.push({
      id: `receivable-${order.id}`, title: `Large receivable · ${order.order_number}`,
      detail: `${customerName(order.customer_id)} has a material outstanding balance.`,
      amount: order.outstanding, severity: order.outstanding >= 50_000 ? 'critical' : 'high', href: `/orders/${order.id}`,
    });
    const cost = order.items.reduce((sum, item) => sum + item.unit_cost * item.quantity, 0);
    const realized = order.total - order.amount_refunded;
    if (realized < cost) signals.push({
      id: `margin-${order.id}`, title: `Negative margin · ${order.order_number}`,
      detail: `Realized value is below recorded product cost by ₹${Math.round(cost - realized).toLocaleString('en-IN')}.`,
      amount: cost - realized, severity: 'critical', href: `/orders/${order.id}`,
    });
  }
  for (const supplier of db.suppliers) {
    if (supplier.deleted_at) continue;
    const purchased = db.orders.reduce((total, order) => total + order.items
      .filter((item) => item.supplier_id === supplier.id)
      .reduce((sum, item) => sum + item.line_cost, 0), 0);
    const paid = db.supplier_payments
      .filter((item) => !item.deleted_at && item.supplier_id === supplier.id)
      .reduce((sum, item) => sum + item.amount, 0);
    const balance = Math.max(0, purchased - paid);
    if (balance <= 0) continue;
    signals.push({
      id: `supplier-${supplier.id}`, title: `Supplier balance outstanding`,
      detail: `${supplier.name} has unpaid recorded product cost under ${supplier.payment_terms || 'its payment terms'}.`,
      amount: balance, severity: balance >= 25_000 ? 'high' : 'medium', href: '/finance/supplier-payments',
    });
  }
  return signals.sort((a, b) => {
    const rank = { critical: 4, high: 3, medium: 2, low: 1 };
    return rank[b.severity] - rank[a.severity] || b.amount - a.amount;
  });
}

export function roleFocus(role: Role): { title: string; href: string; permission: string }[] {
  const shared = [{ title: 'My priority queue', href: '/#today', permission: 'tasks.read' }];
  const byRole: Partial<Record<Role, { title: string; href: string; permission: string }[]>> = {
    owner: [
      { title: 'Approval decisions', href: '/approvals', permission: 'approvals.review' },
      { title: 'Financial risks', href: '/finance/intelligence', permission: 'finance.read' },
    ],
    admin: [
      { title: 'Approval decisions', href: '/approvals', permission: 'approvals.review' },
      { title: 'Team operations', href: '/team', permission: 'team.manage' },
    ],
    sales: [
      { title: 'Renewal pipeline', href: '/renewals', permission: 'subscriptions.read' },
      { title: 'Lead follow-ups', href: '/leads', permission: 'leads.read' },
    ],
    support: [
      { title: 'Unified inbox', href: '/inbox', permission: 'communications.read' },
      { title: 'SLA queue', href: '/support', permission: 'support.read' },
    ],
    accounts: [
      { title: 'Financial risks', href: '/finance/intelligence', permission: 'finance.read' },
      { title: 'Collections', href: '/payments', permission: 'payments.read' },
    ],
    operations: [
      { title: 'Activation queue', href: '/activations', permission: 'activations.read' },
      { title: 'Supplier work', href: '/suppliers', permission: 'suppliers.read' },
    ],
    viewer: [{ title: 'Business analytics', href: '/analytics', permission: 'analytics.read' }],
  };
  return [...shared, ...(byRole[role] ?? [])];
}
