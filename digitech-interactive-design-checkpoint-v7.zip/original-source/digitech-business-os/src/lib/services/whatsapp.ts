/**
 * Provider-agnostic messaging layer.
 *
 * No vendor is hard-coded. A provider implements `send()`; the app only depends
 * on this interface, so swapping Meta Cloud API / Gupshup / Twilio / Interakt /
 * WATI is a configuration change.
 */
export interface MessagePayload {
  to: string;
  body: string;
  channel: 'whatsapp' | 'sms' | 'email';
  templateName?: string;
  variables?: Record<string, string | number>;
  /** Ties the message to a customer for audit + cross-tenant validation. */
  customerId?: string | null;
}

export interface SendResult {
  status: 'sent' | 'queued' | 'failed';
  providerMessageId?: string;
  error?: string;
}

export interface MessagingProvider {
  readonly id: string;
  readonly label: string;
  readonly configured: boolean;
  send(payload: MessagePayload, accessToken?: string): Promise<SendResult>;
}

/** Opens the user's own WhatsApp (web/app). Always available, zero config. */
export class WhatsAppLinkProvider implements MessagingProvider {
  readonly id = 'wa_link';
  readonly label = 'WhatsApp Click-to-Chat (no API key needed)';
  readonly configured = true;

  buildLink(to: string, body: string) {
    return `https://wa.me/${to.replace(/\D/g, '')}?text=${encodeURIComponent(body)}`;
  }

  async send(payload: MessagePayload): Promise<SendResult> {
    if (typeof window === 'undefined') return { status: 'failed', error: 'Browser required' };
    window.open(this.buildLink(payload.to, payload.body), '_blank');
    return { status: 'sent', providerMessageId: `link-${Date.now()}` };
  }
}

/**
 * WhatsApp Cloud API adapter.
 *
 * Sending goes through /api/messaging/whatsapp, which holds
 * WHATSAPP_ACCESS_TOKEN server-side. The token is a long-lived bearer
 * credential for the business' WhatsApp account and must never reach the
 * browser, so it is deliberately NOT a NEXT_PUBLIC_* variable and this class
 * cannot read it.
 *
 * Because availability depends on server-only configuration, the browser
 * cannot know it synchronously. `configured` therefore reports the last known
 * state (pessimistic until checked) and `refresh()` asks the server. This is
 * the honest version of the old behaviour, which reported "configured" from a
 * public env flag while send() always failed.
 */
export class CloudApiProvider implements MessagingProvider {
  readonly id = 'cloud_api';
  readonly label = 'WhatsApp Cloud API';

  /** Server-reported availability. Null means "not yet checked". */
  private available: boolean | null = null;

  get configured() {
    return this.available === true;
  }

  get unavailableReason(): string | null {
    if (this.available === true) return null;
    if (this.available === null) return 'Checking availability…';
    return 'Not configured on this deployment. Set WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID on the server.';
  }

  /** Ask the server whether credentials exist. Never returns the token. */
  async refresh(accessToken?: string): Promise<boolean> {
    try {
      const res = await fetch('/api/messaging/whatsapp', {
        headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : {},
      });
      if (!res.ok) {
        this.available = false;
        return false;
      }
      const data = (await res.json()) as { configured?: boolean };
      this.available = Boolean(data.configured);
      return this.available;
    } catch {
      this.available = false;
      return false;
    }
  }

  async send(payload: MessagePayload, accessToken?: string): Promise<SendResult> {
    try {
      const res = await fetch('/api/messaging/whatsapp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        },
        body: JSON.stringify({
          to: payload.to,
          body: payload.body,
          customer_id: payload.customerId ?? null,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        status?: string;
        providerMessageId?: string;
        error?: string;
      };
      if (!res.ok || data.status !== 'sent') {
        return { status: 'failed', error: data.error ?? `Send failed (${res.status}).` };
      }
      return { status: 'sent', providerMessageId: data.providerMessageId };
    } catch (e) {
      return { status: 'failed', error: (e as Error).message };
    }
  }
}

export const PROVIDERS: MessagingProvider[] = [new WhatsAppLinkProvider(), new CloudApiProvider()];

export function activeProvider(): MessagingProvider {
  const cloud = PROVIDERS.find((p) => p.id === 'cloud_api')!;
  // Only ever select a provider that can genuinely deliver. Cloud API reports
  // configured only after the server has confirmed credentials exist, so the
  // default stays Click-to-Chat rather than a silently-dropping channel.
  return cloud.configured ? cloud : PROVIDERS[0];
}

/** The Cloud API singleton, so callers can refresh availability once at mount. */
export function cloudApiProvider(): CloudApiProvider {
  return PROVIDERS.find((p) => p.id === 'cloud_api') as CloudApiProvider;
}

export const TEMPLATE_VARIABLES = [
  'customer_name',
  'product_name',
  'expiry_date',
  'days_remaining',
  'order_id',
  'payment_due',
  'renewal_price',
] as const;
