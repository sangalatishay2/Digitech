import { validateEnum, validateNumber, type RowIssue } from './csv';
import { CUSTOMER_STATUS, type CustomerStatus, type ProductType, type DeliveryType } from '@/lib/types';

/**
 * Row-level import validation (P2 #18).
 *
 * Previously the importer read mapped fields with `Number(x) || 0` and dropped
 * mapped enum columns entirely:
 *
 *   - `Number('abc') || 0` is 0, so a typo in a price column silently created a
 *     product priced at zero instead of reporting a bad row.
 *   - `status`, `product_type` and `delivery_type` were offered in the field
 *     mapper and then ignored, so users mapped them and wondered why every
 *     record came in with the default.
 *
 * Every row now either validates completely or is reported with the exact row
 * number and field.
 */

// Re-exported from the domain types so these lists can never drift from the
// database enums. Duplicating them here is exactly how the importer ended up
// accepting values the schema rejects.
export { CUSTOMER_STATUS };
export const PRODUCT_TYPE = [
  'subscription', 'license', 'digital_product', 'service',
] as const satisfies readonly ProductType[];
export const DELIVERY_TYPE = [
  'email_activation', 'account_activation', 'license_key', 'invite_link', 'manual',
] as const satisfies readonly DeliveryType[];
export type { CustomerStatus, ProductType, DeliveryType };

export interface ValidatedCustomer {
  name: string;
  phone: string | null;
  whatsapp: string | null;
  email: string | null;
  company: string | null;
  city: string | null;
  state: string | null;
  source: string | null;
  status: CustomerStatus | undefined;
}

export interface ValidatedProduct {
  name: string;
  code: string;
  brand: string | null;
  product_type: ProductType | undefined;
  delivery_type: DeliveryType | undefined;
  duration_days: number;
  cost_price: number;
  selling_price: number;
  stock: number | null;
}

export type RowResult<T> = { ok: true; value: T } | { ok: false; issues: RowIssue[] };

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Row number as the user sees it in a spreadsheet: 1 = header. */
export const displayRow = (index: number) => index + 2;

export function validateCustomerRow(
  get: (field: string) => string,
  index: number,
): RowResult<ValidatedCustomer> {
  const row = displayRow(index);
  const issues: RowIssue[] = [];

  const name = get('name').trim();
  if (!name) issues.push({ row, field: 'name', message: 'name is required' });

  const email = get('email').trim();
  if (email && !EMAIL.test(email)) {
    issues.push({ row, field: 'email', message: `"${email}" is not a valid email address` });
  }

  const phone = get('phone').trim();
  if (phone && phone.replace(/\D/g, '').length < 6) {
    issues.push({ row, field: 'phone', message: `"${phone}" is not a usable phone number` });
  }

  let status: CustomerStatus | undefined;
  const rawStatus = get('status').trim();
  if (rawStatus) {
    const r = validateEnum(rawStatus, CUSTOMER_STATUS, 'status', row);
    if (r.ok) status = r.value;
    else issues.push(r.issue);
  }

  if (issues.length) return { ok: false, issues };
  return {
    ok: true,
    value: {
      name,
      phone: phone || null,
      whatsapp: get('whatsapp').trim() || phone || null,
      email: email || null,
      company: get('company').trim() || null,
      city: get('city').trim() || null,
      state: get('state').trim() || null,
      source: get('source').trim() || null,
      status,
    },
  };
}

export function validateProductRow(
  get: (field: string) => string,
  index: number,
): RowResult<ValidatedProduct> {
  const row = displayRow(index);
  const issues: RowIssue[] = [];

  const name = get('name').trim();
  const code = get('code').trim();
  if (!name) issues.push({ row, field: 'name', message: 'name is required' });
  if (!code) issues.push({ row, field: 'code', message: 'code is required' });

  let product_type: ProductType | undefined;
  const rawType = get('product_type').trim();
  if (rawType) {
    const r = validateEnum(rawType, PRODUCT_TYPE, 'product_type', row);
    if (r.ok) product_type = r.value;
    else issues.push(r.issue);
  }

  let delivery_type: DeliveryType | undefined;
  const rawDelivery = get('delivery_type').trim();
  if (rawDelivery) {
    const r = validateEnum(rawDelivery, DELIVERY_TYPE, 'delivery_type', row);
    if (r.ok) delivery_type = r.value;
    else issues.push(r.issue);
  }

  const duration = validateNumber(get('duration_days'), 'duration_days', row, { min: 0, integer: true });
  if (!duration.ok) issues.push(duration.issue);

  const cost = validateNumber(get('cost_price'), 'cost_price', row, { min: 0 });
  if (!cost.ok) issues.push(cost.issue);

  const price = validateNumber(get('selling_price'), 'selling_price', row, { min: 0 });
  if (!price.ok) issues.push(price.issue);

  const rawStock = get('stock').trim();
  let stock: number | null = null;
  if (rawStock) {
    const r = validateNumber(rawStock, 'stock', row, { min: 0, integer: true });
    if (r.ok) stock = r.value;
    else issues.push(r.issue);
  }

  if (issues.length) return { ok: false, issues };
  return {
    ok: true,
    value: {
      name,
      code,
      brand: get('brand').trim() || null,
      product_type,
      delivery_type,
      duration_days: duration.ok ? duration.value : 0,
      cost_price: cost.ok ? cost.value : 0,
      selling_price: price.ok ? price.value : 0,
      stock,
    },
  };
}

/** Entities whose bulk import is deliberately not supported yet. */
export const UNSUPPORTED_IMPORT_ENTITIES = ['orders', 'subscriptions'] as const;

export function importSupported(entity: string): boolean {
  return !(UNSUPPORTED_IMPORT_ENTITIES as readonly string[]).includes(entity);
}

export function unsupportedReason(entity: string): string {
  return `Bulk ${entity} import is not available: each row must resolve to existing customer and product records, and mis-resolved rows would create incorrect financial data. Create these from the order form.`;
}
