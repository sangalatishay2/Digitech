import type {
  Activation,
  Customer,
  Database,
  Invoice,
  Order,
  OrderItem,
  OrderStatus,
  Payment,
  Product,
  Subscription,
  UUID,
} from '@/lib/types';
import { addDays, round2 } from '@/lib/utils';

/* ------------------------------------------------------------------ */
/* ID generation                                                       */
/* ------------------------------------------------------------------ */
export function newId(): UUID {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-8xxx-xxxxxxxxxxxx'.replace(/x/g, () =>
    Math.floor(Math.random() * 16).toString(16),
  );
}

export const nowIso = () => new Date().toISOString();

/* ------------------------------------------------------------------ */
/* Order state machine                                                 */
/* ------------------------------------------------------------------ */
export const ORDER_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  new: ['awaiting_payment', 'paid', 'cancelled'],
  awaiting_payment: ['paid', 'processing', 'cancelled'],
  paid: ['processing', 'activation_pending', 'refunded', 'cancelled'],
  processing: ['activation_pending', 'activated', 'cancelled'],
  activation_pending: ['activated', 'cancelled', 'processing'],
  activated: ['delivered', 'completed'],
  delivered: ['completed'],
  completed: ['refunded'],
  cancelled: [],
  refunded: [],
};

/** States from which no ordinary transition is permitted. */
export const TERMINAL_ORDER_STATUSES: OrderStatus[] = ['cancelled', 'refunded'];

export function canTransition(from: OrderStatus, to: OrderStatus) {
  return from === to || ORDER_TRANSITIONS[from].includes(to);
}

/* ------------------------------------------------------------------ */
/* Money / totals                                                      */
/* ------------------------------------------------------------------ */
export function computeOrderTotals(items: OrderItem[], orderDiscount = 0, tax = 0) {
  const subtotal = round2(items.reduce((a, i) => a + i.unit_price * i.quantity, 0));
  const itemDiscount = round2(items.reduce((a, i) => a + i.discount, 0));
  const discount = round2(itemDiscount + orderDiscount);
  const total = round2(Math.max(0, subtotal - discount + tax));
  const total_cost = round2(items.reduce((a, i) => a + i.unit_cost * i.quantity, 0));
  const profit = round2(total - total_cost);
  const margin = total > 0 ? round2((profit / total) * 100) : 0;
  return { subtotal, discount, total, total_cost, profit, margin, tax };
}

/**
 * Canonical order ledger.
 *
 * Three quantities are tracked separately and must never be conflated:
 *   collected  — gross money received from the customer (never reduced by refunds)
 *   refunded   — gross money returned to the customer
 *   due        — what the customer still owes RIGHT NOW
 *
 * Accounting decision (documented, and mirrored in SQL):
 * a refund *reverses the payment it returns* and simultaneously cancels the
 * matching part of the sale. Both sides move together, so:
 *
 *     net      = collected - refunded          (cash actually retained)
 *     billable = max(0, total - refunded)      (sale value still standing)
 *     due      = max(0, billable - net)
 *
 * Worked cases:
 *   total 1000, collected 1000, refunded 1000 -> billable 0,   net 0   -> due 0
 *   total 1000, collected 1000, refunded  300 -> billable 700, net 700 -> due 0
 *   total 1000, collected  400, refunded  400 -> billable 600, net 0   -> due 600
 *
 * The last case is the important one: refunding a partial payment returns the
 * customer to owing the un-refunded remainder, rather than 200 (which is what
 * subtracting the refund from both sides independently would produce).
 *
 * The previous formula `total - (paid - refunded)` instead resurrected the full
 * original total as a receivable after a full refund, inflating outstanding.
 */
export interface OrderLedger {
  collected: number;
  refunded: number;
  net: number;
  due: number;
  payment_status: Order['payment_status'];
}

export function computeOrderLedger(order: Pick<Order, 'id' | 'total'>, payments: Payment[]): OrderLedger {
  const rel = payments.filter((p) => p.order_id === order.id);
  const collected = round2(rel.filter((p) => !p.is_refund).reduce((a, p) => a + Math.abs(p.amount), 0));
  const refunded = round2(rel.filter((p) => p.is_refund).reduce((a, p) => a + Math.abs(p.amount), 0));
  const net = round2(collected - refunded);
  const billable = round2(Math.max(0, order.total - refunded));
  const due = round2(Math.max(0, billable - net));

  let payment_status: Order['payment_status'];
  if (refunded > 0 && refunded >= collected && collected > 0) payment_status = 'refunded';
  else if (refunded > 0) payment_status = 'partially_refunded';
  else if (collected <= 0) payment_status = 'pending';
  else if (due > 0) payment_status = 'partial';
  else payment_status = 'paid';

  return { collected, refunded, net, due, payment_status };
}

export function recalcOrderPayments(order: Order, payments: Payment[]): Order {
  const l = computeOrderLedger(order, payments);
  return {
    ...order,
    amount_paid: l.collected,
    amount_refunded: l.refunded,
    outstanding: l.due,
    payment_status: l.payment_status,
  };
}

/* ------------------------------------------------------------------ */
/* Snapshots                                                           */
/* ------------------------------------------------------------------ */
export function buildOrderItem(
  orderId: UUID,
  product: Product,
  opts: { quantity?: number; unit_price?: number; discount?: number; supplierName?: string | null } = {},
): OrderItem {
  const quantity = opts.quantity ?? 1;
  const unit_price = opts.unit_price ?? product.selling_price;
  const discount = opts.discount ?? 0;
  const line_total = round2(unit_price * quantity - discount);
  const line_cost = round2(product.cost_price * quantity);
  return {
    id: newId(),
    order_id: orderId,
    product_id: product.id,
    product_name: product.name,
    product_code: product.code,
    supplier_id: product.supplier_id,
    supplier_name: opts.supplierName ?? null,
    delivery_type: product.delivery_type,
    product_type: product.product_type,
    duration_days: product.duration_days,
    quantity,
    unit_cost: product.cost_price, // immutable snapshot
    unit_price,
    discount,
    line_total,
    line_cost,
    line_profit: round2(line_total - line_cost),
  };
}

export function buildActivation(order: Order, item: OrderItem, orgId: UUID): Activation {
  return {
    id: newId(),
    organization_id: orgId,
    created_at: nowIso(),
    updated_at: nowIso(),
    deleted_at: null,
    order_id: order.id,
    order_item_id: item.id,
    customer_id: order.customer_id,
    product_name: item.product_name,
    status: order.payment_status === 'pending' ? 'waiting_payment' : 'ready',
    priority: 'medium',
    assigned_to: order.assigned_to ?? null,
    supplier_id: item.supplier_id,
    activation_email: null,
    activation_details: null,
    internal_instructions: null,
    proof_url: null,
    activated_at: null,
    delivered_at: null,
    expiry_date: item.duration_days ? addDays(new Date(), item.duration_days).toISOString() : null,
  };
}

export function buildSubscription(
  order: Order,
  item: OrderItem,
  orgId: UUID,
  previousSubscriptionId: UUID | null = null,
  sourceActivationId: UUID | null = null,
): Subscription {
  const start = new Date();
  return {
    id: newId(),
    organization_id: orgId,
    created_at: nowIso(),
    updated_at: nowIso(),
    deleted_at: null,
    customer_id: order.customer_id,
    product_id: item.product_id,
    order_id: order.id,
    order_item_id: item.id,
    source_activation_id: sourceActivationId,
    product_name: item.product_name,
    start_date: start.toISOString(),
    expiry_date: addDays(start, item.duration_days).toISOString(),
    duration_days: item.duration_days, // snapshot — later product changes must not affect this
    purchase_amount: item.line_total,
    cost_amount: item.line_cost,
    profit: item.line_profit,
    supplier_id: item.supplier_id,
    status: 'active',
    reminder_state: 'none',
    assigned_to: order.assigned_to ?? null,
    previous_subscription_id: previousSubscriptionId,
    renewed_to_subscription_id: null,
    notes: null,
  };
}

/* ------------------------------------------------------------------ */
/* Subscription derived state                                          */
/* ------------------------------------------------------------------ */
export function deriveSubscriptionStatus(sub: Subscription, thresholdDays: number): Subscription['status'] {
  if (sub.status === 'renewed' || sub.status === 'cancelled' || sub.status === 'paused' || sub.status === 'pending')
    return sub.status;
  // Compare exact timestamps FIRST. Bucketing by whole days first is wrong:
  // Math.ceil(-1hour / 1day) === -0, and -0 < 0 is false, so a subscription
  // that lapsed within the last 24 hours was reported 'expiring' and stayed in
  // the active renewal pipeline instead of being treated as expired.
  const expiry = new Date(sub.expiry_date).getTime();
  const now = Date.now();
  if (!Number.isFinite(expiry)) return 'active';
  if (expiry <= now) return 'expired';
  const days = Math.ceil((expiry - now) / 86_400_000);
  if (days <= thresholdDays) return 'expiring';
  return 'active';
}

/* ------------------------------------------------------------------ */
/* Duplicate detection (warn, never block)                             */
/* ------------------------------------------------------------------ */
export interface DuplicateWarning {
  field: 'phone' | 'email' | 'whatsapp';
  customer: Customer;
}

const normPhone = (v?: string | null) => (v ?? '').replace(/\D/g, '').slice(-10);
const normEmail = (v?: string | null) => (v ?? '').trim().toLowerCase();

export function findDuplicateCustomers(
  candidate: Partial<Customer>,
  customers: Customer[],
  excludeId?: UUID,
): DuplicateWarning[] {
  const out: DuplicateWarning[] = [];
  for (const c of customers) {
    if (c.id === excludeId || c.deleted_at) continue;
    if (candidate.phone && normPhone(candidate.phone) && normPhone(candidate.phone) === normPhone(c.phone))
      out.push({ field: 'phone', customer: c });
    else if (
      candidate.whatsapp &&
      normPhone(candidate.whatsapp) &&
      normPhone(candidate.whatsapp) === normPhone(c.whatsapp)
    )
      out.push({ field: 'whatsapp', customer: c });
    else if (candidate.email && normEmail(candidate.email) && normEmail(candidate.email) === normEmail(c.email))
      out.push({ field: 'email', customer: c });
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Profit engine                                                       */
/* ------------------------------------------------------------------ */
export interface ProfitSummary {
  grossRevenue: number;
  productCost: number;
  refunds: number;
  grossProfit: number;
  operatingExpenses: number;
  netProfit: number;
  grossMargin: number;
  netMargin: number;
}

export function computeProfit(
  orders: Order[],
  expenses: Database['expenses'],
  range?: { from: Date; to: Date },
): ProfitSummary {
  const inRange = (d: string) => !range || (new Date(d) >= range.from && new Date(d) <= range.to);
  const o = orders.filter((x) => inRange(x.ordered_at) && x.status !== 'cancelled');
  const grossRevenue = round2(o.reduce((a, x) => a + x.total, 0));
  const productCost = round2(o.reduce((a, x) => a + x.total_cost, 0));
  const refunds = round2(o.reduce((a, x) => a + x.amount_refunded, 0));
  const grossProfit = round2(grossRevenue - productCost - refunds);
  const operatingExpenses = round2(
    expenses.filter((e) => inRange(e.spent_at)).reduce((a, e) => a + e.amount, 0),
  );
  const netProfit = round2(grossProfit - operatingExpenses);
  return {
    grossRevenue,
    productCost,
    refunds,
    grossProfit,
    operatingExpenses,
    netProfit,
    grossMargin: grossRevenue ? round2((grossProfit / grossRevenue) * 100) : 0,
    netMargin: grossRevenue ? round2((netProfit / grossRevenue) * 100) : 0,
  };
}

/* ------------------------------------------------------------------ */
/* Template rendering                                                  */
/* ------------------------------------------------------------------ */
export function renderTemplate(body: string, vars: Record<string, string | number>) {
  return body.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, k: string) =>
    k in vars ? String(vars[k]) : `{{${k}}}`,
  );
}

/* ------------------------------------------------------------------ */
/* Webhook events (n8n foundation)                                     */
/* ------------------------------------------------------------------ */
export const WEBHOOK_EVENTS = [
  'order.created',
  'payment.received',
  'subscription.created',
  'subscription.expiring',
  'subscription.expired',
  'renewal.completed',
  'customer.created',
  'support.created',
  'activation.completed',
] as const;
export type WebhookEvent = (typeof WEBHOOK_EVENTS)[number];

/* ------------------------------------------------------------------ */
/* Invoice reconciliation                                              */
/* ------------------------------------------------------------------ */
/**
 * An invoice is a *view* of its order's ledger, not an independent balance.
 * Snapshotting amount_paid at creation time left invoices permanently stale
 * whenever a later payment or refund landed, so paid invoices still showed a
 * balance (and refunded ones still showed "paid").
 *
 * Call this whenever payments change, or use it to project on read.
 */
export interface InvoiceProjection {
  amount_paid: number;
  balance_due: number;
  status: Invoice['status'];
}

export function projectInvoice(
  invoice: Pick<Invoice, 'total' | 'due_date' | 'status'>,
  ledger: { collected: number; refunded: number; due: number },
  now: Date = new Date(),
): InvoiceProjection {
  if (invoice.status === 'void' || invoice.status === 'draft') {
    return { amount_paid: ledger.collected, balance_due: ledger.due, status: invoice.status };
  }
  let status: Invoice['status'];
  if (ledger.due <= 0.005 && ledger.collected > 0) status = 'paid';
  else if (ledger.collected > 0) status = 'partial';
  else if (invoice.due_date && new Date(invoice.due_date) < now) status = 'overdue';
  else status = 'sent';
  return { amount_paid: ledger.collected, balance_due: ledger.due, status };
}

/** Reconcile every invoice in a database against its order's payments. */
export function reconcileInvoices(db: Database, now: Date = new Date()): number {
  let changed = 0;
  for (const inv of db.invoices) {
    if (!inv.order_id) continue;
    const order = db.orders.find((o) => o.id === inv.order_id);
    if (!order) continue;
    const ledger = computeOrderLedger(order, db.payments);
    const next = projectInvoice(inv, ledger, now);
    if (inv.amount_paid !== next.amount_paid || inv.status !== next.status) {
      inv.amount_paid = next.amount_paid;
      inv.status = next.status;
      inv.updated_at = nowIso();
      changed += 1;
    }
  }
  return changed;
}
