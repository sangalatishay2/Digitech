import type { Database } from '@/lib/types';
import { round2 } from '@/lib/utils';

export function supplierBalance(db: Database, supplierId: string) {
  let purchased = 0;
  for (const o of db.orders) {
    if (o.status === 'cancelled') continue;
    for (const i of o.items) if (i.supplier_id === supplierId) purchased += i.line_cost;
  }
  const paid = db.supplier_payments.filter((p) => p.supplier_id === supplierId).reduce((a, p) => a + p.amount, 0);
  return {
    purchased: round2(purchased),
    paid: round2(paid),
    balance: round2(Math.max(0, purchased - paid)),
  };
}

export function supplierPurchaseHistory(db: Database, supplierId: string) {
  return db.orders
    .flatMap((o) => o.items.filter((i) => i.supplier_id === supplierId).map((i) => ({ order: o, item: i })))
    .sort((a, b) => b.order.ordered_at.localeCompare(a.order.ordered_at));
}
