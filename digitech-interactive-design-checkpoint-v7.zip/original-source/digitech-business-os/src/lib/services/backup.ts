/**
 * Backup export / restore with versioned schema validation.
 *
 * Restoring previously did `Object.assign(db, JSON.parse(file))` after checking
 * that two keys existed. That let a malformed or hostile file replace the whole
 * workspace with partial data, mixed organizations, or dangling references —
 * with no permission check and no confirmation.
 */
import { z } from 'zod';
import type { Database } from '@/lib/types';

export const BACKUP_FORMAT_VERSION = 3;

const row = z.object({ id: z.string().min(1) }).catchall(z.unknown());
const orgScoped = row.extend({ organization_id: z.string().min(1) });

const table = <T extends z.ZodTypeAny>(schema: T) => z.array(schema);

export const BackupSchema = z.object({
  __format_version: z.number().int().positive().optional(),
  organizations: table(row).min(1, 'backup contains no organization'),
  profiles: table(orgScoped),
  customers: table(orgScoped),
  products: table(orgScoped),
  suppliers: table(orgScoped),
  orders: table(orgScoped),
  payments: table(orgScoped),
  activations: table(orgScoped),
  subscriptions: table(orgScoped),
  invoices: table(orgScoped),
  expenses: table(orgScoped),
  leads: table(orgScoped),
  support_tickets: table(orgScoped),
  tasks: table(orgScoped),
  notifications: table(orgScoped),
  approval_requests: table(orgScoped).default([]),
  activity_logs: table(orgScoped),
}).catchall(z.unknown());

export interface BackupCheck {
  ok: boolean;
  version: number;
  errors: string[];
  warnings: string[];
  counts: Record<string, number>;
}

/** Structural + referential validation, run BEFORE any data is replaced. */
export function validateBackup(raw: unknown): BackupCheck {
  const errors: string[] = [];
  const warnings: string[] = [];

  const parsed = BackupSchema.safeParse(raw);
  if (!parsed.success) {
    return {
      ok: false,
      version: 0,
      errors: parsed.error.issues.slice(0, 12).map((i) => `${i.path.join('.') || '(root)'}: ${i.message}`),
      warnings,
      counts: {},
    };
  }

  const db = parsed.data as unknown as Database;
  const version = (raw as { __format_version?: number }).__format_version ?? 1;
  if (version > BACKUP_FORMAT_VERSION) {
    errors.push(`backup format v${version} is newer than this app supports (v${BACKUP_FORMAT_VERSION})`);
  }

  // Single-tenant consistency: every row must belong to the backup's org.
  const orgIds = new Set(db.organizations.map((o) => o.id));
  const scoped: (keyof Database)[] = [
    'profiles', 'customers', 'products', 'suppliers', 'orders', 'payments',
    'activations', 'subscriptions', 'invoices', 'expenses', 'leads',
    'support_tickets', 'tasks', 'notifications', 'approval_requests', 'activity_logs',
  ];
  for (const t of scoped) {
    const rows = (db[t] ?? []) as unknown as { organization_id: string }[];
    const foreign = rows.filter((r) => !orgIds.has(r.organization_id)).length;
    if (foreign) errors.push(`${String(t)}: ${foreign} row(s) reference an organization not in the backup`);
  }

  // Referential integrity on the money path.
  const customerIds = new Set(db.customers.map((c) => c.id));
  const orderIds = new Set(db.orders.map((o) => o.id));
  const orphanOrders = db.orders.filter((o) => !customerIds.has(o.customer_id)).length;
  if (orphanOrders) errors.push(`orders: ${orphanOrders} reference a missing customer`);
  const orphanPayments = db.payments.filter((p) => !orderIds.has(p.order_id)).length;
  if (orphanPayments) errors.push(`payments: ${orphanPayments} reference a missing order`);
  const orphanInv = db.invoices.filter((i) => i.order_id && !orderIds.has(i.order_id)).length;
  if (orphanInv) warnings.push(`invoices: ${orphanInv} reference a missing order`);

  // Duplicate primary keys would silently shadow records.
  for (const t of ['customers', 'orders', 'payments', 'products'] as (keyof Database)[]) {
    const rows = (db[t] ?? []) as unknown as { id: string }[];
    if (new Set(rows.map((r) => r.id)).size !== rows.length)
      errors.push(`${String(t)}: duplicate ids present`);
  }

  const counts: Record<string, number> = {};
  for (const [k, v] of Object.entries(db)) if (Array.isArray(v)) counts[k] = v.length;

  return { ok: errors.length === 0, version, errors, warnings, counts };
}

export function buildBackup(db: Database): string {
  return JSON.stringify({ __format_version: BACKUP_FORMAT_VERSION, ...db }, null, 2);
}

/** Migrate an older backup forward. */
export function migrateBackup(raw: Record<string, unknown>): Record<string, unknown> {
  const version = Number(raw.__format_version ?? 1);
  const out = { ...raw };
  if (version < 2) {
    // v1 had no reserved_stock / subscription linkage columns.
    const products = out.products;
    if (Array.isArray(products)) {
      out.products = products.map((p) =>
        typeof p === 'object' && p ? { reserved_stock: 0, ...(p as object) } : p,
      );
    }
  }
  if (version < 3 && !Array.isArray(out.approval_requests)) out.approval_requests = [];
  out.__format_version = BACKUP_FORMAT_VERSION;
  return out;
}
