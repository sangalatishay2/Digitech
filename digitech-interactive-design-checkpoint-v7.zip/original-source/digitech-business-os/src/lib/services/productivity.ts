import type { Database, UUID } from '@/lib/types';

export type ProductivityItemKind =
  | 'task'
  | 'renewal'
  | 'payment'
  | 'lead'
  | 'activation'
  | 'support';

export type ProductivitySeverity = 'critical' | 'high' | 'medium' | 'low';

export interface ProductivityItem {
  id: string;
  kind: ProductivityItemKind;
  title: string;
  subtitle: string;
  href: string;
  severity: ProductivitySeverity;
  dueAt: string | null;
  assignedTo: UUID | null;
  amount?: number;
  score: number;
}

export interface ProductivityQueueOptions {
  now?: Date;
  userId?: UUID | null;
  can?: (action: string) => boolean;
  limit?: number;
}

export interface CustomerNextAction {
  id: string;
  title: string;
  subtitle: string;
  href: string;
  severity: ProductivitySeverity;
  actionLabel: string;
  score: number;
}

const ACCESS: Record<ProductivityItemKind, string> = {
  task: 'tasks.read',
  renewal: 'subscriptions.read',
  payment: 'payments.read',
  lead: 'leads.read',
  activation: 'activations.read',
  support: 'support.read',
};

const SEVERITY_SCORE: Record<ProductivitySeverity, number> = {
  critical: 400,
  high: 300,
  medium: 200,
  low: 100,
};

function endOfDay(date: Date) {
  const value = new Date(date);
  value.setHours(23, 59, 59, 999);
  return value;
}

function daysFrom(now: Date, value: string) {
  return Math.ceil((new Date(value).getTime() - now.getTime()) / 86_400_000);
}

function urgencyScore(severity: ProductivitySeverity, dueAt: string | null, now: Date) {
  if (!dueAt) return SEVERITY_SCORE[severity];
  const days = daysFrom(now, dueAt);
  return SEVERITY_SCORE[severity] + Math.max(-30, Math.min(60, 30 - days));
}

/**
 * Build one cross-module work queue from already organization-scoped data.
 * This service never broadens access: callers pass the same RBAC predicate used
 * by the rest of the app, and unreadable entity types are excluded completely.
 */
export function buildProductivityQueue(
  db: Database,
  options: ProductivityQueueOptions = {},
): ProductivityItem[] {
  const now = options.now ?? new Date();
  const todayEnd = endOfDay(now);
  const can = options.can ?? (() => true);
  const limit = options.limit ?? 50;
  const queue: ProductivityItem[] = [];
  const allowed = (kind: ProductivityItemKind) => can(ACCESS[kind]);
  const customerName = (id: string) => db.customers.find((customer) => customer.id === id)?.name ?? 'Unknown customer';
  const assigneeName = (id?: string | null) => db.profiles.find((profile) => profile.id === id)?.full_name;

  const add = (item: Omit<ProductivityItem, 'score'>) => {
    queue.push({ ...item, score: urgencyScore(item.severity, item.dueAt, now) });
  };

  if (allowed('task')) {
    for (const task of db.tasks) {
      if (task.deleted_at || ['done', 'cancelled'].includes(task.status)) continue;
      const due = task.due_at ? new Date(task.due_at) : null;
      if (!due && task.priority !== 'urgent') continue;
      if (due && due > todayEnd && task.priority !== 'urgent') continue;
      const overdue = Boolean(due && due < now);
      add({
        id: task.id,
        kind: 'task',
        title: task.title,
        subtitle: `${overdue ? 'Overdue' : 'Due today'}${assigneeName(task.assigned_to) ? ` · ${assigneeName(task.assigned_to)}` : ' · Unassigned'}`,
        href: `/tasks?focus=${task.id}`,
        severity: overdue || task.priority === 'urgent' ? 'critical' : task.priority === 'high' ? 'high' : 'medium',
        dueAt: task.due_at ?? null,
        assignedTo: task.assigned_to ?? null,
      });
    }
  }

  if (allowed('lead')) {
    for (const lead of db.leads) {
      if (lead.deleted_at || !lead.follow_up_at || ['won', 'lost'].includes(lead.status)) continue;
      const followUp = new Date(lead.follow_up_at);
      if (followUp > todayEnd) continue;
      const overdue = followUp < now;
      add({
        id: lead.id,
        kind: 'lead',
        title: `Follow up with ${lead.name}`,
        subtitle: `${lead.company ?? lead.status}${lead.value ? ` · ₹${lead.value.toLocaleString('en-IN')} opportunity` : ''}`,
        href: `/leads?focus=${lead.id}`,
        severity: overdue ? 'high' : 'medium',
        dueAt: lead.follow_up_at,
        assignedTo: lead.assigned_to ?? null,
        amount: lead.value,
      });
    }
  }

  if (allowed('renewal')) {
    const threshold = db.organizations[0]?.expiry_threshold_days ?? 15;
    for (const subscription of db.subscriptions) {
      if (subscription.deleted_at || !['active', 'expiring', 'expired'].includes(subscription.status)) continue;
      const days = daysFrom(now, subscription.expiry_date);
      if (days > threshold) continue;
      add({
        id: subscription.id,
        kind: 'renewal',
        title: `${subscription.product_name} renewal`,
        subtitle: `${customerName(subscription.customer_id)} · ${days < 0 ? `${Math.abs(days)} days expired` : days === 0 ? 'Expires today' : `${days} days left`}`,
        href: `/renewals?subscription=${subscription.id}`,
        severity: days < 0 ? 'critical' : days <= 3 ? 'high' : 'medium',
        dueAt: subscription.expiry_date,
        assignedTo: subscription.assigned_to ?? null,
        amount: subscription.purchase_amount,
      });
    }
  }

  if (allowed('payment')) {
    for (const order of db.orders) {
      if (order.deleted_at || order.outstanding <= 0 || ['cancelled', 'refunded'].includes(order.status)) continue;
      add({
        id: order.id,
        kind: 'payment',
        title: `Collect ₹${order.outstanding.toLocaleString('en-IN')}`,
        subtitle: `${customerName(order.customer_id)} · ${order.order_number}`,
        href: `/orders/${order.id}`,
        severity: order.payment_status === 'failed' || order.outstanding >= 10_000 ? 'high' : 'medium',
        dueAt: null,
        assignedTo: order.assigned_to ?? null,
        amount: order.outstanding,
      });
    }
  }

  if (allowed('activation')) {
    for (const activation of db.activations) {
      if (activation.deleted_at || !['ready', 'processing', 'waiting_supplier', 'failed'].includes(activation.status)) continue;
      add({
        id: activation.id,
        kind: 'activation',
        title: `${activation.product_name} activation`,
        subtitle: `${customerName(activation.customer_id)} · ${activation.status.replace('_', ' ')}`,
        href: `/activations?focus=${activation.id}`,
        severity: activation.status === 'failed' || activation.priority === 'urgent' ? 'critical' : activation.priority === 'high' ? 'high' : 'medium',
        dueAt: activation.created_at,
        assignedTo: activation.assigned_to ?? null,
      });
    }
  }

  if (allowed('support')) {
    for (const ticket of db.support_tickets) {
      if (ticket.deleted_at || !['open', 'in_progress'].includes(ticket.status)) continue;
      const due = ticket.due_at ? new Date(ticket.due_at) : null;
      const overdue = Boolean(due && due < now);
      if (!overdue && !['urgent', 'high'].includes(ticket.priority)) continue;
      add({
        id: ticket.id,
        kind: 'support',
        title: ticket.subject,
        subtitle: `${ticket.ticket_number} · ${customerName(ticket.customer_id)}`,
        href: `/support/${ticket.id}`,
        severity: overdue || ticket.priority === 'urgent' ? 'critical' : 'high',
        dueAt: ticket.due_at ?? null,
        assignedTo: ticket.assigned_to ?? null,
      });
    }
  }

  return queue
    .sort((a, b) => b.score - a.score || (a.dueAt ?? '9999').localeCompare(b.dueAt ?? '9999') || a.title.localeCompare(b.title))
    .slice(0, Math.max(0, limit));
}

export function productivitySummary(items: ProductivityItem[], userId?: UUID | null) {
  return {
    total: items.length,
    critical: items.filter((item) => item.severity === 'critical').length,
    mine: userId ? items.filter((item) => item.assignedTo === userId).length : 0,
    unassigned: items.filter((item) => !item.assignedTo).length,
  };
}

export function buildCustomerNextActions(
  db: Database,
  customerId: UUID,
  options: Pick<ProductivityQueueOptions, 'now' | 'can' | 'limit'> = {},
): CustomerNextAction[] {
  const now = options.now ?? new Date();
  const can = options.can ?? (() => true);
  const limit = options.limit ?? 4;
  const actions: CustomerNextAction[] = [];
  const add = (action: Omit<CustomerNextAction, 'score'>, dueAt: string | null = null) => {
    actions.push({ ...action, score: urgencyScore(action.severity, dueAt, now) });
  };

  const unpaid = db.orders
    .filter((order) => order.customer_id === customerId && order.outstanding > 0 && !['cancelled', 'refunded'].includes(order.status))
    .sort((a, b) => b.outstanding - a.outstanding)[0];
  if (unpaid && can('payments.read')) {
    add({
      id: `payment-${unpaid.id}`,
      title: `Collect ₹${unpaid.outstanding.toLocaleString('en-IN')}`,
      subtitle: `${unpaid.order_number} still has an outstanding balance`,
      href: `/orders/${unpaid.id}`,
      severity: unpaid.outstanding >= 10_000 || unpaid.payment_status === 'failed' ? 'critical' : 'high',
      actionLabel: 'Collect payment',
    });
  }

  const threshold = db.organizations[0]?.expiry_threshold_days ?? 15;
  const renewal = db.subscriptions
    .filter((subscription) => subscription.customer_id === customerId && !['renewed', 'cancelled'].includes(subscription.status))
    .filter((subscription) => daysFrom(now, subscription.expiry_date) <= threshold)
    .sort((a, b) => a.expiry_date.localeCompare(b.expiry_date))[0];
  if (renewal && can('subscriptions.read')) {
    const days = daysFrom(now, renewal.expiry_date);
    add({
      id: `renewal-${renewal.id}`,
      title: `${renewal.product_name} renewal`,
      subtitle: days < 0 ? `Expired ${Math.abs(days)} days ago` : days === 0 ? 'Expires today' : `Expires in ${days} days`,
      href: `/orders/new?renew=${renewal.id}`,
      severity: days <= 0 ? 'critical' : days <= 3 ? 'high' : 'medium',
      actionLabel: 'Start renewal',
    }, renewal.expiry_date);
  }

  const ticket = db.support_tickets
    .filter((item) => item.customer_id === customerId && ['open', 'in_progress'].includes(item.status))
    .sort((a, b) => {
      const rank = { urgent: 4, high: 3, medium: 2, low: 1 };
      return rank[b.priority] - rank[a.priority] || (a.due_at ?? '9999').localeCompare(b.due_at ?? '9999');
    })[0];
  if (ticket && can('support.read')) {
    const overdue = Boolean(ticket.due_at && new Date(ticket.due_at) < now);
    add({
      id: `ticket-${ticket.id}`,
      title: ticket.subject,
      subtitle: `${ticket.ticket_number} · ${ticket.status.replace('_', ' ')}`,
      href: `/support/${ticket.id}`,
      severity: overdue || ticket.priority === 'urgent' ? 'critical' : 'high',
      actionLabel: 'Resolve ticket',
    }, ticket.due_at ?? null);
  }

  const task = db.tasks
    .filter((item) => item.entity_type === 'customer' && item.entity_id === customerId && !['done', 'cancelled'].includes(item.status))
    .sort((a, b) => (a.due_at ?? '9999').localeCompare(b.due_at ?? '9999'))[0];
  if (task && can('tasks.read')) {
    const overdue = Boolean(task.due_at && new Date(task.due_at) < now);
    add({
      id: `task-${task.id}`,
      title: task.title,
      subtitle: overdue ? 'Customer follow-up task is overdue' : 'Open customer follow-up task',
      href: `/tasks?focus=${task.id}`,
      severity: overdue ? 'high' : 'medium',
      actionLabel: 'Open task',
    }, task.due_at ?? null);
  }

  const hasOrders = db.orders.some((order) => order.customer_id === customerId && order.status !== 'cancelled');
  if (!hasOrders && can('orders.create')) {
    add({
      id: `first-order-${customerId}`,
      title: 'No order recorded yet',
      subtitle: 'Convert this customer by creating their first order',
      href: `/orders/new?customer=${customerId}`,
      severity: 'low',
      actionLabel: 'Create order',
    });
  }

  return actions.sort((a, b) => b.score - a.score || a.title.localeCompare(b.title)).slice(0, Math.max(0, limit));
}
