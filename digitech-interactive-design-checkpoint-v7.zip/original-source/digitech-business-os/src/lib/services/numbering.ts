/**
 * Business document numbering.
 *
 * The previous scheme was `PREFIX + (base + rows.length)`, which produces a
 * DUPLICATE the moment any row is deleted (delete ORD-1005 and the next order
 * reuses 1005). Here we derive the next value from the highest number actually
 * issued, so the sequence is monotonic and gap-tolerant.
 *
 * In production this must be the database sequence added in
 * 0015_financial_integrity.sql (`next_business_number`), which is atomic under
 * concurrency; this client-side helper is the demo-mode equivalent and is
 * backed by the same unique constraints.
 */
import type { Database } from '@/lib/types';

export type NumberKind = 'order' | 'invoice' | 'customer' | 'ticket';

const CONFIG: Record<NumberKind, { prefix: string; start: number; table: keyof Database; field: string }> = {
  order:    { prefix: 'ORD-', start: 1001, table: 'orders',          field: 'order_number' },
  invoice:  { prefix: 'INV-', start: 501,  table: 'invoices',        field: 'invoice_number' },
  customer: { prefix: 'DT-',  start: 1001, table: 'customers',       field: 'customer_code' },
  ticket:   { prefix: 'TKT-', start: 2000, table: 'support_tickets', field: 'ticket_number' },
};

export function peekNumber(db: Database, kind: NumberKind): number {
  const { prefix, start, table, field } = CONFIG[kind];
  const rows = (db[table] ?? []) as unknown as Record<string, unknown>[];
  let max = start - 1;
  for (const r of rows) {
    const raw = r?.[field];
    if (typeof raw !== 'string' || !raw.startsWith(prefix)) continue;
    const n = parseInt(raw.slice(prefix.length), 10);
    if (Number.isFinite(n) && n > max) max = n;
  }
  return max + 1;
}

export function nextNumber(db: Database, kind: NumberKind): string {
  return CONFIG[kind].prefix + peekNumber(db, kind);
}
