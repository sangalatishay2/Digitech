/**
 * CSV import/export with formula-injection protection.
 *
 * Spreadsheet applications execute a cell beginning with = + - @ (and the
 * control characters TAB / CR) as a formula. An attacker who gets a crafted
 * value stored (e.g. a customer name of `=HYPERLINK("http://evil","click")`)
 * achieves code execution on any machine that opens the export. Every exported
 * field is therefore neutralised with a leading apostrophe.
 */
const FORMULA_PREFIX = /^[=+\-@\t\r]/;

export function sanitizeCsvValue(value: unknown): string {
  const s = value === null || value === undefined ? '' : String(value);
  return FORMULA_PREFIX.test(s) ? `'${s}` : s;
}

export function csvCell(value: unknown): string {
  return `"${sanitizeCsvValue(value).replace(/"/g, '""')}"`;
}

export function toCsv(headers: string[], rows: unknown[][]): string {
  const head = headers.map((h) => csvCell(h)).join(',');
  const body = rows.map((r) => r.map((c) => csvCell(c)).join(',')).join('\n');
  return body ? `${head}\n${body}` : head;
}

/**
 * RFC 4180 parser: handles quoted fields, escaped quotes (""), embedded commas
 * and newlines, and CRLF. The previous implementation split on commas and
 * newlines, so any quoted field containing either corrupted the whole import.
 */
export function parseCsv(text: string): { headers: string[]; rows: string[][] } {
  const src = text.replace(/^\uFEFF/, ''); // strip BOM
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;
  let i = 0;

  const endField = () => { row.push(field); field = ''; };
  const endRow = () => { endField(); rows.push(row); row = []; };

  while (i < src.length) {
    const ch = src[i];
    if (inQuotes) {
      if (ch === '"') {
        if (src[i + 1] === '"') { field += '"'; i += 2; continue; }
        inQuotes = false; i++; continue;
      }
      field += ch; i++; continue;
    }
    if (ch === '"') { inQuotes = true; i++; continue; }
    if (ch === ',') { endField(); i++; continue; }
    if (ch === '\r') { i++; continue; }
    if (ch === '\n') { endRow(); i++; continue; }
    field += ch; i++;
  }
  if (field.length > 0 || row.length > 0) endRow();

  const nonEmpty = rows.filter((r) => r.some((c) => c.trim() !== ''));
  const headers = (nonEmpty.shift() ?? []).map((h) => h.trim());
  return { headers, rows: nonEmpty };
}

/* ------------------------------------------------------------------ */
/* Row validation                                                      */
/* ------------------------------------------------------------------ */
export interface RowIssue { row: number; field: string; message: string }

export function validateEnum<T extends string>(
  value: string, allowed: readonly T[], field: string, row: number,
): { ok: true; value: T } | { ok: false; issue: RowIssue } {
  const v = value?.trim().toLowerCase().replace(/[\s-]+/g, '_');
  const hit = allowed.find((a) => a.toLowerCase() === v);
  if (hit) return { ok: true, value: hit };
  return {
    ok: false,
    issue: { row, field, message: `"${value}" is not one of: ${allowed.join(', ')}` },
  };
}

export function validateNumber(
  value: string, field: string, row: number, opts: { min?: number; integer?: boolean } = {},
): { ok: true; value: number } | { ok: false; issue: RowIssue } {
  const raw = (value ?? '').toString().replace(/[, ₹]/g, '').trim();
  if (raw === '') return { ok: true, value: 0 };
  const n = Number(raw);
  if (!Number.isFinite(n))
    return { ok: false, issue: { row, field, message: `"${value}" is not a number` } };
  if (opts.integer && !Number.isInteger(n))
    return { ok: false, issue: { row, field, message: `"${value}" must be a whole number` } };
  if (opts.min !== undefined && n < opts.min)
    return { ok: false, issue: { row, field, message: `must be >= ${opts.min}` } };
  return { ok: true, value: n };
}
