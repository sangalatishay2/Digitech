import { APPROVAL_TYPES, type ApprovalRequest, type ApprovalRisk, type ApprovalType } from '@/lib/types';

export interface ApprovalInput {
  request_type: ApprovalType;
  title: string;
  description?: string;
  reason: string;
  risk_level?: ApprovalRisk;
  entity_type?: string | null;
  entity_id?: string | null;
  financial_impact?: number;
  payload?: Record<string, unknown>;
  expires_at?: string | null;
}

const SECRET_KEY = /(password|passcode|secret|token|api[_-]?key|credential|private[_-]?key)/i;
const SECRET_VALUE = /(?:bearer\s+[a-z0-9._~+/=-]{12,}|(?:api[_-]?key|token|password|secret)\s*[:=]\s*\S{8,}|\bsk-[a-z0-9_-]{16,})/i;

export function payloadContainsSecret(value: unknown, depth = 0): boolean {
  if (depth > 8 || value === null) return false;
  if (typeof value === 'string') return SECRET_VALUE.test(value);
  if (typeof value !== 'object') return false;
  if (Array.isArray(value)) return value.some((item) => payloadContainsSecret(item, depth + 1));
  for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
    if (SECRET_KEY.test(key)) return true;
    if (payloadContainsSecret(child, depth + 1)) return true;
  }
  return false;
}

export function inferApprovalRisk(type: ApprovalType, financialImpact = 0): ApprovalRisk {
  if (type === 'secret_access' || type === 'account_change' || financialImpact >= 50_000) return 'critical';
  if (['refund', 'supplier_payment', 'bulk_message', 'data_export', 'ai_action'].includes(type) || financialImpact >= 10_000) return 'high';
  if (type === 'discount' || type === 'expense' || financialImpact > 0) return 'medium';
  return 'low';
}

export function validateApprovalInput(input: ApprovalInput): string[] {
  const errors: string[] = [];
  if (!APPROVAL_TYPES.includes(input.request_type)) errors.push('Unsupported request type.');
  const title = input.title.trim();
  const reason = input.reason.trim();
  if (title.length < 3 || title.length > 160) errors.push('Title must be between 3 and 160 characters.');
  if (reason.length < 3 || reason.length > 1000) errors.push('Reason must be between 3 and 1000 characters.');
  if ((input.description?.length ?? 0) > 4000) errors.push('Description cannot exceed 4000 characters.');
  if (!Number.isFinite(input.financial_impact ?? 0) || (input.financial_impact ?? 0) < 0) {
    errors.push('Financial impact must be zero or a positive number.');
  }
  if (input.expires_at && new Date(input.expires_at).getTime() <= Date.now()) {
    errors.push('Expiry must be in the future.');
  }
  if (payloadContainsSecret(input.payload ?? {})) {
    errors.push('Approval payloads cannot contain passwords, API keys, tokens, credentials, or other secrets.');
  }
  if (input.request_type === 'ai_action') {
    const command = input.payload?.command;
    if (typeof command !== 'string' || command.trim().length < 3 || command.length > 8000) {
      errors.push('AI action instruction must be between 3 and 8000 characters.');
    }
  }
  const payloadBytes = new TextEncoder().encode(JSON.stringify(input.payload ?? {})).length;
  if (payloadBytes > 60_000) errors.push('Approval payload is too large.');
  return errors;
}

export function canReviewApproval(request: ApprovalRequest, decision: 'approved' | 'rejected', now = new Date()): string | null {
  if (request.status !== 'pending') return 'This approval request has already been finalized.';
  if (!['approved', 'rejected'].includes(decision)) return 'Unsupported review decision.';
  if (decision === 'approved' && request.expires_at && new Date(request.expires_at) <= now) {
    return 'This approval request has expired.';
  }
  return null;
}

export function approvalJobKey(id: string) {
  return `approval:${id}`;
}
