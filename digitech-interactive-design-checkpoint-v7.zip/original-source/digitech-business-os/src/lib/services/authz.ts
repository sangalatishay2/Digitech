/**
 * Central authorization.
 *
 * This module is the single source of truth for "may this actor do X". It is
 * used by the UI *and* by every mutation in the store, so a hidden button is
 * never the only thing standing between a user and a write.
 *
 * In production the same matrix is enforced again by Postgres RLS
 * (supabase/migrations/0016_rls_rewrite.sql). Defence in depth is intentional:
 * client checks are UX, server checks are security.
 */
import type { Profile, Role, UUID } from '@/lib/types';

export const ROLE_PERMISSIONS: Record<Role, string[]> = {
  owner: ['*'],
  admin: ['*'],
  sales: [
    'customers.*', 'orders.*', 'leads.*', 'payments.read', 'subscriptions.*',
    'tasks.*', 'products.read', 'analytics.read', 'communications.*', 'approvals.read', 'approvals.create',
  ],
  support: [
    'customers.read', 'support.*', 'tasks.*', 'orders.read',
    'subscriptions.read', 'products.read', 'communications.*', 'approvals.read', 'approvals.create',
  ],
  accounts: [
    'payments.*', 'invoices.*', 'expenses.*', 'finance.*', 'orders.read',
    'customers.read', 'analytics.read', 'communications.read', 'approvals.read', 'approvals.create',
  ],
  operations: [
    'activations.*', 'orders.read', 'subscriptions.*', 'products.*',
    'suppliers.*', 'tasks.*', 'customers.read', 'communications.read', 'approvals.read', 'approvals.create',
  ],
  viewer: ['*.read'],
};

export function roleAllows(role: Role, action: string): boolean {
  const perms = ROLE_PERMISSIONS[role] ?? [];
  return perms.some((p) => {
    if (p === '*') return true;
    if (p === action) return true;
    if (p.endsWith('.*')) return action.startsWith(p.slice(0, -1));
    if (p.startsWith('*.')) return action.endsWith(p.slice(1));
    return false;
  });
}

export interface Actor {
  id: UUID;
  organization_id: UUID;
  role: Role;
  is_active: boolean;
  deleted_at?: string | null;
}

export function toActor(p: Profile | null | undefined): Actor | null {
  if (!p) return null;
  return {
    id: p.id,
    organization_id: p.organization_id,
    role: p.role,
    is_active: p.is_active,
    deleted_at: p.deleted_at ?? null,
  };
}

/**
 * A disabled or soft-deleted profile can never act, regardless of role.
 * The previous implementation checked only the role, so deactivating a user
 * left them fully capable until they logged out.
 */
export function actorCan(actor: Actor | null, action: string): boolean {
  if (!actor) return false;
  if (!actor.is_active) return false;
  if (actor.deleted_at) return false;
  return roleAllows(actor.role, action);
}

/** Org-scoped variant: also rejects acting on another tenant's records. */
export function actorCanInOrg(actor: Actor | null, action: string, orgId: UUID | null | undefined): boolean {
  if (!actorCan(actor, action)) return false;
  if (orgId && actor && actor.organization_id !== orgId) return false;
  return true;
}

export class AuthorizationError extends Error {
  readonly action: string;
  constructor(action: string, detail = 'not permitted') {
    super(`Authorization failed for "${action}": ${detail}`);
    this.name = 'AuthorizationError';
    this.action = action;
  }
}

/** Throwing guard for mutation paths. */
export function assertCan(actor: Actor | null, action: string, orgId?: UUID | null): void {
  if (!actor) throw new AuthorizationError(action, 'no authenticated actor');
  if (!actor.is_active) throw new AuthorizationError(action, 'profile is disabled');
  if (actor.deleted_at) throw new AuthorizationError(action, 'profile is deleted');
  if (!roleAllows(actor.role, action))
    throw new AuthorizationError(action, `role "${actor.role}" lacks this capability`);
  if (orgId && actor.organization_id !== orgId)
    throw new AuthorizationError(action, 'cross-organization access denied');
}
