import type { Database, Order } from '@/lib/types';
import { computePeriod, refundRateFor, averageLifetimeValue } from './finance';
import { round2 } from '@/lib/utils';

export type RangeKey = 'today' | 'yesterday' | '7d' | '30d' | 'this_month' | 'last_month' | 'all' | 'custom';

export interface DateRange {
  from: Date;
  to: Date;
  label: string;
}

export function resolveRange(key: RangeKey, custom?: { from: string; to: string }): DateRange {
  const now = new Date();
  const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const endOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);

  switch (key) {
    case 'today':
      return { from: startOfDay(now), to: endOfDay(now), label: 'Today' };
    case 'yesterday': {
      const y = new Date(now);
      y.setDate(y.getDate() - 1);
      return { from: startOfDay(y), to: endOfDay(y), label: 'Yesterday' };
    }
    case '7d': {
      const f = new Date(now);
      f.setDate(f.getDate() - 6);
      return { from: startOfDay(f), to: endOfDay(now), label: 'Last 7 days' };
    }
    case '30d': {
      const f = new Date(now);
      f.setDate(f.getDate() - 29);
      return { from: startOfDay(f), to: endOfDay(now), label: 'Last 30 days' };
    }
    case 'this_month':
      return { from: new Date(now.getFullYear(), now.getMonth(), 1), to: endOfDay(now), label: 'This month' };
    case 'last_month':
      return {
        from: new Date(now.getFullYear(), now.getMonth() - 1, 1),
        to: endOfDay(new Date(now.getFullYear(), now.getMonth(), 0)),
        label: 'Last month',
      };
    case 'custom':
      return {
        from: startOfDay(new Date(custom?.from ?? now)),
        to: endOfDay(new Date(custom?.to ?? now)),
        label: 'Custom',
      };
    default:
      return { from: new Date(2000, 0, 1), to: endOfDay(now), label: 'All time' };
  }
}

export const RANGE_OPTIONS: { key: RangeKey; label: string }[] = [
  { key: 'today', label: 'Today' },
  { key: 'yesterday', label: 'Yesterday' },
  { key: '7d', label: '7 Days' },
  { key: '30d', label: '30 Days' },
  { key: 'this_month', label: 'This Month' },
  { key: 'last_month', label: 'Last Month' },
  { key: 'all', label: 'All Time' },
  { key: 'custom', label: 'Custom' },
];

export interface Kpis {
  revenue: number;
  grossProfit: number;
  netProfit: number;
  orders: number;
  aov: number;
  newCustomers: number;
  activeSubscriptions: number;
  renewalsDue: number;
  outstanding: number;
  pendingActivations: number;
  expenses: number;
  grossMargin: number;
  netMargin: number;
}

const within = (d: string, r: DateRange) => {
  const t = new Date(d).getTime();
  return t >= r.from.getTime() && t <= r.to.getTime();
};

export function computeKpis(db: Database, range: DateRange): Kpis {
  // Single source of truth -- see src/lib/services/finance.ts. Previously this
  // summed order.total directly (ignoring refunds) while the P&L subtracted
  // them, so the dashboard and the profit page disagreed.
  const p = computePeriod(db, range);
  return {
    revenue: p.grossRevenue,
    grossProfit: p.grossProfit,
    netProfit: p.netProfit,
    orders: p.orderCount,
    aov: p.aov,
    newCustomers: db.customers.filter((c) => within(c.created_at, range)).length,
    activeSubscriptions: db.subscriptions.filter((s) => s.status === 'active' || s.status === 'expiring').length,
    renewalsDue: db.subscriptions.filter((s) => s.status === 'expiring').length,
    outstanding: p.outstanding,
    pendingActivations: db.activations.filter((a) => ['ready', 'processing', 'waiting_supplier', 'waiting_payment'].includes(a.status)).length,
    expenses: p.operatingExpenses,
    grossMargin: p.grossMargin,
    netMargin: p.netMargin,
  };
}

export interface SeriesPoint {
  label: string;
  revenue: number;
  profit: number;
  orders: number;
  expenses: number;
}

export function buildSeries(db: Database, range: DateRange): SeriesPoint[] {
  const spanDays = Math.max(1, Math.ceil((range.to.getTime() - range.from.getTime()) / 86_400_000));
  const bucketBy: 'day' | 'week' | 'month' = spanDays <= 31 ? 'day' : spanDays <= 120 ? 'week' : 'month';

  const keyOf = (d: Date) => {
    if (bucketBy === 'day') return d.toISOString().slice(0, 10);
    if (bucketBy === 'month') return d.toISOString().slice(0, 7);
    const start = new Date(d);
    start.setDate(start.getDate() - start.getDay());
    return start.toISOString().slice(0, 10);
  };
  const labelOf = (key: string) => {
    const d = new Date(key.length === 7 ? `${key}-01` : key);
    return bucketBy === 'month'
      ? d.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' })
      : d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
  };

  const buckets = new Map<string, SeriesPoint>();
  const cursor = new Date(range.from);
  while (cursor <= range.to) {
    const k = keyOf(cursor);
    if (!buckets.has(k)) buckets.set(k, { label: labelOf(k), revenue: 0, profit: 0, orders: 0, expenses: 0 });
    cursor.setDate(cursor.getDate() + (bucketBy === 'month' ? 28 : 1));
  }

  for (const o of db.orders) {
    if (!within(o.ordered_at, range) || o.status === 'cancelled') continue;
    const k = keyOf(new Date(o.ordered_at));
    const b = buckets.get(k) ?? { label: labelOf(k), revenue: 0, profit: 0, orders: 0, expenses: 0 };
    b.revenue = round2(b.revenue + o.total);
    b.profit = round2(b.profit + o.profit);
    b.orders += 1;
    buckets.set(k, b);
  }
  for (const e of db.expenses) {
    if (!within(e.spent_at, range)) continue;
    const k = keyOf(new Date(e.spent_at));
    const b = buckets.get(k) ?? { label: labelOf(k), revenue: 0, profit: 0, orders: 0, expenses: 0 };
    b.expenses = round2(b.expenses + e.amount);
    buckets.set(k, b);
  }

  return Array.from(buckets.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, v]) => v);
}

export function topProducts(db: Database, range: DateRange, limit = 6) {
  const map = new Map<string, { name: string; units: number; revenue: number; profit: number }>();
  for (const o of db.orders) {
    if (!within(o.ordered_at, range) || o.status === 'cancelled') continue;
    for (const i of o.items) {
      const cur = map.get(i.product_name) ?? { name: i.product_name, units: 0, revenue: 0, profit: 0 };
      cur.units += i.quantity;
      cur.revenue = round2(cur.revenue + i.line_total);
      cur.profit = round2(cur.profit + i.line_profit);
      map.set(i.product_name, cur);
    }
  }
  return Array.from(map.values()).sort((a, b) => b.revenue - a.revenue).slice(0, limit);
}

export function customerStats(db: Database, customerId: string) {
  const orders = db.orders.filter((o) => o.customer_id === customerId && o.status !== 'cancelled');
  const revenue = round2(orders.reduce((a, o) => a + o.total, 0));
  const profit = round2(orders.reduce((a, o) => a + o.profit, 0));
  const outstanding = round2(orders.reduce((a, o) => a + o.outstanding, 0));
  const subs = db.subscriptions.filter((s) => s.customer_id === customerId);
  const active = subs.filter((s) => s.status === 'active' || s.status === 'expiring');
  const lastPurchase = orders.map((o) => o.ordered_at).sort().pop() ?? null;
  const nextRenewal = active.map((s) => s.expiry_date).sort()[0] ?? null;
  return {
    revenue,
    profit,
    orders: orders.length,
    aov: orders.length ? round2(revenue / orders.length) : 0,
    outstanding,
    activePlans: active.length,
    lastPurchase,
    nextRenewal,
  };
}

export function renewalRate(db: Database) {
  const finished = db.subscriptions.filter((s) => s.status === 'expired' || s.status === 'renewed');
  if (!finished.length) return 0;
  const renewed = finished.filter((s) => s.status === 'renewed').length;
  return round2((renewed / finished.length) * 100);
}

export function refundRate(db: Database, range?: DateRange) {
  return refundRateFor(db, range);
}

export function customerLifetimeValue(db: Database) {
  // Net of refunds -- see finance.averageLifetimeValue.
  return averageLifetimeValue(db);
}

export function repeatRate(db: Database) {
  const counts = new Map<string, number>();
  for (const o of db.orders) counts.set(o.customer_id, (counts.get(o.customer_id) ?? 0) + 1);
  if (!counts.size) return 0;
  const repeat = Array.from(counts.values()).filter((n) => n > 1).length;
  return round2((repeat / counts.size) * 100);
}

export function orderRevenue(orders: Order[]) {
  return round2(orders.reduce((a, o) => a + o.total, 0));
}

/** The equivalent window immediately preceding `range`, for period-over-period deltas. */
export function previousRange(range: DateRange): DateRange {
  const span = range.to.getTime() - range.from.getTime();
  return {
    from: new Date(range.from.getTime() - span - 1),
    to: new Date(range.from.getTime() - 1),
    label: 'Previous period',
  };
}

/** Percentage change from `prev` to `curr`. Returns 0 when there is no baseline. */
export function pctChange(curr: number, prev: number): number {
  if (!prev) return curr ? 100 : 0;
  return round2(((curr - prev) / Math.abs(prev)) * 100);
}

/** KPI set plus period-over-period deltas and sparkline series. */
export function computeKpisWithTrend(db: Database, range: DateRange) {
  const curr = computeKpis(db, range);
  const prev = computeKpis(db, previousRange(range));
  const series = buildSeries(db, range);
  return {
    ...curr,
    delta: {
      revenue: pctChange(curr.revenue, prev.revenue),
      grossProfit: pctChange(curr.grossProfit, prev.grossProfit),
      netProfit: pctChange(curr.netProfit, prev.netProfit),
      orders: pctChange(curr.orders, prev.orders),
      aov: pctChange(curr.aov, prev.aov),
      newCustomers: pctChange(curr.newCustomers, prev.newCustomers),
      expenses: pctChange(curr.expenses, prev.expenses),
    },
    trend: {
      revenue: series.map((s) => s.revenue),
      profit: series.map((s) => s.profit),
      orders: series.map((s) => s.orders),
      expenses: series.map((s) => s.expenses),
    },
  };
}
