/**
 * Mutation-layer validation.
 *
 * These checks run inside the store before any state changes, so an invalid
 * order can never be persisted regardless of which screen (or future API
 * caller) submitted it. UI-level guards remain, but are no longer the only
 * defence.
 */
import type { Database, UUID } from '@/lib/types';
import { round2 } from '@/lib/utils';

export class ValidationError extends Error {
  readonly issues: string[];
  constructor(issues: string[]) {
    super(`Validation failed: ${issues.join('; ')}`);
    this.name = 'ValidationError';
    this.issues = issues;
  }
}

export interface OrderLineInput {
  product_id: UUID;
  quantity: number;
  unit_price: number;
  discount: number;
}

export interface OrderInput {
  customer_id: UUID;
  lines: OrderLineInput[];
  renewal_of_subscription_id?: UUID | null;
}

export function validateOrderInput(db: Database, input: OrderInput, orgId: UUID): string[] {
  const issues: string[] = [];

  // Customer must exist, belong to this org, and not be deleted.
  const customer = db.customers.find((c) => c.id === input.customer_id);
  if (!input.customer_id) issues.push('customer is required');
  else if (!customer) issues.push('customer does not exist');
  else if (customer.deleted_at) issues.push('customer has been deleted');
  else if (customer.organization_id !== orgId)
    issues.push('customer belongs to a different organization');

  // At least one line.
  if (!Array.isArray(input.lines) || input.lines.length === 0) {
    issues.push('order must contain at least one item');
  }

  for (const [i, line] of (input.lines ?? []).entries()) {
    const label = `line ${i + 1}`;
    const product = db.products.find((p) => p.id === line.product_id);
    if (!line.product_id) issues.push(`${label}: product is required`);
    else if (!product) issues.push(`${label}: product does not exist`);
    else if (product.deleted_at) issues.push(`${label}: product has been deleted`);
    else if (product.organization_id !== orgId)
      issues.push(`${label}: product belongs to a different organization`);
    else if (product.is_active === false) issues.push(`${label}: product is inactive`);

    if (!Number.isFinite(line.quantity) || line.quantity <= 0 || !Number.isInteger(line.quantity))
      issues.push(`${label}: quantity must be a positive whole number`);
    if (!Number.isFinite(line.unit_price) || line.unit_price < 0)
      issues.push(`${label}: price must be zero or greater`);
    if (!Number.isFinite(line.discount) || line.discount < 0)
      issues.push(`${label}: discount must be zero or greater`);

    const gross = round2((line.unit_price || 0) * (line.quantity || 0));
    if (Number.isFinite(line.discount) && line.discount > gross)
      issues.push(`${label}: discount ${line.discount} exceeds line value ${gross}`);
  }

  // Renewal link must be a real subscription for the same customer + org.
  if (input.renewal_of_subscription_id) {
    const sub = db.subscriptions.find((s) => s.id === input.renewal_of_subscription_id);
    if (!sub) issues.push('renewal target subscription does not exist');
    else {
      if (sub.organization_id !== orgId)
        issues.push('renewal target belongs to a different organization');
      if (sub.customer_id !== input.customer_id)
        issues.push('renewal target belongs to a different customer');
    }
  }

  return issues;
}

export function assertValidOrder(db: Database, input: OrderInput, orgId: UUID): void {
  const issues = validateOrderInput(db, input, orgId);
  if (issues.length) throw new ValidationError(issues);
}

/* ------------------------------------------------------------------ */
/* Inventory: reservation vs fulfilment                                */
/* ------------------------------------------------------------------ */
/**
 * Stock model:
 *   stock            — units physically on hand
 *   reserved         — units committed to unfulfilled orders
 *   available        — stock - reserved (what may still be sold)
 *
 * Ordering RESERVES stock; delivering an activation FULFILS it (decrements
 * stock and releases the reservation); cancelling releases the reservation
 * without touching stock. Previously ordering silently decremented stock with
 * `Math.max(0, ...)`, so overselling was invisible and cancelling never
 * restored inventory.
 */
export interface StockCheck {
  product_id: UUID;
  product_name: string;
  requested: number;
  available: number;
  backorder: number;
}

export function checkStock(db: Database, lines: OrderLineInput[]): StockCheck[] {
  const out: StockCheck[] = [];
  for (const line of lines) {
    const p = db.products.find((x) => x.id === line.product_id);
    if (!p || p.stock === null || p.stock === undefined) continue;
    const reserved = p.reserved_stock ?? 0;
    const available = p.stock - reserved;
    if (line.quantity > available) {
      out.push({
        product_id: p.id,
        product_name: p.name,
        requested: line.quantity,
        available,
        backorder: line.quantity - available,
      });
    }
  }
  return out;
}
