import { resolveMode } from '@/lib/runtime/mode';
import { getSupabaseClient } from '@/lib/data/supabase-client';

/**
 * Client access to activation credentials.
 *
 * In production these fields are encrypted at rest and are deliberately
 * excluded from the ordinary snapshot the store loads, so they must be fetched
 * on demand from /api/activations/[id]/secrets — the only endpoint that can
 * decrypt them, and only after checking the caller's permissions. Each read is
 * audited, which is why they are fetched when a specific activation is opened
 * rather than eagerly for the whole list.
 *
 * In demo mode there is no server, so the values already live in the local
 * snapshot and these helpers are not used.
 */

export interface ActivationSecrets {
  activation_email: string;
  activation_password: string;
  activation_details: string;
  internal_instructions: string;
}

export const EMPTY_SECRETS: ActivationSecrets = {
  activation_email: '',
  activation_password: '',
  activation_details: '',
  internal_instructions: '',
};

/** True when secrets must go through the server instead of the local snapshot. */
export function secretsAreServerSide(): boolean {
  return resolveMode().mode === 'production';
}

async function authHeader(): Promise<Record<string, string>> {
  const client = getSupabaseClient();
  if (!client) return {};
  const { data } = await client.auth.getSession();
  const token = (data as { session?: { access_token?: string } } | null)?.session?.access_token;
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function fetchActivationSecrets(id: string): Promise<ActivationSecrets> {
  const res = await fetch(`/api/activations/${id}/secrets`, {
    headers: await authHeader(),
    cache: 'no-store',
  });
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(body.error ?? `Could not load credentials (${res.status}).`);
  }
  const data = (await res.json()) as Partial<ActivationSecrets>;
  return { ...EMPTY_SECRETS, ...data };
}

export async function saveActivationSecrets(
  id: string,
  secrets: Partial<ActivationSecrets>,
): Promise<void> {
  const res = await fetch(`/api/activations/${id}/secrets`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
    body: JSON.stringify(secrets),
  });
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(body.error ?? `Could not save credentials (${res.status}).`);
  }
}
