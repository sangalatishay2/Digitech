import type { Database, Order, Payment } from '@/lib/types';
import type { DateRange } from '@/lib/services/analytics';
import { round2 } from '@/lib/utils';

/**
 * THE canonical financial calculation layer (P1 #12).
 *
 * Every KPI, chart, customer stat, top-product row, CLV and refund-rate figure
 * must come from here. Previously each surface recomputed its own totals and
 * they disagreed:
 *
 *   - Revenue summed `order.total`, so a refunded order still counted at full
 *     value on the dashboard while the P&L had subtracted it.
 *   - Refunds were attributed to the ORDER's date, not the refund's date. A
 *     January order refunded in March reduced January's profit, so a closed
 *     month's numbers changed retroactively. Refund events are now date-aware:
 *     they land in the period the money actually moved.
 *   - CLV and refund rate ignored refunds entirely.
 *
 * Definitions (single source of truth):
 *   grossRevenue  — order totals for non-cancelled orders placed in the period
 *   refunds       — refund payments that SETTLED in the period, whenever the
 *                   order was placed
 *   netRevenue    — grossRevenue - refunds
 *   productCost   — cost snapshot of those orders
 *   grossProfit   — netRevenue - productCost
 *   netProfit     — grossProfit - operatingExpenses
 */

export interface FinancePeriod {
  grossRevenue: number;
  refunds: number;
  netRevenue: number;
  productCost: number;
  grossProfit: number;
  operatingExpenses: number;
  netProfit: number;
  grossMargin: number;
  netMargin: number;
  collected: number;
  outstanding: number;
  orderCount: number;
  aov: number;
}

const inRange = (iso: string | null | undefined, range?: DateRange) => {
  if (!range) return true;
  if (!iso) return false;
  const t = new Date(iso).getTime();
  return t >= range.from.getTime() && t <= range.to.getTime();
};

/** Orders that count toward revenue: placed in period, not cancelled. */
export function revenueOrders(db: Database, range?: DateRange): Order[] {
  return db.orders.filter((o) => o.status !== 'cancelled' && !o.deleted_at && inRange(o.ordered_at, range));
}

/** Refund payments that SETTLED in the period, regardless of order date. */
export function refundEvents(db: Database, range?: DateRange): Payment[] {
  return db.payments.filter((p) => p.is_refund && !p.deleted_at && inRange(p.paid_at, range));
}

/** Non-refund payments that settled in the period. */
export function collectionEvents(db: Database, range?: DateRange): Payment[] {
  return db.payments.filter((p) => !p.is_refund && !p.deleted_at && inRange(p.paid_at, range));
}

const sumAbs = (rows: { amount: number }[]) => round2(rows.reduce((a, r) => a + Math.abs(r.amount), 0));

export function computePeriod(db: Database, range?: DateRange): FinancePeriod {
  const orders = revenueOrders(db, range);
  const grossRevenue = round2(orders.reduce((a, o) => a + o.total, 0));
  const productCost = round2(orders.reduce((a, o) => a + o.total_cost, 0));

  // Date-aware: refunds belong to the period they settled in.
  const refunds = sumAbs(refundEvents(db, range));
  const collected = sumAbs(collectionEvents(db, range));

  const netRevenue = round2(grossRevenue - refunds);
  const grossProfit = round2(netRevenue - productCost);

  const operatingExpenses = round2(
    db.expenses
      .filter((e) => !e.deleted_at && inRange(e.spent_at, range))
      .reduce((a, e) => a + e.amount, 0),
  );
  const netProfit = round2(grossProfit - operatingExpenses);

  // Outstanding is a balance-sheet figure: it is "as of now" across all open
  // orders, never a period slice, or it would double count across ranges.
  const outstanding = round2(
    db.orders
      .filter((o) => o.status !== 'cancelled' && !o.deleted_at)
      .reduce((a, o) => a + o.outstanding, 0),
  );

  return {
    grossRevenue,
    refunds,
    netRevenue,
    productCost,
    grossProfit,
    operatingExpenses,
    netProfit,
    grossMargin: grossRevenue ? round2((grossProfit / grossRevenue) * 100) : 0,
    netMargin: grossRevenue ? round2((netProfit / grossRevenue) * 100) : 0,
    collected,
    outstanding,
    orderCount: orders.length,
    aov: orders.length ? round2(grossRevenue / orders.length) : 0,
  };
}

/** Refund rate for a period, using date-aware refund events. */
export function refundRateFor(db: Database, range?: DateRange): number {
  const p = computePeriod(db, range);
  return p.grossRevenue ? round2((p.refunds / p.grossRevenue) * 100) : 0;
}

/**
 * Per-customer lifetime value, net of refunds.
 *
 * Refunds are matched through the customer's own orders so a refund is never
 * attributed to the wrong customer.
 */
export function customerValue(db: Database, customerId: string) {
  const orders = db.orders.filter(
    (o) => o.customer_id === customerId && o.status !== 'cancelled' && !o.deleted_at,
  );
  const ids = new Set(orders.map((o) => o.id));
  const gross = round2(orders.reduce((a, o) => a + o.total, 0));
  const refunded = sumAbs(db.payments.filter((p) => p.is_refund && !p.deleted_at && ids.has(p.order_id)));
  const collected = sumAbs(db.payments.filter((p) => !p.is_refund && !p.deleted_at && ids.has(p.order_id)));
  return {
    orders: orders.length,
    gross,
    refunded,
    net: round2(gross - refunded),
    collected: round2(collected - refunded),
    outstanding: round2(orders.reduce((a, o) => a + o.outstanding, 0)),
  };
}

/** Average CLV across non-deleted customers, net of refunds. */
export function averageLifetimeValue(db: Database): number {
  const customers = db.customers.filter((c) => !c.deleted_at);
  if (!customers.length) return 0;
  const orders = db.orders.filter((o) => o.status !== 'cancelled' && !o.deleted_at);
  const gross = round2(orders.reduce((a, o) => a + o.total, 0));
  const refunded = sumAbs(db.payments.filter((p) => p.is_refund && !p.deleted_at));
  return round2((gross - refunded) / customers.length);
}

/**
 * Top products by NET revenue for the period.
 *
 * A product whose orders were refunded must not stay at the top of the chart.
 * Refunds are apportioned across an order's line items by value share.
 */
export function topProductsByNet(db: Database, range?: DateRange, limit = 6) {
  const orders = revenueOrders(db, range);
  const byOrder = new Map(orders.map((o) => [o.id, o]));

  const refundByOrder = new Map<string, number>();
  for (const p of refundEvents(db, range)) {
    if (!byOrder.has(p.order_id)) continue;
    refundByOrder.set(p.order_id, round2((refundByOrder.get(p.order_id) ?? 0) + Math.abs(p.amount)));
  }

  const acc = new Map<string, { name: string; qty: number; gross: number; net: number }>();
  // Order items are nested on the order record, not a top-level table.
  for (const order of orders) {
    for (const item of order.items ?? []) {
      const lineTotal = item.line_total ?? 0;
      const orderTotal = order.total || 1;
      const refundShare = round2(((refundByOrder.get(order.id) ?? 0) * lineTotal) / orderTotal);
      const key = item.product_id ?? item.product_name;
      const cur = acc.get(key) ?? { name: item.product_name, qty: 0, gross: 0, net: 0 };
      cur.qty += item.quantity ?? 0;
      cur.gross = round2(cur.gross + lineTotal);
      cur.net = round2(cur.net + lineTotal - refundShare);
      acc.set(key, cur);
    }
  }

  return [...acc.values()].sort((a, b) => b.net - a.net).slice(0, limit);
}

/**
 * Reconciliation check used by the tests: every surface must agree.
 * Returns the discrepancies found, empty when consistent.
 */
export function reconcile(db: Database, range?: DateRange): string[] {
  const issues: string[] = [];
  const p = computePeriod(db, range);

  if (round2(p.grossRevenue - p.refunds) !== p.netRevenue) {
    issues.push(`netRevenue ${p.netRevenue} != gross ${p.grossRevenue} - refunds ${p.refunds}`);
  }
  if (round2(p.netRevenue - p.productCost) !== p.grossProfit) {
    issues.push(`grossProfit ${p.grossProfit} != net ${p.netRevenue} - cost ${p.productCost}`);
  }
  if (round2(p.grossProfit - p.operatingExpenses) !== p.netProfit) {
    issues.push(`netProfit ${p.netProfit} mismatch`);
  }

  // Top products must not exceed the period's gross revenue.
  const top = topProductsByNet(db, range, 10_000);
  const topGross = round2(top.reduce((a, t) => a + t.gross, 0));
  if (topGross - p.grossRevenue > 0.05) {
    issues.push(`top products gross ${topGross} exceeds period revenue ${p.grossRevenue}`);
  }
  return issues;
}
