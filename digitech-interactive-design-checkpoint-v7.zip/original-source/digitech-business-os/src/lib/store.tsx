'use client';

import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type {
  Activation,
  ApprovalRequest,
  ActivityLog,
  Customer,
  CommunicationLog,
  Database,
  Expense,
  Invoice,
  Lead,
  Order,
  Payment,
  Product,
  Profile,
  Subscription,
  SupportTicket,
  Supplier,
  Task,
  UUID,
  Role,
} from '@/lib/types';
import type { ApprovalInput } from '@/lib/services/approvals';
import { canReviewApproval, inferApprovalRisk, validateApprovalInput } from '@/lib/services/approvals';
import { localProvider } from '@/lib/data/local-provider';
import { supabaseProvider } from '@/lib/data/supabase-provider';
import { getSupabaseClient } from '@/lib/data/supabase-client';
import type { DataProvider } from '@/lib/data/provider';
import { resolveMode } from '@/lib/runtime/mode';
import { resolveSession, assertSwitchingAllowed, profileCanAct, type Session } from '@/lib/auth/session';
import { buildSeed, emptyDb } from '@/lib/data/seed';
import { actorCan, assertCan, toActor } from '@/lib/services/authz';
import { assertValidOrder, checkStock, ValidationError } from '@/lib/services/validation';
import { nextNumber } from '@/lib/services/numbering';
import {
  buildActivation,
  buildOrderItem,
  buildSubscription,
  canTransition,
  computeOrderTotals,
  deriveSubscriptionStatus,
  newId,
  nowIso,
  recalcOrderPayments,
  reconcileInvoices,
  TERMINAL_ORDER_STATUSES,
} from '@/lib/services/business';
import { round2 } from '@/lib/utils';

export interface NewOrderLine {
  product_id: UUID;
  quantity: number;
  unit_price: number;
  discount: number;
}

export interface CreateOrderInput {
  customer_id: UUID;
  lines: NewOrderLine[];
  notes?: string;
  assigned_to?: UUID | null;
  renewal_of_subscription_id?: UUID | null;
  payment?: { amount: number; method: Payment['method']; reference?: string } | null;
}

interface StoreValue {
  db: Database;
  loading: boolean;
  currentUser: Profile | null;
  /** Why there is no usable identity, when currentUser is null. */
  sessionReason: string | null;
  /** Non-null when a production write or load failed to reach the server. */
  syncError: string | null;
  setCurrentUserId: (id: UUID) => void;
  can: (action: string) => boolean;
  orgId: UUID;
  org: Database['organizations'][number];
  update: (fn: (db: Database) => void) => void;
  resetData: (mode: 'demo' | 'empty') => Promise<void>;

  // entity helpers
  customerById: (id?: UUID | null) => Customer | undefined;
  productById: (id?: UUID | null) => Product | undefined;
  profileById: (id?: UUID | null) => Profile | undefined;
  supplierById: (id?: UUID | null) => Supplier | undefined;

  // mutations
  createCustomer: (input: Partial<Customer>) => Customer;
  updateCustomer: (id: UUID, patch: Partial<Customer>) => void;
  deleteCustomer: (id: UUID) => void;

  createProduct: (input: Partial<Product>) => Product;
  updateProduct: (id: UUID, patch: Partial<Product>) => void;
  deleteProduct: (id: UUID) => void;

  createSupplier: (input: Partial<Supplier>) => Supplier;
  updateSupplier: (id: UUID, patch: Partial<Supplier>) => void;

  createOrder: (input: CreateOrderInput) => Order;
  updateOrderStatus: (id: UUID, status: Order['status'], opts?: { adminOverride?: boolean }) => void;
  addPayment: (orderId: UUID, amount: number, method: Payment['method'], opts?: { reference?: string; isRefund?: boolean }) => void;

  updateActivation: (id: UUID, patch: Partial<Activation>) => void;
  completeActivation: (id: UUID) => void;

  updateSubscription: (id: UUID, patch: Partial<Subscription>) => void;

  createLead: (input: Partial<Lead>) => Lead;
  updateLead: (id: UUID, patch: Partial<Lead>) => void;
  convertLead: (id: UUID) => Customer;

  createTask: (input: Partial<Task>) => Task;
  updateTask: (id: UUID, patch: Partial<Task>) => void;

  createTicket: (input: Partial<SupportTicket>) => SupportTicket;
  updateTicket: (id: UUID, patch: Partial<SupportTicket>) => void;

  /** Sensitive team/settings mutations -- permission-checked and audited. */
  addTeamMember: (input: { full_name: string; email: string; phone?: string | null; role: Role }) => void;
  setMemberRole: (id: UUID, role: Role) => void;
  setMemberActive: (id: UUID, active: boolean) => void;
  saveOrgSettings: (patch: Record<string, unknown>) => void;
  createExpense: (input: Partial<Expense>) => Expense;
  updateExpense: (id: UUID, patch: Partial<Expense>) => void;
  deleteExpense: (id: UUID) => void;

  createInvoiceForOrder: (orderId: UUID) => Invoice | null;
  queueCommunication: (input: {
    customer_id?: UUID | null;
    channel: CommunicationLog['channel'];
    to_address: string;
    body: string;
  }) => CommunicationLog;

  createApproval: (input: ApprovalInput) => ApprovalRequest;
  reviewApproval: (id: UUID, decision: 'approved' | 'rejected', note?: string) => void;

  markNotificationRead: (id: UUID) => void;
  markAllNotificationsRead: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

/**
 * Demo-mode only guard against exhausting localStorage. Production persists the
 * full, unbounded audit trail server-side.
 */
const AUDIT_LOG_SAFETY_CEILING = 20_000;

export function StoreProvider({ children }: { children: React.ReactNode }) {
  // Seed synchronously so the very first paint has real data — both on the server
  // and on the client. Persisted state is merged in right after mount. This keeps
  // the app renderable instead of hiding everything behind a loading gate.
  const [db, setDb] = useState<Database>(() => withDerived(buildSeed()));
  const [currentUserId, setCurrentUserId] = useState<UUID | null>(null);
  const [syncError, setSyncError] = useState<string | null>(null);
  // The verified Supabase session in production. Null in demo mode, where
  // identity comes from the in-app switcher instead.
  const [authSession, setAuthSession] = useState<Session | null>(null);

  // Which backend is actually in charge. Resolved once: flipping providers
  // mid-session would mix demo and production data.
  const mode = useMemo(() => resolveMode(), []);
  const provider = useMemo<DataProvider>(
    () => (mode.mode === 'production' ? supabaseProvider : localProvider),
    [mode.mode],
  );

  // Last snapshot known to be persisted. Diffing against this is what lets the
  // provider write only the rows that changed instead of the whole database.
  const persisted = useRef<Database | null>(null);

  useEffect(() => {
    let alive = true;
    provider
      .load()
      .then((loaded) => {
        if (!alive) return;
        const next = withDerived(loaded);
        persisted.current = next;
        setDb(next);
        setCurrentUserId((id) => id ?? next.profiles.find(profileCanAct)?.id ?? null);
      })
      .catch((e: unknown) => {
        if (!alive) return;
        // In production a failed load must be visible: showing seed data as if
        // it were the customer's real records would be far worse than an error.
        if (mode.mode === 'production') {
          setSyncError(`Could not load data: ${(e as Error).message}`);
          setDb(withDerived(emptyDb()));
        }
        /* demo: keep the seeded in-memory database */
      });
    return () => {
      alive = false;
    };
  }, [provider, mode.mode]);

  // Track the real session in production: read it once at mount, then follow
  // sign-in/sign-out so a signed-out user immediately loses their identity
  // rather than keeping a stale one until reload.
  useEffect(() => {
    // Demo mode never populates authSession (it stays null), so there is
    // nothing to reset here — identity comes from the in-app switcher.
    if (mode.mode !== 'production') return;

    const client = getSupabaseClient();
    if (!client) return;

    let alive = true;
    const toSession = (raw: unknown): Session | null => {
      const s = raw as
        | { access_token?: string; user?: { id?: string; email?: string | null } }
        | null;
      if (!s?.user?.id) return null;
      return {
        userId: s.user.id,
        email: s.user.email ?? null,
        accessToken: s.access_token ?? null,
        source: 'supabase',
      };
    };

    void client.auth.getSession().then(({ data }) => {
      if (alive) setAuthSession(toSession((data as { session?: unknown } | null)?.session));
    });

    const sub = client.auth.onAuthStateChange?.((_event: string, raw: unknown) => {
      if (alive) setAuthSession(toSession(raw));
    });

    return () => {
      alive = false;
      (sub as { data?: { subscription?: { unsubscribe?: () => void } } } | undefined)
        ?.data?.subscription?.unsubscribe?.();
    };
  }, [mode.mode]);

  const update = useCallback(
    (fn: (draft: Database) => void) => {
      setDb((prev) => {
        const draft: Database = JSON.parse(JSON.stringify(prev));
        fn(draft);
        const next = withDerived(draft);

        if (mode.mode === 'production') {
          // Per-entity writes: only the rows that actually changed are sent.
          const base = persisted.current ?? prev;
          void supabaseProvider
            .saveDiff(base, next, next.organizations[0]?.id ?? '')
            .then(() => {
              persisted.current = next;
              setSyncError(null);
            })
            .catch((e: unknown) => setSyncError((e as Error).message));
        } else {
          void localProvider.save(next);
          persisted.current = next;
        }
        return next;
      });
    },
    [mode.mode],
  );

  const value = useMemo<StoreValue | null>(() => {
    const org = db.organizations[0];
    if (!org) return null;
    const orgId = org.id;
    // Identity comes from resolveSession(), never from a bare array index.
    // The old `?? db.profiles[0]` fallback could silently hand the app a
    // DISABLED profile, which then passed every UI check while SQL would have
    // denied it -- exactly the divergence the audit calls out.
    const resolved = resolveSession(db.profiles, {
      requestedUserId: currentUserId,
      session: authSession,
    });
    const currentUser = resolved.profile;

    const baseFields = () => ({
      id: newId(),
      organization_id: orgId,
      created_at: nowIso(),
      updated_at: nowIso(),
      deleted_at: null,
    });

    /**
     * Durable audit trail.
     *
     * The trail is append-only and is NOT truncated. It previously kept only
     * the newest 500 entries, which silently destroyed the audit history of an
     * active workspace — exactly the records an audit needs. Demo mode keeps a
     * generous safety ceiling purely to protect browser storage quota; in
     * production the table is unbounded and append-only via RLS
     * (0016_rls_rewrite.sql grants INSERT but no UPDATE/DELETE policy).
     */
    const log = (
      draft: Database,
      action: string,
      record_type: string,
      record_id: UUID,
      summary: string,
      values?: { old?: unknown; new?: unknown },
    ) => {
      const entry: ActivityLog = {
        ...baseFields(),
        actor_id: currentUser?.id ?? null,
        actor_name: currentUser?.full_name ?? 'System',
        action,
        record_type,
        record_id,
        summary,
        old_values: (values?.old ?? null) as ActivityLog['old_values'],
        new_values: (values?.new ?? null) as ActivityLog['new_values'],
      };
      draft.activity_logs.unshift(entry);
      if (draft.activity_logs.length > AUDIT_LOG_SAFETY_CEILING) {
        draft.activity_logs.length = AUDIT_LOG_SAFETY_CEILING;
      }
    };

    const v: StoreValue = {
      db,
      loading: false,
      currentUser,
      sessionReason: resolved.reason,
      syncError,
      setCurrentUserId: (id: UUID) => {
        // Switching identity is a demo affordance only.
        assertSwitchingAllowed();
        setCurrentUserId(id);
      },
      can: (action) => actorCan(toActor(currentUser), action),
      orgId,
      org,
      update,
      resetData: async (mode) => {
        const fresh = await localProvider.reset(mode);
        const derived = withDerived(fresh);
        setDb(derived);
        setCurrentUserId(derived.profiles.find(profileCanAct)?.id ?? null);
      },

      customerById: (id) => db.customers.find((c) => c.id === id),
      productById: (id) => db.products.find((p) => p.id === id),
      profileById: (id) => db.profiles.find((p) => p.id === id),
      supplierById: (id) => db.suppliers.find((s) => s.id === id),

      createCustomer: (input) => {
        assertCan(toActor(currentUser), 'customers.create', orgId);
        const seq = db.customers.length + 1001;
        const customer: Customer = {
          ...baseFields(),
          customer_code: input.customer_code || `DT-${seq}`,
          name: input.name ?? 'Unnamed',
          email: input.email ?? null,
          phone: input.phone ?? null,
          whatsapp: input.whatsapp ?? input.phone ?? null,
          company: input.company ?? null,
          city: input.city ?? null,
          state: input.state ?? null,
          status: input.status ?? 'active',
          source: input.source ?? null,
          owner_id: input.owner_id ?? currentUser?.id ?? null,
          notes: input.notes ?? null,
          tags: input.tags ?? [],
        };
        update((d) => {
          d.customers.unshift(customer);
          log(d, 'created', 'customer', customer.id, `Customer ${customer.name} created`);
        });
        return customer;
      },
      updateCustomer: (id, patch) =>
        update((d) => {
          const i = d.customers.findIndex((c) => c.id === id);
          if (i >= 0) {
            d.customers[i] = { ...d.customers[i], ...patch, updated_at: nowIso() };
            log(d, 'updated', 'customer', id, `Customer ${d.customers[i].name} updated`);
          }
        }),
      deleteCustomer: (id) =>
        update((d) => {
          const c = d.customers.find((x) => x.id === id);
          if (c) {
            c.deleted_at = nowIso();
            log(d, 'archived', 'customer', id, `Customer ${c.name} archived`);
          }
        }),

      createProduct: (input) => {
        assertCan(toActor(currentUser), 'products.create', orgId);
        const product: Product = {
          ...baseFields(),
          name: input.name ?? 'New Product',
          code: input.code ?? `SKU-${Math.floor(Math.random() * 9000 + 1000)}`,
          category_id: input.category_id ?? null,
          brand: input.brand ?? null,
          description: input.description ?? null,
          product_type: input.product_type ?? 'subscription',
          delivery_type: input.delivery_type ?? 'email_activation',
          duration_days: input.duration_days ?? 365,
          cost_price: input.cost_price ?? 0,
          selling_price: input.selling_price ?? 0,
          supplier_id: input.supplier_id ?? null,
          stock: input.stock ?? null,
          low_stock_threshold: input.low_stock_threshold ?? 5,
          is_active: input.is_active ?? true,
          notes: input.notes ?? null,
        };
        update((d) => {
          d.products.unshift(product);
          log(d, 'created', 'product', product.id, `Product ${product.name} created`);
        });
        return product;
      },
      updateProduct: (id, patch) =>
        update((d) => {
          const i = d.products.findIndex((p) => p.id === id);
          if (i >= 0) {
            d.products[i] = { ...d.products[i], ...patch, updated_at: nowIso() };
            log(d, 'updated', 'product', id, `Product ${d.products[i].name} updated`);
          }
        }),
      deleteProduct: (id) =>
        update((d) => {
          const p = d.products.find((x) => x.id === id);
          if (p) p.deleted_at = nowIso();
        }),

      createSupplier: (input) => {
        const supplier: Supplier = {
          ...baseFields(),
          name: input.name ?? 'New Supplier',
          contact_person: input.contact_person ?? null,
          email: input.email ?? null,
          phone: input.phone ?? null,
          website: input.website ?? null,
          payment_terms: input.payment_terms ?? 'Prepaid',
          notes: input.notes ?? null,
          is_active: true,
        };
        update((d) => {
          d.suppliers.unshift(supplier);
          log(d, 'created', 'supplier', supplier.id, `Supplier ${supplier.name} created`);
        });
        return supplier;
      },
      updateSupplier: (id, patch) =>
        update((d) => {
          const i = d.suppliers.findIndex((s) => s.id === id);
          if (i >= 0) d.suppliers[i] = { ...d.suppliers[i], ...patch, updated_at: nowIso() };
        }),

      createOrder: (input) => {
        // Server-side authorization + validation. UI guards are UX only.
        assertCan(toActor(currentUser), 'orders.create', orgId);
        assertValidOrder(db, input, orgId);
        const orderId = newId();
        const items = input.lines.flatMap((line) => {
          const product = db.products.find((p) => p.id === line.product_id);
          if (!product) return [];
          const supplier = db.suppliers.find((s) => s.id === product.supplier_id);
          return [
            buildOrderItem(orderId, product, {
              quantity: line.quantity,
              unit_price: line.unit_price,
              discount: line.discount,
              supplierName: supplier?.name ?? null,
            }),
          ];
        });
        const totals = computeOrderTotals(items);
        // Monotonic counter, not `1000 + length` (which collides after a delete).
        let order: Order = {
          ...baseFields(),
          id: orderId,
          order_number: nextNumber(db, 'order'),
          customer_id: input.customer_id,
          status: 'new',
          payment_status: 'pending',
          ...totals,
          amount_paid: 0,
          amount_refunded: 0,
          outstanding: totals.total,
          notes: input.notes ?? null,
          source: null,
          renewal_of_subscription_id: input.renewal_of_subscription_id ?? null,
          assigned_to: input.assigned_to ?? currentUser?.id ?? null,
          ordered_at: nowIso(),
          items,
        };

        const payments: Payment[] = [];
        if (input.payment && input.payment.amount > 0) {
          payments.push({
            ...baseFields(),
            order_id: orderId,
            customer_id: input.customer_id,
            amount: round2(input.payment.amount),
            method: input.payment.method,
            status: 'paid',
            reference: input.payment.reference ?? null,
            is_refund: false,
            paid_at: nowIso(),
            notes: null,
          });
          order = recalcOrderPayments(order, payments);
          order.status = order.payment_status === 'paid' ? 'activation_pending' : 'awaiting_payment';
        } else {
          order.status = 'awaiting_payment';
        }

        update((d) => {
          d.orders.unshift(order);
          d.payments.unshift(...payments);
          for (const item of items) d.activations.unshift(buildActivation(order, item, orgId));
          // Ordering RESERVES stock; it is only decremented on fulfilment
          // (completeActivation) and released on cancellation. Reserving can
          // exceed availability — that is an explicit backorder, recorded below
          // rather than silently clamped to zero.
          for (const item of items) {
            const p = d.products.find((x) => x.id === item.product_id);
            if (p && p.stock !== null) p.reserved_stock = (p.reserved_stock ?? 0) + item.quantity;
          }
          for (const s of checkStock(db, input.lines)) {
            log(d, 'backorder', 'product', s.product_id,
              `Backorder: ${s.product_name} short by ${s.backorder} (requested ${s.requested}, available ${s.available})`);
          }
          if (input.renewal_of_subscription_id) {
            const prev = d.subscriptions.find((s) => s.id === input.renewal_of_subscription_id);
            if (prev) prev.reminder_state = 'interested';
          }
          const cust = d.customers.find((c) => c.id === input.customer_id);
          log(d, 'created', 'order', order.id, `Order ${order.order_number} created for ${cust?.name ?? 'customer'}`);
        });
        return order;
      },

      updateOrderStatus: (id, status, opts) =>
        update((d) => {
          const o = d.orders.find((x) => x.id === id);
          if (!o) return;
          assertCan(toActor(currentUser), 'orders.update', o.organization_id);
          const from = o.status;
          if (from === status) return;

          // Terminal states are final except for an explicit admin recovery.
          const terminal = TERMINAL_ORDER_STATUSES.includes(from);
          const adminOverride = Boolean(opts?.adminOverride);
          if (terminal && !adminOverride) {
            throw new ValidationError([
              `order ${o.order_number} is ${from} (terminal); use an admin recovery action to change it`,
            ]);
          }
          if (adminOverride) {
            assertCan(toActor(currentUser), 'orders.override', o.organization_id);
          }
          if (!adminOverride && !canTransition(from, status)) {
            throw new ValidationError([
              `illegal order transition ${from} -> ${status} on ${o.order_number}`,
            ]);
          }

          o.status = status;
          o.updated_at = nowIso();

          // Cancelling releases any stock still reserved for this order.
          if (status === 'cancelled' || status === 'refunded') {
            for (const item of o.items) {
              const prod = d.products.find((x) => x.id === item.product_id);
              if (prod && prod.stock !== null) {
                prod.reserved_stock = Math.max(0, (prod.reserved_stock ?? 0) - item.quantity);
              }
            }
            for (const a of d.activations.filter((x) => x.order_id === o.id)) {
              if (a.status !== 'delivered') a.status = 'cancelled';
            }
          }
          log(d, 'status_changed', 'order', id,
            `Order ${o.order_number} ${from} → ${status}${adminOverride ? ' (admin override)' : ''}`);
        }),

      addPayment: (orderId, amount, method, opts) =>
        update((d) => {
          const o = d.orders.find((x) => x.id === orderId);
          if (!o) return;
          assertCan(toActor(currentUser), 'payments.create', o.organization_id);
          const isRefund = Boolean(opts?.isRefund);
          // Defence in depth: never let a payment exceed the outstanding balance,
          // nor a refund exceed what has actually been collected.
          const headroom = isRefund
            ? round2(o.amount_paid - o.amount_refunded)
            : round2(o.total - round2(o.amount_paid - o.amount_refunded));
          const amt = round2(Math.min(Math.abs(amount), Math.max(0, headroom)));
          if (amt <= 0) return;
          d.payments.unshift({
            ...baseFields(),
            order_id: orderId,
            customer_id: o.customer_id,
            amount: amt,
            method,
            status: isRefund ? 'refunded' : 'paid',
            reference: opts?.reference ?? null,
            is_refund: isRefund,
            paid_at: nowIso(),
            notes: null,
          });
          const updated = recalcOrderPayments(o, d.payments);
          Object.assign(o, updated);
          if (!isRefund && o.payment_status === 'paid' && o.status === 'awaiting_payment') {
            o.status = 'activation_pending';
            for (const a of d.activations.filter((x) => x.order_id === orderId && x.status === 'waiting_payment'))
              a.status = 'ready';
          }
          if (isRefund && o.payment_status === 'refunded') o.status = 'refunded';
          log(d, isRefund ? 'refunded' : 'payment_added', 'order', orderId, `${isRefund ? 'Refund' : 'Payment'} of ₹${amt} on ${o.order_number}`);
        }),

      updateActivation: (id, patch) =>
        update((d) => {
          const i = d.activations.findIndex((a) => a.id === id);
          if (i >= 0) d.activations[i] = { ...d.activations[i], ...patch, updated_at: nowIso() };
        }),

      completeActivation: (id) =>
        update((d) => {
          const a = d.activations.find((x) => x.id === id);
          if (!a) return;
          assertCan(toActor(currentUser), 'activations.update', a.organization_id);

          // IDEMPOTENCY: replaying a completion (double click, retry, restored
          // backup) must never create a second subscription or re-run the
          // renewal chain. The activation is the idempotency key.
          const alreadyDelivered = a.status === 'delivered';
          const existingSub = d.subscriptions.find((sb) => sb.source_activation_id === a.id);
          if (alreadyDelivered && existingSub) return;

          a.status = 'delivered';
          a.activated_at = a.activated_at ?? nowIso();
          a.delivered_at = a.delivered_at ?? nowIso();
          const order = d.orders.find((o) => o.id === a.order_id);
          const item = order?.items.find((i) => i.id === a.order_item_id);
          if (order && item) {
            if (item.duration_days > 0 && !existingSub) {
              const prevSubId = order.renewal_of_subscription_id ?? null;
              const sub = buildSubscription(order, item, orgId, prevSubId, a.id);
              d.subscriptions.unshift(sub);
              if (prevSubId) {
                const prev = d.subscriptions.find((s) => s.id === prevSubId);
                // Only advance the chain once.
                if (prev && prev.status !== 'renewed') {
                  prev.status = 'renewed';
                  prev.renewed_to_subscription_id = sub.id;
                }
              }
              a.expiry_date = sub.expiry_date;
            }

            // FULFILMENT: decrement real stock and release the reservation.
            const prod = d.products.find((x) => x.id === item.product_id);
            if (prod && prod.stock !== null) {
              prod.stock = Math.max(0, prod.stock - item.quantity);
              prod.reserved_stock = Math.max(0, (prod.reserved_stock ?? 0) - item.quantity);
            }
            const allDone = d.activations
              .filter((x) => x.order_id === order.id)
              .every((x) => x.status === 'delivered' || x.status === 'cancelled');
            if (allDone) order.status = order.payment_status === 'paid' ? 'completed' : 'delivered';
            else order.status = 'activated';
          }
          log(d, 'activated', 'activation', id, `${a.product_name} delivered`);
        }),

      updateSubscription: (id, patch) =>
        update((d) => {
          const i = d.subscriptions.findIndex((s) => s.id === id);
          if (i >= 0) d.subscriptions[i] = { ...d.subscriptions[i], ...patch, updated_at: nowIso() };
        }),

      createLead: (input) => {
        const lead: Lead = {
          ...baseFields(),
          name: input.name ?? 'New Lead',
          phone: input.phone ?? null,
          email: input.email ?? null,
          company: input.company ?? null,
          source: input.source ?? null,
          interested_product_id: input.interested_product_id ?? null,
          value: input.value ?? 0,
          probability: input.probability ?? 20,
          status: input.status ?? 'new',
          assigned_to: input.assigned_to ?? currentUser?.id ?? null,
          follow_up_at: input.follow_up_at ?? null,
          notes: input.notes ?? null,
          converted_customer_id: null,
        };
        update((d) => {
          d.leads.unshift(lead);
          log(d, 'created', 'lead', lead.id, `Lead ${lead.name} created`);
        });
        return lead;
      },
      updateLead: (id, patch) =>
        update((d) => {
          const i = d.leads.findIndex((l) => l.id === id);
          if (i >= 0) d.leads[i] = { ...d.leads[i], ...patch, updated_at: nowIso() };
        }),
      convertLead: (id) => {
        const lead = db.leads.find((l) => l.id === id)!;
        const customer: Customer = {
          ...baseFields(),
          customer_code: `DT-${db.customers.length + 1001}`,
          name: lead.name,
          email: lead.email ?? null,
          phone: lead.phone ?? null,
          whatsapp: lead.phone ?? null,
          company: lead.company ?? null,
          city: null,
          state: null,
          status: 'active',
          source: lead.source ?? null,
          owner_id: lead.assigned_to ?? null,
          notes: lead.notes ?? null,
          tags: ['converted-lead'],
        };
        update((d) => {
          d.customers.unshift(customer);
          const l = d.leads.find((x) => x.id === id);
          if (l) {
            l.status = 'won';
            l.converted_customer_id = customer.id;
          }
          log(d, 'converted', 'lead', id, `Lead ${lead.name} converted to customer`);
        });
        return customer;
      },

      createTask: (input) => {
        const task: Task = {
          ...baseFields(),
          title: input.title ?? 'New task',
          description: input.description ?? null,
          entity_type: input.entity_type ?? 'general',
          entity_id: input.entity_id ?? null,
          priority: input.priority ?? 'medium',
          status: input.status ?? 'open',
          assigned_to: input.assigned_to ?? currentUser?.id ?? null,
          due_at: input.due_at ?? null,
          reminder_at: null,
          completed_at: null,
        };
        update((d) => {
          d.tasks.unshift(task);
          log(d, 'created', 'task', task.id, `Task "${task.title}" created`, { new: task });
        });
        return task;
      },
      updateTask: (id, patch) =>
        update((d) => {
          const i = d.tasks.findIndex((t) => t.id === id);
          if (i < 0) return;
          const before = { ...d.tasks[i] };
          d.tasks[i] = { ...d.tasks[i], ...patch, updated_at: nowIso() };
          if (patch.status === 'done') d.tasks[i].completed_at = nowIso();
          log(d, 'updated', 'task', id, `Task "${d.tasks[i].title}" updated`,
            { old: before, new: d.tasks[i] });
        }),

      createTicket: (input) => {
        const ticket: SupportTicket = {
          ...baseFields(),
          ticket_number: nextNumber(db, 'ticket'),
          customer_id: input.customer_id!,
          order_id: input.order_id ?? null,
          product_id: input.product_id ?? null,
          category: input.category ?? 'General',
          subject: input.subject ?? 'Support request',
          description: input.description ?? '',
          priority: input.priority ?? 'medium',
          status: 'open',
          assigned_to: input.assigned_to ?? currentUser?.id ?? null,
          first_response_at: null,
          resolved_at: null,
          due_at: new Date(Date.now() + 2 * 86400000).toISOString(),
        };
        update((d) => {
          d.support_tickets.unshift(ticket);
          log(d, 'created', 'ticket', ticket.id, `Ticket ${ticket.ticket_number} opened`);
        });
        return ticket;
      },
      updateTicket: (id, patch) =>
        update((d) => {
          const i = d.support_tickets.findIndex((t) => t.id === id);
          if (i >= 0) {
            d.support_tickets[i] = { ...d.support_tickets[i], ...patch, updated_at: nowIso() };
            if (patch.status === 'resolved' || patch.status === 'closed')
              d.support_tickets[i].resolved_at = d.support_tickets[i].resolved_at ?? nowIso();
          }
        }),

      addTeamMember: (input) => {
        assertCan(toActor(currentUser), 'team.manage', orgId);
        update((d) => {
          const profile: Profile = {
            id: newId(),
            organization_id: d.organizations[0].id,
            created_at: nowIso(),
            updated_at: nowIso(),
            deleted_at: null,
            auth_user_id: null, // standalone-first; linked when Supabase Auth is connected
            full_name: input.full_name,
            email: input.email,
            phone: input.phone ?? null,
            role: input.role,
            is_active: true,
          } as Profile;
          d.profiles.push(profile);
          log(d, 'created', 'profile', profile.id,
            `Team member ${profile.full_name} added as ${profile.role}`, { new: profile });
        });
      },

      setMemberRole: (id, role) => {
        assertCan(toActor(currentUser), 'team.manage', orgId);
        update((d) => {
          const p = d.profiles.find((x) => x.id === id);
          if (!p) return;
          const before = { role: p.role };
          if (p.role === role) return;
          p.role = role;
          p.updated_at = nowIso();
          // A privilege change is the single most security-relevant mutation
          // in the app; it must always be attributable.
          log(d, 'role_changed', 'profile', id,
            `${p.full_name} role changed from ${before.role} to ${role}`,
            { old: before, new: { role } });
        });
      },

      setMemberActive: (id, active) => {
        assertCan(toActor(currentUser), 'team.manage', orgId);
        update((d) => {
          const p = d.profiles.find((x) => x.id === id);
          if (!p || p.is_active === active) return;
          const before = { is_active: p.is_active };
          p.is_active = active;
          p.updated_at = nowIso();
          log(d, active ? 'enabled' : 'disabled', 'profile', id,
            `${p.full_name} ${active ? 'enabled' : 'disabled'}`,
            { old: before, new: { is_active: active } });
        });
      },

      saveOrgSettings: (patch) => {
        assertCan(toActor(currentUser), 'settings.update', orgId);
        update((d) => {
          const o = d.organizations[0];
          const before: Record<string, unknown> = {};
          for (const k of Object.keys(patch)) before[k] = (o as unknown as Record<string, unknown>)[k];
          Object.assign(o, patch, { updated_at: nowIso() });
          log(d, 'updated', 'settings', o.id, 'Organization settings updated',
            { old: before, new: patch });
        });
      },

      createExpense: (input) => {
        assertCan(toActor(currentUser), 'expenses.create', orgId);
        const expense: Expense = {
          ...baseFields(),
          category: input.category ?? 'miscellaneous',
          description: input.description ?? 'Expense',
          amount: input.amount ?? 0,
          vendor: input.vendor ?? null,
          spent_at: input.spent_at ?? nowIso(),
          method: input.method ?? 'upi',
          is_recurring: input.is_recurring ?? false,
          attachment_url: null,
          created_by: currentUser?.id ?? null,
        };
        update((d) => {
          d.expenses.unshift(expense);
          log(d, 'created', 'expense', expense.id,
            `Expense ₹${expense.amount} — ${expense.description}`, { new: expense });
        });
        return expense;
      },
      updateExpense: (id, patch) =>
        update((d) => {
          const i = d.expenses.findIndex((e) => e.id === id);
          if (i < 0) return;
          assertCan(toActor(currentUser), 'expenses.update', d.expenses[i].organization_id);
          const before = { ...d.expenses[i] };
          d.expenses[i] = { ...d.expenses[i], ...patch, updated_at: nowIso() };
          log(d, 'updated', 'expense', id,
            `Expense ${d.expenses[i].description} updated`,
            { old: before, new: d.expenses[i] });
        }),
      deleteExpense: (id) =>
        update((d) => {
          const victim = d.expenses.find((e) => e.id === id);
          if (!victim) return;
          assertCan(toActor(currentUser), 'expenses.delete', victim.organization_id);
          d.expenses = d.expenses.filter((e) => e.id !== id);
          // Deletes must leave a durable record of WHAT was removed.
          log(d, 'deleted', 'expense', id,
            `Expense ₹${victim.amount} — ${victim.description} deleted`, { old: victim });
        }),

      createInvoiceForOrder: (orderId) => {
        const order = db.orders.find((o) => o.id === orderId);
        if (!order) return null;
        const existing = db.invoices.find((i) => i.order_id === orderId);
        if (existing) return existing;
        const invoice: Invoice = {
          ...baseFields(),
          invoice_number: nextNumber(db, 'invoice'),
          customer_id: order.customer_id,
          order_id: order.id,
          issue_date: nowIso(),
          due_date: new Date(Date.now() + 7 * 86400000).toISOString(),
          subtotal: order.subtotal,
          discount: order.discount,
          tax: order.tax,
          total: order.total,
          amount_paid: order.amount_paid,
          status: order.amount_paid >= order.total ? 'paid' : order.amount_paid > 0 ? 'partial' : 'sent',
          items: order.items.map((i) => ({
            id: newId(),
            description: i.product_name,
            quantity: i.quantity,
            unit_price: i.unit_price,
            total: i.line_total,
          })),
          notes: null,
        };
        update((d) => {
          d.invoices.unshift(invoice);
          log(d, 'created', 'invoice', invoice.id,
            `Invoice ${invoice.invoice_number} issued for ₹${invoice.total}`, { new: invoice });
        });
        return invoice;
      },

      queueCommunication: (input) => {
        assertCan(toActor(currentUser), 'communications.create', orgId);
        const address = input.to_address.trim();
        const body = input.body.trim();
        if (!address) throw new ValidationError(['A recipient address is required.']);
        if (body.length < 1 || body.length > 4000) throw new ValidationError(['Message must be between 1 and 4000 characters.']);
        const communication: CommunicationLog = {
          ...baseFields(),
          channel: input.channel,
          direction: 'outbound',
          customer_id: input.customer_id ?? null,
          template_id: null,
          to_address: address,
          body,
          status: 'queued',
          provider: 'pending-provider',
          error: null,
        };
        update((d) => {
          d.communication_logs.unshift(communication);
          log(d, 'queued', 'communication', communication.id,
            `${communication.channel} message queued`, {
              new: { channel: communication.channel, customer_id: communication.customer_id, status: communication.status },
            });
        });
        return communication;
      },

      createApproval: (input) => {
        assertCan(toActor(currentUser), 'approvals.create', orgId);
        const errors = validateApprovalInput(input);
        if (errors.length) throw new ValidationError(errors);
        if (!currentUser) throw new ValidationError(['An authenticated requester is required.']);
        const financialImpact = round2(input.financial_impact ?? 0);
        const approval: ApprovalRequest = {
          ...baseFields(),
          request_type: input.request_type,
          title: input.title.trim(),
          description: input.description?.trim() ?? '',
          reason: input.reason.trim(),
          risk_level: input.risk_level ?? inferApprovalRisk(input.request_type, financialImpact),
          status: 'pending',
          entity_type: input.entity_type ?? null,
          entity_id: input.entity_id ?? null,
          financial_impact: financialImpact,
          payload: input.payload ?? {},
          requested_by: currentUser.id,
          reviewed_by: null,
          reviewed_at: null,
          review_note: null,
          expires_at: input.expires_at ?? null,
          executed_at: null,
        };
        update((d) => {
          d.approval_requests.unshift(approval);
          log(d, 'requested', 'approval_request', approval.id,
            `Approval requested: ${approval.title}`, { new: approval });
        });
        return approval;
      },

      reviewApproval: (id, decision, note) => {
        assertCan(toActor(currentUser), 'approvals.review', orgId);
        update((d) => {
          const approval = d.approval_requests.find((item) => item.id === id);
          if (!approval) throw new ValidationError(['Approval request was not found.']);
          assertCan(toActor(currentUser), 'approvals.review', approval.organization_id);
          const error = canReviewApproval(approval, decision);
          if (error) throw new ValidationError([error]);
          const before = { status: approval.status, reviewed_by: approval.reviewed_by };
          approval.status = decision;
          approval.reviewed_by = currentUser?.id ?? null;
          approval.reviewed_at = nowIso();
          approval.review_note = note?.trim() || null;
          approval.updated_at = nowIso();
          log(d, decision, 'approval_request', id,
            `${approval.title} ${decision}`, { old: before, new: {
              status: approval.status,
              reviewed_by: approval.reviewed_by,
              review_note: approval.review_note,
            } });
          // In production, migration 0019 atomically creates the durable action
          // job after approval. Demo mode records the decision but never fakes
          // execution of a consequential action.
        });
      },

      markNotificationRead: (id) =>
        update((d) => {
          const n = d.notifications.find((x) => x.id === id);
          if (n) n.read_at = nowIso();
        }),
      markAllNotificationsRead: () =>
        update((d) => {
          for (const n of d.notifications) n.read_at = n.read_at ?? nowIso();
        }),
    };
    return v;
  }, [db, currentUserId, update, syncError, authSession]);

  if (!value) {
    return (
      <div className="flex h-screen items-center justify-center bg-[var(--bg)]">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-[var(--border)] border-t-[var(--accent)]" />
          <p className="text-sm text-[var(--muted)]">Loading DigiTech Business OS…</p>
        </div>
      </div>
    );
  }

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used inside <StoreProvider>');
  return ctx;
}

/* ------------------------------------------------------------------ */
/* Derived state: subscription status + generated notifications        */
/* ------------------------------------------------------------------ */
function withDerived(db: Database): Database {
  const org = db.organizations[0];
  const threshold = org?.expiry_threshold_days ?? 15;
  for (const s of db.subscriptions) s.status = deriveSubscriptionStatus(s, threshold);

  // Invoices are a projection of their order's payment ledger, so they are
  // reconciled on every derivation rather than snapshotted at creation.
  reconcileInvoices(db);

  const notifications: Database['notifications'] = [];
  const mk = (
    type: string,
    title: string,
    body: string,
    severity: Database['notifications'][number]['severity'],
    entity_type: string,
    entity_id: string,
  ) => {
    const existing = db.notifications.find((n) => n.type === type && n.entity_id === entity_id);
    notifications.push({
      id: existing?.id ?? `ntf-${type}-${entity_id}`,
      organization_id: org?.id ?? '',
      created_at: existing?.created_at ?? nowIso(),
      updated_at: nowIso(),
      deleted_at: null,
      type,
      title,
      body,
      severity,
      entity_type,
      entity_id,
      read_at: existing?.read_at ?? null,
    });
  };

  for (const s of db.subscriptions.filter((x) => x.status === 'expiring').slice(0, 25)) {
    const c = db.customers.find((x) => x.id === s.customer_id);
    const days = Math.ceil((new Date(s.expiry_date).getTime() - Date.now()) / 86400000);
    mk('subscription.expiring', 'Subscription expiring', `${c?.name ?? 'Customer'} — ${s.product_name} expires in ${days} day(s)`, 'warning', 'subscription', s.id);
  }
  for (const o of db.orders.filter((x) => x.outstanding > 0 && x.status !== 'cancelled').slice(0, 20)) {
    const c = db.customers.find((x) => x.id === o.customer_id);
    mk('payment.overdue', 'Payment outstanding', `${o.order_number} — ₹${o.outstanding} pending from ${c?.name ?? 'customer'}`, 'critical', 'order', o.id);
  }
  for (const a of db.activations.filter((x) => x.status === 'ready' || x.status === 'waiting_supplier').slice(0, 20)) {
    mk('activation.pending', 'Activation pending', `${a.product_name} awaiting delivery`, 'info', 'activation', a.id);
  }
  for (const t of db.support_tickets.filter((x) => x.status === 'open').slice(0, 15)) {
    mk('support.open', 'Open support ticket', `${t.ticket_number} — ${t.subject}`, 'warning', 'ticket', t.id);
  }
  for (const t of db.tasks.filter((x) => x.status !== 'done' && x.due_at && new Date(x.due_at) < new Date()).slice(0, 15)) {
    mk('task.overdue', 'Task overdue', t.title, 'warning', 'task', t.id);
  }
  for (const p of db.products.filter((x) => x.stock !== null && x.stock <= x.low_stock_threshold).slice(0, 10)) {
    mk('product.low_stock', 'Low stock', `${p.name} — ${p.stock} left`, 'warning', 'product', p.id);
  }

  db.notifications = notifications.sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
  );
  return db;
}
