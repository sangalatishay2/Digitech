import { createCipheriv, createDecipheriv, randomBytes, createHash } from 'node:crypto';

/**
 * Envelope encryption for activation credentials at rest.
 *
 * Activation records hold what the customer actually bought: the account email
 * and password for a shared subscription, a license key, admin instructions.
 * Postgres RLS controls *who can read the row*, but the values are still
 * plaintext in the table, in backups and in any logical replication stream.
 * Encrypting them means a leaked dump is not a leaked credential set.
 *
 * AES-256-GCM: authenticated, so tampering is detected rather than silently
 * decrypting to garbage. A fresh random IV per value means identical passwords
 * do not produce identical ciphertext.
 *
 * The key comes from ACTIVATION_ENCRYPTION_KEY — server-only, never
 * NEXT_PUBLIC_. Missing key is a hard failure: silently storing plaintext when
 * the operator believes it is encrypted is worse than refusing to store at all.
 */

const ALGO = 'aes-256-gcm';
const IV_BYTES = 12;
const TAG_BYTES = 16;
export const CIPHER_PREFIX = 'enc:v1:';

export class EncryptionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'EncryptionError';
  }
}

/**
 * Derive a 32-byte key. A 64-char hex string is used directly; anything else is
 * hashed so an operator cannot accidentally weaken the key by supplying a short
 * passphrase.
 */
export function deriveKey(secret: string): Buffer {
  if (/^[0-9a-fA-F]{64}$/.test(secret)) return Buffer.from(secret, 'hex');
  return createHash('sha256').update(secret, 'utf8').digest();
}

export function encryptionKey(): Buffer {
  const raw = process.env.ACTIVATION_ENCRYPTION_KEY;
  if (!raw || raw.length < 16) {
    throw new EncryptionError(
      'ACTIVATION_ENCRYPTION_KEY is missing or too short (min 16 chars; 64 hex chars recommended). ' +
        'Refusing to store activation credentials unencrypted.',
    );
  }
  return deriveKey(raw);
}

export function encryptionAvailable(): boolean {
  const raw = process.env.ACTIVATION_ENCRYPTION_KEY;
  return Boolean(raw && raw.length >= 16);
}

export function isEncrypted(value: unknown): value is string {
  return typeof value === 'string' && value.startsWith(CIPHER_PREFIX);
}

/** Encrypt a value. Returns `enc:v1:<iv>:<tag>:<ciphertext>`, all base64. */
export function encryptSecret(plain: string, key: Buffer = encryptionKey()): string {
  if (plain === '') return '';
  const iv = randomBytes(IV_BYTES);
  const cipher = createCipheriv(ALGO, key, iv);
  const ct = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${CIPHER_PREFIX}${iv.toString('base64')}:${tag.toString('base64')}:${ct.toString('base64')}`;
}

/** Decrypt a value produced by encryptSecret. Throws if tampered with. */
export function decryptSecret(payload: string, key: Buffer = encryptionKey()): string {
  if (payload === '') return '';
  if (!isEncrypted(payload)) {
    // An `enc:` value we cannot parse is a *future or corrupted* envelope, not
    // legacy plaintext. Returning it verbatim would hand the caller ciphertext
    // labelled as a password, so refuse loudly instead.
    if (/^enc:/.test(payload)) {
      throw new EncryptionError('Unsupported ciphertext version.');
    }
    // Value predates encryption (or was written directly in SQL). Return as-is
    // so existing rows stay readable while they are migrated.
    return payload;
  }
  const body = payload.slice(CIPHER_PREFIX.length);
  const parts = body.split(':');
  if (parts.length !== 3) throw new EncryptionError('Malformed ciphertext.');
  const [ivB64, tagB64, ctB64] = parts;
  const iv = Buffer.from(ivB64, 'base64');
  const tag = Buffer.from(tagB64, 'base64');
  const ct = Buffer.from(ctB64, 'base64');
  if (iv.length !== IV_BYTES) throw new EncryptionError('Bad IV length.');
  if (tag.length !== TAG_BYTES) throw new EncryptionError('Bad auth tag length.');
  try {
    const d = createDecipheriv(ALGO, key, iv);
    d.setAuthTag(tag);
    return Buffer.concat([d.update(ct), d.final()]).toString('utf8');
  } catch {
    throw new EncryptionError('Could not decrypt: wrong key or the value was tampered with.');
  }
}

/** Fields on an activation that must be encrypted before they reach the table. */
export const ENCRYPTED_ACTIVATION_FIELDS = [
  'activation_email',
  'activation_password',
  'activation_details',
  'internal_instructions',
] as const;

export type EncryptedField = (typeof ENCRYPTED_ACTIVATION_FIELDS)[number];

export function encryptActivationFields<T extends Record<string, unknown>>(row: T): T {
  const key = encryptionKey();
  const out: Record<string, unknown> = { ...row };
  for (const f of ENCRYPTED_ACTIVATION_FIELDS) {
    const v = out[f];
    if (typeof v === 'string' && v !== '' && !isEncrypted(v)) {
      out[f] = encryptSecret(v, key);
    }
  }
  return out as T;
}

export function decryptActivationFields<T extends Record<string, unknown>>(row: T): T {
  const key = encryptionKey();
  const out: Record<string, unknown> = { ...row };
  for (const f of ENCRYPTED_ACTIVATION_FIELDS) {
    const v = out[f];
    if (typeof v === 'string' && v !== '') out[f] = decryptSecret(v, key);
  }
  return out as T;
}

/** Strip secret fields entirely — for anything that reaches a browser. */
export function redactActivationFields<T extends Record<string, unknown>>(row: T): T {
  const out: Record<string, unknown> = { ...row };
  for (const f of ENCRYPTED_ACTIVATION_FIELDS) {
    if (f in out) out[f] = null;
  }
  return out as T;
}
