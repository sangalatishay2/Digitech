import type { Profile, Role, UUID } from '@/lib/types';
import { getRequestClient, getServiceClient } from '@/lib/data/supabase-client';

/**
 * Server-side session resolution.
 *
 * Establishes, from a bearer token alone:
 *   who the caller is (auth user)  →  which profile  →  which organization
 *   →  which role
 *
 * All four come from the database, never from the client. A request may claim
 * any organization_id it likes; it is ignored. This is the identity that
 * server routes authorize against.
 */

export interface AuthenticatedSession {
  userId: string;
  email: string | null;
  accessToken: string;
  profile: Profile;
  organizationId: UUID;
  role: Role;
}

export type SessionOutcome =
  | { ok: true; session: AuthenticatedSession }
  | { ok: false; status: 401 | 403; reason: string };

/** Extract the bearer token from an incoming request. */
export function bearerFrom(req: Request): string | null {
  const h = req.headers.get('authorization') ?? req.headers.get('Authorization');
  if (!h) return null;
  const m = /^Bearer\s+(.+)$/i.exec(h.trim());
  return m ? m[1] : null;
}

/**
 * Verify a token and resolve the acting profile.
 *
 * The profile lookup uses the service client on purpose: `profiles` has RLS
 * that depends on `current_org_id()`, which itself reads `profiles`. Resolving
 * identity through the user's own client would be circular. The service client
 * reads exactly one row, by auth_user_id, and every subsequent data operation
 * is performed with the *user's* token so RLS still governs the actual work.
 */
export async function resolveServerSession(token: string | null): Promise<SessionOutcome> {
  if (!token) return { ok: false, status: 401, reason: 'Missing bearer token.' };

  const asUser = getRequestClient(token);
  const { data: userData, error: userErr } = await asUser.auth.getUser();
  if (userErr || !userData?.user) {
    return { ok: false, status: 401, reason: 'Invalid or expired session.' };
  }
  const user = userData.user;

  const svc = getServiceClient();
  const { data: rows, error: profErr } = await svc
    .from('profiles')
    .select('*')
    .eq('auth_user_id', user.id)
    .limit(1);

  if (profErr) return { ok: false, status: 403, reason: `Profile lookup failed: ${profErr.message}` };

  const profile = (rows ?? [])[0] as Profile | undefined;
  if (!profile) return { ok: false, status: 403, reason: 'No profile is linked to this account.' };

  // Mirrors current_org_id()/current_app_role() in SQL, which return NULL for a
  // disabled profile so every policy denies. Fail closed here too.
  if (profile.deleted_at) return { ok: false, status: 403, reason: 'This account has been removed.' };
  if (!profile.is_active) {
    return { ok: false, status: 403, reason: 'This account is disabled and cannot perform actions.' };
  }
  if (!profile.organization_id) {
    return { ok: false, status: 403, reason: 'Profile has no organization.' };
  }

  return {
    ok: true,
    session: {
      userId: user.id,
      email: user.email ?? null,
      accessToken: token,
      profile,
      organizationId: profile.organization_id,
      role: profile.role,
    },
  };
}

/** Resolve straight from a Request. */
export function sessionFromRequest(req: Request): Promise<SessionOutcome> {
  return resolveServerSession(bearerFrom(req));
}

/** Standard JSON error for a failed session. */
export function sessionErrorResponse(outcome: Extract<SessionOutcome, { ok: false }>): Response {
  return new Response(JSON.stringify({ error: outcome.reason }), {
    status: outcome.status,
    headers: { 'Content-Type': 'application/json' },
  });
}
