import type { Profile } from '@/lib/types';
import { isDemoMode } from '@/lib/runtime/mode';

/**
 * Session / identity resolution.
 *
 * Two sources of identity, chosen by runtime mode and never mixed:
 *
 *   demo       — the in-app user switcher. Convenient for evaluation, and the
 *                only reason it is tolerable is that demo mode holds no real
 *                data.
 *   production — a verified Supabase session. The switcher is refused outright;
 *                being able to become another user by clicking a menu would
 *                make every permission check theatre.
 */

export interface Session {
  userId: string;
  email: string | null;
  /** Supabase access token, when a real session backs this identity. */
  accessToken: string | null;
  source: 'demo-switch' | 'supabase';
}

export interface SessionResolution {
  session: Session | null;
  profile: Profile | null;
  /** Why no usable identity was produced, for display. */
  reason: string | null;
}

export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AuthError';
  }
}

/**
 * A profile may only act if it exists, is active, and is not soft-deleted.
 * Mirrors current_org_id() / current_app_role() in SQL, which return NULL for a
 * disabled profile so every RLS policy evaluates false.
 */
export function profileCanAct(p: Profile | null | undefined): boolean {
  return Boolean(p && p.is_active && !p.deleted_at);
}

export function assertProfileCanAct(p: Profile | null | undefined): asserts p is Profile {
  if (!p) throw new AuthError('Not signed in.');
  if (p.deleted_at) throw new AuthError('This account has been removed.');
  if (!p.is_active) throw new AuthError('This account is disabled and cannot perform actions.');
}

/**
 * Resolve the acting profile for a request/render.
 *
 * In production the requested id is ignored entirely — identity comes from the
 * verified session and nothing else.
 */
export function resolveSession(
  profiles: Profile[],
  opts: { requestedUserId?: string | null; session?: Session | null },
): SessionResolution {
  const demo = isDemoMode();

  if (!demo) {
    const s = opts.session ?? null;
    if (!s) {
      return { session: null, profile: null, reason: 'No authenticated session.' };
    }
    const profile = profiles.find((p) => p.auth_user_id === s.userId) ?? null;
    if (!profile) {
      return { session: s, profile: null, reason: 'No profile is linked to this account.' };
    }
    if (!profileCanAct(profile)) {
      return {
        session: s,
        profile: null,
        reason: profile.deleted_at
          ? 'This account has been removed.'
          : 'This account is disabled and cannot perform actions.',
      };
    }
    return { session: s, profile, reason: null };
  }

  // Demo mode: the switcher picks the identity, but a disabled profile is still
  // inert — that rule must hold in every mode or the tests prove nothing.
  const requested = opts.requestedUserId
    ? profiles.find((p) => p.id === opts.requestedUserId)
    : undefined;
  const fallback = profiles.find((p) => profileCanAct(p)) ?? null;
  const chosen = requested ?? fallback;

  if (!chosen) return { session: null, profile: null, reason: 'No profiles exist.' };
  if (!profileCanAct(chosen)) {
    return {
      session: null,
      profile: null,
      reason: chosen.deleted_at
        ? 'This account has been removed.'
        : 'This account is disabled and cannot perform actions.',
    };
  }
  return {
    session: { userId: chosen.id, email: chosen.email ?? null, accessToken: null, source: 'demo-switch' },
    profile: chosen,
    reason: null,
  };
}

/** In-app user switching is a demo affordance and must never work in production. */
export function assertSwitchingAllowed() {
  if (!isDemoMode()) {
    throw new AuthError(
      'User switching is disabled in production mode. Sign in with the intended account.',
    );
  }
}
