import {
  LayoutDashboard, ShoppingCart, CreditCard, FileText, Users, UserPlus, Layers,
  RefreshCw, CalendarClock, CalendarX, Repeat, Zap, CheckSquare, LifeBuoy,
  Package, FolderTree, Truck, TrendingUp, PiggyBank, Receipt, Banknote,
  Megaphone, MessageCircle, BarChart3, Workflow, UsersRound, Bell, History, Settings, Bot, ShieldCheck, Inbox, ScanSearch,
  type LucideIcon,
} from 'lucide-react';

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  /** Key into the badge-count map supplied by the sidebar. */
  badge?: string;
}
export interface NavGroup {
  label: string | null;
  items: NavItem[];
}

export const NAV: NavGroup[] = [
  {
    label: 'Overview',
    items: [
      { label: 'Dashboard', href: '/', icon: LayoutDashboard },
      { label: 'AI Copilot', href: '/copilot', icon: Bot },
    ],
  },
  {
    label: 'Sales',
    items: [
      { label: 'Orders', href: '/orders', icon: ShoppingCart, badge: 'orders' },
      { label: 'Payments', href: '/payments', icon: CreditCard, badge: 'payments' },
      { label: 'Invoices', href: '/invoices', icon: FileText },
    ],
  },
  {
    label: 'Customers',
    items: [
      { label: 'Customers', href: '/customers', icon: Users },
      { label: 'Leads', href: '/leads', icon: UserPlus, badge: 'leads' },
      { label: 'Segments', href: '/segments', icon: Layers },
    ],
  },
  {
    label: 'Subscriptions',
    items: [
      { label: 'Subscriptions', href: '/subscriptions', icon: RefreshCw },
      { label: 'Renewal Center', href: '/renewals', icon: Repeat, badge: 'renewals' },
      { label: 'Expiring', href: '/subscriptions/expiring', icon: CalendarClock, badge: 'expiring' },
      { label: 'Expired', href: '/subscriptions/expired', icon: CalendarX },
    ],
  },
  {
    label: 'Operations',
    items: [
      { label: 'Unified Inbox', href: '/inbox', icon: Inbox, badge: 'inbox' },
      { label: 'Activations', href: '/activations', icon: Zap, badge: 'activations' },
      { label: 'Tasks', href: '/tasks', icon: CheckSquare, badge: 'tasks' },
      { label: 'Support', href: '/support', icon: LifeBuoy, badge: 'support' },
    ],
  },
  {
    label: 'Catalog',
    items: [
      { label: 'Products', href: '/products', icon: Package },
      { label: 'Categories', href: '/categories', icon: FolderTree },
      { label: 'Suppliers', href: '/suppliers', icon: Truck },
    ],
  },
  {
    label: 'Finance',
    items: [
      { label: 'Revenue', href: '/finance/revenue', icon: TrendingUp },
      { label: 'Profit', href: '/finance/profit', icon: PiggyBank },
      { label: 'Expenses', href: '/finance/expenses', icon: Receipt },
      { label: 'Supplier Payments', href: '/finance/supplier-payments', icon: Banknote },
      { label: 'Analytics', href: '/analytics', icon: BarChart3 },
      { label: 'Finance Intelligence', href: '/finance/intelligence', icon: ScanSearch },
    ],
  },
  {
    label: 'Automation',
    items: [
      { label: 'Automations', href: '/automations', icon: Workflow },
      { label: 'Campaigns', href: '/marketing/campaigns', icon: Megaphone },
      { label: 'WhatsApp', href: '/marketing/whatsapp', icon: MessageCircle },
    ],
  },
  {
    label: 'Admin',
    items: [
      { label: 'Approval Center', href: '/approvals', icon: ShieldCheck, badge: 'approvals' },
      { label: 'Team', href: '/team', icon: UsersRound },
      { label: 'Notifications', href: '/notifications', icon: Bell, badge: 'notifications' },
      { label: 'Activity', href: '/activity', icon: History },
      { label: 'Settings', href: '/settings', icon: Settings },
    ],
  },
];

export const ALL_NAV_ITEMS: NavItem[] = NAV.flatMap((g) => g.items);
