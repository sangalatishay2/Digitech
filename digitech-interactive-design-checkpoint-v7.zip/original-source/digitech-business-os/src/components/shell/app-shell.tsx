'use client';

import React, { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import { Sidebar } from './sidebar';
import { Topbar } from './topbar';
import { CommandPalette } from './command-palette';
import { SyncBanner } from './sync-banner';

/**
 * Routes that must render without the application chrome.
 *
 * The sign-in page sat inside the shell, so an unauthenticated visitor was
 * shown the sidebar, workspace switcher and global search of an app they had
 * not signed into yet. Those controls also mount store-backed widgets that have
 * no meaning without an identity.
 */
const BARE_ROUTES = ['/login', '/auth/callback'];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(() =>
    typeof window !== 'undefined' && localStorage.getItem('digitech-os:sidebar') === '1',
  );
  const [mobileOpen, setMobileOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen((v) => !v);
      }
      // Escape closes the mobile navigation drawer.
      if (e.key === 'Escape') setMobileOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileOpen]);

  const toggle = () => {
    setCollapsed((c) => {
      localStorage.setItem('digitech-os:sidebar', c ? '0' : '1');
      return !c;
    });
  };

  // Rendered before any chrome: an auth screen is standalone by definition.
  if (BARE_ROUTES.some((r) => pathname?.startsWith(r))) {
    return <>{children}</>;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[var(--bg)]">
      <div className="hidden lg:block">
        <Sidebar collapsed={collapsed} onToggle={toggle} />
      </div>

      {mobileOpen && (
        <div className="fixed inset-0 z-[55] lg:hidden">
          <div
            className="animate-overlay absolute inset-0 bg-[#0a0b0d]/50 backdrop-blur-[3px]"
            onClick={() => setMobileOpen(false)}
          />
          <div className="animate-slide-in-left relative h-full w-[250px]">
            <Sidebar collapsed={false} mobile onToggle={toggle} onNavigate={() => setMobileOpen(false)} />
          </div>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar onMenu={() => setMobileOpen(true)} onOpenPalette={() => setPaletteOpen(true)} />
        <SyncBanner />
        <main className="flex-1 overflow-y-auto">
          <div className="mx-auto w-full max-w-[1560px] px-4 py-5 md:px-6 md:py-6">{children}</div>
        </main>
      </div>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />
    </div>
  );
}

/** Re-exported from primitives so every page shares one implementation. */
export { PageHeader } from '@/components/ui/primitives';
