'use client';

import React from 'react';
import { CloudOff } from 'lucide-react';
import { useStore } from '@/lib/store';

/**
 * Surfaces a failed server write.
 *
 * Without this the app would keep showing optimistically-applied changes that
 * never reached the database — the user would believe their work was saved.
 * The banner is intentionally persistent and non-dismissible: a silent sync
 * failure is exactly the kind of thing that turns into lost data.
 */
export function SyncBanner() {
  const { syncError } = useStore();
  if (!syncError) return null;

  return (
    <div
      role="alert"
      className="flex items-start gap-2 px-4 py-2 text-xs md:px-6"
      style={{
        background: 'var(--danger-soft)',
        color: 'var(--danger)',
        borderBottom: '1px solid var(--danger-border)',
      }}
    >
      <CloudOff size={14} className="mt-0.5 shrink-0" />
      <div>
        <span className="font-medium">Changes are not being saved.</span>{' '}
        <span style={{ opacity: 0.9 }}>{syncError}</span>{' '}
        <span style={{ opacity: 0.9 }}>
          Reload the page to re-sync; recent edits may need to be re-entered.
        </span>
      </div>
    </div>
  );
}
