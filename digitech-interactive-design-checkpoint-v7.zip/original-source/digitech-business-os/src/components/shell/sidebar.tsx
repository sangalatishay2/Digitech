'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { NAV } from './nav-config';
import { resolveMode } from '@/lib/runtime/mode';
import { cn } from '@/lib/utils';
import { PanelLeftClose, PanelLeftOpen, ChevronsUpDown, Check, Database } from 'lucide-react';
import { useStore } from '@/lib/store';
import { Dropdown, MenuItem, MenuLabel, MenuSeparator, Tooltip } from '@/components/ui/primitives';

function Logo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} fill="none" aria-hidden>
      <rect width="32" height="32" rx="8" fill="var(--accent)" />
      <path d="M16 7l8 4.6v9.2L16 25.4 8 20.8v-9.2L16 7z" fill="#fff" fillOpacity=".92" />
      <path d="M16 11.4l4.2 2.4v4.8L16 21l-4.2-2.4v-4.8L16 11.4z" fill="var(--accent)" />
    </svg>
  );
}

export function Sidebar({
  collapsed,
  onToggle,
  onNavigate,
  mobile,
}: {
  collapsed: boolean;
  onToggle: () => void;
  onNavigate?: () => void;
  mobile?: boolean;
}) {
  const mode = resolveMode();
  const pathname = usePathname();
  const { db } = useStore();
  const mini = collapsed && !mobile;

  const counts: Record<string, number> = {
    approvals: db.approval_requests.filter((item) => item.status === 'pending').length,
    inbox: db.communication_logs.filter((item) => item.direction === 'inbound').length,
    activations: db.activations.filter((a) =>
      ['ready', 'processing', 'waiting_supplier', 'waiting_payment'].includes(a.status),
    ).length,
    renewals: db.subscriptions.filter((s) => s.status === 'expiring' || s.status === 'expired').length,
    expiring: db.subscriptions.filter((s) => s.status === 'expiring').length,
    support: db.support_tickets.filter((t) => ['open', 'in_progress'].includes(t.status)).length,
    tasks: db.tasks.filter((t) => t.status !== 'done' && t.status !== 'cancelled').length,
    notifications: db.notifications.filter((n) => !n.read_at).length,
    leads: db.leads.filter((l) => !['won', 'lost'].includes(l.status)).length,
    orders: db.orders.filter((o) => ['new', 'awaiting_payment', 'processing', 'activation_pending'].includes(o.status)).length,
    payments: db.orders.filter((o) => o.outstanding > 0 && !['cancelled', 'refunded'].includes(o.status)).length,
  };

  const isActive = (href: string) =>
    href === '/' ? pathname === '/' : pathname === href || pathname.startsWith(href + '/');

  return (
    <aside
      className={cn(
        'flex h-full flex-col border-r border-[var(--border)] bg-[var(--sidebar)] transition-[width] duration-200',
        mini ? 'w-[62px]' : 'w-[250px]',
      )}
    >
      {/* Brand */}
      <div className={cn('flex h-[52px] shrink-0 items-center gap-2.5 px-3', mini && 'justify-center px-0')}>
        <Logo className="h-[26px] w-[26px] shrink-0" />
        {!mini && (
          <div className="min-w-0 flex-1">
            <p className="truncate text-[13.5px] font-semibold leading-tight tracking-[-0.015em]">DigiTech</p>
            <p className="truncate text-[10px] font-medium uppercase tracking-[0.07em] text-[var(--muted-2)]">
              Business OS
            </p>
          </div>
        )}
      </div>

      {/* Workspace selector */}
      {!mini && (
        <div className="px-2.5 pb-2.5">
          <Dropdown
            align="left"
            width={222}
            trigger={
              <button className="press flex w-full items-center gap-2 rounded-[8px] border border-[var(--border)] bg-[var(--surface)] px-2 py-[7px] text-left transition-colors hover:bg-[var(--surface-2)]">
                <span className="flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-[5px] bg-[var(--accent-soft)] text-[10.5px] font-bold text-[var(--accent)]">
                  DT
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12.5px] font-medium leading-tight">
                    {db.organizations[0]?.name ?? 'DigiTech'}
                  </span>
                  <span className="block truncate text-[10.5px] leading-tight text-[var(--muted-2)]">
                    {db.organizations[0]?.currency ?? 'INR'} · Workspace
                  </span>
                </span>
                <ChevronsUpDown className="h-3.5 w-3.5 shrink-0 text-[var(--muted-2)]" />
              </button>
            }
          >
            <MenuLabel>Workspace</MenuLabel>
            <MenuItem checked icon={Check}>
              {db.organizations[0]?.name ?? 'DigiTech'}
            </MenuItem>
            {/* Multi-workspace switching needs org membership + a real session.
                Rather than render a switcher that cannot switch, state the limit. */}
            <div className="px-2 pb-1.5 pt-0.5 text-[11px] leading-snug text-[var(--muted-2)]">
              Single workspace. Switching requires multi-org membership (not yet supported).
            </div>
            <MenuSeparator />
            <MenuLabel>Data source</MenuLabel>
            <div className="flex items-center gap-2 px-2 py-1.5 text-[12px] text-[var(--muted)]">
              <Database className="h-3.5 w-3.5" />
              {mode.mode === 'demo' ? 'Local demo data' : 'Supabase'}
              <span
                className="ml-auto h-1.5 w-1.5 rounded-full"
                style={{ background: mode.degraded ? 'var(--warning)' : 'var(--success)' }}
              />
            </div>
            {mode.mode === 'demo' && (
              <div className="px-2 pb-1.5 text-[11px] leading-snug text-[var(--warning)]">
                Demo mode — data is stored in this browser only. Not for real customer data.
              </div>
            )}
            {mode.degraded && mode.reason && (
              <div className="px-2 pb-1.5 text-[11px] leading-snug text-[var(--danger)]">
                {mode.reason}
              </div>
            )}
          </Dropdown>
        </div>
      )}

      {/* Navigation */}
      <nav className={cn('flex-1 overflow-y-auto pb-3', mini ? 'px-2' : 'px-2.5')}>
        {NAV.map((group, gi) => (
          <div key={gi} className="mb-[14px]">
            {group.label && !mini && (
              <p className="px-2 pb-[5px] text-[10px] font-semibold uppercase tracking-[0.08em] text-[var(--muted-2)]">
                {group.label}
              </p>
            )}
            {group.label && mini && gi > 0 && <div className="mx-2 mb-3 border-t border-[var(--border)]" />}
            <ul className="space-y-[1px]">
              {group.items.map((item) => {
                const active = isActive(item.href);
                const count = item.badge ? counts[item.badge] : undefined;
                const link = (
                  <Link
                    href={item.href}
                    onClick={onNavigate}
                    className={cn(
                      'nav-item group flex items-center gap-2.5 rounded-[7px] text-[13px] font-medium',
                      mini ? 'justify-center px-0 py-[7px]' : 'px-2 py-[6px]',
                      active
                        ? 'nav-item-active bg-[var(--accent-soft)] text-[var(--accent)]'
                        : 'text-[var(--sidebar-fg)] hover:bg-[var(--surface-2)] hover:text-[var(--fg)]',
                    )}
                  >
                    <item.icon
                      className={cn('h-[16px] w-[16px] shrink-0', active ? 'opacity-100' : 'opacity-70')}
                      strokeWidth={active ? 2.2 : 1.9}
                    />
                    {!mini && <span className="flex-1 truncate">{item.label}</span>}
                    {!mini && !!count && (
                      <span
                        className={cn(
                          'min-w-[18px] rounded-[5px] px-1 text-center text-[10.5px] font-semibold tabular-nums',
                          active
                            ? 'bg-[var(--accent)]/15 text-[var(--accent)]'
                            : 'bg-[var(--surface-3)] text-[var(--muted-2)]',
                        )}
                      >
                        {count > 99 ? '99+' : count}
                      </span>
                    )}
                    {mini && !!count && (
                      <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
                    )}
                  </Link>
                );
                return (
                  <li key={item.href} className="relative">
                    {mini ? (
                      <Tooltip label={item.label} side="right" className="w-full">
                        {link}
                      </Tooltip>
                    ) : (
                      link
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className={cn('shrink-0 border-t border-[var(--border)]', mini ? 'p-2' : 'p-2.5')}>
        {!mini ? (
          <div className="flex items-center justify-between gap-2">
            <div className="flex min-w-0 items-center gap-1.5 text-[11px] text-[var(--muted-2)]">
              <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--success)]" />
              <span className="truncate">Local demo data</span>
            </div>
            {!mobile && (
              <button
                onClick={onToggle}
                aria-label="Collapse sidebar"
                className="press rounded-[6px] p-1.5 text-[var(--muted-2)] transition-colors hover:bg-[var(--surface-2)] hover:text-[var(--fg)]"
              >
                <PanelLeftClose className="h-4 w-4" />
              </button>
            )}
          </div>
        ) : (
          <Tooltip label="Expand sidebar" side="right">
            <button
              onClick={onToggle}
              aria-label="Expand sidebar"
              className="press flex w-full justify-center rounded-[6px] p-1.5 text-[var(--muted-2)] hover:bg-[var(--surface-2)] hover:text-[var(--fg)]"
            >
              <PanelLeftOpen className="h-4 w-4" />
            </button>
          </Tooltip>
        )}
      </div>
    </aside>
  );
}
