import type { Database } from '@/lib/types';

export interface SearchResult {
  id: string;
  type: string;
  title: string;
  subtitle: string;
  href: string;
}

interface RankedSearchResult extends SearchResult {
  score: number;
}

type AccessPredicate = (action: string) => boolean;

/** Ranked, organization-local search. Sensitive activation secret fields are
 * deliberately never indexed, and callers can apply the current RBAC matrix. */
export function globalSearch(
  db: Database,
  q: string,
  limit = 20,
  can: AccessPredicate = () => true,
): SearchResult[] {
  const term = q.trim().toLowerCase();
  if (!term) return [];
  const digits = term.replace(/\D/g, '');
  const out: RankedSearchResult[] = [];
  const scoreText = (value?: string | null) => {
    if (!value) return 0;
    const normalized = value.toLowerCase().trim();
    if (normalized === term) return 120;
    if (normalized.startsWith(term)) return 90;
    if (normalized.split(/\s+/).some((word) => word.startsWith(term))) return 70;
    if (normalized.includes(term)) return 50;
    return 0;
  };
  const scoreDigits = (value?: string | null) => {
    if (digits.length < 3 || !value) return 0;
    const normalized = value.replace(/\D/g, '');
    if (normalized === digits) return 115;
    if (normalized.endsWith(digits)) return 85;
    return normalized.includes(digits) ? 60 : 0;
  };
  const best = (...scores: number[]) => Math.max(0, ...scores);
  const related = (score: number) => Math.floor(score * 0.75);
  const add = (score: number, result: SearchResult) => {
    if (score > 0) out.push({ ...result, score });
  };

  if (can('customers.read')) for (const c of db.customers) {
    if (c.deleted_at) continue;
    add(best(scoreText(c.name), scoreText(c.email), scoreText(c.customer_code), scoreText(c.company), scoreDigits(c.phone), scoreDigits(c.whatsapp)), {
      id: c.id, type: 'Customer', title: c.name,
      subtitle: `${c.customer_code} · ${c.phone ?? c.email ?? ''}`, href: `/customers/${c.id}`,
    });
  }
  if (can('orders.read')) for (const o of db.orders) {
    const c = db.customers.find((x) => x.id === o.customer_id);
    add(best(scoreText(o.order_number), related(scoreText(c?.name)), related(scoreDigits(c?.phone))), {
      id: o.id, type: 'Order', title: o.order_number,
      subtitle: `${c?.name ?? ''} · ₹${o.total.toLocaleString('en-IN')}`, href: `/orders/${o.id}`,
    });
  }
  if (can('products.read')) for (const p of db.products) {
    if (p.deleted_at) continue;
    add(best(scoreText(p.name), scoreText(p.code), scoreText(p.brand)), {
      id: p.id, type: 'Product', title: p.name,
      subtitle: `${p.code} · ₹${p.selling_price.toLocaleString('en-IN')}`, href: `/products/${p.id}`,
    });
  }
  if (can('subscriptions.read')) for (const s of db.subscriptions) {
    const c = db.customers.find((x) => x.id === s.customer_id);
    add(best(scoreText(s.product_name), related(scoreText(c?.name)), related(scoreDigits(c?.phone))), {
      id: s.id, type: 'Subscription', title: s.product_name,
      subtitle: `${c?.name ?? ''} · ${s.status}`, href: `/renewals?subscription=${s.id}`,
    });
  }
  if (can('invoices.read')) for (const i of db.invoices) {
    const c = db.customers.find((x) => x.id === i.customer_id);
    add(best(scoreText(i.invoice_number), related(scoreText(c?.name))), {
      id: i.id, type: 'Invoice', title: i.invoice_number,
      subtitle: `₹${i.total.toLocaleString('en-IN')} · ${i.status}`, href: `/invoices/${i.id}`,
    });
  }
  if (can('suppliers.read')) for (const s of db.suppliers) {
    add(best(scoreText(s.name), scoreText(s.email), scoreText(s.contact_person), scoreDigits(s.phone)), {
      id: s.id, type: 'Supplier', title: s.name, subtitle: s.contact_person ?? '', href: `/suppliers/${s.id}`,
    });
  }
  if (can('support.read')) for (const t of db.support_tickets) {
    const c = db.customers.find((x) => x.id === t.customer_id);
    add(best(scoreText(t.subject), scoreText(t.ticket_number), related(scoreText(c?.name))), {
      id: t.id, type: 'Support', title: t.subject,
      subtitle: `${t.ticket_number} · ${c?.name ?? t.status}`, href: `/support/${t.id}`,
    });
  }
  if (can('leads.read')) for (const l of db.leads) {
    add(best(scoreText(l.name), scoreText(l.email), scoreText(l.company), scoreDigits(l.phone)), {
      id: l.id, type: 'Lead', title: l.name,
      subtitle: `${l.status} · ₹${l.value.toLocaleString('en-IN')}`, href: `/leads?focus=${l.id}`,
    });
  }
  if (can('tasks.read')) for (const task of db.tasks) {
    if (task.deleted_at) continue;
    add(best(scoreText(task.title), scoreText(task.description)), {
      id: task.id, type: 'Task', title: task.title,
      subtitle: `${task.priority} · ${task.status.replace('_', ' ')}`, href: `/tasks?focus=${task.id}`,
    });
  }
  if (can('activations.read')) for (const activation of db.activations) {
    const c = db.customers.find((x) => x.id === activation.customer_id);
    const order = db.orders.find((x) => x.id === activation.order_id);
    add(best(scoreText(activation.product_name), scoreText(activation.activation_email), related(scoreText(c?.name)), related(scoreText(order?.order_number))), {
      id: activation.id, type: 'Activation', title: activation.product_name,
      subtitle: `${c?.name ?? ''} · ${activation.status.replace('_', ' ')}`, href: `/activations?focus=${activation.id}`,
    });
  }
  if (can('payments.read')) for (const payment of db.payments) {
    const order = db.orders.find((x) => x.id === payment.order_id);
    const c = db.customers.find((x) => x.id === payment.customer_id);
    add(best(scoreText(payment.reference), related(scoreText(order?.order_number)), related(scoreText(c?.name))), {
      id: payment.id, type: 'Payment', title: payment.reference || order?.order_number || 'Payment',
      subtitle: `${c?.name ?? ''} · ₹${Math.abs(payment.amount).toLocaleString('en-IN')}`, href: `/payments?focus=${payment.id}`,
    });
  }

  return out
    .sort((a, b) => b.score - a.score || a.type.localeCompare(b.type) || a.title.localeCompare(b.title))
    .slice(0, Math.max(0, limit))
    .map(({ score: _score, ...result }) => result);
}
