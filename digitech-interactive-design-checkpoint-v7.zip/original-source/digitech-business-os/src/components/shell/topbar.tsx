'use client';

import React, { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useStore } from '@/lib/store';
import { useTheme } from '@/components/theme';
import { globalSearch } from './search';
import { ALL_NAV_ITEMS } from './nav-config';
import { Avatar, Button, Tooltip } from '@/components/ui/primitives';
import {
  Bell, Menu, Plus, Search, Sun, Moon, Monitor, ChevronRight, Check,
  ShoppingCart, UserPlus, Users, Package, Receipt, CheckSquare, LifeBuoy, Settings as SettingsIcon,
  CreditCard,
} from 'lucide-react';
import { cn, relativeTime } from '@/lib/utils';

const CREATE_ITEMS: [string, string, React.ComponentType<{ className?: string }>, string][] = [
  ['New Order', '/orders/new', ShoppingCart, 'orders.create'],
  ['New Customer', '/customers?new=1', Users, 'customers.create'],
  ['Add Payment', '/payments?new=1', CreditCard, 'payments.create'],
  ['New Lead', '/leads?new=1', UserPlus, 'leads.create'],
  ['New Product', '/products?new=1', Package, 'products.create'],
  ['New Expense', '/finance/expenses?new=1', Receipt, 'expenses.create'],
  ['New Task', '/tasks?new=1', CheckSquare, 'tasks.create'],
  ['New Ticket', '/support?new=1', LifeBuoy, 'support.create'],
];

export function Topbar({
  onMenu,
  onOpenPalette,
}: {
  onMenu: () => void;
  onOpenPalette: () => void;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const { db, currentUser, setCurrentUserId, markAllNotificationsRead, can } = useStore();
  const { theme, setTheme } = useTheme();

  const [q, setQ] = useState('');
  const [openMenu, setOpenMenu] = useState<null | 'notif' | 'user' | 'create'>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpenMenu(null);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpenMenu(null);
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKey);
    };
  }, []);

  const results = q.trim() ? globalSearch(db, q, 8, can) : [];
  const createItems = CREATE_ITEMS.filter(([, , , permission]) => can(permission));
  const unread = db.notifications.filter((n) => !n.read_at);

  const crumbs = (() => {
    const parts = pathname.split('/').filter(Boolean);
    const acc: { label: string; href: string }[] = [{ label: 'DigiTech', href: '/' }];
    let path = '';
    for (const p of parts) {
      path += `/${p}`;
      const nav = ALL_NAV_ITEMS.find((n) => n.href === path);
      acc.push({
        label: nav?.label ?? decodeURIComponent(p).replace(/-/g, ' ').slice(0, 24),
        href: path,
      });
    }
    return acc;
  })();

  const panel =
    'animate-scale-in absolute right-0 top-[42px] z-50 origin-top-right overflow-hidden rounded-[11px] border border-[var(--border)] bg-[var(--surface)] shadow-[var(--shadow-lg)]';

  return (
    <header
      className="sticky top-0 z-40 flex h-[52px] shrink-0 items-center gap-2 border-b border-[var(--border)] bg-[var(--surface)]/80 px-3 backdrop-blur-xl"
      ref={ref}
    >
      <button
        onClick={onMenu}
        aria-label="Open menu"
        className="press rounded-[7px] p-2 text-[var(--muted)] hover:bg-[var(--surface-2)] lg:hidden"
      >
        <Menu className="h-4 w-4" />
      </button>

      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="hidden min-w-0 items-center gap-1 text-[12.5px] md:flex">
        {crumbs.map((c, i) => {
          const last = i === crumbs.length - 1;
          return (
            <React.Fragment key={c.href + i}>
              {i > 0 && <ChevronRight className="h-3 w-3 shrink-0 text-[var(--muted-2)] opacity-60" />}
              <Link
                href={c.href}
                className={cn(
                  'truncate rounded px-1 py-0.5 capitalize transition-colors',
                  last
                    ? 'font-semibold text-[var(--fg)]'
                    : 'text-[var(--muted)] hover:text-[var(--fg)]',
                )}
              >
                {c.label}
              </Link>
            </React.Fragment>
          );
        })}
      </nav>

      {/* Global search */}
      <div className="relative ml-auto w-full max-w-[340px]">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-[var(--muted-2)]" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && results[0]) {
              router.push(results[0].href);
              setQ('');
            }
            if (e.key === 'Escape') setQ('');
          }}
          placeholder="Search customers, orders, products…"
          className="h-[34px] w-full rounded-[8px] border border-[var(--border)] bg-[var(--surface-2)] pl-[30px] pr-[46px] text-[12.5px] outline-none transition-all duration-150 placeholder:text-[var(--muted-2)] focus:border-[var(--accent)] focus:bg-[var(--surface)] focus:shadow-[var(--ring)]"
        />
        <kbd className="pointer-events-none absolute right-2 top-1/2 hidden -translate-y-1/2 items-center rounded-[5px] border border-[var(--border)] bg-[var(--surface)] px-1.5 py-[2px] font-sans text-[10.5px] font-medium text-[var(--muted-2)] sm:flex">
          ⌘K
        </kbd>
        {results.length > 0 && (
          <div className="animate-scale-in absolute left-0 right-0 top-[40px] z-50 origin-top overflow-hidden rounded-[11px] border border-[var(--border)] bg-[var(--surface)] p-1 shadow-[var(--shadow-lg)]">
            {results.map((r) => (
              <button
                key={r.type + r.id}
                onMouseDown={() => {
                  router.push(r.href);
                  setQ('');
                }}
                className="flex w-full items-center gap-2.5 rounded-[7px] px-2.5 py-2 text-left transition-colors hover:bg-[var(--surface-2)]"
              >
                <span className="w-[68px] shrink-0 text-[10px] font-semibold uppercase tracking-[0.04em] text-[var(--muted-2)]">
                  {r.type}
                </span>
                <span className="flex-1 truncate text-[13px] font-medium">{r.title}</span>
                <span className="max-w-[120px] truncate text-[11.5px] text-[var(--muted-2)]">{r.subtitle}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      <Tooltip label="Search  ⌘K">
        <button
          onClick={onOpenPalette}
          aria-label="Open command palette"
          className="press rounded-[7px] p-2 text-[var(--muted)] hover:bg-[var(--surface-2)] sm:hidden"
        >
          <Search className="h-4 w-4" />
        </button>
      </Tooltip>

      {/* Quick create */}
      {createItems.length > 0 && <div className="relative">
        <Button
          variant="primary"
          size="sm"
          onClick={() => setOpenMenu(openMenu === 'create' ? null : 'create')}
        >
          <Plus className="h-3.5 w-3.5" strokeWidth={2.4} />
          <span className="hidden sm:inline">Create</span>
        </Button>
        {openMenu === 'create' && (
          <div className={cn(panel, 'w-[196px] p-1')}>
            {createItems.map(([label, href, Icon]) => (
              <button
                key={href}
                onClick={() => {
                  setOpenMenu(null);
                  router.push(href);
                }}
                className="flex w-full items-center gap-2.5 rounded-[7px] px-2.5 py-[7px] text-left text-[12.5px] font-medium text-[var(--fg-soft)] transition-colors hover:bg-[var(--surface-2)] hover:text-[var(--fg)]"
              >
                <Icon className="h-3.5 w-3.5 opacity-65" />
                {label}
              </button>
            ))}
          </div>
        )}
      </div>}

      {/* Notifications */}
      <div className="relative">
        <button
          onClick={() => setOpenMenu(openMenu === 'notif' ? null : 'notif')}
          aria-label="Notifications"
          className="press relative rounded-[7px] p-2 text-[var(--muted)] transition-colors hover:bg-[var(--surface-2)] hover:text-[var(--fg)]"
        >
          <Bell className="h-4 w-4" />
          {unread.length > 0 && (
            <span className="absolute right-[5px] top-[5px] flex h-[15px] min-w-[15px] items-center justify-center rounded-full bg-[var(--danger)] px-[3px] text-[9px] font-bold leading-none text-white ring-2 ring-[var(--surface)]">
              {unread.length > 99 ? '99' : unread.length}
            </span>
          )}
        </button>
        {openMenu === 'notif' && (
          <div className={cn(panel, 'w-[min(370px,calc(100vw-1.5rem))]')}>
            <div className="flex items-center justify-between border-b border-[var(--border)] px-3.5 py-2.5">
              <p className="text-[13px] font-semibold">Notifications</p>
              {unread.length > 0 && (
                <button
                  onClick={() => markAllNotificationsRead()}
                  className="text-[11.5px] font-medium text-[var(--accent)] hover:underline"
                >
                  Mark all read
                </button>
              )}
            </div>
            <div className="max-h-[340px] overflow-y-auto">
              {db.notifications.slice(0, 20).map((n) => (
                <div
                  key={n.id}
                  className={cn(
                    'relative border-b border-[var(--border-subtle)] px-3.5 py-2.5 last:border-0',
                    !n.read_at && 'bg-[var(--accent-soft)]/45',
                  )}
                >
                  {!n.read_at && (
                    <span className="absolute left-1.5 top-[15px] h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
                  )}
                  <p className="text-[12.5px] font-medium leading-snug">{n.title}</p>
                  <p className="mt-0.5 text-[11.5px] leading-snug text-[var(--muted)]">{n.body}</p>
                  <p className="mt-1 text-[10.5px] text-[var(--muted-2)]">{relativeTime(n.created_at)}</p>
                </div>
              ))}
              {db.notifications.length === 0 && (
                <p className="px-3 py-10 text-center text-[12.5px] text-[var(--muted)]">
                  You&rsquo;re all caught up.
                </p>
              )}
            </div>
            <Link
              href="/notifications"
              onClick={() => setOpenMenu(null)}
              className="block border-t border-[var(--border)] px-3 py-2.5 text-center text-[12px] font-medium text-[var(--accent)] transition-colors hover:bg-[var(--surface-2)]"
            >
              View all notifications
            </Link>
          </div>
        )}
      </div>

      {/* User */}
      <div className="relative">
        <button
          onClick={() => setOpenMenu(openMenu === 'user' ? null : 'user')}
          aria-label="Account menu"
          className="press flex rounded-full transition-opacity hover:opacity-85"
        >
          <Avatar name={currentUser?.full_name ?? 'User'} size={27} />
        </button>
        {openMenu === 'user' && (
          <div className={cn(panel, 'w-[236px] p-1')}>
            <div className="flex items-center gap-2.5 border-b border-[var(--border)] px-2.5 py-2.5">
              <Avatar name={currentUser?.full_name ?? 'User'} size={32} />
              <div className="min-w-0">
                <p className="truncate text-[13px] font-semibold leading-tight">{currentUser?.full_name}</p>
                <p className="truncate text-[11px] capitalize leading-tight text-[var(--muted)]">
                  {currentUser?.role} · {currentUser?.email}
                </p>
              </div>
            </div>

            <p className="px-2.5 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-[0.06em] text-[var(--muted-2)]">
              Switch user · demo RBAC
            </p>
            <div className="max-h-[176px] overflow-y-auto">
              {db.profiles.map((p) => {
                // A disabled or removed profile can never act (enforced in the
                // store, in the service layer and by RLS). Show it, but do not
                // offer it as a selectable identity.
                const inert = !p.is_active || Boolean(p.deleted_at);
                return (
                  <button
                    key={p.id}
                    disabled={inert}
                    title={inert ? (p.deleted_at ? 'Removed account' : 'Disabled account') : undefined}
                    onClick={() => {
                      if (inert) return;
                      setCurrentUserId(p.id);
                      setOpenMenu(null);
                    }}
                    className={cn(
                      'flex w-full items-center gap-2 rounded-[7px] px-2.5 py-[6px] text-left transition-colors',
                      inert ? 'cursor-not-allowed opacity-45' : 'hover:bg-[var(--surface-2)]',
                    )}
                  >
                    <Avatar name={p.full_name} size={20} />
                    <span className="flex-1 truncate text-[12.5px] font-medium">{p.full_name}</span>
                    {inert && (
                      <span className="text-[10px] text-[var(--muted-2)]">
                        {p.deleted_at ? 'removed' : 'disabled'}
                      </span>
                    )}
                    <span className="text-[10px] capitalize text-[var(--muted-2)]">{p.role}</span>
                    {p.id === currentUser?.id && <Check className="h-3 w-3 shrink-0 text-[var(--accent)]" />}
                  </button>
                );
              })}
            </div>

            <div className="mt-1 border-t border-[var(--border)] pt-1.5">
              <p className="px-2.5 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.06em] text-[var(--muted-2)]">
                Theme
              </p>
              <div className="flex gap-1 px-1.5 pb-1.5">
                {([['light', Sun], ['dark', Moon], ['system', Monitor]] as const).map(([t, Icon]) => (
                  <button
                    key={t}
                    onClick={() => setTheme(t)}
                    className={cn(
                      'press flex flex-1 items-center justify-center gap-1 rounded-[6px] border py-[6px] text-[11px] font-medium capitalize transition-colors',
                      theme === t
                        ? 'border-[var(--accent-border)] bg-[var(--accent-soft)] text-[var(--accent)]'
                        : 'border-[var(--border)] text-[var(--muted)] hover:bg-[var(--surface-2)]',
                    )}
                  >
                    <Icon className="h-3 w-3" />
                    {t}
                  </button>
                ))}
              </div>
              <Link
                href="/settings"
                onClick={() => setOpenMenu(null)}
                className="flex items-center gap-2.5 rounded-[7px] px-2.5 py-[7px] text-[12.5px] font-medium text-[var(--fg-soft)] transition-colors hover:bg-[var(--surface-2)]"
              >
                <SettingsIcon className="h-3.5 w-3.5 opacity-65" />
                Settings
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
