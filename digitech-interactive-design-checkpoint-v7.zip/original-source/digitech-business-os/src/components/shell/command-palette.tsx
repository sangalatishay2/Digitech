'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useStore } from '@/lib/store';
import { globalSearch } from './search';
import { ALL_NAV_ITEMS } from './nav-config';
import { Search, CornerDownLeft } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Cmd {
  id: string;
  label: string;
  group: string;
  hint?: string;
  run: () => void;
}

export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  // Remount on open so query/selection reset without an effect.
  return open ? <PaletteBody key={String(open)} onClose={onClose} /> : null;
}

function PaletteBody({ onClose }: { onClose: () => void }) {
  const open = true;
  const router = useRouter();
  const { db, can } = useStore();
  const [q, setQ] = useState('');
  const [idx, setIdx] = useState(0);

  const go = (href: string) => {
    router.push(href);
    onClose();
  };

  const commands = useMemo<Cmd[]>(() => {
    const actions: (Cmd & { permission: string })[] = [
      { id: 'a1', label: 'Create Customer', group: 'Actions', permission: 'customers.create', run: () => go('/customers?new=1') },
      { id: 'a2', label: 'Create Order', group: 'Actions', permission: 'orders.create', run: () => go('/orders/new') },
      { id: 'a3', label: 'Add Payment', group: 'Actions', permission: 'payments.create', run: () => go('/payments?new=1') },
      { id: 'a4', label: 'Create Lead', group: 'Actions', permission: 'leads.create', run: () => go('/leads?new=1') },
      { id: 'a5', label: 'New Expense', group: 'Actions', permission: 'expenses.create', run: () => go('/finance/expenses?new=1') },
      { id: 'a6', label: 'Create Task', group: 'Actions', permission: 'tasks.create', run: () => go('/tasks?new=1') },
      { id: 'a7', label: 'Open Renewal Center', group: 'Actions', permission: 'subscriptions.read', run: () => go('/renewals') },
      { id: 'a8', label: 'New Support Ticket', group: 'Actions', permission: 'support.create', run: () => go('/support?new=1') },
    ];
    const nav: Cmd[] = ALL_NAV_ITEMS.filter((n) => {
      const section = n.href.split('/').filter(Boolean)[0] ?? 'analytics';
      const permission = section === 'finance' ? 'finance.read' : `${section}.read`;
      return n.href === '/' || n.href === '/copilot' || can(permission);
    }).map((n) => ({
      id: `n-${n.href}`,
      label: n.label,
      group: 'Navigate',
      hint: n.href,
      run: () => go(n.href),
    }));
    const results: Cmd[] = q.trim()
      ? globalSearch(db, q, 12, can).map((r) => ({
          id: `s-${r.type}-${r.id}`,
          label: r.title,
          group: r.type,
          hint: r.subtitle,
          run: () => go(r.href),
        }))
      : [];

    const term = q.trim().toLowerCase();
    const filt = (c: Cmd) => !term || c.label.toLowerCase().includes(term);
    return [...results, ...actions.filter((action) => can(action.permission)).filter(filt), ...nav.filter(filt)].slice(0, 30);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, db]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setIdx((i) => Math.min(i + 1, commands.length - 1));
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setIdx((i) => Math.max(i - 1, 0));
      }
      if (e.key === 'Enter') {
        e.preventDefault();
        commands[idx]?.run();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, commands, idx, onClose]);

  if (!open) return null;

  let lastGroup = '';
  return (
    <div className="fixed inset-0 z-[90] flex items-start justify-center p-4 pt-[11vh]">
      <div className="animate-overlay absolute inset-0 bg-[#0a0b0d]/55 backdrop-blur-[3px]" onClick={onClose} />
      <div className="animate-scale-in relative z-10 w-full max-w-[560px] overflow-hidden rounded-[14px] border border-[var(--border)] bg-[var(--surface)] shadow-[var(--shadow-xl)]">
        <div className="flex items-center gap-2.5 border-b border-[var(--border)] px-4">
          <Search className="h-[15px] w-[15px] shrink-0 text-[var(--muted-2)]" />
          <input
            autoFocus
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setIdx(0);
            }}
            placeholder="Search customers, orders, products… or run a command"
            className="h-[50px] flex-1 bg-transparent text-[13.5px] outline-none placeholder:text-[var(--muted-2)]"
          />
          <kbd className="shrink-0 rounded-[5px] border border-[var(--border)] bg-[var(--surface-2)] px-1.5 py-[2px] font-sans text-[10.5px] font-medium text-[var(--muted-2)]">
            ESC
          </kbd>
        </div>
        <div className="max-h-[54vh] overflow-y-auto p-1.5">
          {commands.length === 0 && (
            <p className="px-3 py-10 text-center text-[13px] text-[var(--muted)]">
              No results for &ldquo;{q}&rdquo;
            </p>
          )}
          {commands.map((c, i) => {
            const showGroup = c.group !== lastGroup;
            lastGroup = c.group;
            return (
              <React.Fragment key={c.id}>
                {showGroup && (
                  <p className="px-2.5 pb-1 pt-2.5 text-[10px] font-semibold uppercase tracking-[0.07em] text-[var(--muted-2)]">
                    {c.group}
                  </p>
                )}
                <button
                  onMouseEnter={() => setIdx(i)}
                  onClick={c.run}
                  className={cn(
                    'flex w-full items-center gap-2.5 rounded-[8px] px-2.5 py-[9px] text-left text-[13px] transition-colors',
                    i === idx
                      ? 'bg-[var(--accent-soft)] font-medium text-[var(--accent)]'
                      : 'text-[var(--fg-soft)] hover:bg-[var(--surface-2)]',
                  )}
                >
                  <span className="flex-1 truncate">{c.label}</span>
                  {c.hint && (
                    <span className="max-w-[160px] truncate text-[11.5px] text-[var(--muted-2)]">{c.hint}</span>
                  )}
                  {i === idx && <CornerDownLeft className="h-3.5 w-3.5 shrink-0 opacity-70" />}
                </button>
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </div>
  );
}
