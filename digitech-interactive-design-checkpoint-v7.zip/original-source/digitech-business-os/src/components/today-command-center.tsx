'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { buildProductivityQueue, productivitySummary, type ProductivityItemKind } from '@/lib/services/productivity';
import { Badge, Button, Card, CardHeader, EmptyState } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { cn, relativeTime } from '@/lib/utils';
import {
  ArrowRight,
  CalendarClock,
  Check,
  CheckSquare,
  CircleDollarSign,
  Headphones,
  Sparkles,
  UserRoundSearch,
  Zap,
} from 'lucide-react';

type Filter = 'all' | 'mine' | 'critical';

const ICONS: Record<ProductivityItemKind, typeof CheckSquare> = {
  task: CheckSquare,
  renewal: CalendarClock,
  payment: CircleDollarSign,
  lead: UserRoundSearch,
  activation: Zap,
  support: Headphones,
};

const LABELS: Record<ProductivityItemKind, string> = {
  task: 'Task',
  renewal: 'Renewal',
  payment: 'Payment',
  lead: 'Lead',
  activation: 'Activation',
  support: 'Support',
};

const TONES = {
  critical: { color: 'var(--danger)', surface: 'var(--danger-soft)', badge: 'danger' as const },
  high: { color: 'var(--warning)', surface: 'var(--warning-soft)', badge: 'warning' as const },
  medium: { color: 'var(--accent)', surface: 'var(--accent-soft)', badge: 'accent' as const },
  low: { color: 'var(--muted)', surface: 'var(--surface-2)', badge: 'neutral' as const },
};

export function TodayCommandCenter() {
  const { db, currentUser, can, updateTask } = useStore();
  const toast = useToast();
  const [filter, setFilter] = useState<Filter>('all');
  const now = useMemo(() => new Date(), []);

  const items = useMemo(
    () => buildProductivityQueue(db, { now, userId: currentUser?.id, can, limit: 80 }),
    [db, now, currentUser?.id, can],
  );
  const summary = useMemo(() => productivitySummary(items, currentUser?.id), [items, currentUser?.id]);
  const visible = useMemo(() => {
    if (filter === 'mine') return items.filter((item) => item.assignedTo === currentUser?.id).slice(0, 8);
    if (filter === 'critical') return items.filter((item) => item.severity === 'critical').slice(0, 8);
    return items.slice(0, 8);
  }, [filter, items, currentUser?.id]);

  const filters: { id: Filter; label: string; count: number }[] = [
    { id: 'all', label: 'Priority queue', count: summary.total },
    { id: 'mine', label: 'Assigned to me', count: summary.mine },
    { id: 'critical', label: 'Critical', count: summary.critical },
  ];

  return (
    <Card className="overflow-hidden">
      <div className="relative overflow-hidden border-b border-[var(--border)] bg-[linear-gradient(115deg,var(--surface),var(--accent-soft))]">
        <div className="pointer-events-none absolute -right-16 -top-20 h-52 w-52 rounded-full border-[28px] border-[var(--accent)]/[0.035]" />
        <CardHeader
          title="Today Command Center"
          subtitle={`${summary.total} actionable item${summary.total === 1 ? '' : 's'} across sales, renewals and operations`}
          action={
            <Link href="/tasks" className="inline-flex items-center gap-1 text-[12px] font-semibold text-[var(--accent)] hover:underline">
              Open work queue <ArrowRight className="h-3 w-3" />
            </Link>
          }
        />
        <div className="flex gap-1.5 overflow-x-auto px-4 pb-3" role="tablist" aria-label="Today queue filters">
          {filters.map((item) => (
            <button
              key={item.id}
              type="button"
              role="tab"
              aria-selected={filter === item.id}
              onClick={() => setFilter(item.id)}
              className={cn(
                'press inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11.5px] font-semibold transition-colors',
                filter === item.id
                  ? 'border-[var(--accent-border)] bg-[var(--surface)] text-[var(--accent)] shadow-[var(--shadow-xs)]'
                  : 'border-transparent text-[var(--muted)] hover:bg-[var(--surface)]/70 hover:text-[var(--fg)]',
              )}
            >
              {item.label}
              <span className="tabular-nums opacity-70">{item.count}</span>
            </button>
          ))}
        </div>
      </div>

      {visible.length === 0 ? (
        <EmptyState
          icon={Sparkles}
          title={filter === 'mine' ? 'Nothing assigned to you right now.' : 'You are all caught up.'}
          message="New work will appear here automatically when it needs attention."
          compact
        />
      ) : (
        <div className="grid divide-y divide-[var(--border-subtle)] lg:grid-cols-2 lg:divide-x lg:divide-y-0">
          {visible.map((item, index) => {
            const Icon = ICONS[item.kind];
            const tone = TONES[item.severity];
            return (
              <div
                key={`${item.kind}-${item.id}`}
                className={cn(
                  'group flex min-w-0 items-center gap-3 border-b border-[var(--border-subtle)] px-4 py-3 transition-colors last:border-b-0 hover:bg-[var(--surface-2)]',
                  index % 2 === 1 && 'lg:border-l',
                )}
              >
                <span
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px]"
                  style={{ color: tone.color, background: tone.surface }}
                >
                  <Icon className="h-4 w-4" strokeWidth={2} />
                </span>
                <Link href={item.href} className="min-w-0 flex-1 rounded focus-visible:outline-none focus-visible:shadow-[var(--ring)]">
                  <div className="flex min-w-0 items-center gap-2">
                    <p className="truncate text-[12.5px] font-semibold text-[var(--fg)]">{item.title}</p>
                    <Badge tone={tone.badge}>{LABELS[item.kind]}</Badge>
                  </div>
                  <p className="mt-0.5 truncate text-[11.5px] text-[var(--muted)]">{item.subtitle}</p>
                  {item.dueAt && (
                    <p className="mt-1 text-[10.5px] font-medium" style={{ color: tone.color }}>
                      {relativeTime(item.dueAt)}
                    </p>
                  )}
                </Link>
                {item.kind === 'task' && can('tasks.update') ? (
                  <Button
                    size="icon-sm"
                    variant="ghost"
                    aria-label={`Complete ${item.title}`}
                    onClick={() => {
                      updateTask(item.id, { status: 'done', completed_at: new Date().toISOString() });
                      toast({ title: 'Task completed', description: item.title });
                    }}
                  >
                    <Check className="h-3.5 w-3.5" />
                  </Button>
                ) : (
                  <ArrowRight className="h-3.5 w-3.5 shrink-0 text-[var(--muted-2)] transition-transform group-hover:translate-x-0.5" />
                )}
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}
