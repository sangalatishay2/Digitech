'use client';

import { useState } from 'react';
import { RANGE_OPTIONS, resolveRange, type RangeKey, type DateRange } from '@/lib/services/analytics';
import { cn } from '@/lib/utils';

export function useDateRange(initial: RangeKey = '30d') {
  const [key, setKey] = useState<RangeKey>(initial);
  const [custom, setCustom] = useState({ from: '', to: '' });
  const range: DateRange = resolveRange(key, custom);
  return { key, setKey, custom, setCustom, range };
}

export function RangePicker({
  value,
  onChange,
  custom,
  onCustomChange,
}: {
  value: RangeKey;
  onChange: (k: RangeKey) => void;
  custom: { from: string; to: string };
  onCustomChange: (c: { from: string; to: string }) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {RANGE_OPTIONS.map((r) => (
        <button
          key={r.key}
          onClick={() => onChange(r.key)}
          className={cn(
            'rounded-md border px-2.5 py-1.5 text-[12.5px] font-medium transition-colors',
            value === r.key
              ? 'border-[var(--accent)] bg-[var(--accent-soft)] text-[var(--accent)]'
              : 'border-[var(--border-strong)] hover:bg-[var(--surface-2)]',
          )}
        >
          {r.label}
        </button>
      ))}
      {value === 'custom' && (
        <>
          <input type="date" className="field h-8 w-auto py-0 text-[12.5px]" value={custom.from} onChange={(e) => onCustomChange({ ...custom, from: e.target.value })} />
          <input type="date" className="field h-8 w-auto py-0 text-[12.5px]" value={custom.to} onChange={(e) => onCustomChange({ ...custom, to: e.target.value })} />
        </>
      )}
    </div>
  );
}
