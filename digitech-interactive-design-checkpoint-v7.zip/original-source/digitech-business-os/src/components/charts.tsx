'use client';

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { formatINR } from '@/lib/utils';

/** Canonical DigiTech chart palette — used everywhere for consistency. */
export const CHART_COLORS = {
  primary: 'var(--chart-1)',
  success: 'var(--chart-2)',
  info: 'var(--chart-3)',
  warning: 'var(--chart-4)',
  pink: 'var(--chart-5)',
} as const;

export const CHART_SERIES = [
  'var(--chart-1)',
  'var(--chart-2)',
  'var(--chart-3)',
  'var(--chart-4)',
  'var(--chart-5)',
  '#8b5cf6',
  '#0891b2',
  '#db2777',
];

const axis = {
  stroke: 'var(--muted-2)',
  fontSize: 11,
  tickLine: false,
  axisLine: false,
  tick: { fill: 'var(--muted-2)', fontSize: 11 },
};

const grid = {
  strokeDasharray: '2 4',
  stroke: 'var(--chart-grid)',
  vertical: false,
} as const;

const tooltipStyle = {
  cursor: { fill: 'var(--surface-2)', opacity: 0.55 },
  contentStyle: {
    background: 'var(--surface)',
    border: '1px solid var(--border-strong)',
    borderRadius: 10,
    fontSize: 12,
    padding: '8px 10px',
    boxShadow: 'var(--shadow-lg)',
    color: 'var(--fg)',
  },
  labelStyle: {
    color: 'var(--muted)',
    fontSize: 11,
    fontWeight: 600,
    marginBottom: 4,
  },
  itemStyle: { padding: '1px 0', fontSize: 12 },
};

const legendStyle = { fontSize: 11.5, paddingTop: 8, color: 'var(--muted)' };

export function RevenueAreaChart({
  data,
  keys,
  height = 260,
  showLegend = true,
}: {
  data: Record<string, string | number>[];
  keys: { key: string; label: string; color: string }[];
  height?: number;
  showLegend?: boolean;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 10, right: 10, left: -14, bottom: 0 }}>
        <defs>
          {keys.map((k) => (
            <linearGradient key={k.key} id={`grad-${k.key}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={k.color} stopOpacity={0.24} />
              <stop offset="100%" stopColor={k.color} stopOpacity={0.01} />
            </linearGradient>
          ))}
        </defs>
        <CartesianGrid {...grid} />
        <XAxis dataKey="label" {...axis} dy={4} />
        <YAxis {...axis} tickFormatter={(v) => formatINR(Number(v), { compact: true })} width={58} />
        <Tooltip
          {...tooltipStyle}
          formatter={((v: unknown, n: unknown) => [formatINR(Number(v)), String(n)]) as never}
        />
        {showLegend && <Legend wrapperStyle={legendStyle} iconType="circle" iconSize={7} />}
        {keys.map((k) => (
          <Area
            key={k.key}
            type="monotone"
            dataKey={k.key}
            name={k.label}
            stroke={k.color}
            fill={`url(#grad-${k.key})`}
            strokeWidth={2}
            activeDot={{ r: 3.5, strokeWidth: 2, stroke: 'var(--surface)' }}
          />
        ))}
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function SimpleBarChart({
  data,
  dataKey,
  label,
  color = 'var(--chart-1)',
  height = 240,
  currency = true,
}: {
  data: Record<string, string | number>[];
  dataKey: string;
  label: string;
  color?: string;
  height?: number;
  currency?: boolean;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 10, right: 10, left: -14, bottom: 0 }}>
        <CartesianGrid {...grid} />
        <XAxis dataKey="label" {...axis} dy={4} />
        <YAxis
          {...axis}
          width={currency ? 58 : 34}
          tickFormatter={(v) => (currency ? formatINR(Number(v), { compact: true }) : String(v))}
        />
        <Tooltip
          {...tooltipStyle}
          formatter={((v: unknown) => [currency ? formatINR(Number(v)) : Number(v), label]) as never}
        />
        <Bar dataKey={dataKey} name={label} fill={color} radius={[5, 5, 0, 0]} maxBarSize={34} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function SimpleLineChart({
  data,
  dataKey,
  label,
  color = 'var(--chart-3)',
  height = 240,
}: {
  data: Record<string, string | number>[];
  dataKey: string;
  label: string;
  color?: string;
  height?: number;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
        <CartesianGrid {...grid} />
        <XAxis dataKey="label" {...axis} dy={4} />
        <YAxis {...axis} width={42} />
        <Tooltip {...tooltipStyle} />
        <Line
          type="monotone"
          dataKey={dataKey}
          name={label}
          stroke={color}
          strokeWidth={2}
          dot={false}
          activeDot={{ r: 3.5, strokeWidth: 2, stroke: 'var(--surface)' }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function SimplePieChart({
  data,
  height = 240,
  showLegend = true,
}: {
  data: { name: string; value: number }[];
  height?: number;
  showLegend?: boolean;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          nameKey="name"
          innerRadius="58%"
          outerRadius="82%"
          paddingAngle={2}
          strokeWidth={2}
        >
          {data.map((_, i) => (
            <Cell key={i} fill={CHART_SERIES[i % CHART_SERIES.length]} stroke="var(--surface)" strokeWidth={2} />
          ))}
        </Pie>
        <Tooltip {...tooltipStyle} formatter={((v: unknown) => formatINR(Number(v))) as never} />
        {showLegend && <Legend wrapperStyle={legendStyle} iconType="circle" iconSize={7} />}
      </PieChart>
    </ResponsiveContainer>
  );
}

/** Horizontal ranked bar list — better than a pie for "top N" data. */
export function RankedBars({
  items,
  formatValue = (v: number) => formatINR(v),
  color = 'var(--chart-1)',
  emptyLabel = 'No data',
}: {
  items: { label: string; value: number; secondary?: string }[];
  formatValue?: (v: number) => string;
  color?: string;
  emptyLabel?: string;
}) {
  if (!items.length) {
    return <p className="py-8 text-center text-[12.5px] text-[var(--muted)]">{emptyLabel}</p>;
  }
  const max = Math.max(...items.map((i) => i.value)) || 1;
  return (
    <div className="space-y-[11px]">
      {items.map((it, i) => (
        <div key={i}>
          <div className="mb-[5px] flex items-baseline justify-between gap-3">
            <span className="truncate text-[12.5px] font-medium text-[var(--fg-soft)]">{it.label}</span>
            <span className="shrink-0 text-[12.5px] font-semibold tabular-nums">{formatValue(it.value)}</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-[5px] flex-1 overflow-hidden rounded-full bg-[var(--surface-3)]">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{ width: `${(it.value / max) * 100}%`, background: color, opacity: 1 - i * 0.09 }}
              />
            </div>
            {it.secondary && (
              <span className="w-14 shrink-0 text-right text-[11px] tabular-nums text-[var(--muted-2)]">
                {it.secondary}
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
