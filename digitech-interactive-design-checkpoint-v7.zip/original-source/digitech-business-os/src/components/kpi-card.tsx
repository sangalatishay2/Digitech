'use client';

import Link from 'next/link';
import { cn } from '@/lib/utils';
import type { LucideIcon } from 'lucide-react';
import { ArrowUpRight } from 'lucide-react';

export type KpiTone = 'neutral' | 'success' | 'warning' | 'danger' | 'accent' | 'info';

const TONE: Record<KpiTone, string> = {
  neutral: 'var(--muted)',
  success: 'var(--success)',
  warning: 'var(--warning)',
  danger: 'var(--danger)',
  accent: 'var(--accent)',
  info: 'var(--info)',
};

/** Minimal inline sparkline — no chart library, no layout cost. */
export function Sparkline({
  data,
  color = 'var(--accent)',
  width = 68,
  height = 22,
  fill = true,
}: {
  data: number[];
  color?: string;
  width?: number;
  height?: number;
  fill?: boolean;
}) {
  if (!data || data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = max - min || 1;
  const step = width / (data.length - 1);
  const pts = data.map((v, i) => [i * step, height - ((v - min) / span) * (height - 3) - 1.5]);
  const line = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const area = `${line} L${width},${height} L0,${height} Z`;
  const id = `spk-${Math.abs(data.reduce((a, b) => a + b, 0) | 0)}-${data.length}`;
  return (
    <svg width={width} height={height} className="overflow-visible" aria-hidden>
      {fill && (
        <>
          <defs>
            <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.22} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <path d={area} fill={`url(#${id})`} />
        </>
      )}
      <path d={line} fill="none" stroke={color} strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function KpiCard({
  label,
  value,
  sub,
  icon: Icon,
  tone = 'neutral',
  href,
  delta,
  deltaLabel,
  trend,
  invertDelta,
  className,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon?: LucideIcon;
  tone?: KpiTone;
  href?: string;
  /** Percentage change vs previous period. */
  delta?: number;
  deltaLabel?: string;
  /** Series for the sparkline. */
  trend?: number[];
  /** For metrics where a decrease is good (e.g. outstanding). */
  invertDelta?: boolean;
  className?: string;
}) {
  const toneColor = TONE[tone];
  const hasDelta = typeof delta === 'number' && isFinite(delta);
  const flat = hasDelta && Math.abs(delta) < 0.05;
  const good = invertDelta ? (delta ?? 0) < 0 : (delta ?? 0) > 0;
  const deltaColor = flat ? 'var(--muted-2)' : good ? 'var(--success)' : 'var(--danger)';

  const body = (
    <div
      className={cn(
        'card relative p-[15px]',
        href && 'card-hover cursor-pointer',
        className,
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <p className="truncate text-[12px] font-medium text-[var(--muted)]">{label}</p>
        {Icon ? (
          <Icon className="h-[15px] w-[15px] shrink-0 opacity-55" style={{ color: toneColor }} strokeWidth={1.9} />
        ) : href ? (
          <ArrowUpRight className="h-[14px] w-[14px] shrink-0 text-[var(--muted-2)] opacity-0 transition-opacity group-hover:opacity-100" />
        ) : null}
      </div>

      <p className="kpi-value mt-2 text-[24px] font-semibold leading-[1.15] tracking-[-0.025em] md:text-[26px]">
        {value}
      </p>

      <div className="mt-2 flex items-end justify-between gap-2">
        <div className="min-w-0">
          {hasDelta && (
            <span className="inline-flex items-center gap-1 text-[11.5px] font-semibold tabular-nums" style={{ color: deltaColor }}>
              {!flat && (delta! > 0 ? '↑' : '↓')}
              {Math.abs(delta!).toFixed(1)}%
              {deltaLabel && (
                <span className="font-normal text-[var(--muted-2)]">{deltaLabel}</span>
              )}
            </span>
          )}
          {!hasDelta && sub && <p className="truncate text-[11.5px] text-[var(--muted-2)]">{sub}</p>}
          {hasDelta && sub && <p className="mt-0.5 truncate text-[11px] text-[var(--muted-2)]">{sub}</p>}
        </div>
        {trend && trend.length > 1 && (
          <Sparkline data={trend} color={toneColor === 'var(--muted)' ? 'var(--accent)' : toneColor} />
        )}
      </div>
    </div>
  );

  return href ? (
    <Link href={href} className="group block">
      {body}
    </Link>
  ) : (
    body
  );
}

/** Dense KPI used in tight rows (page sub-headers). */
export function MiniStat({
  label,
  value,
  tone = 'neutral',
  className,
}: {
  label: string;
  value: React.ReactNode;
  tone?: KpiTone;
  className?: string;
}) {
  return (
    <div className={cn('min-w-0', className)}>
      <p className="truncate text-[11px] font-medium uppercase tracking-[0.04em] text-[var(--muted-2)]">
        {label}
      </p>
      <p
        className="mt-1 truncate text-[17px] font-semibold tabular-nums tracking-[-0.02em]"
        style={{ color: tone === 'neutral' ? undefined : TONE[tone] }}
      >
        {value}
      </p>
    </div>
  );
}
