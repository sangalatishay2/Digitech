'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/lib/store';
import { DataTable, type Column } from '@/components/ui/data-table';
import { Badge, Button, StatusBadge } from '@/components/ui/primitives';
import { daysUntil, formatDate, formatINR } from '@/lib/utils';
import type { Subscription } from '@/lib/types';

export function SubscriptionsTable({ rows }: { rows: Subscription[] }) {
  const { db } = useStore();
  const router = useRouter();

  const cname = (s: Subscription) => db.customers.find((c) => c.id === s.customer_id)?.name ?? '—';

  const columns: Column<Subscription>[] = [
    {
      key: 'customer', header: 'Customer', sortValue: cname, exportValue: cname,
      render: (s) => <Link href={`/customers/${s.customer_id}`} className="font-medium text-[var(--accent)] hover:underline">{cname(s)}</Link>,
    },
    { key: 'product', header: 'Product', sortValue: (s) => s.product_name, exportValue: (s) => s.product_name, render: (s) => <span className="text-[13px]">{s.product_name}</span> },
    { key: 'start', header: 'Start', sortValue: (s) => s.start_date, exportValue: (s) => s.start_date, render: (s) => <span className="text-[12.5px]">{formatDate(s.start_date)}</span> },
    {
      key: 'expiry', header: 'Expiry', sortValue: (s) => s.expiry_date, exportValue: (s) => s.expiry_date,
      render: (s) => {
        const d = daysUntil(s.expiry_date);
        return (
          <span className="whitespace-nowrap text-[12.5px]">
            {formatDate(s.expiry_date)}{' '}
            <Badge tone={d < 0 ? 'danger' : d <= 7 ? 'warning' : 'neutral'}>{d < 0 ? `${Math.abs(d)}d ago` : `${d}d`}</Badge>
          </span>
        );
      },
    },
    { key: 'status', header: 'Status', sortValue: (s) => s.status, exportValue: (s) => s.status, render: (s) => <StatusBadge status={s.status} /> },
    { key: 'amount', header: 'Amount', className: 'text-right', sortValue: (s) => s.purchase_amount, exportValue: (s) => s.purchase_amount, render: (s) => <span className="tabular-nums">{formatINR(s.purchase_amount)}</span> },
    { key: 'profit', header: 'Profit', className: 'text-right', sortValue: (s) => s.profit, exportValue: (s) => s.profit, render: (s) => <span className="tabular-nums" style={{ color: 'var(--success)' }}>{formatINR(s.profit)}</span>, hidden: true },
    {
      key: 'action', header: '', className: 'text-right', exportValue: () => '',
      render: (s) => (
        <Button size="sm" onClick={(e) => { e.stopPropagation(); router.push(`/orders/new?renew=${s.id}`); }}>Renew</Button>
      ),
    },
  ];

  return (
    <DataTable
      rows={rows}
      columns={columns}
      exportName="subscriptions"
      searchable={(s) => `${cname(s)} ${s.product_name} ${s.status}`}
      emptyTitle="No subscriptions in this view"
    />
  );
}
