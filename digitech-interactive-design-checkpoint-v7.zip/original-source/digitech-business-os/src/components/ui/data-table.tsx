'use client';

import React, { useMemo, useState } from 'react';
import {
  ChevronDown, ChevronUp, ChevronLeft, ChevronRight, ChevronsUpDown,
  Search, Download, Columns3, X,
} from 'lucide-react';
import { Button, Checkbox, EmptyState, Table, Td, Th, Dropdown } from './primitives';
import { cn } from '@/lib/utils';
import { toCsv } from '@/lib/services/csv';

export interface Column<T> {
  key: string;
  header: string;
  render: (row: T) => React.ReactNode;
  sortValue?: (row: T) => string | number;
  exportValue?: (row: T) => string | number;
  className?: string;
  hidden?: boolean;
  /** Right-align + tabular numerals, for money/quantity columns. */
  numeric?: boolean;
  width?: number | string;
}

export function DataTable<T extends { id: string }>({
  rows,
  columns,
  searchable = (r) => JSON.stringify(r),
  onRowClick,
  pageSize = 12,
  toolbar,
  emptyTitle = 'Nothing here yet',
  emptyMessage,
  emptyIcon,
  emptyAction,
  exportName,
  selectable,
  bulkActions,
  searchPlaceholder = 'Search…',
  rowActions,
  dense,
}: {
  rows: T[];
  columns: Column<T>[];
  searchable?: (row: T) => string;
  onRowClick?: (row: T) => void;
  pageSize?: number;
  toolbar?: React.ReactNode;
  emptyTitle?: string;
  emptyMessage?: string;
  emptyIcon?: React.ComponentType<{ className?: string }>;
  emptyAction?: React.ReactNode;
  exportName?: string;
  selectable?: boolean;
  bulkActions?: (selected: T[], clear: () => void) => React.ReactNode;
  searchPlaceholder?: string;
  rowActions?: (row: T) => React.ReactNode;
  dense?: boolean;
}) {
  const [q, setQ] = useState('');
  const [sort, setSort] = useState<{ key: string; dir: 'asc' | 'desc' } | null>(null);
  const [page, setPage] = useState(0);
  const [hidden, setHidden] = useState<Set<string>>(
    new Set(columns.filter((c) => c.hidden).map((c) => c.key)),
  );
  const [sel, setSel] = useState<Set<string>>(new Set());

  const visible = columns.filter((c) => !hidden.has(c.key));

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    let out = term ? rows.filter((r) => searchable(r).toLowerCase().includes(term)) : rows;
    if (sort) {
      const col = columns.find((c) => c.key === sort.key);
      if (col?.sortValue) {
        out = [...out].sort((a, b) => {
          const av = col.sortValue!(a);
          const bv = col.sortValue!(b);
          const cmp =
            typeof av === 'number' && typeof bv === 'number'
              ? av - bv
              : String(av).localeCompare(String(bv));
          return sort.dir === 'asc' ? cmp : -cmp;
        });
      }
    }
    return out;
  }, [rows, q, sort, columns, searchable]);

  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const current = Math.min(page, pages - 1);
  const slice = filtered.slice(current * pageSize, current * pageSize + pageSize);

  const selectedRows = filtered.filter((r) => sel.has(r.id));
  const allOnPage = slice.length > 0 && slice.every((r) => sel.has(r.id));
  const clearSel = () => setSel(new Set());

  const exportCsv = () => {
    const cols = visible;
    const source = selectedRows.length ? selectedRows : filtered;
    // toCsv() neutralises spreadsheet formula injection (= + - @ prefixes).
    const csv = toCsv(
      cols.map((c) => c.header),
      source.map((r) => cols.map((c) => (c.exportValue ? c.exportValue(r) : c.sortValue ? c.sortValue(r) : ''))),
    );
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${exportName ?? 'export'}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const cellPad = dense ? 'py-[7px]' : '';

  return (
    <div className="card overflow-visible">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[var(--border)] p-2.5">
        <div className="relative min-w-[190px] flex-1">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-[14px] w-[14px] -translate-y-1/2 text-[var(--muted-2)]" />
          <input
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(0);
            }}
            placeholder={searchPlaceholder}
            className="h-8 w-full rounded-[7px] border border-[var(--border)] bg-[var(--surface-2)] pl-[30px] pr-7 text-[12.5px] outline-none transition-all placeholder:text-[var(--muted-2)] focus:border-[var(--accent)] focus:bg-[var(--surface)] focus:shadow-[var(--ring)]"
          />
          {q && (
            <button
              onClick={() => setQ('')}
              aria-label="Clear search"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-[var(--muted-2)] hover:text-[var(--fg)]"
            >
              <X className="h-3 w-3" />
            </button>
          )}
        </div>

        {toolbar}

        <Dropdown
          width={180}
          trigger={
            <Button size="sm" variant="outline">
              <Columns3 className="h-3.5 w-3.5" /> Columns
            </Button>
          }
        >
          <div className="max-h-64 overflow-y-auto">
            {columns.map((c) => (
              <label
                key={c.key}
                className="flex cursor-pointer items-center gap-2 rounded-[6px] px-2 py-[6px] text-[12.5px] font-medium text-[var(--fg-soft)] hover:bg-[var(--surface-2)]"
              >
                <input
                  type="checkbox"
                  className="h-[14px] w-[14px] rounded-[4px] accent-[var(--accent)]"
                  checked={!hidden.has(c.key)}
                  onChange={() =>
                    setHidden((h) => {
                      const n = new Set(h);
                      if (n.has(c.key)) n.delete(c.key);
                      else n.add(c.key);
                      return n;
                    })
                  }
                />
                {c.header}
              </label>
            ))}
          </div>
        </Dropdown>

        <Button size="sm" variant="outline" onClick={exportCsv} title="Export rows to CSV">
          <Download className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Export</span>
        </Button>
      </div>

      {/* Bulk action bar */}
      {selectable && selectedRows.length > 0 && (
        <div className="animate-in flex flex-wrap items-center gap-2 border-b border-[var(--accent-border)] bg-[var(--accent-soft)] px-3 py-2">
          <span className="text-[12.5px] font-semibold text-[var(--accent)]">
            {selectedRows.length} selected
          </span>
          <button
            onClick={clearSel}
            className="text-[12px] font-medium text-[var(--muted)] underline-offset-2 hover:underline"
          >
            Clear
          </button>
          <div className="ml-auto flex flex-wrap items-center gap-1.5">
            {bulkActions?.(selectedRows, clearSel)}
          </div>
        </div>
      )}

      {slice.length === 0 ? (
        <EmptyState
          icon={emptyIcon}
          title={q ? 'No matches found' : emptyTitle}
          message={q ? `Nothing matches “${q}”. Try a different search.` : emptyMessage}
          action={q ? <Button size="sm" onClick={() => setQ('')}>Clear search</Button> : emptyAction}
        />
      ) : (
        <Table>
          <thead className="sticky-head">
            <tr>
              {selectable && (
                <Th className="w-[38px] pr-0">
                  <Checkbox
                    aria-label="Select all rows on page"
                    checked={allOnPage}
                    indeterminate={slice.some((r) => sel.has(r.id))}
                    onChange={(v) =>
                      setSel((s) => {
                        const n = new Set(s);
                        slice.forEach((r) => (v ? n.add(r.id) : n.delete(r.id)));
                        return n;
                      })
                    }
                  />
                </Th>
              )}
              {visible.map((c) => {
                const sorted = sort?.key === c.key;
                return (
                  <Th
                    key={c.key}
                    className={c.className}
                    align={c.numeric ? 'right' : 'left'}
                    style={c.width ? { width: c.width } : undefined}
                  >
                    {c.sortValue ? (
                      <button
                        className={cn(
                          'group inline-flex items-center gap-1 transition-colors hover:text-[var(--fg)]',
                          sorted && 'text-[var(--fg)]',
                          c.numeric && 'flex-row-reverse',
                        )}
                        onClick={() =>
                          setSort((s) =>
                            s?.key === c.key
                              ? { key: c.key, dir: s.dir === 'asc' ? 'desc' : 'asc' }
                              : { key: c.key, dir: 'asc' },
                          )
                        }
                      >
                        {c.header}
                        {sorted ? (
                          sort!.dir === 'asc' ? (
                            <ChevronUp className="h-3 w-3 text-[var(--accent)]" />
                          ) : (
                            <ChevronDown className="h-3 w-3 text-[var(--accent)]" />
                          )
                        ) : (
                          <ChevronsUpDown className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-50" />
                        )}
                      </button>
                    ) : (
                      c.header
                    )}
                  </Th>
                );
              })}
              {rowActions && <Th className="w-[44px]" />}
            </tr>
          </thead>
          <tbody>
            {slice.map((row) => {
              const on = sel.has(row.id);
              return (
                <tr
                  key={row.id}
                  onClick={() => onRowClick?.(row)}
                  className={cn(
                    'row-hover group/row',
                    onRowClick && 'cursor-pointer',
                    on && 'bg-[var(--accent-soft)]/40',
                  )}
                >
                  {selectable && (
                    <Td className={cn('pr-0', cellPad)} onClick={(e) => e.stopPropagation()}>
                      <span onClick={(e) => e.stopPropagation()}>
                        <Checkbox
                          aria-label="Select row"
                          checked={on}
                          onChange={(v) =>
                            setSel((s) => {
                              const n = new Set(s);
                              if (v) n.add(row.id);
                              else n.delete(row.id);
                              return n;
                            })
                          }
                        />
                      </span>
                    </Td>
                  )}
                  {visible.map((c) => (
                    <Td
                      key={c.key}
                      className={cn(c.className, cellPad)}
                      align={c.numeric ? 'right' : undefined}
                      num={c.numeric}
                    >
                      {c.render(row)}
                    </Td>
                  ))}
                  {rowActions && (
                    <Td className={cn('pl-0 text-right', cellPad)}>
                      <span
                        className="inline-flex opacity-0 transition-opacity group-hover/row:opacity-100 focus-within:opacity-100"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {rowActions(row)}
                      </span>
                    </Td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </Table>
      )}

      {/* Pagination */}
      {filtered.length > 0 && (
        <div className="flex items-center justify-between gap-2 px-3 py-2.5 text-[12px] text-[var(--muted)]">
          <span className="tabular-nums">
            <span className="font-medium text-[var(--fg-soft)]">
              {current * pageSize + 1}–{Math.min(filtered.length, (current + 1) * pageSize)}
            </span>{' '}
            of <span className="font-medium text-[var(--fg-soft)]">{filtered.length}</span>
          </span>
          {pages > 1 && (
            <div className="flex items-center gap-1">
              <Button
                size="icon-sm"
                variant="ghost"
                disabled={current === 0}
                onClick={() => setPage(current - 1)}
                aria-label="Previous page"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
              </Button>
              <span className="px-1 tabular-nums">
                {current + 1} / {pages}
              </span>
              <Button
                size="icon-sm"
                variant="ghost"
                disabled={current >= pages - 1}
                onClick={() => setPage(current + 1)}
                aria-label="Next page"
              >
                <ChevronRight className="h-3.5 w-3.5" />
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
