'use client';

import React, { createContext, useCallback, useContext, useState } from 'react';
import { CheckCircle2, AlertTriangle, Info, XCircle, X } from 'lucide-react';

type ToastTone = 'success' | 'error' | 'warning' | 'info';
interface Toast {
  id: string;
  title: string;
  description?: string;
  tone: ToastTone;
}

const ToastContext = createContext<{
  toast: (t: { title: string; description?: string; tone?: ToastTone }) => void;
} | null>(null);

const ICONS = {
  success: CheckCircle2,
  error: XCircle,
  warning: AlertTriangle,
  info: Info,
};
const COLORS = {
  success: 'var(--success)',
  error: 'var(--danger)',
  warning: 'var(--warning)',
  info: 'var(--info)',
};

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const toast = useCallback(({ title, description, tone = 'success' }: { title: string; description?: string; tone?: ToastTone }) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((t) => [...t, { id, title, description, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="pointer-events-none fixed bottom-4 right-4 z-[100] flex w-[min(360px,calc(100vw-2rem))] flex-col gap-2">
        {toasts.map((t) => {
          const Icon = ICONS[t.tone];
          return (
            <div
              key={t.id}
              className="animate-slide-up pointer-events-auto flex items-start gap-2.5 rounded-[11px] border border-[var(--border)] bg-[var(--surface)] p-3 shadow-[var(--shadow-lg)]"
            >
              <Icon className="mt-[1px] h-4 w-4 shrink-0" style={{ color: COLORS[t.tone] }} />
              <div className="min-w-0 flex-1">
                <p className="text-[13px] font-medium leading-snug">{t.title}</p>
                {t.description && (
                  <p className="mt-0.5 text-[12px] leading-snug text-[var(--muted)]">{t.description}</p>
                )}
              </div>
              <button
                onClick={() => setToasts((x) => x.filter((y) => y.id !== t.id))}
                className="press rounded-[5px] p-1 text-[var(--muted-2)] transition-colors hover:bg-[var(--surface-2)] hover:text-[var(--fg)]"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx.toast;
}
