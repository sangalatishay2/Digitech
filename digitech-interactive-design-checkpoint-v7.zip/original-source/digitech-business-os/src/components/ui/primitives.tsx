'use client';

import React from 'react';
import { cn } from '@/lib/utils';
import { X, Check } from 'lucide-react';

/* ---------------- Button ---------------- */
type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline' | 'subtle';
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'icon' | 'icon-sm';
};

export function Button({ className, variant = 'secondary', size = 'md', ...props }: ButtonProps) {
  const base =
    'press focusable inline-flex items-center justify-center gap-1.5 rounded-[7px] font-medium ' +
    'disabled:opacity-45 disabled:pointer-events-none whitespace-nowrap select-none';
  const variants: Record<string, string> = {
    primary:
      'bg-[var(--accent)] text-white shadow-[var(--shadow-xs)] hover:bg-[var(--accent-hover)]',
    secondary:
      'bg-[var(--surface)] border border-[var(--border-strong)] text-[var(--fg-soft)] hover:bg-[var(--surface-2)] hover:text-[var(--fg)] shadow-[var(--shadow-xs)]',
    outline:
      'border border-[var(--border-strong)] text-[var(--fg-soft)] hover:bg-[var(--surface-2)] hover:text-[var(--fg)]',
    ghost: 'text-[var(--muted)] hover:bg-[var(--surface-2)] hover:text-[var(--fg)]',
    subtle: 'bg-[var(--accent-soft)] text-[var(--accent)] hover:bg-[var(--accent-soft-2)]',
    danger: 'bg-[var(--danger)] text-white hover:brightness-110 shadow-[var(--shadow-xs)]',
  };
  const sizes: Record<string, string> = {
    xs: 'h-7 px-2 text-[12px]',
    sm: 'h-8 px-2.5 text-[12.5px]',
    md: 'h-[34px] px-3.5 text-[13px]',
    lg: 'h-10 px-4 text-[13.5px]',
    icon: 'h-[34px] w-[34px]',
    'icon-sm': 'h-8 w-8',
  };
  return <button className={cn(base, variants[variant], sizes[size], className)} {...props} />;
}

/* ---------------- Card ---------------- */
export function Card({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('card', className)} {...props} />;
}

export function CardHeader({
  title,
  subtitle,
  action,
  className,
}: {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        'flex items-center justify-between gap-3 border-b border-[var(--border)] px-4 py-3',
        className,
      )}
    >
      <div className="min-w-0">
        <h3 className="truncate text-[13.5px] font-semibold tracking-[-0.01em]">{title}</h3>
        {subtitle && <p className="mt-0.5 text-[12px] text-[var(--muted)]">{subtitle}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

/* ---------------- Page header ---------------- */
export function PageHeader({
  title,
  description,
  actions,
  className,
}: {
  title: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('flex flex-wrap items-start justify-between gap-3', className)}>
      <div className="min-w-0">
        <h1 className="text-[22px] font-semibold leading-tight tracking-[-0.022em] sm:text-[25px]">
          {title}
        </h1>
        {description && (
          <p className="mt-1 text-[13px] leading-relaxed text-[var(--muted)]">{description}</p>
        )}
      </div>
      {actions && <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

/* ---------------- Badge ---------------- */
const TONES: Record<string, string> = {
  neutral: 'bg-[var(--surface-2)] text-[var(--muted)] border-[var(--border)]',
  success: 'bg-[var(--success-soft)] text-[var(--success)] border-[var(--success-border)]',
  warning: 'bg-[var(--warning-soft)] text-[var(--warning)] border-[var(--warning-border)]',
  danger: 'bg-[var(--danger-soft)] text-[var(--danger)] border-[var(--danger-border)]',
  info: 'bg-[var(--info-soft)] text-[var(--info)] border-[var(--info-border)]',
  accent: 'bg-[var(--accent-soft)] text-[var(--accent)] border-[var(--accent-border)]',
};

export type Tone = keyof typeof TONES;

export function Badge({
  children,
  tone = 'neutral',
  className,
  dot,
}: {
  children: React.ReactNode;
  tone?: Tone;
  className?: string;
  dot?: boolean;
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-[6px] border px-1.5 py-[2px] text-[11px] font-medium capitalize leading-[16px] tracking-[-0.005em]',
        TONES[tone],
        className,
      )}
    >
      {dot && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-current opacity-80" />}
      {children}
    </span>
  );
}

export const STATUS_TONE: Record<string, Tone> = {
  // customers
  lead: 'info', active: 'success', vip: 'accent', inactive: 'neutral', blocked: 'danger', lost: 'danger',
  // orders
  new: 'info', awaiting_payment: 'warning', paid: 'success', processing: 'info',
  activation_pending: 'warning', activated: 'success', delivered: 'success',
  completed: 'success', cancelled: 'neutral', refunded: 'danger',
  // payments
  pending: 'warning', partial: 'warning', failed: 'danger', partially_refunded: 'warning',
  // activations
  waiting_payment: 'warning', ready: 'info', waiting_supplier: 'warning',
  // subscriptions
  expiring: 'warning', expired: 'danger', renewed: 'accent', paused: 'neutral',
  // leads
  contacted: 'info', qualified: 'info', interested: 'accent', negotiation: 'warning',
  won: 'success', follow_up: 'warning',
  // support
  open: 'warning', in_progress: 'info', waiting_customer: 'warning', resolved: 'success', closed: 'neutral',
  // tasks
  done: 'success',
  // priority
  low: 'neutral', medium: 'info', high: 'warning', urgent: 'danger',
  // roles
  owner: 'accent', admin: 'accent', sales: 'info', support: 'info',
  accounts: 'info', operations: 'info', viewer: 'neutral',
};

export function StatusBadge({ status, dot = true }: { status: string; dot?: boolean }) {
  return (
    <Badge tone={STATUS_TONE[status] ?? 'neutral'} dot={dot}>
      {status.replace(/_/g, ' ')}
    </Badge>
  );
}

/* ---------------- Tooltip ---------------- */
export function Tooltip({
  label,
  children,
  side = 'top',
  className,
}: {
  label: React.ReactNode;
  children: React.ReactNode;
  side?: 'top' | 'right' | 'bottom' | 'left';
  className?: string;
}) {
  const pos = {
    top: 'bottom-full left-1/2 -translate-x-1/2 mb-1.5',
    bottom: 'top-full left-1/2 -translate-x-1/2 mt-1.5',
    left: 'right-full top-1/2 -translate-y-1/2 mr-1.5',
    right: 'left-full top-1/2 -translate-y-1/2 ml-1.5',
  }[side];
  return (
    <span className={cn('group/tt relative inline-flex', className)}>
      {children}
      <span
        role="tooltip"
        className={cn(
          'pointer-events-none absolute z-[70] whitespace-nowrap rounded-[6px] border border-[var(--border-strong)] bg-[var(--surface)] px-2 py-1 text-[11.5px] font-medium text-[var(--fg)] opacity-0 shadow-[var(--shadow-md)] transition-opacity duration-150 group-hover/tt:opacity-100',
          pos,
        )}
      >
        {label}
      </span>
    </span>
  );
}

/* ---------------- Dropdown menu ---------------- */
export function Dropdown({
  trigger,
  children,
  align = 'right',
  width = 190,
  className,
}: {
  trigger: React.ReactNode;
  children: React.ReactNode | ((close: () => void) => React.ReactNode);
  align?: 'left' | 'right';
  width?: number;
  className?: string;
}) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const close = React.useCallback(() => setOpen(false), []);

  return (
    <div className={cn('relative', className)} ref={ref}>
      <div onClick={() => setOpen((v) => !v)}>{trigger}</div>
      {open && (
        <div
          style={{ width }}
          className={cn(
            'animate-scale-in absolute z-50 mt-1.5 origin-top overflow-hidden rounded-[10px] border border-[var(--border)] bg-[var(--surface)] p-1 shadow-[var(--shadow-lg)]',
            align === 'right' ? 'right-0' : 'left-0',
          )}
        >
          {typeof children === 'function' ? children(close) : children}
        </div>
      )}
    </div>
  );
}

export function MenuItem({
  children,
  onClick,
  icon: Icon,
  danger,
  checked,
  disabled,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  icon?: React.ComponentType<{ className?: string }>;
  danger?: boolean;
  checked?: boolean;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'flex w-full items-center gap-2 rounded-[6px] px-2 py-[6px] text-left text-[12.5px] font-medium transition-colors disabled:opacity-40',
        danger
          ? 'text-[var(--danger)] hover:bg-[var(--danger-soft)]'
          : 'text-[var(--fg-soft)] hover:bg-[var(--surface-2)] hover:text-[var(--fg)]',
      )}
    >
      {Icon && <Icon className="h-3.5 w-3.5 shrink-0 opacity-70" />}
      <span className="flex-1 truncate">{children}</span>
      {checked && <Check className="h-3.5 w-3.5 shrink-0 text-[var(--accent)]" />}
    </button>
  );
}

export function MenuSeparator() {
  return <div className="my-1 h-px bg-[var(--border)]" />;
}

export function MenuLabel({ children }: { children: React.ReactNode }) {
  return <div className="px-2 py-1 text-[10.5px] font-semibold uppercase tracking-[0.05em] text-[var(--muted-2)]">{children}</div>;
}

/* ---------------- Modal ---------------- */
/**
 * Reference-counted body scroll lock. Nested overlays (e.g. a customer form
 * opened from inside the order modal) must not release the lock when only the
 * inner one closes.
 */
let scrollLocks = 0;
function lockBodyScroll() {
  scrollLocks += 1;
  document.body.style.overflow = 'hidden';
  return () => {
    scrollLocks = Math.max(0, scrollLocks - 1);
    if (scrollLocks === 0) document.body.style.overflow = '';
  };
}

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  width = 'md',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  width?: 'sm' | 'md' | 'lg' | 'xl';
}) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    const unlock = lockBodyScroll();
    return () => {
      window.removeEventListener('keydown', onKey);
      unlock();
    };
  }, [open, onClose]);

  const titleId = React.useId();
  if (!open) return null;
  const w = { sm: 'max-w-md', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' }[width];
  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-center overflow-y-auto p-4 sm:p-8">
      <div className="animate-overlay absolute inset-0 bg-[#0a0b0d]/50 backdrop-blur-[3px]" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className={cn(
          'animate-scale-in relative z-10 my-auto w-full rounded-[14px] border border-[var(--border)] bg-[var(--surface)] shadow-[var(--shadow-xl)]',
          w,
        )}
      >
        <div className="flex items-start justify-between gap-4 border-b border-[var(--border)] px-5 py-4">
          <div className="min-w-0">
            <h2 id={titleId} className="text-[15px] font-semibold tracking-[-0.015em]">{title}</h2>
            {description && <p className="mt-0.5 text-[12.5px] leading-relaxed text-[var(--muted)]">{description}</p>}
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="press -mr-1 -mt-0.5 rounded-[6px] p-1.5 text-[var(--muted)] transition-colors hover:bg-[var(--surface-2)] hover:text-[var(--fg)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="px-5 py-4">{children}</div>
        {footer && (
          <div className="flex justify-end gap-2 border-t border-[var(--border)] bg-[var(--surface-2)]/40 px-5 py-3.5">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------- Drawer ---------------- */
export function Drawer({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  width = 420,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  width?: number;
}) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    const unlock = lockBodyScroll();
    return () => {
      window.removeEventListener('keydown', onKey);
      unlock();
    };
  }, [open, onClose]);

  const titleId = React.useId();
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] flex justify-end">
      <div className="animate-overlay absolute inset-0 bg-[#0a0b0d]/50 backdrop-blur-[3px]" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        style={{ maxWidth: width }}
        className="animate-slide-in-right relative z-10 flex h-full w-full flex-col border-l border-[var(--border)] bg-[var(--surface)] shadow-[var(--shadow-xl)]"
      >
        <div className="flex items-start justify-between gap-4 border-b border-[var(--border)] px-5 py-4">
          <div className="min-w-0">
            <h2 id={titleId} className="text-[15px] font-semibold tracking-[-0.015em]">{title}</h2>
            {description && <p className="mt-0.5 text-[12.5px] text-[var(--muted)]">{description}</p>}
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="press -mr-1 rounded-[6px] p-1.5 text-[var(--muted)] hover:bg-[var(--surface-2)] hover:text-[var(--fg)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="border-t border-[var(--border)] px-5 py-3.5">{footer}</div>}
      </div>
    </div>
  );
}

/* ---------------- Confirm ---------------- */
export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  message,
  confirmLabel = 'Confirm',
  danger,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      width="sm"
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button
            variant={danger ? 'danger' : 'primary'}
            onClick={() => {
              onConfirm();
              onClose();
            }}
          >
            {confirmLabel}
          </Button>
        </>
      }
    >
      <p className="text-[13px] leading-relaxed text-[var(--muted)]">{message}</p>
    </Modal>
  );
}

/* ---------------- Empty / Loading ---------------- */
export function EmptyState({
  icon: Icon,
  title,
  message,
  action,
  compact,
}: {
  icon?: React.ComponentType<{ className?: string }>;
  title: string;
  message?: string;
  action?: React.ReactNode;
  compact?: boolean;
}) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center gap-1.5 px-6 text-center',
        compact ? 'py-8' : 'py-14',
      )}
    >
      {Icon && (
        <div className="mb-1.5 flex h-9 w-9 items-center justify-center rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)]">
          <Icon className="h-[17px] w-[17px] text-[var(--muted-2)]" />
        </div>
      )}
      <p className="text-[13.5px] font-semibold">{title}</p>
      {message && <p className="max-w-xs text-[12.5px] leading-relaxed text-[var(--muted)]">{message}</p>}
      {action && <div className="mt-2.5">{action}</div>}
    </div>
  );
}

export function Skeleton({ className, style }: { className?: string; style?: React.CSSProperties }) {
  return <div className={cn('skeleton', className)} style={style} />;
}

/** Skeleton shaped like a data table. */
export function TableSkeleton({ rows = 6, cols = 5 }: { rows?: number; cols?: number }) {
  return (
    <div className="w-full">
      <div className="flex gap-3 border-b border-[var(--border)] px-3.5 py-2.5">
        {Array.from({ length: cols }).map((_, i) => (
          <Skeleton key={i} className="h-3" style={{ width: i === 0 ? '22%' : `${60 / cols}%` }} />
        ))}
      </div>
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} className="flex items-center gap-3 border-b border-[var(--border-subtle)] px-3.5 py-3">
          {Array.from({ length: cols }).map((_, c) => (
            <Skeleton
              key={c}
              className="h-3.5"
              style={{ width: c === 0 ? '22%' : `${60 / cols}%`, opacity: 1 - r * 0.1 }}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

/** Skeleton shaped like a KPI row. */
export function KpiSkeleton({ count = 4 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="card p-4">
          <Skeleton className="h-2.5 w-16" />
          <Skeleton className="mt-3 h-6 w-24" />
          <Skeleton className="mt-3 h-2.5 w-12" />
        </div>
      ))}
    </div>
  );
}

/* ---------------- Form fields ---------------- */
export function Field({
  label,
  children,
  hint,
  error,
  className,
  required,
}: {
  label?: string;
  children: React.ReactNode;
  hint?: string;
  error?: string;
  className?: string;
  required?: boolean;
}) {
  // Associate the label (and any hint/error text) with the control so screen
  // readers announce them. The single child is cloned with the generated ids;
  // an explicit id on the child always wins.
  const autoId = React.useId();
  const hintId = hint && !error ? `${autoId}-hint` : undefined;
  const errorId = error ? `${autoId}-error` : undefined;

  let control = children;
  if (React.isValidElement(children)) {
    const child = children as React.ReactElement<Record<string, unknown>>;
    const describedBy = [hintId, errorId, child.props['aria-describedby'] as string | undefined]
      .filter(Boolean)
      .join(' ');
    control = React.cloneElement(child, {
      id: (child.props.id as string | undefined) ?? autoId,
      'aria-describedby': describedBy || undefined,
      'aria-invalid': error ? true : child.props['aria-invalid'],
      'aria-required': required ? true : child.props['aria-required'],
    });
  }

  return (
    <div className={className}>
      {label && (
        <label className="label" htmlFor={autoId}>
          {label}
          {required && <span className="ml-0.5 text-[var(--danger)]">*</span>}
        </label>
      )}
      {control}
      {hint && !error && (
        <p id={hintId} className="mt-1 text-[11.5px] leading-snug text-[var(--muted-2)]">
          {hint}
        </p>
      )}
      {error && (
        <p id={errorId} className="mt-1 text-[11.5px] font-medium leading-snug text-[var(--danger)]">
          {error}
        </p>
      )}
    </div>
  );
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn('field', props.className)} />;
}

export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn('field', props.className)} />;
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={cn('field', props.className)} />;
}

/** Small toggle switch. */
export function Switch({
  checked,
  onChange,
  disabled,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
  label?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn(
        'focusable relative inline-flex h-[20px] w-[34px] shrink-0 items-center rounded-full transition-colors duration-200 disabled:opacity-40',
        checked ? 'bg-[var(--accent)]' : 'bg-[var(--border-strong)]',
      )}
    >
      <span
        className={cn(
          'inline-block h-[15px] w-[15px] transform rounded-full bg-white shadow-sm transition-transform duration-200',
          checked ? 'translate-x-[16px]' : 'translate-x-[3px]',
        )}
      />
    </button>
  );
}

/* ---------------- Tabs ---------------- */
export function Tabs({
  tabs,
  value,
  onChange,
  className,
}: {
  tabs: { id: string; label: string; count?: number }[];
  value: string;
  onChange: (id: string) => void;
  className?: string;
}) {
  return (
    <div className={cn('flex gap-0.5 overflow-x-auto border-b border-[var(--border)]', className)}>
      {tabs.map((t) => {
        const on = value === t.id;
        return (
          <button
            key={t.id}
            onClick={() => onChange(t.id)}
            className={cn(
              'relative -mb-px whitespace-nowrap px-3 py-2 text-[13px] font-medium transition-colors duration-150',
              on ? 'text-[var(--fg)]' : 'text-[var(--muted)] hover:text-[var(--fg)]',
            )}
          >
            {t.label}
            {t.count !== undefined && (
              <span
                className={cn(
                  'ml-1.5 rounded-[5px] px-1.5 py-[1px] text-[10.5px] font-semibold tabular-nums',
                  on ? 'bg-[var(--accent-soft)] text-[var(--accent)]' : 'bg-[var(--surface-2)] text-[var(--muted-2)]',
                )}
              >
                {t.count}
              </span>
            )}
            <span
              className={cn(
                'absolute inset-x-0 -bottom-px h-[2px] rounded-full transition-all duration-200',
                on ? 'bg-[var(--accent)] opacity-100' : 'opacity-0',
              )}
            />
          </button>
        );
      })}
    </div>
  );
}

/** Pill-style filter group. */
export function FilterPills({
  options,
  value,
  onChange,
  className,
}: {
  options: { id: string; label: string; count?: number; tone?: Tone }[];
  value: string;
  onChange: (id: string) => void;
  className?: string;
}) {
  return (
    <div className={cn('flex flex-wrap items-center gap-1.5', className)}>
      {options.map((o) => {
        const on = value === o.id;
        return (
          <button
            key={o.id}
            onClick={() => onChange(o.id)}
            className={cn(
              'press inline-flex items-center gap-1.5 rounded-[7px] border px-2.5 py-[5px] text-[12.5px] font-medium transition-colors',
              on
                ? 'border-[var(--accent-border)] bg-[var(--accent-soft)] text-[var(--accent)]'
                : 'border-[var(--border)] bg-[var(--surface)] text-[var(--muted)] hover:bg-[var(--surface-2)] hover:text-[var(--fg)]',
            )}
          >
            {o.label}
            {o.count !== undefined && (
              <span className={cn('tabular-nums', on ? 'opacity-80' : 'text-[var(--muted-2)]')}>{o.count}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}

/* ---------------- Table ---------------- */
export function Table({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className="tbl-wrap w-full">
      <table className={cn('w-full min-w-[640px] border-collapse text-[13px]', className)}>{children}</table>
    </div>
  );
}

export function Th({
  children,
  className,
  style,
  align,
}: {
  children?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  align?: 'left' | 'right' | 'center';
}) {
  return (
    <th
      className={cn(
        'border-b border-[var(--border)] bg-[var(--surface)] px-3.5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.04em] text-[var(--muted-2)]',
        align === 'right' ? 'text-right' : align === 'center' ? 'text-center' : 'text-left',
        className,
      )}
      style={style}
    >
      {children}
    </th>
  );
}

export function Td({
  children,
  className,
  style,
  align,
  num,
  onClick,
}: {
  children?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  align?: 'left' | 'right' | 'center';
  num?: boolean;
  onClick?: React.MouseEventHandler<HTMLTableCellElement>;
}) {
  return (
    <td
      className={cn(
        'border-b border-[var(--border-subtle)] px-3.5 py-[11px] align-middle text-[var(--fg-soft)]',
        align === 'right' ? 'text-right' : align === 'center' ? 'text-center' : '',
        num && 'tnum',
        className,
      )}
      style={style}
      onClick={onClick}
    >
      {children}
    </td>
  );
}

/** Checkbox styled for table row selection. */
export function Checkbox({
  checked,
  onChange,
  indeterminate,
  'aria-label': ariaLabel,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  indeterminate?: boolean;
  'aria-label'?: string;
}) {
  const ref = React.useRef<HTMLInputElement>(null);
  React.useEffect(() => {
    if (ref.current) ref.current.indeterminate = !!indeterminate && !checked;
  }, [indeterminate, checked]);
  return (
    <input
      ref={ref}
      type="checkbox"
      aria-label={ariaLabel}
      checked={checked}
      onChange={(e) => onChange(e.target.checked)}
      className="h-[15px] w-[15px] cursor-pointer rounded-[4px] border-[var(--border-strong)] accent-[var(--accent)]"
    />
  );
}

/* ---------------- Avatar ---------------- */
export function Avatar({
  name,
  size = 28,
  square,
}: {
  name: string;
  size?: number;
  square?: boolean;
}) {
  const hue = Array.from(name).reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  const label = name
    .split(' ')
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');
  return (
    <span
      className={cn(
        'inline-flex shrink-0 select-none items-center justify-center font-semibold text-white',
        square ? 'rounded-[7px]' : 'rounded-full',
      )}
      style={{
        width: size,
        height: size,
        fontSize: size * 0.37,
        letterSpacing: '-0.02em',
        background: `linear-gradient(140deg, hsl(${hue} 55% 56%), hsl(${(hue + 38) % 360} 52% 46%))`,
      }}
    >
      {label}
    </span>
  );
}

/** Name + secondary line, used in table identity cells. */
export function IdentityCell({
  name,
  secondary,
  size = 28,
  badge,
}: {
  name: string;
  secondary?: React.ReactNode;
  size?: number;
  badge?: React.ReactNode;
}) {
  return (
    <div className="flex min-w-0 items-center gap-2.5">
      <Avatar name={name} size={size} />
      <div className="min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="truncate text-[13px] font-medium text-[var(--fg)]">{name}</span>
          {badge}
        </div>
        {secondary && (
          <div className="truncate text-[11.5px] leading-tight text-[var(--muted-2)]">{secondary}</div>
        )}
      </div>
    </div>
  );
}

/* ---------------- Progress ---------------- */
export function Progress({
  value,
  tone = 'accent',
  size = 'md',
}: {
  value: number;
  tone?: Tone;
  size?: 'sm' | 'md';
}) {
  const color = {
    accent: 'var(--accent)',
    success: 'var(--success)',
    warning: 'var(--warning)',
    danger: 'var(--danger)',
    info: 'var(--info)',
    neutral: 'var(--muted)',
  }[tone];
  return (
    <div
      className={cn(
        'w-full overflow-hidden rounded-full bg-[var(--surface-3)]',
        size === 'sm' ? 'h-1' : 'h-1.5',
      )}
    >
      <div
        className="h-full rounded-full transition-all duration-500"
        style={{ width: `${Math.min(100, Math.max(0, value))}%`, background: color }}
      />
    </div>
  );
}

/* ---------------- Section / layout helpers ---------------- */
export function SectionTitle({
  children,
  action,
  className,
}: {
  children: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('flex items-center justify-between gap-3', className)}>
      <h2 className="text-[14.5px] font-semibold tracking-[-0.012em]">{children}</h2>
      {action}
    </div>
  );
}

/** Key/value row for detail panels. */
export function DetailRow({
  label,
  children,
  className,
}: {
  label: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('flex items-baseline justify-between gap-4 py-[7px]', className)}>
      <span className="shrink-0 text-[12.5px] text-[var(--muted)]">{label}</span>
      <span className="min-w-0 truncate text-right text-[13px] font-medium text-[var(--fg)]">{children}</span>
    </div>
  );
}

/** Colored left-border callout. */
export function Callout({
  tone = 'info',
  title,
  children,
  icon: Icon,
  className,
}: {
  tone?: Tone;
  title?: React.ReactNode;
  children?: React.ReactNode;
  icon?: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
  className?: string;
}) {
  const map: Record<string, { bg: string; fg: string; bd: string }> = {
    info: { bg: 'var(--info-soft)', fg: 'var(--info)', bd: 'var(--info-border)' },
    success: { bg: 'var(--success-soft)', fg: 'var(--success)', bd: 'var(--success-border)' },
    warning: { bg: 'var(--warning-soft)', fg: 'var(--warning)', bd: 'var(--warning-border)' },
    danger: { bg: 'var(--danger-soft)', fg: 'var(--danger)', bd: 'var(--danger-border)' },
    accent: { bg: 'var(--accent-soft)', fg: 'var(--accent)', bd: 'var(--accent-border)' },
    neutral: { bg: 'var(--surface-2)', fg: 'var(--muted)', bd: 'var(--border)' },
  };
  const c = map[tone] ?? map.info;
  return (
    <div
      className={cn('flex gap-2.5 rounded-[10px] border p-3', className)}
      style={{ background: c.bg, borderColor: c.bd }}
    >
      {Icon && <Icon className="mt-[1px] h-4 w-4 shrink-0" style={{ color: c.fg }} />}
      <div className="min-w-0 flex-1">
        {title && (
          <p className="text-[12.5px] font-semibold" style={{ color: c.fg }}>
            {title}
          </p>
        )}
        {children && (
          <div className={cn('text-[12.5px] leading-relaxed text-[var(--fg-soft)]', title && 'mt-0.5')}>
            {children}
          </div>
        )}
      </div>
    </div>
  );
}

/** Inline delta indicator (+12.4%). */
export function Delta({
  value,
  suffix = '%',
  invert,
  className,
}: {
  value: number;
  suffix?: string;
  invert?: boolean;
  className?: string;
}) {
  const good = invert ? value < 0 : value > 0;
  const flat = Math.abs(value) < 0.05;
  return (
    <span
      className={cn('inline-flex items-center gap-0.5 text-[11.5px] font-semibold tabular-nums', className)}
      style={{ color: flat ? 'var(--muted-2)' : good ? 'var(--success)' : 'var(--danger)' }}
    >
      {!flat && (value > 0 ? '↑' : '↓')}
      {Math.abs(value).toFixed(1)}
      {suffix}
    </span>
  );
}
