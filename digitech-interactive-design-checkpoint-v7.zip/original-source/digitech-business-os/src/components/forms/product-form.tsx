'use client';

import { useState } from 'react';
import { z } from 'zod';
import { useStore } from '@/lib/store';
import { Button, Field, Input, Modal, Select, Textarea } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import type { Product } from '@/lib/types';
import { formatINR, round2, num } from '@/lib/utils';

const schema = z.object({
  name: z.string().min(2, 'Name required'),
  code: z.string().min(2, 'Code required'),
  cost_price: z.number().min(0),
  selling_price: z.number().min(0),
  duration_days: z.number().min(0),
});

export function ProductForm({ open, onClose, product }: { open: boolean; onClose: () => void; product?: Product }) {
  const { db, createProduct, updateProduct } = useStore();
  const toast = useToast();
  const [f, setF] = useState({
    name: product?.name ?? '',
    code: product?.code ?? '',
    category_id: product?.category_id ?? '',
    brand: product?.brand ?? '',
    description: product?.description ?? '',
    product_type: product?.product_type ?? 'subscription',
    delivery_type: product?.delivery_type ?? 'email_activation',
    duration_days: product?.duration_days ?? 365,
    cost_price: product?.cost_price ?? 0,
    selling_price: product?.selling_price ?? 0,
    supplier_id: product?.supplier_id ?? '',
    stock: product?.stock ?? '',
    low_stock_threshold: product?.low_stock_threshold ?? 5,
    is_active: product?.is_active ?? true,
    notes: product?.notes ?? '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const profit = round2(f.selling_price - f.cost_price);
  const margin = f.selling_price > 0 ? round2((profit / f.selling_price) * 100) : 0;

  const submit = () => {
    const parsed = schema.safeParse(f);
    if (!parsed.success) {
      const e: Record<string, string> = {};
      for (const i of parsed.error.issues) e[String(i.path[0])] = i.message;
      setErrors(e);
      return;
    }
    const payload: Partial<Product> = {
      ...f,
      category_id: f.category_id || null,
      supplier_id: f.supplier_id || null,
      stock: f.stock === '' ? null : Number(f.stock),
      product_type: f.product_type as Product['product_type'],
      delivery_type: f.delivery_type as Product['delivery_type'],
    };
    if (product) {
      updateProduct(product.id, payload);
      toast({ title: 'Product updated', description: 'Existing orders keep their original cost snapshot.' });
    } else {
      createProduct(payload);
      toast({ title: 'Product created' });
    }
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={product ? 'Edit product' : 'New product'}
      description="Price changes never affect historical orders or existing subscriptions."
      width="lg"
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={submit}>{product ? 'Save changes' : 'Create product'}</Button>
        </>
      }
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Product name *" error={errors.name} className="sm:col-span-2">
          <Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="Canva Pro — 12 Months" />
        </Field>
        <Field label="Code / SKU *" error={errors.code}>
          <Input value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} placeholder="CANVA-12M" />
        </Field>
        <Field label="Brand">
          <Input value={f.brand} onChange={(e) => setF({ ...f, brand: e.target.value })} />
        </Field>
        <Field label="Category">
          <Select value={f.category_id} onChange={(e) => setF({ ...f, category_id: e.target.value })}>
            <option value="">Uncategorised</option>
            {db.product_categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        </Field>
        <Field label="Supplier">
          <Select value={f.supplier_id} onChange={(e) => setF({ ...f, supplier_id: e.target.value })}>
            <option value="">None</option>
            {db.suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        </Field>
        <Field label="Product type">
          <Select value={f.product_type} onChange={(e) => setF({ ...f, product_type: e.target.value as Product['product_type'] })}>
            <option value="subscription">Subscription</option>
            <option value="license">License</option>
            <option value="digital_product">Digital product</option>
            <option value="service">Service</option>
          </Select>
        </Field>
        <Field label="Delivery type">
          <Select value={f.delivery_type} onChange={(e) => setF({ ...f, delivery_type: e.target.value as Product['delivery_type'] })}>
            <option value="email_activation">Email activation</option>
            <option value="account_activation">Account activation</option>
            <option value="license_key">License key</option>
            <option value="invite_link">Invite link</option>
            <option value="manual">Manual</option>
          </Select>
        </Field>
        <Field label="Duration (days)" hint="0 = one-time / no expiry">
          <Input type="number" value={f.duration_days} onChange={(e) => setF({ ...f, duration_days: Math.max(0, Math.floor(num(e.target.value))) })} />
        </Field>
        <Field label="Cost price (₹)">
          <Input type="number" value={f.cost_price} onChange={(e) => setF({ ...f, cost_price: Math.max(0, num(e.target.value)) })} />
        </Field>
        <Field label="Selling price (₹)">
          <Input type="number" value={f.selling_price} onChange={(e) => setF({ ...f, selling_price: Math.max(0, num(e.target.value)) })} />
        </Field>
        <Field label="Stock / slots" hint="Leave blank for unlimited">
          <Input type="number" value={f.stock} onChange={(e) => setF({ ...f, stock: e.target.value })} />
        </Field>
        <Field label="Low-stock threshold">
          <Input type="number" value={f.low_stock_threshold} onChange={(e) => setF({ ...f, low_stock_threshold: Math.max(0, Math.floor(num(e.target.value))) })} />
        </Field>
        <Field label="Description" className="sm:col-span-2">
          <Textarea rows={2} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
        </Field>
        <Field label="Internal notes" className="sm:col-span-2">
          <Textarea rows={2} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
        </Field>
        <label className="flex items-center gap-2 text-[13px] sm:col-span-2">
          <input type="checkbox" checked={f.is_active} onChange={(e) => setF({ ...f, is_active: e.target.checked })} />
          Active (available for sale)
        </label>
      </div>

      <div className="mt-3 flex flex-wrap gap-4 rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] p-3 text-[13px]">
        <span>Profit: <strong className="tabular-nums" style={{ color: profit >= 0 ? 'var(--success)' : 'var(--danger)' }}>{formatINR(profit)}</strong></span>
        <span>Margin: <strong className="tabular-nums">{margin}%</strong></span>
      </div>
    </Modal>
  );
}
