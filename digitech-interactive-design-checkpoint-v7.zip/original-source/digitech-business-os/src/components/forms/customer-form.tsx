'use client';

import { useMemo, useState } from 'react';
import { z } from 'zod';
import { useStore } from '@/lib/store';
import { Button, Field, Input, Modal, Select, Textarea } from '@/components/ui/primitives';
import { findDuplicateCustomers } from '@/lib/services/business';
import { useToast } from '@/components/ui/toast';
import type { Customer } from '@/lib/types';
import { CUSTOMER_STATUS } from '@/lib/types';
import { AlertTriangle } from 'lucide-react';

const schema = z.object({
  name: z.string().min(2, 'Name is required'),
  email: z.string().email('Invalid email').optional().or(z.literal('')),
  phone: z.string().min(6, 'Phone looks too short').optional().or(z.literal('')),
  whatsapp: z.string().optional().or(z.literal('')),
  company: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  status: z.enum(CUSTOMER_STATUS),
  source: z.string().optional(),
  notes: z.string().optional(),
});

const SOURCES = ['Instagram', 'WhatsApp', 'Referral', 'Google', 'Website', 'Facebook', 'Walk-in', 'YouTube', 'Other'];

export function CustomerForm({
  open,
  onClose,
  customer,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  customer?: Customer;
  onSaved?: (c: Customer) => void;
}) {
  const { db, createCustomer, updateCustomer } = useStore();
  const toast = useToast();
  const [form, setForm] = useState({
    name: customer?.name ?? '',
    email: customer?.email ?? '',
    phone: customer?.phone ?? '',
    whatsapp: customer?.whatsapp ?? '',
    company: customer?.company ?? '',
    city: customer?.city ?? '',
    state: customer?.state ?? '',
    status: customer?.status ?? 'active',
    source: customer?.source ?? '',
    notes: customer?.notes ?? '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [override, setOverride] = useState(false);

  const dupes = useMemo(
    () => findDuplicateCustomers(form as Partial<Customer>, db.customers, customer?.id),
    [form, db.customers, customer?.id],
  );

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      const e: Record<string, string> = {};
      for (const issue of parsed.error.issues) e[String(issue.path[0])] = issue.message;
      setErrors(e);
      return;
    }
    if (dupes.length > 0 && !override) {
      toast({ title: 'Possible duplicate detected', description: 'Review the warning and confirm to continue.', tone: 'warning' });
      return;
    }
    const payload = { ...form, whatsapp: form.whatsapp || form.phone } as Partial<Customer>;
    if (customer) {
      updateCustomer(customer.id, payload);
      toast({ title: 'Customer updated' });
      onClose();
    } else {
      const created = createCustomer(payload);
      toast({ title: 'Customer created', description: created.name });
      onSaved?.(created);
      onClose();
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={customer ? 'Edit customer' : 'New customer'}
      description="Duplicate phone/email/WhatsApp raises a warning, never a hard block."
      width="lg"
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={submit}>
            {customer ? 'Save changes' : 'Create customer'}
          </Button>
        </>
      }
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Full name *" error={errors.name} className="sm:col-span-2">
          <Input value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Rahul Sharma" />
        </Field>
        <Field label="Phone" error={errors.phone}>
          <Input value={form.phone} onChange={(e) => set('phone', e.target.value)} placeholder="+91 98765 43210" />
        </Field>
        <Field label="WhatsApp" hint="Defaults to phone if empty">
          <Input value={form.whatsapp} onChange={(e) => set('whatsapp', e.target.value)} />
        </Field>
        <Field label="Email" error={errors.email}>
          <Input value={form.email} onChange={(e) => set('email', e.target.value)} placeholder="name@gmail.com" />
        </Field>
        <Field label="Company">
          <Input value={form.company} onChange={(e) => set('company', e.target.value)} />
        </Field>
        <Field label="City">
          <Input value={form.city} onChange={(e) => set('city', e.target.value)} placeholder="Meerut" />
        </Field>
        <Field label="State">
          <Input value={form.state} onChange={(e) => set('state', e.target.value)} placeholder="Uttar Pradesh" />
        </Field>
        <Field label="Status">
          <Select value={form.status} onChange={(e) => set('status', e.target.value)}>
            {CUSTOMER_STATUS.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </Select>
        </Field>
        <Field label="Source">
          <Select value={form.source} onChange={(e) => set('source', e.target.value)}>
            <option value="">Select…</option>
            {SOURCES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </Select>
        </Field>
        <Field label="Notes" className="sm:col-span-2">
          <Textarea rows={3} value={form.notes} onChange={(e) => set('notes', e.target.value)} />
        </Field>
      </div>

      {dupes.length > 0 && (
        <div className="mt-3 rounded-[10px] border border-[var(--warning)]/40 bg-[var(--warning-soft)] p-3">
          <div className="flex items-start gap-2">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[var(--warning)]" />
            <div className="min-w-0 flex-1">
              <p className="text-[12.5px] font-semibold text-[var(--warning)]">
                {dupes.length} possible duplicate{dupes.length > 1 ? 's' : ''} found
              </p>
              <ul className="mt-1 space-y-0.5 text-[11px] text-[var(--warning)]">
                {dupes.slice(0, 4).map((d) => (
                  <li key={d.customer.id}>
                    Matching {d.field}: <strong>{d.customer.name}</strong> ({d.customer.customer_code})
                  </li>
                ))}
              </ul>
              <label className="mt-2 flex cursor-pointer items-center gap-2 text-[11px] font-medium text-[var(--warning)]">
                <input type="checkbox" checked={override} onChange={(e) => setOverride(e.target.checked)} />
                Save anyway — this is a legitimate separate customer
              </label>
            </div>
          </div>
        </div>
      )}
    </Modal>
  );
}
