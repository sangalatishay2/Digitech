import { NextResponse, type NextRequest } from 'next/server';

/**
 * Session middleware.
 *
 * In production mode every application route requires a Supabase session
 * cookie. Demo mode short-circuits: there is no auth backend and no real data,
 * so gating would only break the evaluation experience.
 *
 * This is a coarse gate. It is NOT the authorization boundary — that is RLS in
 * Postgres plus the service-layer permission checks. Middleware only keeps
 * unauthenticated traffic from reaching the app at all; anyone who forged a
 * cookie past this point still cannot read or write a single row, because
 * current_org_id() would return NULL and every policy would deny.
 */

const PUBLIC_PATHS = ['/login', '/auth/callback', '/_next', '/favicon.ico', '/icon.svg', '/manifest.webmanifest'];

function isProductionMode(): boolean {
  const requested = process.env.NEXT_PUBLIC_DATA_PROVIDER;
  const configured = Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  );
  // Mirrors resolveMode(): the repository layer is now implemented, so
  // production is real whenever it is requested AND credentials exist.
  // Keep in sync with SUPABASE_REPOSITORY_IMPLEMENTED in src/lib/runtime/mode.ts.
  return requested === 'supabase' && configured;
}

/** Supabase stores its session in cookies named sb-<ref>-auth-token. */
function hasSupabaseSession(req: NextRequest): boolean {
  for (const c of req.cookies.getAll()) {
    if (/^sb-.*-auth-token(\.\d+)?$/.test(c.name) && c.value) return true;
  }
  return false;
}

export function middleware(req: NextRequest) {
  if (!isProductionMode()) return NextResponse.next();

  const { pathname } = req.nextUrl;
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p))) return NextResponse.next();

  if (!hasSupabaseSession(req)) {
    const url = req.nextUrl.clone();
    url.pathname = '/login';
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
