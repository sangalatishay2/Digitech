'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/lib/store';
import {
  Badge, Button, Card, Dropdown, EmptyState, FilterPills, IdentityCell, MenuItem,
  PageHeader, Table, Td, Th, Tooltip,
} from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { useToast } from '@/components/ui/toast';
import { renderTemplate } from '@/lib/services/business';
import { daysUntil, formatDate, formatINR, relativeTime } from '@/lib/utils';
import type { Subscription } from '@/lib/types';
import {
  CalendarClock, MessageCircle, Phone, RefreshCw, MoreHorizontal,
  CheckCircle2, Clock, XCircle, ThumbsUp, IndianRupee, TrendingUp,
  CheckSquare, UserRoundCheck,
} from 'lucide-react';

type ViewKey = 'today' | '3' | '7' | '15' | '30' | 'expired' | 'follow_up';

/** Likelihood of renewal, derived from engagement + recency. */
function renewalProbability(s: Subscription, hasRenewedBefore: boolean): number {
  let p = 50;
  if (s.reminder_state === 'interested') p += 30;
  else if (s.reminder_state === 'contacted') p += 12;
  else if (s.reminder_state === 'follow_up') p += 5;
  else if (s.reminder_state === 'not_interested') p -= 35;
  else if (s.reminder_state === 'lost') p -= 45;
  if (hasRenewedBefore) p += 18;
  const d = daysUntil(s.expiry_date);
  if (d < -30) p -= 25;
  else if (d < 0) p -= 12;
  return Math.max(3, Math.min(97, p));
}

export default function RenewalsPage() {
  const { db, updateSubscription, createTask, can } = useStore();
  const router = useRouter();
  const toast = useToast();
  const [view, setView] = useState<ViewKey>('7');
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const inWindow = (s: Subscription, max: number) => {
    const d = daysUntil(s.expiry_date);
    return d >= 0 && d <= max && s.status !== 'renewed' && s.status !== 'cancelled';
  };

  const buckets = useMemo(
    () => ({
      today: db.subscriptions.filter((s) => daysUntil(s.expiry_date) === 0 && s.status !== 'renewed'),
      '3': db.subscriptions.filter((s) => inWindow(s, 3)),
      '7': db.subscriptions.filter((s) => inWindow(s, 7)),
      '15': db.subscriptions.filter((s) => inWindow(s, 15)),
      '30': db.subscriptions.filter((s) => inWindow(s, 30)),
      expired: db.subscriptions.filter((s) => s.status === 'expired'),
      follow_up: db.subscriptions.filter(
        (s) => s.reminder_state === 'follow_up' || s.reminder_state === 'interested',
      ),
    }),
    [db.subscriptions],
  );

  const rows = [...buckets[view]].sort((a, b) => a.expiry_date.localeCompare(b.expiry_date));

  // KPIs
  const renewalValue = buckets['30'].reduce((a, s) => a + s.purchase_amount, 0);
  const renewedCount = db.subscriptions.filter((s) => s.status === 'renewed').length;
  const eligible = renewedCount + db.subscriptions.filter((s) => s.status === 'expired').length;
  const renewalRatePct = eligible ? Math.round((renewedCount / eligible) * 100) : 0;

  const template = db.message_templates.find((t) => t.name === 'Subscription Expiry Reminder');

  const waLink = (s: Subscription) => {
    const c = db.customers.find((x) => x.id === s.customer_id);
    const phone = (c?.whatsapp ?? c?.phone ?? '').replace(/\D/g, '');
    if (!phone) return null;
    const body = renderTemplate(
      template?.body ?? 'Hi {{customer_name}}, your {{product_name}} expires on {{expiry_date}}.',
      {
        customer_name: c?.name ?? 'there',
        product_name: s.product_name,
        expiry_date: formatDate(s.expiry_date),
        days_remaining: daysUntil(s.expiry_date),
        renewal_price: s.purchase_amount,
      },
    );
    return `https://wa.me/${phone}?text=${encodeURIComponent(body)}`;
  };

  const selectedRows = rows.filter((subscription) => selected.has(subscription.id));
  const allSelected = rows.length > 0 && rows.every((subscription) => selected.has(subscription.id));
  const canSelect = can('subscriptions.update') || can('tasks.create');
  const toggleSelected = (id: string) => {
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };
  const toggleAll = () => {
    setSelected((current) => {
      const next = new Set(current);
      if (allSelected) rows.forEach((subscription) => next.delete(subscription.id));
      else rows.forEach((subscription) => next.add(subscription.id));
      return next;
    });
  };
  const bulkMarkContacted = () => {
    const contactedAt = new Date().toISOString();
    selectedRows.forEach((subscription) => updateSubscription(subscription.id, {
      reminder_state: 'contacted',
      last_contacted_at: contactedAt,
    }));
    toast({ title: `${selectedRows.length} renewals marked contacted` });
    setSelected(new Set());
  };
  const bulkCreateTasks = () => {
    const due = new Date();
    due.setDate(due.getDate() + 1);
    let created = 0;
    for (const subscription of selectedRows) {
      const exists = db.tasks.some((task) =>
        task.entity_type === 'subscription'
        && task.entity_id === subscription.id
        && !['done', 'cancelled'].includes(task.status),
      );
      if (exists) continue;
      const customer = db.customers.find((item) => item.id === subscription.customer_id);
      createTask({
        title: `Renew ${subscription.product_name} — ${customer?.name ?? 'customer'}`,
        description: `Subscription expires ${formatDate(subscription.expiry_date)}. Follow up and update the renewal state.`,
        entity_type: 'subscription',
        entity_id: subscription.id,
        priority: daysUntil(subscription.expiry_date) <= 3 ? 'high' : 'medium',
        status: 'open',
        assigned_to: subscription.assigned_to ?? null,
        due_at: due.toISOString(),
      });
      created += 1;
    }
    toast({
      title: `${created} follow-up task${created === 1 ? '' : 's'} created`,
      description: created < selectedRows.length ? 'Existing open tasks were not duplicated.' : undefined,
    });
    setSelected(new Set());
  };

  const mark = (s: Subscription, state: Subscription['reminder_state'], label: string) => {
    updateSubscription(s.id, { reminder_state: state, last_contacted_at: new Date().toISOString() });
    toast({ title: label });
  };

  const pills = [
    { id: 'today', label: 'Today', count: buckets.today.length },
    { id: '3', label: '3 Days', count: buckets['3'].length },
    { id: '7', label: '7 Days', count: buckets['7'].length },
    { id: '15', label: '15 Days', count: buckets['15'].length },
    { id: '30', label: '30 Days', count: buckets['30'].length },
    { id: 'expired', label: 'Expired', count: buckets.expired.length },
    { id: 'follow_up', label: 'Follow-Up', count: buckets.follow_up.length },
  ];

  return (
    <div className="space-y-5">
      <PageHeader
        title="Renewal Center"
        description="Work the expiry pipeline — contact, qualify and renew before revenue churns."
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <KpiCard
          label="Expires Today"
          value={buckets.today.length}
          icon={CalendarClock}
          tone={buckets.today.length ? 'danger' : 'neutral'}
        />
        <KpiCard label="Next 7 Days" value={buckets['7'].length} icon={Clock} tone="warning" />
        <KpiCard label="Next 30 Days" value={buckets['30'].length} icon={CalendarClock} tone="info" />
        <KpiCard
          label="Renewal Value"
          value={formatINR(renewalValue, { compact: true })}
          sub="next 30 days"
          icon={IndianRupee}
          tone="accent"
        />
        <KpiCard
          label="Renewal Rate"
          value={`${renewalRatePct}%`}
          sub={`${renewedCount} renewed`}
          icon={TrendingUp}
          tone="success"
        />
      </div>

      <FilterPills options={pills} value={view} onChange={(v) => { setView(v as ViewKey); setSelected(new Set()); }} />

      {selectedRows.length > 0 && (
        <Card className="flex flex-wrap items-center gap-2 border-[var(--accent-border)] bg-[var(--accent-soft)]/55 px-3 py-2.5">
          <Badge tone="accent">{selectedRows.length} selected</Badge>
          <p className="mr-auto text-[12px] text-[var(--muted)]">Apply one safe workflow action to the selected renewal records.</p>
          {can('tasks.create') && (
            <Button size="sm" variant="outline" onClick={bulkCreateTasks}>
              <CheckSquare className="h-3.5 w-3.5" /> Create follow-up tasks
            </Button>
          )}
          {can('subscriptions.update') && (
            <Button size="sm" variant="primary" onClick={bulkMarkContacted}>
              <UserRoundCheck className="h-3.5 w-3.5" /> Mark contacted
            </Button>
          )}
        </Card>
      )}

      <Card>
        {rows.length === 0 ? (
          <EmptyState
            icon={CalendarClock}
            title="No subscriptions expire in this window."
            message="You're all caught up. Switch to another view or check back tomorrow."
          />
        ) : (
          <Table>
            <thead className="sticky-head">
              <tr>
                {canSelect && (
                  <Th>
                    <input
                      type="checkbox"
                      checked={allSelected}
                      onChange={toggleAll}
                      aria-label={allSelected ? 'Clear visible renewal selection' : 'Select all visible renewals'}
                      className="h-4 w-4 cursor-pointer accent-[var(--accent)]"
                    />
                  </Th>
                )}
                <Th>Customer</Th>
                <Th>Product</Th>
                <Th>Expiry</Th>
                <Th>Days Left</Th>
                <Th align="right">Amount</Th>
                <Th>Last Contact</Th>
                <Th>Probability</Th>
                <Th align="right">Action</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map((s) => {
                const c = db.customers.find((x) => x.id === s.customer_id);
                const d = daysUntil(s.expiry_date);
                const hasRenewed = db.subscriptions.some((x) => x.previous_subscription_id === s.id);
                const prob = renewalProbability(s, hasRenewed);
                const dColor =
                  d < 0 || d <= 3 ? 'var(--danger)' : d <= 7 ? 'var(--warning)' : 'var(--muted)';
                const probColor =
                  prob >= 70 ? 'var(--success)' : prob >= 40 ? 'var(--warning)' : 'var(--danger)';
                const whatsappUrl = waLink(s);

                return (
                  <tr key={s.id} className="row-hover group/row">
                    {canSelect && (
                      <Td>
                        <input
                          type="checkbox"
                          checked={selected.has(s.id)}
                          onChange={() => toggleSelected(s.id)}
                          aria-label={`Select ${s.product_name} renewal for ${c?.name ?? 'customer'}`}
                          className="h-4 w-4 cursor-pointer accent-[var(--accent)]"
                        />
                      </Td>
                    )}
                    <Td>
                      <Link href={`/customers/${c?.id}`} className="block hover:opacity-80">
                        <IdentityCell name={c?.name ?? '—'} secondary={c?.customer_code} size={28} />
                      </Link>
                    </Td>
                    <Td>
                      <p className="max-w-[190px] truncate text-[12.5px] font-medium text-[var(--fg)]">
                        {s.product_name}
                      </p>
                      {s.reminder_state !== 'none' && (
                        <Badge tone="accent" className="mt-1">
                          {s.reminder_state.replace(/_/g, ' ')}
                        </Badge>
                      )}
                    </Td>
                    <Td className="whitespace-nowrap text-[12.5px]">{formatDate(s.expiry_date)}</Td>
                    <Td>
                      <span
                        className="inline-flex items-center gap-1.5 whitespace-nowrap text-[12.5px] font-semibold tabular-nums"
                        style={{ color: dColor }}
                      >
                        <span className="h-1.5 w-1.5 rounded-full" style={{ background: dColor }} />
                        {d < 0 ? `${Math.abs(d)}d overdue` : d === 0 ? 'Today' : `${d} days`}
                      </span>
                    </Td>
                    <Td align="right" num className="font-semibold text-[var(--fg)]">
                      {formatINR(s.purchase_amount)}
                    </Td>
                    <Td className="whitespace-nowrap text-[12px] text-[var(--muted)]">
                      {s.last_contacted_at ? relativeTime(s.last_contacted_at) : '—'}
                    </Td>
                    <Td>
                      <div className="flex items-center gap-2">
                        <div className="h-1 w-12 overflow-hidden rounded-full bg-[var(--surface-3)]">
                          <div
                            className="h-full rounded-full"
                            style={{ width: `${prob}%`, background: probColor }}
                          />
                        </div>
                        <span className="text-[11.5px] font-semibold tabular-nums" style={{ color: probColor }}>
                          {prob}%
                        </span>
                      </div>
                    </Td>
                    <Td align="right">
                      <div className="flex items-center justify-end gap-1.5">
                        <Tooltip label="Send WhatsApp reminder">
                          {whatsappUrl ? <a href={whatsappUrl} target="_blank" rel="noreferrer">
                            <Button size="icon-sm" variant="outline" aria-label="WhatsApp">
                              <MessageCircle className="h-3.5 w-3.5" />
                            </Button>
                          </a> : <Button size="icon-sm" variant="outline" aria-label="WhatsApp number unavailable" disabled>
                            <MessageCircle className="h-3.5 w-3.5" />
                          </Button>}
                        </Tooltip>
                        <Button
                          size="sm"
                          variant="primary"
                          onClick={() => router.push(`/orders/new?renew=${s.id}`)}
                        >
                          <RefreshCw className="h-3.5 w-3.5" /> Renew
                        </Button>
                        <Dropdown
                          width={186}
                          trigger={
                            <Button size="icon-sm" variant="ghost" aria-label="More actions">
                              <MoreHorizontal className="h-3.5 w-3.5" />
                            </Button>
                          }
                        >
                          {(close) => (
                            <>
                              {c?.phone && (
                                <MenuItem
                                  icon={Phone}
                                  onClick={() => {
                                    close();
                                    window.location.href = `tel:${c.phone}`;
                                  }}
                                >
                                  Call {c.phone}
                                </MenuItem>
                              )}
                              <MenuItem
                                icon={CheckCircle2}
                                onClick={() => {
                                  close();
                                  mark(s, 'contacted', 'Marked contacted');
                                }}
                              >
                                Mark contacted
                              </MenuItem>
                              <MenuItem
                                icon={ThumbsUp}
                                onClick={() => {
                                  close();
                                  mark(s, 'interested', 'Marked interested');
                                }}
                              >
                                Interested
                              </MenuItem>
                              <MenuItem
                                icon={Clock}
                                onClick={() => {
                                  close();
                                  mark(s, 'follow_up', 'Moved to follow-up');
                                }}
                              >
                                Follow up later
                              </MenuItem>
                              <MenuItem
                                icon={XCircle}
                                onClick={() => {
                                  close();
                                  mark(s, 'not_interested', 'Marked not interested');
                                }}
                              >
                                Not interested
                              </MenuItem>
                              <MenuItem
                                danger
                                icon={XCircle}
                                onClick={() => {
                                  close();
                                  updateSubscription(s.id, { reminder_state: 'lost', status: 'cancelled' });
                                  toast({ title: 'Marked lost', tone: 'warning' });
                                }}
                              >
                                Mark lost
                              </MenuItem>
                            </>
                          )}
                        </Dropdown>
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        )}
      </Card>
    </div>
  );
}
