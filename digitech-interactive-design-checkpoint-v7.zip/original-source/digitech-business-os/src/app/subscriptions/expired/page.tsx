'use client';

import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { SubscriptionsTable } from '@/components/subscriptions-table';

export default function ExpiredPage() {
  const { db } = useStore();
  const rows = db.subscriptions.filter((s) => s.status === 'expired');
  return (
    <>
      <PageHeader title="Expired Subscriptions" description={`${rows.length} lapsed subscriptions — win them back`} />
      <SubscriptionsTable rows={rows} />
    </>
  );
}
