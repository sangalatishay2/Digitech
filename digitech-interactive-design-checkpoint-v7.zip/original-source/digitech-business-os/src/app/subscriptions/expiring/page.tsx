'use client';

import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { SubscriptionsTable } from '@/components/subscriptions-table';
import { Button } from '@/components/ui/primitives';
import Link from 'next/link';

export default function ExpiringPage() {
  const { db, org } = useStore();
  const rows = db.subscriptions.filter((s) => s.status === 'expiring');
  return (
    <>
      <PageHeader
        title="Expiring Subscriptions"
        description={`Within the ${org.expiry_threshold_days}-day threshold (configurable in Settings)`}
        actions={<Link href="/renewals"><Button variant="primary">Open Renewal Center</Button></Link>}
      />
      <SubscriptionsTable rows={rows} />
    </>
  );
}
