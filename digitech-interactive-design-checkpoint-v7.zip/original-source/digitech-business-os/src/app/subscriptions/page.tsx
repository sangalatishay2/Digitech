'use client';

import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { SubscriptionsTable } from '@/components/subscriptions-table';
import { KpiCard } from '@/components/kpi-card';
import { formatINR } from '@/lib/utils';
import { RefreshCw, CalendarClock, CalendarX, IndianRupee } from 'lucide-react';

export default function SubscriptionsPage() {
  const { db } = useStore();
  const active = db.subscriptions.filter((s) => s.status === 'active' || s.status === 'expiring');
  const mrrish = active.reduce((a, s) => a + (s.duration_days ? (s.purchase_amount / s.duration_days) * 30 : 0), 0);

  return (
    <>
      <PageHeader title="Active Subscriptions" description={`${active.length} live subscriptions`} />
      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiCard label="Active" value={db.subscriptions.filter((s) => s.status === 'active').length} icon={RefreshCw} tone="success" />
        <KpiCard label="Expiring" value={db.subscriptions.filter((s) => s.status === 'expiring').length} icon={CalendarClock} tone="warning" href="/subscriptions/expiring" />
        <KpiCard label="Expired" value={db.subscriptions.filter((s) => s.status === 'expired').length} icon={CalendarX} tone="danger" href="/subscriptions/expired" />
        <KpiCard label="Normalised monthly value" value={formatINR(mrrish, { compact: true })} icon={IndianRupee} tone="accent" />
      </div>
      <SubscriptionsTable rows={active} />
    </>
  );
}
