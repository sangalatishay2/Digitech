'use client';

import { useState } from 'react';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Button, Card, CardHeader, EmptyState, Field, Input, Modal, Table, Td, Textarea, Th } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { newId, nowIso } from '@/lib/services/business';
import { formatINR, slugify, round2 } from '@/lib/utils';
import { Plus, FolderTree } from 'lucide-react';

export default function CategoriesPage() {
  const { db, update } = useStore();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');

  const create = () => {
    if (!name.trim()) return;
    update((d) => {
      d.product_categories.unshift({
        id: newId(),
        organization_id: d.organizations[0].id,
        created_at: nowIso(),
        updated_at: nowIso(),
        deleted_at: null,
        name: name.trim(),
        slug: slugify(name),
        description: desc || null,
      });
    });
    toast({ title: 'Category created' });
    setName('');
    setDesc('');
    setOpen(false);
  };

  const stats = (catId: string) => {
    const prods = db.products.filter((p) => p.category_id === catId);
    const ids = new Set(prods.map((p) => p.id));
    let revenue = 0;
    for (const o of db.orders) for (const i of o.items) if (i.product_id && ids.has(i.product_id)) revenue += i.line_total;
    return { count: prods.length, revenue: round2(revenue) };
  };

  return (
    <>
      <PageHeader
        title="Categories"
        description="Organise the catalog"
        actions={<Button variant="primary" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5" /> New Category</Button>}
      />
      <Card>
        <CardHeader title="Product categories" subtitle={`${db.product_categories.length} categories`} />
        {db.product_categories.length === 0 ? (
          <EmptyState icon={FolderTree} title="No categories yet" />
        ) : (
          <Table>
            <thead><tr><Th>Name</Th><Th>Slug</Th><Th>Description</Th><Th className="text-right">Products</Th><Th className="text-right">Revenue</Th></tr></thead>
            <tbody>
              {db.product_categories.map((c) => {
                const s = stats(c.id);
                return (
                  <tr key={c.id}>
                    <Td className="font-medium">{c.name}</Td>
                    <Td className="text-[12.5px] text-[var(--muted)]">{c.slug}</Td>
                    <Td className="text-[12.5px] text-[var(--muted)]">{c.description ?? '—'}</Td>
                    <Td className="text-right tabular-nums">{s.count}</Td>
                    <Td className="text-right tabular-nums">{formatINR(s.revenue)}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        )}
      </Card>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="New category"
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" onClick={create}>Create</Button></>}
      >
        <div className="space-y-3">
          <Field label="Name"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="AI Tools" /></Field>
          <Field label="Description"><Textarea rows={2} value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
        </div>
      </Modal>
    </>
  );
}
