'use client';

import { useMemo, useState } from 'react';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Badge, Button, Card, CardHeader, Select, Table, Td, Th } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { findDuplicateCustomers } from '@/lib/services/business';
import { cn } from '@/lib/utils';
// RFC4180 parser + formula-injection-safe writer (shared, unit tested).
import { parseCsv, toCsv } from '@/lib/services/csv';
import {
  validateCustomerRow, validateProductRow, importSupported, unsupportedReason,
} from '@/lib/services/import';
import { AlertTriangle, CheckCircle2, Download, Upload } from 'lucide-react';

type Entity = 'customers' | 'products' | 'suppliers' | 'subscriptions' | 'orders';

const FIELDS: Record<Entity, string[]> = {
  customers: ['name', 'phone', 'whatsapp', 'email', 'company', 'city', 'state', 'source', 'status'],
  products: ['name', 'code', 'brand', 'product_type', 'delivery_type', 'duration_days', 'cost_price', 'selling_price', 'stock'],
  suppliers: ['name', 'contact_person', 'email', 'phone', 'website', 'payment_terms'],
  subscriptions: ['customer_name', 'product_name', 'start_date', 'expiry_date', 'purchase_amount'],
  orders: ['customer_name', 'product_name', 'quantity', 'unit_price', 'discount', 'ordered_at'],
};

const REQUIRED: Record<Entity, string[]> = {
  customers: ['name'],
  products: ['name', 'code', 'selling_price'],
  suppliers: ['name'],
  subscriptions: ['customer_name', 'product_name', 'expiry_date'],
  orders: ['customer_name', 'product_name'],
};

export default function ImportExportPage() {
  const { db, createCustomer, createProduct, createSupplier } = useStore();
  const toast = useToast();
  const [entity, setEntity] = useState<Entity>('customers');
  const [csv, setCsv] = useState<{ headers: string[]; rows: string[][] } | null>(null);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [report, setReport] = useState<{ created: number; skipped: number; errors: string[] } | null>(null);

  const onFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const parsed = parseCsv(String(reader.result));
      setCsv(parsed);
      setReport(null);
      const auto: Record<string, string> = {};
      for (const f of FIELDS[entity]) {
        const hit = parsed.headers.find((h) => h.toLowerCase().replace(/[^a-z]/g, '') === f.toLowerCase().replace(/[^a-z]/g, ''));
        if (hit) auto[f] = hit;
      }
      setMapping(auto);
    };
    reader.readAsText(file);
  };

  const preview = useMemo(() => {
    if (!csv) return [];
    return csv.rows.slice(0, 8).map((row) => {
      const obj: Record<string, string> = {};
      for (const f of FIELDS[entity]) {
        const idx = csv.headers.indexOf(mapping[f]);
        obj[f] = idx >= 0 ? row[idx] ?? '' : '';
      }
      return obj;
    });
  }, [csv, mapping, entity]);

  const dupWarnings = useMemo(() => {
    if (entity !== 'customers' || !csv) return 0;
    return preview.filter((r) => findDuplicateCustomers({ name: r.name, phone: r.phone, email: r.email, whatsapp: r.whatsapp }, db.customers).length > 0).length;
  }, [preview, db.customers, entity, csv]);

  const runImport = () => {
    if (!csv) return;
    const missing = REQUIRED[entity].filter((f) => !mapping[f]);
    if (missing.length) { toast({ title: `Map required fields: ${missing.join(', ')}`, tone: 'error' }); return; }
    let created = 0, skipped = 0;
    const errors: string[] = [];

    if (!importSupported(entity)) {
      setReport({ created: 0, skipped: csv.rows.length, errors: [unsupportedReason(entity)] });
      toast({ title: 'Import not supported for this entity', tone: 'warning' });
      return;
    }

    csv.rows.forEach((row, i) => {
      const val = (f: string) => {
        const idx = csv.headers.indexOf(mapping[f]);
        return idx >= 0 ? (row[idx] ?? '').trim() : '';
      };
      try {
        if (entity === 'customers') {
          // Every row is validated; a bad row is reported, never coerced.
          const r = validateCustomerRow(val, i);
          if (!r.ok) {
            skipped++;
            for (const iss of r.issues) errors.push(`Row ${iss.row} · ${iss.field}: ${iss.message}`);
            return;
          }
          createCustomer(r.value);
          created++;
        } else if (entity === 'products') {
          const r = validateProductRow(val, i);
          if (!r.ok) {
            skipped++;
            for (const iss of r.issues) errors.push(`Row ${iss.row} · ${iss.field}: ${iss.message}`);
            return;
          }
          createProduct(r.value);
          created++;
        } else if (entity === 'suppliers') {
          if (!val('name')) {
            skipped++;
            errors.push(`Row ${i + 2} · name: name is required`);
            return;
          }
          createSupplier({
            name: val('name'), contact_person: val('contact_person') || null,
            email: val('email') || null, phone: val('phone') || null,
            website: val('website') || null, payment_terms: val('payment_terms') || null,
          });
          created++;
        }
      } catch (e) {
        skipped++;
        errors.push(`Row ${i + 2}: ${(e as Error).message}`);
      }
    });

    setReport({ created, skipped, errors });
    toast({ title: `Import finished — ${created} created`, description: skipped ? `${skipped} rows skipped` : undefined, tone: created ? 'success' : 'warning' });
  };

  const downloadTemplate = () => {
    const csvText = FIELDS[entity].join(',') + '\n';
    const url = URL.createObjectURL(new Blob([csvText], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url; a.download = `${entity}-template.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const exportEntity = () => {
    const rows = (
      entity === 'customers' ? db.customers
        : entity === 'products' ? db.products
        : entity === 'suppliers' ? db.suppliers
        : entity === 'subscriptions' ? db.subscriptions
        : db.orders) as unknown as Record<string, unknown>[];
    if (!rows.length) { toast({ title: 'Nothing to export', tone: 'warning' }); return; }
    const keys = Object.keys(rows[0]).filter((k) => typeof (rows[0] as Record<string, unknown>)[k] !== 'object');
    const csv = toCsv(keys, rows.map((r) => keys.map((k) => (r as Record<string, unknown>)[k] ?? '')));
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url; a.download = `${entity}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast({ title: `Exported ${rows.length} ${entity}` });
  };

  return (
    <>
      <PageHeader title="Import / Export" description="CSV import with field mapping, preview, duplicate detection and a result report" />

      <Card className="mb-4">
        <CardHeader title="1 · Choose entity" />
        <div className="flex flex-wrap items-end gap-3 p-4">
          <div className="min-w-[200px]">
            <label className="label">Entity</label>
            <Select value={entity} onChange={(e) => { setEntity(e.target.value as Entity); setCsv(null); setReport(null); }}>
              {(['customers', 'products', 'suppliers', 'subscriptions', 'orders'] as Entity[]).map((e) => <option key={e} value={e}>{e}</option>)}
            </Select>
          </div>
          <Button onClick={downloadTemplate}><Download className="h-3.5 w-3.5" /> Download template</Button>
          <Button onClick={exportEntity} variant="outline"><Download className="h-3.5 w-3.5" /> Export existing</Button>
          <label>
            <input type="file" accept=".csv,text/csv" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); }} />
            <span className="inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-[10px] bg-[var(--accent)] px-3.5 text-[13px] font-medium text-white hover:opacity-90">
              <Upload className="h-3.5 w-3.5" /> Upload CSV
            </span>
          </label>
        </div>
      </Card>

      {csv && (
        <>
          <Card className="mb-4">
            <CardHeader title="2 · Map fields" subtitle={`${csv.rows.length} rows detected`} />
            <div className="grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3">
              {FIELDS[entity].map((f) => (
                <div key={f}>
                  <label className="label">
                    {f} {REQUIRED[entity].includes(f) && <span style={{ color: 'var(--danger)' }}>*</span>}
                  </label>
                  <Select value={mapping[f] ?? ''} onChange={(e) => setMapping({ ...mapping, [f]: e.target.value })}>
                    <option value="">— not mapped —</option>
                    {csv.headers.map((h) => <option key={h} value={h}>{h}</option>)}
                  </Select>
                </div>
              ))}
            </div>
          </Card>

          <Card className="mb-4">
            <CardHeader
              title="3 · Preview"
              subtitle="First 8 rows"
              action={dupWarnings > 0 ? <Badge tone="warning"><AlertTriangle className="h-3 w-3" /> {dupWarnings} possible duplicates</Badge> : undefined}
            />
            <Table>
              <thead><tr>{FIELDS[entity].map((f) => <Th key={f}>{f}</Th>)}</tr></thead>
              <tbody>
                {preview.map((r, i) => {
                  const dup = entity === 'customers' && findDuplicateCustomers({ name: r.name, phone: r.phone, email: r.email, whatsapp: r.whatsapp }, db.customers).length > 0;
                  return (
                    <tr key={i} className={cn(dup && 'bg-[var(--warning-soft)]')}>
                      {FIELDS[entity].map((f) => <Td key={f} className="text-[12.5px]">{r[f] || <span className="text-[var(--muted-2)]">—</span>}</Td>)}
                    </tr>
                  );
                })}
              </tbody>
            </Table>
            <div className="p-4">
              <Button variant="primary" onClick={runImport}><Upload className="h-3.5 w-3.5" /> Import {csv.rows.length} rows</Button>
              <p className="mt-2 text-[11.5px] text-[var(--muted)]">Duplicates are highlighted but not blocked — imported anyway with a warning, matching the app-wide duplicate policy.</p>
            </div>
          </Card>
        </>
      )}

      {report && (
        <Card>
          <CardHeader title="4 · Result report" />
          <div className="space-y-2 p-4 text-[13px]">
            <p className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4" style={{ color: 'var(--success)' }} /> {report.created} records created</p>
            <p className="flex items-center gap-2"><AlertTriangle className="h-4 w-4" style={{ color: 'var(--warning)' }} /> {report.skipped} rows skipped</p>
            {report.errors.map((e, i) => <p key={i} className="text-[12.5px]" style={{ color: 'var(--danger)' }}>{e}</p>)}
          </div>
        </Card>
      )}
    </>
  );
}
