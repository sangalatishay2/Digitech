'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { LogIn, Loader2, ShieldCheck, TriangleAlert } from 'lucide-react';
import { Button, Field, Input, Callout } from '@/components/ui/primitives';
import { getSupabaseClient, supabaseConfigured } from '@/lib/data/supabase-client';
import { resolveMode } from '@/lib/runtime/mode';

/**
 * Email + password sign-in.
 *
 * The session is established by Supabase and stored in cookies; middleware
 * only checks that one exists, while the real authorization boundary stays in
 * Postgres (RLS) and the service layer. Error text is deliberately generic —
 * distinguishing "no such user" from "wrong password" would let anyone
 * enumerate the customer's staff accounts.
 */
export default function LoginPage() {
  const router = useRouter();

  // Read ?next= from the URL directly rather than via useSearchParams, which
  // would force the entire page behind a Suspense boundary and leave an
  // unauthenticated visitor staring at a blank screen until JS hydrates.
  // The value is only used for the post-login redirect, never rendered, so
  // server ('/') and client values cannot cause a hydration mismatch.
  const [next] = useState(() =>
    typeof window === 'undefined'
      ? '/'
      : new URLSearchParams(window.location.search).get('next') || '/',
  );

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mode = resolveMode();
  const configured = supabaseConfigured();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const supabase = getSupabaseClient();
      if (!supabase) {
        setError('Authentication is not configured on this deployment.');
        return;
      }
      const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
      if (authError) {
        setError('Incorrect email or password.');
        return;
      }
      router.replace(next);
      router.refresh();
    } catch (err) {
      setError((err as Error).message || 'Sign-in failed. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen grid place-items-center px-4" style={{ background: 'var(--bg)' }}>
      <div className="w-full max-w-[400px] animate-in">
        <div className="flex items-center gap-2.5 mb-6">
          <div
            className="h-9 w-9 rounded-[10px] grid place-items-center"
            style={{ background: 'var(--accent)' }}
          >
            <ShieldCheck size={18} style={{ color: 'var(--accent-fg)' }} />
          </div>
          <div>
            <div className="font-semibold tracking-tight">DigiTech Business OS</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>
              Sign in to continue
            </div>
          </div>
        </div>

        <div className="card p-6">
          {!configured && (
            <Callout tone="warning" className="mb-4">
              <div className="flex gap-2">
                <TriangleAlert size={15} className="shrink-0 mt-0.5" />
                <div>
                  <div className="font-medium">Authentication is not configured</div>
                  <div className="text-xs mt-0.5">
                    Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY to enable
                    sign-in.
                  </div>
                </div>
              </div>
            </Callout>
          )}

          {mode.mode === 'demo' && (
            <Callout tone="info" className="mb-4">
              This deployment is running in <strong>demo mode</strong>. Data is stored in your
              browser only and no sign-in is required.
            </Callout>
          )}

          <form onSubmit={submit} className="space-y-3.5">
            <Field label="Email">
              <Input
                type="email"
                autoComplete="username"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
              />
            </Field>
            <Field label="Password">
              <Input
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
            </Field>

            {error && (
              <div
                className="text-xs rounded-[7px] px-2.5 py-2"
                style={{
                  background: 'var(--danger-soft)',
                  color: 'var(--danger)',
                  border: '1px solid var(--danger-border)',
                }}
              >
                {error}
              </div>
            )}

            <Button
              type="submit"
              variant="primary"
              className="w-full"
              disabled={busy || !configured}
            >
              {busy ? (
                <>
                  <Loader2 size={15} className="animate-spin" /> Signing in…
                </>
              ) : (
                <>
                  <LogIn size={15} /> Sign in
                </>
              )}
            </Button>
          </form>
        </div>

        <p className="text-[11px] text-center mt-4" style={{ color: 'var(--muted-2)' }}>
          Access is governed by your organization role. Disabled accounts cannot sign in.
        </p>
      </div>
    </div>
  );
}

