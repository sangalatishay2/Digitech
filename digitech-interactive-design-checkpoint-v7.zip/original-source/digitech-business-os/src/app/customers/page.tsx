'use client';

import { Suspense, useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useStore } from '@/lib/store';
import { DataTable, type Column } from '@/components/ui/data-table';
import { CustomerForm } from '@/components/forms/customer-form';
import {
  Badge, Button, Dropdown, IdentityCell, MenuItem, PageHeader, Select, StatusBadge,
} from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { customerStats } from '@/lib/services/analytics';
import { formatDate, formatINR } from '@/lib/utils';
import type { Customer } from '@/lib/types';
import { CUSTOMER_STATUS } from '@/lib/types';
import {
  Plus, Upload, Users, Crown, IndianRupee, AlertCircle, MoreHorizontal,
  Eye, ShoppingCart, MessageCircle,
} from 'lucide-react';
import Link from 'next/link';

function CustomersInner() {
  const { db, can } = useStore();
  const router = useRouter();
  const params = useSearchParams();
  const [open, setOpen] = useState(params.get('new') === '1');
  const [status, setStatus] = useState<string>('all');
  const [savedView, setSavedView] = useState<string>('all');

  const all = useMemo(() => db.customers.filter((c) => !c.deleted_at), [db.customers]);

  const rows = useMemo(() => {
    let list = all;
    if (status !== 'all') list = list.filter((c) => c.status === status);
    if (savedView === 'vip') list = list.filter((c) => c.status === 'vip');
    if (savedView === 'outstanding') list = list.filter((c) => customerStats(db, c.id).outstanding > 0);
    if (savedView === 'no_orders') list = list.filter((c) => customerStats(db, c.id).orders === 0);
    return list;
  }, [all, db, status, savedView]);

  const summary = useMemo(() => {
    let revenue = 0;
    let outstanding = 0;
    for (const c of all) {
      const s = customerStats(db, c.id);
      revenue += s.revenue;
      outstanding += s.outstanding;
    }
    return {
      total: all.length,
      active: all.filter((c) => c.status === 'active').length,
      vip: all.filter((c) => c.status === 'vip').length,
      revenue,
      outstanding,
    };
  }, [all, db]);

  const columns: Column<Customer>[] = [
    {
      key: 'name',
      header: 'Customer',
      sortValue: (c) => c.name,
      exportValue: (c) => c.name,
      render: (c) => (
        <IdentityCell
          name={c.name}
          secondary={`${c.customer_code}${c.company ? ` · ${c.company}` : ''}`}
          badge={c.status === 'vip' ? <Crown className="h-3 w-3 text-[var(--accent)]" /> : undefined}
        />
      ),
    },
    {
      key: 'contact',
      header: 'Contact',
      sortValue: (c) => c.phone ?? '',
      exportValue: (c) => `${c.phone ?? ''} ${c.email ?? ''}`,
      render: (c) => (
        <div className="min-w-0">
          <p className="truncate text-[12.5px] tabular-nums">{c.phone ?? '—'}</p>
          <p className="truncate text-[11.5px] text-[var(--muted-2)]">{c.email ?? '—'}</p>
        </div>
      ),
    },
    {
      key: 'city',
      header: 'City',
      sortValue: (c) => c.city ?? '',
      exportValue: (c) => c.city ?? '',
      render: (c) => <span className="text-[12.5px]">{c.city ?? '—'}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      sortValue: (c) => c.status,
      exportValue: (c) => c.status,
      render: (c) => <StatusBadge status={c.status} />,
    },
    {
      key: 'revenue',
      header: 'Lifetime Revenue',
      numeric: true,
      sortValue: (c) => customerStats(db, c.id).revenue,
      exportValue: (c) => customerStats(db, c.id).revenue,
      render: (c) => (
        <span className="font-semibold text-[var(--fg)]">{formatINR(customerStats(db, c.id).revenue)}</span>
      ),
    },
    {
      key: 'orders',
      header: 'Orders',
      numeric: true,
      sortValue: (c) => customerStats(db, c.id).orders,
      exportValue: (c) => customerStats(db, c.id).orders,
      render: (c) => <span>{customerStats(db, c.id).orders}</span>,
    },
    {
      key: 'outstanding',
      header: 'Outstanding',
      numeric: true,
      sortValue: (c) => customerStats(db, c.id).outstanding,
      exportValue: (c) => customerStats(db, c.id).outstanding,
      render: (c) => {
        const v = customerStats(db, c.id).outstanding;
        return v > 0 ? (
          <Badge tone="danger">{formatINR(v)}</Badge>
        ) : (
          <span className="text-[var(--muted-2)]">—</span>
        );
      },
    },
    {
      key: 'last',
      header: 'Last Purchase',
      sortValue: (c) => customerStats(db, c.id).lastPurchase ?? '',
      exportValue: (c) => customerStats(db, c.id).lastPurchase ?? '',
      render: (c) => (
        <span className="whitespace-nowrap text-[12.5px] text-[var(--muted)]">
          {formatDate(customerStats(db, c.id).lastPurchase)}
        </span>
      ),
      hidden: true,
    },
  ];

  return (
    <div className="space-y-5">
      <PageHeader
        title="Customers"
        description="Every customer, their lifetime value and what they owe you."
        actions={
          <>
            <Link href="/import-export">
              <Button variant="outline">
                <Upload className="h-3.5 w-3.5" /> Import
              </Button>
            </Link>
            {can('customers.create') || can('customers.*') ? (
              <Button variant="primary" onClick={() => setOpen(true)}>
                <Plus className="h-3.5 w-3.5" /> New Customer
              </Button>
            ) : null}
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <KpiCard label="Total Customers" value={summary.total} icon={Users} />
        <KpiCard label="Active" value={summary.active} icon={Users} tone="success" />
        <KpiCard label="VIP" value={summary.vip} icon={Crown} tone="accent" />
        <KpiCard
          label="Lifetime Revenue"
          value={formatINR(summary.revenue, { compact: true })}
          icon={IndianRupee}
          tone="accent"
        />
        <KpiCard
          label="Outstanding"
          value={formatINR(summary.outstanding, { compact: true })}
          icon={AlertCircle}
          tone={summary.outstanding > 0 ? 'danger' : 'neutral'}
        />
      </div>

      <DataTable
        rows={rows}
        columns={columns}
        exportName="customers"
        selectable
        onRowClick={(c) => router.push(`/customers/${c.id}`)}
        searchable={(c) => `${c.name} ${c.email} ${c.phone} ${c.whatsapp} ${c.customer_code} ${c.company}`}
        searchPlaceholder="Search by name, phone, email or code…"
        emptyTitle="No customers found"
        emptyMessage="Adjust your filters, or add your first customer."
        emptyIcon={Users}
        emptyAction={
          <Button variant="primary" size="sm" onClick={() => setOpen(true)}>
            <Plus className="h-3.5 w-3.5" /> New Customer
          </Button>
        }
        bulkActions={(sel) => (
          <>
            <Button size="xs" variant="outline">
              {sel.length} selected
            </Button>
            <Link href="/marketing/whatsapp">
              <Button size="xs" variant="outline">
                <MessageCircle className="h-3 w-3" /> WhatsApp
              </Button>
            </Link>
          </>
        )}
        rowActions={(c) => (
          <Dropdown
            width={170}
            trigger={
              <Button size="icon-sm" variant="ghost" aria-label="Row actions">
                <MoreHorizontal className="h-3.5 w-3.5" />
              </Button>
            }
          >
            {(close) => (
              <>
                <MenuItem icon={Eye} onClick={() => { close(); router.push(`/customers/${c.id}`); }}>
                  View profile
                </MenuItem>
                <MenuItem icon={ShoppingCart} onClick={() => { close(); router.push(`/orders/new?customer=${c.id}`); }}>
                  New order
                </MenuItem>
                {c.whatsapp && (
                  <MenuItem
                    icon={MessageCircle}
                    onClick={() => {
                      close();
                      window.open(`https://wa.me/${c.whatsapp!.replace(/\D/g, '')}`, '_blank');
                    }}
                  >
                    WhatsApp
                  </MenuItem>
                )}
              </>
            )}
          </Dropdown>
        )}
        toolbar={
          <>
            <Select
              value={savedView}
              onChange={(e) => setSavedView(e.target.value)}
              className="h-8 w-auto py-0 text-[12.5px]"
            >
              <option value="all">Saved view: All</option>
              <option value="vip">VIP customers</option>
              <option value="outstanding">With outstanding</option>
              <option value="no_orders">No orders yet</option>
            </Select>
            <Select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="h-8 w-auto py-0 text-[12.5px]"
            >
              <option value="all">All statuses</option>
              {CUSTOMER_STATUS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
          </>
        }
      />

      <CustomerForm open={open} onClose={() => setOpen(false)} onSaved={(c) => router.push(`/customers/${c.id}`)} />
    </div>
  );
}

export default function CustomersPage() {
  return (
    <Suspense fallback={null}>
      <CustomersInner />
    </Suspense>
  );
}
