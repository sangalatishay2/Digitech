'use client';

import { use, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/lib/store';
import {
  Avatar, Badge, Button, Card, CardHeader, ConfirmDialog, EmptyState, Field,
  StatusBadge, Table, Td, Textarea, Th, Tabs,
} from '@/components/ui/primitives';
import { CustomerForm } from '@/components/forms/customer-form';
import { customerStats } from '@/lib/services/analytics';
import { formatDate, formatDateTime, formatINR, relativeTime, daysUntil } from '@/lib/utils';
import { useToast } from '@/components/ui/toast';
import { newId, nowIso } from '@/lib/services/business';
import { buildCustomerNextActions } from '@/lib/services/productivity';
import {
  Archive, ArrowLeft, Mail, MessageCircle, Pencil, Phone, Plus, ShoppingCart,
  RefreshCw, CreditCard, FileText, LifeBuoy, CheckSquare, History as HistoryIcon,
  ArrowRight, Sparkles,
} from 'lucide-react';

export default function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const store = useStore();
  const { db, update, deleteCustomer } = store;
  const router = useRouter();
  const toast = useToast();
  const [tab, setTab] = useState('overview');
  const [edit, setEdit] = useState(false);
  const [archive, setArchive] = useState(false);
  const [note, setNote] = useState('');

  const customer = db.customers.find((c) => c.id === id);
  if (!customer) {
    return <EmptyState title="Customer not found" message="It may have been archived or removed." action={<Link href="/customers"><Button>Back to customers</Button></Link>} />;
  }

  const stats = customerStats(db, customer.id);
  const orders = db.orders.filter((o) => o.customer_id === customer.id).sort((a, b) => b.ordered_at.localeCompare(a.ordered_at));
  const subs = db.subscriptions.filter((s) => s.customer_id === customer.id);
  const payments = db.payments.filter((p) => p.customer_id === customer.id);
  const invoices = db.invoices.filter((i) => i.customer_id === customer.id);
  const tickets = db.support_tickets.filter((t) => t.customer_id === customer.id);
  const tasks = db.tasks.filter((t) => t.entity_type === 'customer' && t.entity_id === customer.id);
  const notes = db.customer_notes.filter((n) => n.customer_id === customer.id);
  const comms = db.communication_logs.filter((c) => c.customer_id === customer.id);
  const activity = db.activity_logs.filter((a) => a.record_id === customer.id || orders.some((o) => o.id === a.record_id));
  const nextActions = buildCustomerNextActions(db, customer.id, { can: store.can });

  const addNote = () => {
    if (!note.trim()) return;
    update((d) => {
      d.customer_notes.unshift({
        id: newId(),
        organization_id: d.organizations[0].id,
        created_at: nowIso(),
        updated_at: nowIso(),
        deleted_at: null,
        customer_id: customer.id,
        author_id: store.currentUser?.id ?? null,
        body: note.trim(),
      });
    });
    setNote('');
    toast({ title: 'Note added' });
  };

  const waLink = customer.whatsapp
    ? `https://wa.me/${customer.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(`Hi ${customer.name}, this is DigiTech.`)}`
    : null;

  return (
    <>
      <div className="mb-4">
        <Link
          href="/customers"
          className="inline-flex items-center gap-1 text-[12px] font-medium text-[var(--muted)] transition-colors hover:text-[var(--fg)]"
        >
          <ArrowLeft className="h-3 w-3" /> Customers
        </Link>
      </div>

      {/* Profile hero */}
      <Card className="mb-4 overflow-hidden">
        <div className="flex flex-wrap items-start gap-4 p-5">
          <Avatar name={customer.name} size={56} />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-[21px] font-semibold leading-tight tracking-[-0.02em]">{customer.name}</h1>
              <StatusBadge status={customer.status} />
              {customer.tags.map((t) => (
                <Badge key={t} tone="accent">{t}</Badge>
              ))}
            </div>
            <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-[12.5px] text-[var(--muted)]">
              <span className="font-medium text-[var(--fg-soft)]">{customer.customer_code}</span>
              {customer.phone && (
                <a href={`tel:${customer.phone}`} className="inline-flex items-center gap-1.5 tabular-nums hover:text-[var(--fg)]">
                  <Phone className="h-3 w-3 opacity-60" /> {customer.phone}
                </a>
              )}
              {customer.email && (
                <a href={`mailto:${customer.email}`} className="inline-flex items-center gap-1.5 hover:text-[var(--fg)]">
                  <Mail className="h-3 w-3 opacity-60" /> {customer.email}
                </a>
              )}
              {customer.city && <span>{customer.city}</span>}
              <span>Joined {formatDate(customer.created_at)}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {customer.phone && (
              <a href={`tel:${customer.phone}`}>
                <Button variant="outline" size="sm"><Phone className="h-3.5 w-3.5" /> Call</Button>
              </a>
            )}
            {waLink && (
              <a href={waLink} target="_blank" rel="noreferrer">
                <Button variant="outline" size="sm"><MessageCircle className="h-3.5 w-3.5" /> WhatsApp</Button>
              </a>
            )}
            <Button size="sm" onClick={() => setEdit(true)}><Pencil className="h-3.5 w-3.5" /> Edit</Button>
            <Link href={`/orders/new?customer=${customer.id}`}>
              <Button variant="primary" size="sm"><Plus className="h-3.5 w-3.5" /> New Order</Button>
            </Link>
            <Button variant="ghost" size="icon-sm" onClick={() => setArchive(true)} aria-label="Archive customer">
              <Archive className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>

        {/* Stats strip */}
        <div className="grid grid-cols-2 gap-px border-t border-[var(--border)] bg-[var(--border)] sm:grid-cols-3 lg:grid-cols-5">
          {([
            { label: 'Lifetime Revenue', value: formatINR(stats.revenue), tone: 'accent' },
            { label: 'Lifetime Profit', value: formatINR(stats.profit), tone: stats.profit >= 0 ? 'success' : 'danger' },
            { label: 'Orders', value: String(stats.orders), tone: 'neutral' },
            { label: 'Active Plans', value: String(stats.activePlans), tone: 'neutral' },
            { label: 'Outstanding', value: formatINR(stats.outstanding), tone: stats.outstanding > 0 ? 'danger' : 'neutral' },
          ] as { label: string; value: string; tone: string }[]).map((m) => (
            <div key={m.label} className="bg-[var(--surface)] px-4 py-3">
              <p className="truncate text-[11.5px] font-medium uppercase tracking-[0.04em] text-[var(--muted-2)]">
                {m.label}
              </p>
              <p
                className="mt-1 truncate text-[17px] font-semibold tabular-nums tracking-[-0.02em]"
                style={{
                  color:
                    m.tone === 'accent' ? 'var(--accent)'
                    : m.tone === 'success' ? 'var(--success)'
                    : m.tone === 'danger' ? 'var(--danger)'
                    : undefined,
                }}
              >
                {m.value}
              </p>
            </div>
          ))}
        </div>
      </Card>

      {nextActions.length > 0 && (
        <Card className="mb-4 overflow-hidden">
          <CardHeader
            title="Next best actions"
            subtitle="Prioritized from this customer's payments, renewals, support and follow-ups"
          />
          <div className="grid gap-px bg-[var(--border-subtle)] sm:grid-cols-2 xl:grid-cols-4">
            {nextActions.map((action) => {
              const color = action.severity === 'critical'
                ? 'var(--danger)'
                : action.severity === 'high'
                  ? 'var(--warning)'
                  : action.severity === 'medium'
                    ? 'var(--accent)'
                    : 'var(--muted)';
              return (
                <Link
                  key={action.id}
                  href={action.href}
                  className="group min-w-0 bg-[var(--surface)] p-4 transition-colors hover:bg-[var(--surface-2)] focus-visible:outline-none focus-visible:shadow-[var(--ring)]"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="flex h-8 w-8 items-center justify-center rounded-[9px]" style={{ color, background: `color-mix(in srgb, ${color} 11%, transparent)` }}>
                      <Sparkles className="h-3.5 w-3.5" />
                    </span>
                    <Badge tone={action.severity === 'critical' ? 'danger' : action.severity === 'high' ? 'warning' : action.severity === 'medium' ? 'accent' : 'neutral'}>
                      {action.severity}
                    </Badge>
                  </div>
                  <p className="mt-3 truncate text-[13px] font-semibold">{action.title}</p>
                  <p className="mt-1 line-clamp-2 min-h-8 text-[11.5px] leading-4 text-[var(--muted)]">{action.subtitle}</p>
                  <span className="mt-3 inline-flex items-center gap-1 text-[11.5px] font-semibold" style={{ color }}>
                    {action.actionLabel}
                    <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
                  </span>
                </Link>
              );
            })}
          </div>
        </Card>
      )}

      <div className="grid gap-4 lg:grid-cols-[300px_1fr]">
        <div className="space-y-4">
          <Card>
            <CardHeader title="Contact" />
            <div className="space-y-2 p-4 text-[12.5px]">
              <InfoRow icon={Phone} value={customer.phone ?? '—'} />
              <InfoRow icon={MessageCircle} value={customer.whatsapp ?? '—'} />
              <InfoRow icon={Mail} value={customer.email ?? '—'} />
              {customer.company && <p className="text-[var(--muted)]">Company: {customer.company}</p>}
              {customer.source && <p className="text-[var(--muted)]">Source: {customer.source}</p>}
            </div>
          </Card>

          <Card>
            <CardHeader title="Lifetime value" />
            <div className="space-y-2 p-4 text-[13px]">
              <Stat label="Lifetime Revenue" value={formatINR(stats.revenue)} />
              <Stat label="Lifetime Profit" value={formatINR(stats.profit)} />
              <Stat label="Total Orders" value={String(stats.orders)} />
              <Stat label="Average Order Value" value={formatINR(stats.aov)} />
              <Stat label="Outstanding" value={formatINR(stats.outstanding)} tone={stats.outstanding > 0 ? 'danger' : undefined} />
              <Stat label="Active Plans" value={String(stats.activePlans)} />
              <Stat label="Last Purchase" value={formatDate(stats.lastPurchase)} />
              <Stat label="Next Renewal" value={formatDate(stats.nextRenewal)} />
            </div>
          </Card>
        </div>

        <div className="min-w-0">
          <Card>
            <Tabs
              value={tab}
              onChange={setTab}
              tabs={[
                { id: 'overview', label: 'Overview' },
                { id: 'orders', label: 'Orders', count: orders.length },
                { id: 'subscriptions', label: 'Subscriptions', count: subs.length },
                { id: 'payments', label: 'Payments', count: payments.length },
                { id: 'invoices', label: 'Invoices', count: invoices.length },
                { id: 'support', label: 'Support', count: tickets.length },
                { id: 'tasks', label: 'Tasks', count: tasks.length },
                { id: 'notes', label: 'Notes', count: notes.length },
                { id: 'comms', label: 'Communication', count: comms.length },
                { id: 'activity', label: 'Activity' },
              ]}
              className="px-2"
            />

            <div className="p-4">
              {tab === 'overview' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                    <MiniStat label="Revenue" value={formatINR(stats.revenue, { compact: true })} />
                    <MiniStat label="Profit" value={formatINR(stats.profit, { compact: true })} />
                    <MiniStat label="Orders" value={String(stats.orders)} />
                    <MiniStat label="Active Plans" value={String(stats.activePlans)} />
                  </div>
                  <div>
                    <p className="mb-2 text-[12.5px] font-semibold text-[var(--muted)]">Recent orders</p>
                    {orders.length === 0 ? (
                      <EmptyState icon={ShoppingCart} title="No orders yet" />
                    ) : (
                      <ul className="divide-y divide-[var(--border)] rounded-[10px] border border-[var(--border)]">
                        {orders.slice(0, 5).map((o) => (
                          <li key={o.id} className="flex items-center gap-2 px-3 py-2 text-[13px]">
                            <Link href={`/orders/${o.id}`} className="font-medium text-[var(--accent)] hover:underline">{o.order_number}</Link>
                            <span className="truncate text-[12.5px] text-[var(--muted)]">{o.items.map((i) => i.product_name).join(', ')}</span>
                            <span className="ml-auto shrink-0 tabular-nums">{formatINR(o.total)}</span>
                            <StatusBadge status={o.status} />
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              )}

              {tab === 'orders' && (
                orders.length === 0 ? <EmptyState compact icon={ShoppingCart} title="No orders yet" message="This customer hasn't placed an order." /> : (
                  <Table>
                    <thead><tr><Th>Order</Th><Th>Items</Th><Th>Status</Th><Th>Payment</Th><Th className="text-right">Total</Th><Th>Date</Th></tr></thead>
                    <tbody>
                      {orders.map((o) => (
                        <tr key={o.id}>
                          <Td><Link href={`/orders/${o.id}`} className="text-[var(--accent)] hover:underline">{o.order_number}</Link></Td>
                          <Td className="max-w-[200px] truncate text-[12.5px]">{o.items.map((i) => i.product_name).join(', ')}</Td>
                          <Td><StatusBadge status={o.status} /></Td>
                          <Td><StatusBadge status={o.payment_status} /></Td>
                          <Td className="text-right tabular-nums">{formatINR(o.total)}</Td>
                          <Td className="text-[12.5px] text-[var(--muted)]">{formatDate(o.ordered_at)}</Td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                )
              )}

              {tab === 'subscriptions' && (
                subs.length === 0 ? <EmptyState compact icon={RefreshCw} title="No subscriptions" message="Subscriptions appear here once an activation is delivered." /> : (
                  <Table>
                    <thead><tr><Th>Product</Th><Th>Start</Th><Th>Expiry</Th><Th>Status</Th><Th className="text-right">Amount</Th></tr></thead>
                    <tbody>
                      {subs.map((s) => (
                        <tr key={s.id}>
                          <Td className="text-[12.5px]">{s.product_name}</Td>
                          <Td className="text-[12.5px]">{formatDate(s.start_date)}</Td>
                          <Td className="text-[12.5px]">{formatDate(s.expiry_date)} <span className="text-[var(--muted-2)]">({daysUntil(s.expiry_date)}d)</span></Td>
                          <Td><StatusBadge status={s.status} /></Td>
                          <Td className="text-right tabular-nums">{formatINR(s.purchase_amount)}</Td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                )
              )}

              {tab === 'payments' && (
                payments.length === 0 ? <EmptyState compact icon={CreditCard} title="No payments" message="Recorded payments will appear here." /> : (
                  <Table>
                    <thead><tr><Th>Date</Th><Th>Method</Th><Th>Reference</Th><Th className="text-right">Amount</Th></tr></thead>
                    <tbody>
                      {payments.map((p) => (
                        <tr key={p.id}>
                          <Td className="text-[12.5px]">{formatDate(p.paid_at)}</Td>
                          <Td className="text-[12.5px] capitalize">{p.method.replace('_', ' ')}</Td>
                          <Td className="text-[12.5px] text-[var(--muted)]">{p.reference ?? '—'}</Td>
                          <Td className={`text-right tabular-nums ${p.is_refund ? 'text-[var(--danger)]' : ''}`}>
                            {p.is_refund ? '-' : ''}{formatINR(p.amount)}
                          </Td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                )
              )}

              {tab === 'invoices' && (
                invoices.length === 0 ? <EmptyState compact icon={FileText} title="No invoices" message="Generate an invoice from any order." /> : (
                  <Table>
                    <thead><tr><Th>Invoice</Th><Th>Issued</Th><Th>Status</Th><Th className="text-right">Total</Th></tr></thead>
                    <tbody>
                      {invoices.map((i) => (
                        <tr key={i.id}>
                          <Td><Link href={`/invoices/${i.id}`} className="text-[var(--accent)] hover:underline">{i.invoice_number}</Link></Td>
                          <Td className="text-[12.5px]">{formatDate(i.issue_date)}</Td>
                          <Td><StatusBadge status={i.status} /></Td>
                          <Td className="text-right tabular-nums">{formatINR(i.total)}</Td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                )
              )}

              {tab === 'support' && (
                tickets.length === 0 ? <EmptyState compact icon={LifeBuoy} title="No support tickets" message="You're all caught up." /> : (
                  <ul className="divide-y divide-[var(--border)]">
                    {tickets.map((t) => (
                      <li key={t.id} className="flex items-center gap-2 py-2 text-[13px]">
                        <Link href={`/support/${t.id}`} className="text-[var(--accent)] hover:underline">{t.ticket_number}</Link>
                        <span className="flex-1 truncate">{t.subject}</span>
                        <StatusBadge status={t.status} />
                      </li>
                    ))}
                  </ul>
                )
              )}

              {tab === 'tasks' && (
                tasks.length === 0 ? <EmptyState compact icon={CheckSquare} title="No tasks" message="No follow-ups scheduled for this customer." /> : (
                  <ul className="divide-y divide-[var(--border)]">
                    {tasks.map((t) => (
                      <li key={t.id} className="flex items-center gap-2 py-2 text-[13px]">
                        <span className="flex-1 truncate">{t.title}</span>
                        <span className="text-[12.5px] text-[var(--muted)]">{formatDate(t.due_at)}</span>
                        <StatusBadge status={t.status} />
                      </li>
                    ))}
                  </ul>
                )
              )}

              {tab === 'notes' && (
                <div className="space-y-3">
                  <Field label="Add note">
                    <Textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Internal note about this customer…" />
                  </Field>
                  <Button variant="primary" onClick={addNote}>Add note</Button>
                  <ul className="divide-y divide-[var(--border)]">
                    {notes.map((n) => (
                      <li key={n.id} className="py-2">
                        <p className="text-[13px]">{n.body}</p>
                        <p className="mt-0.5 text-[11.5px] text-[var(--muted-2)]">{relativeTime(n.created_at)}</p>
                      </li>
                    ))}
                  </ul>
                  {customer.notes && <p className="rounded-md bg-[var(--surface-2)] p-2 text-[12.5px] text-[var(--muted)]">Profile note: {customer.notes}</p>}
                </div>
              )}

              {tab === 'comms' && (
                comms.length === 0 ? (
                  <EmptyState title="No messages logged" message="Messages sent from the WhatsApp console appear here." action={<Link href="/marketing/whatsapp"><Button>Open WhatsApp console</Button></Link>} />
                ) : (
                  <ul className="divide-y divide-[var(--border)]">
                    {comms.map((c) => (
                      <li key={c.id} className="py-2">
                        <div className="flex items-center gap-2">
                          <Badge tone="accent">{c.channel}</Badge>
                          <span className="text-[11.5px] text-[var(--muted-2)]">{formatDateTime(c.created_at)}</span>
                          <StatusBadge status={c.status} />
                        </div>
                        <p className="mt-1 text-[12.5px]">{c.body}</p>
                      </li>
                    ))}
                  </ul>
                )
              )}

              {tab === 'activity' && (
                activity.length === 0 ? <EmptyState compact icon={HistoryIcon} title="No activity" message="Changes to this customer will be logged here." /> : (
                  <ul className="divide-y divide-[var(--border)]">
                    {activity.slice(0, 40).map((a) => (
                      <li key={a.id} className="py-2">
                        <p className="text-[13px]">{a.summary}</p>
                        <p className="text-[11.5px] text-[var(--muted-2)]">{a.actor_name} · {relativeTime(a.created_at)}</p>
                      </li>
                    ))}
                  </ul>
                )
              )}
            </div>
          </Card>
        </div>
      </div>

      <CustomerForm open={edit} onClose={() => setEdit(false)} customer={customer} />
      <ConfirmDialog
        open={archive}
        onClose={() => setArchive(false)}
        onConfirm={() => {
          deleteCustomer(customer.id);
          toast({ title: 'Customer archived', tone: 'warning' });
          router.push('/customers');
        }}
        title="Archive customer?"
        message="This performs a soft delete. Orders and history are retained and the record can be restored from the database."
        confirmLabel="Archive"
        danger
      />
    </>
  );
}

function InfoRow({ icon: Icon, value }: { icon: React.ComponentType<{ className?: string }>; value: string }) {
  return (
    <p className="flex items-center gap-2 text-[var(--muted)]">
      <Icon className="h-3.5 w-3.5 shrink-0" />
      <span className="truncate">{value}</span>
    </p>
  );
}
function Stat({ label, value, tone }: { label: string; value: string; tone?: 'danger' }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[12.5px] text-[var(--muted)]">{label}</span>
      <span className="text-[13px] font-medium tabular-nums" style={tone === 'danger' ? { color: 'var(--danger)' } : undefined}>{value}</span>
    </div>
  );
}
function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] p-3">
      <p className="text-[11.5px] text-[var(--muted)]">{label}</p>
      <p className="mt-0.5 text-[16px] font-semibold tabular-nums">{value}</p>
    </div>
  );
}
