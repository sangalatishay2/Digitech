'use client';

import { Suspense, useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Avatar, Badge, Button, Card, EmptyState, Field, Input, Modal, Select, StatusBadge, Tabs, Textarea } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { formatDate, cn } from '@/lib/utils';
import { PRIORITY, TASK_STATUS, type Priority, type Task, type TaskEntity, type TaskStatus } from '@/lib/types';
import { CheckSquare, Plus } from 'lucide-react';

const ENTITIES: TaskEntity[] = ['general', 'customer', 'lead', 'order', 'subscription', 'supplier', 'ticket'];

function TasksInner() {
  const { db, createTask, updateTask, currentUser } = useStore();
  const toast = useToast();
  const params = useSearchParams();
  const [open, setOpen] = useState(params.get('new') === '1');
  const [tab, setTab] = useState('open');
  const [editing, setEditing] = useState<Task | null>(null);
  const [f, setF] = useState({ title: '', description: '', entity_type: 'general' as TaskEntity, entity_id: '', priority: 'medium' as Priority, status: 'open' as TaskStatus, assigned_to: currentUser?.id ?? '', due_at: '' });

  const overdue = (t: Task) => t.status !== 'done' && t.status !== 'cancelled' && t.due_at && new Date(t.due_at) < new Date();

  const rows = useMemo(() => {
    const list = [...db.tasks].sort((a, b) => (a.due_at ?? '').localeCompare(b.due_at ?? ''));
    if (tab === 'open') return list.filter((t) => t.status === 'open' || t.status === 'in_progress');
    if (tab === 'overdue') return list.filter(overdue);
    if (tab === 'mine') return list.filter((t) => t.assigned_to === currentUser?.id && t.status !== 'done');
    if (tab === 'all') return list;
    return list.filter((t) => t.status === tab);
  }, [db.tasks, tab, currentUser]);

  const openNew = () => {
    setEditing(null);
    setF({ title: '', description: '', entity_type: 'general', entity_id: '', priority: 'medium', status: 'open', assigned_to: currentUser?.id ?? '', due_at: '' });
    setOpen(true);
  };
  const openEdit = (t: Task) => {
    setEditing(t);
    setF({ title: t.title, description: t.description ?? '', entity_type: t.entity_type, entity_id: t.entity_id ?? '', priority: t.priority, status: t.status, assigned_to: t.assigned_to ?? '', due_at: t.due_at?.slice(0, 10) ?? '' });
    setOpen(true);
  };
  const submit = () => {
    if (!f.title.trim()) return;
    const payload: Partial<Task> = { ...f, entity_id: f.entity_id || null, assigned_to: f.assigned_to || null, due_at: f.due_at ? new Date(f.due_at).toISOString() : null };
    if (editing) { updateTask(editing.id, payload); toast({ title: 'Task updated' }); }
    else { createTask(payload); toast({ title: 'Task created' }); }
    setOpen(false);
  };

  const entityOptions = () => {
    switch (f.entity_type) {
      case 'customer': return db.customers.map((c) => [c.id, c.name] as const);
      case 'lead': return db.leads.map((l) => [l.id, l.name] as const);
      case 'order': return db.orders.slice(0, 100).map((o) => [o.id, o.order_number] as const);
      case 'subscription': return db.subscriptions.slice(0, 100).map((s) => [s.id, s.product_name] as const);
      case 'supplier': return db.suppliers.map((s) => [s.id, s.name] as const);
      case 'ticket': return db.support_tickets.map((t) => [t.id, t.ticket_number] as const);
      default: return [];
    }
  };

  return (
    <>
      <PageHeader title="Tasks" description={`${db.tasks.filter((t) => t.status !== 'done').length} open tasks`}
        actions={<Button variant="primary" onClick={openNew}><Plus className="h-3.5 w-3.5" /> New Task</Button>} />

      <Card className="mb-4">
        <Tabs value={tab} onChange={setTab} className="px-2" tabs={[
          { id: 'open', label: 'Open', count: db.tasks.filter((t) => ['open', 'in_progress'].includes(t.status)).length },
          { id: 'mine', label: 'Assigned to me', count: db.tasks.filter((t) => t.assigned_to === currentUser?.id && t.status !== 'done').length },
          { id: 'overdue', label: 'Overdue', count: db.tasks.filter(overdue).length },
          { id: 'done', label: 'Done', count: db.tasks.filter((t) => t.status === 'done').length },
          { id: 'all', label: 'All', count: db.tasks.length },
        ]} />
      </Card>

      {rows.length === 0 ? (
        <Card><EmptyState icon={CheckSquare} title="No tasks here" /></Card>
      ) : (
        <div className="space-y-2">
          {rows.map((t) => {
            const assignee = db.profiles.find((p) => p.id === t.assigned_to);
            return (
              <Card key={t.id} className={cn('flex flex-wrap items-center gap-3 p-3', overdue(t) && 'border-[var(--danger)]/40')}>
                <input
                  type="checkbox"
                  checked={t.status === 'done'}
                  onChange={(e) => { updateTask(t.id, { status: e.target.checked ? 'done' : 'open' }); toast({ title: e.target.checked ? 'Task completed' : 'Task reopened' }); }}
                  className="h-4 w-4 shrink-0 cursor-pointer"
                />
                <button onClick={() => openEdit(t)} className="min-w-[160px] flex-1 text-left">
                  <p className={cn('text-[13px] font-medium', t.status === 'done' && 'text-[var(--muted-2)] line-through')}>{t.title}</p>
                  <p className="text-[11.5px] capitalize text-[var(--muted)]">{t.entity_type}{t.description ? ` · ${t.description.slice(0, 50)}` : ''}</p>
                </button>
                <Badge tone={t.priority === 'urgent' ? 'danger' : t.priority === 'high' ? 'warning' : 'neutral'}>{t.priority}</Badge>
                <StatusBadge status={t.status} />
                <span className="text-[12.5px]" style={overdue(t) ? { color: 'var(--danger)' } : { color: 'var(--muted)' }}>{formatDate(t.due_at)}</span>
                {assignee && <Avatar name={assignee.full_name} size={24} />}
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit task' : 'New task'} width="lg"
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" onClick={submit}>{editing ? 'Save' : 'Create'}</Button></>}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Title *" className="sm:col-span-2"><Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
          <Field label="Description" className="sm:col-span-2"><Textarea rows={2} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
          <Field label="Attach to">
            <Select value={f.entity_type} onChange={(e) => setF({ ...f, entity_type: e.target.value as TaskEntity, entity_id: '' })}>
              {ENTITIES.map((e) => <option key={e} value={e}>{e}</option>)}
            </Select>
          </Field>
          <Field label="Record">
            <Select value={f.entity_id} onChange={(e) => setF({ ...f, entity_id: e.target.value })} disabled={f.entity_type === 'general'}>
              <option value="">{f.entity_type === 'general' ? 'N/A' : 'Select…'}</option>
              {entityOptions().map(([id, label]) => <option key={id} value={id}>{label}</option>)}
            </Select>
          </Field>
          <Field label="Priority"><Select value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value as Priority })}>{PRIORITY.map((p) => <option key={p} value={p}>{p}</option>)}</Select></Field>
          <Field label="Status"><Select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as TaskStatus })}>{TASK_STATUS.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</Select></Field>
          <Field label="Assignee">
            <Select value={f.assigned_to} onChange={(e) => setF({ ...f, assigned_to: e.target.value })}>
              <option value="">Unassigned</option>
              {db.profiles.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
            </Select>
          </Field>
          <Field label="Due date"><Input type="date" value={f.due_at} onChange={(e) => setF({ ...f, due_at: e.target.value })} /></Field>
        </div>
      </Modal>
    </>
  );
}

export default function TasksPage() {
  return <Suspense fallback={null}><TasksInner /></Suspense>;
}
