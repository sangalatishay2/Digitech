'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/lib/store';
import { KpiCard } from '@/components/kpi-card';
import {
  Badge, Card, CardHeader, EmptyState, PageHeader, StatusBadge,
  Table, Td, Th, Avatar, Progress, IdentityCell,
} from '@/components/ui/primitives';
import { RevenueAreaChart, RankedBars } from '@/components/charts';
import { TodayCommandCenter } from '@/components/today-command-center';
import {
  RANGE_OPTIONS, buildSeries, computeKpisWithTrend, resolveRange, topProducts, type RangeKey,
} from '@/lib/services/analytics';
import { roleFocus } from '@/lib/services/intelligence';
import { daysUntil, formatDate, formatINR, relativeTime, cn } from '@/lib/utils';
import {
  IndianRupee, PiggyBank, ShoppingCart, RefreshCw, CalendarClock,
  AlertCircle, Zap, LifeBuoy, CheckSquare, UserPlus, ArrowRight, ChevronRight,
  Activity as ActivityIcon, Sparkles, Target,
} from 'lucide-react';

export default function DashboardPage() {
  const { db, currentUser, can } = useStore();
  const router = useRouter();
  const [rangeKey, setRangeKey] = useState<RangeKey>('30d');
  const [custom, setCustom] = useState({ from: '', to: '' });

  const range = useMemo(() => resolveRange(rangeKey, custom), [rangeKey, custom]);
  const kpis = useMemo(() => computeKpisWithTrend(db, range), [db, range]);
  const series = useMemo(() => buildSeries(db, range), [db, range]);
  const products = useMemo(() => topProducts(db, range), [db, range]);

  const recentOrders = [...db.orders]
    .sort((a, b) => b.ordered_at.localeCompare(a.ordered_at))
    .slice(0, 6);

  const upcoming = db.subscriptions
    .filter((s) => s.status === 'expiring' || s.status === 'active')
    .sort((a, b) => a.expiry_date.localeCompare(b.expiry_date))
    .slice(0, 6);

  const now = new Date();
  const actions = [
    {
      label: 'Subscriptions expiring',
      context: 'Renewal window open',
      count: db.subscriptions.filter((s) => s.status === 'expiring').length,
      href: '/renewals',
      icon: CalendarClock,
      tone: 'warning' as const,
    },
    {
      label: 'Payments pending',
      context: 'Outstanding balance to collect',
      count: db.orders.filter((o) => o.outstanding > 0 && o.status !== 'cancelled').length,
      href: '/payments',
      icon: AlertCircle,
      tone: 'danger' as const,
    },
    {
      label: 'Activations pending',
      context: 'Waiting in operations queue',
      count: kpis.pendingActivations,
      href: '/activations',
      icon: Zap,
      tone: 'accent' as const,
    },
    {
      label: 'Support tickets open',
      context: 'Awaiting first response or fix',
      count: db.support_tickets.filter((t) => ['open', 'in_progress'].includes(t.status)).length,
      href: '/support',
      icon: LifeBuoy,
      tone: 'info' as const,
    },
    {
      label: 'Leads need follow-up',
      context: 'Follow-up date has passed',
      count: db.leads.filter(
        (l) => l.follow_up_at && new Date(l.follow_up_at) <= now && !['won', 'lost'].includes(l.status),
      ).length,
      href: '/leads',
      icon: UserPlus,
      tone: 'accent' as const,
    },
    {
      label: 'Tasks overdue',
      context: 'Past their due date',
      count: db.tasks.filter((t) => t.status !== 'done' && t.due_at && new Date(t.due_at) < now).length,
      href: '/tasks',
      icon: CheckSquare,
      tone: 'danger' as const,
    },
  ].filter((a) => a.count > 0);

  const todayOrders = db.orders.filter(
    (o) => new Date(o.ordered_at).toDateString() === now.toDateString(),
  );
  const todayRevenue = todayOrders.reduce((a, o) => a + o.total, 0);
  const expiringToday = db.subscriptions.filter((s) => daysUntil(s.expiry_date) === 0).length;
  const activations = db.activations.filter((a) =>
    ['ready', 'processing', 'waiting_supplier'].includes(a.status),
  ).length;

  // Renewal health
  const totalSubs = db.subscriptions.length || 1;
  const activeSubs = db.subscriptions.filter((s) => s.status === 'active').length;
  const expiringSubs = db.subscriptions.filter((s) => s.status === 'expiring').length;
  const expiredSubs = db.subscriptions.filter((s) => s.status === 'expired').length;
  const renewedSubs = db.subscriptions.filter((s) => s.status === 'renewed').length;

  const hour = now.getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const focusLinks = currentUser ? roleFocus(currentUser.role).filter((item) => can(item.permission)) : [];

  const toneVar = {
    warning: 'var(--warning)',
    danger: 'var(--danger)',
    accent: 'var(--accent)',
    info: 'var(--info)',
    success: 'var(--success)',
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title={`${greeting}, ${currentUser?.full_name.split(' ')[0] ?? 'there'}`}
        description={`Here's what's happening with ${db.organizations[0].name} today.`}
        actions={
          <div className="flex flex-wrap items-center gap-1.5">
            {RANGE_OPTIONS.filter((r) => r.key !== 'custom').map((r) => (
              <button
                key={r.key}
                onClick={() => setRangeKey(r.key)}
                className={cn(
                  'press rounded-[7px] border px-2.5 py-[5px] text-[12px] font-medium transition-colors',
                  rangeKey === r.key
                    ? 'border-[var(--accent-border)] bg-[var(--accent-soft)] text-[var(--accent)]'
                    : 'border-[var(--border)] bg-[var(--surface)] text-[var(--muted)] hover:bg-[var(--surface-2)] hover:text-[var(--fg)]',
                )}
              >
                {r.label}
              </button>
            ))}
          </div>
        }
      />

      {rangeKey === 'custom' && (
        <Card className="flex flex-wrap items-end gap-3 p-3">
          <label className="text-[12px] text-[var(--muted)]">
            From
            <input
              type="date"
              className="field mt-1"
              value={custom.from}
              onChange={(e) => setCustom((c) => ({ ...c, from: e.target.value }))}
            />
          </label>
          <label className="text-[12px] text-[var(--muted)]">
            To
            <input
              type="date"
              className="field mt-1"
              value={custom.to}
              onChange={(e) => setCustom((c) => ({ ...c, to: e.target.value }))}
            />
          </label>
        </Card>
      )}

      {/* Primary KPIs */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3 xl:grid-cols-6">
        <KpiCard
          label="Revenue"
          value={formatINR(kpis.revenue, { compact: true })}
          delta={kpis.delta.revenue}
          deltaLabel="vs prev"
          trend={kpis.trend.revenue}
          icon={IndianRupee}
          tone="accent"
          href="/finance/revenue"
        />
        <KpiCard
          label="Net Profit"
          value={formatINR(kpis.netProfit, { compact: true })}
          delta={kpis.delta.netProfit}
          deltaLabel="vs prev"
          trend={kpis.trend.profit}
          icon={PiggyBank}
          tone={kpis.netProfit >= 0 ? 'success' : 'danger'}
          href="/finance/profit"
        />
        <KpiCard
          label="Orders"
          value={kpis.orders}
          delta={kpis.delta.orders}
          deltaLabel="vs prev"
          trend={kpis.trend.orders}
          icon={ShoppingCart}
          tone="info"
          href="/orders"
        />
        <KpiCard
          label="Active Subscriptions"
          value={kpis.activeSubscriptions}
          sub={`${expiringSubs} expiring soon`}
          icon={RefreshCw}
          tone="success"
          href="/subscriptions"
        />
        <KpiCard
          label="Outstanding"
          value={formatINR(kpis.outstanding, { compact: true })}
          sub="to collect"
          icon={AlertCircle}
          tone="danger"
          href="/payments"
        />
        <KpiCard
          label="Renewals Due"
          value={kpis.renewalsDue}
          sub="within threshold"
          icon={CalendarClock}
          tone="warning"
          href="/renewals"
        />
      </div>

      <TodayCommandCenter />

      {focusLinks.length > 0 && (
        <Card id="role-focus">
          <CardHeader title={`${currentUser?.role.replace('_', ' ')} focus`} subtitle="Shortcuts matched to your role and permissions" />
          <div className="grid gap-2 p-3 sm:grid-cols-2 lg:grid-cols-3">
            {focusLinks.map((item) => (
              <Link key={item.href} href={item.href} className="group flex items-center gap-3 rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)]/50 px-3 py-3 transition-colors hover:border-[var(--accent-border)] hover:bg-[var(--accent-soft)]">
                <span className="grid h-8 w-8 place-items-center rounded-[8px] bg-[var(--surface)] text-[var(--accent)]"><Target className="h-4 w-4" /></span>
                <span className="min-w-0 flex-1 truncate text-[12.5px] font-semibold capitalize">{item.title}</span>
                <ChevronRight className="h-3.5 w-3.5 text-[var(--muted-2)] transition-transform group-hover:translate-x-0.5" />
              </Link>
            ))}
          </div>
        </Card>
      )}

      {/* Chart + Action Required */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader
            title="Revenue & Profit"
            subtitle={`${range.label} · ${formatINR(kpis.revenue)} revenue · ${kpis.grossMargin}% gross margin`}
            action={
              <Link
                href="/analytics"
                className="inline-flex items-center gap-1 text-[12px] font-medium text-[var(--accent)] hover:underline"
              >
                Analytics <ArrowRight className="h-3 w-3" />
              </Link>
            }
          />
          <div className="p-3 pt-4">
            <RevenueAreaChart
              data={series as unknown as Record<string, string | number>[]}
              keys={[
                { key: 'revenue', label: 'Revenue', color: 'var(--chart-1)' },
                { key: 'profit', label: 'Profit', color: 'var(--chart-2)' },
              ]}
              height={272}
            />
          </div>
        </Card>

        <Card>
          <CardHeader
            title="Action Required"
            subtitle={actions.length ? `${actions.length} area${actions.length > 1 ? 's' : ''} need attention` : 'Everything is handled'}
          />
          {actions.length === 0 ? (
            <EmptyState
              icon={Sparkles}
              title="You're all caught up."
              message="No pending renewals, payments, activations or tickets right now."
            />
          ) : (
            <div className="divide-y divide-[var(--border-subtle)]">
              {actions.map((a) => (
                <Link
                  key={a.href}
                  href={a.href}
                  className="group flex items-center gap-3 px-4 py-[11px] transition-colors hover:bg-[var(--surface-2)]"
                >
                  <span
                    className="flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-[8px]"
                    style={{ background: `color-mix(in srgb, ${toneVar[a.tone]} 12%, transparent)` }}
                  >
                    <a.icon className="h-[15px] w-[15px]" style={{ color: toneVar[a.tone] }} strokeWidth={2} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-medium leading-tight">{a.label}</p>
                    <p className="mt-0.5 truncate text-[11.5px] leading-tight text-[var(--muted-2)]">
                      {a.context}
                    </p>
                  </div>
                  <span className="shrink-0 text-[15px] font-semibold tabular-nums" style={{ color: toneVar[a.tone] }}>
                    {a.count}
                  </span>
                  <ChevronRight className="h-3.5 w-3.5 shrink-0 text-[var(--muted-2)] transition-transform group-hover:translate-x-0.5" />
                </Link>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Recent orders + Today's brief */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader
            title="Recent Orders"
            subtitle="Latest activity across the pipeline"
            action={
              <Link
                href="/orders"
                className="inline-flex items-center gap-1 text-[12px] font-medium text-[var(--accent)] hover:underline"
              >
                View all <ArrowRight className="h-3 w-3" />
              </Link>
            }
          />
          {recentOrders.length === 0 ? (
            <EmptyState icon={ShoppingCart} title="No orders yet" message="Create your first order to get started." compact />
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th>Customer</Th>
                  <Th>Order</Th>
                  <Th align="right">Amount</Th>
                  <Th>Status</Th>
                  <Th>Date</Th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((o) => {
                  const c = db.customers.find((x) => x.id === o.customer_id);
                  return (
                    <tr
                      key={o.id}
                      className="row-hover cursor-pointer"
                      onClick={() => router.push(`/orders/${o.id}`)}
                    >
                      <Td>
                        <IdentityCell
                          name={c?.name ?? 'Unknown'}
                          secondary={c?.customer_code}
                          size={26}
                        />
                      </Td>
                      <Td className="font-medium text-[var(--fg)]">{o.order_number}</Td>
                      <Td align="right" num className="font-semibold text-[var(--fg)]">
                        {formatINR(o.total)}
                      </Td>
                      <Td>
                        <StatusBadge status={o.status} />
                      </Td>
                      <Td className="whitespace-nowrap text-[12px] text-[var(--muted)]">
                        {formatDate(o.ordered_at)}
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          )}
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader title="Today's Brief" subtitle={formatDate(now.toISOString())} />
            <div className="space-y-0.5 p-4 pt-3">
              <BriefRow label="Orders today" value={String(todayOrders.length)} />
              <BriefRow label="Revenue today" value={formatINR(todayRevenue)} accent />
              <BriefRow label="Expiring today" value={String(expiringToday)} tone={expiringToday ? 'warning' : undefined} />
              <BriefRow label="Activations queued" value={String(activations)} />
              <BriefRow
                label="Outstanding"
                value={formatINR(kpis.outstanding, { compact: true })}
                tone={kpis.outstanding > 0 ? 'danger' : undefined}
              />
            </div>
          </Card>

          <Card>
            <CardHeader title="Renewal Health" subtitle={`${db.subscriptions.length} subscriptions tracked`} />
            <div className="space-y-3 p-4">
              {[
                { label: 'Active', value: activeSubs, tone: 'success' as const },
                { label: 'Expiring soon', value: expiringSubs, tone: 'warning' as const },
                { label: 'Expired', value: expiredSubs, tone: 'danger' as const },
                { label: 'Renewed', value: renewedSubs, tone: 'accent' as const },
              ].map((s) => (
                <div key={s.label}>
                  <div className="mb-1 flex items-baseline justify-between">
                    <span className="text-[12.5px] text-[var(--muted)]">{s.label}</span>
                    <span className="text-[12.5px] font-semibold tabular-nums">{s.value}</span>
                  </div>
                  <Progress value={(s.value / totalSubs) * 100} tone={s.tone} size="sm" />
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Renewals + Top products + Activity */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2 xl:grid-cols-3">
        <Card>
          <CardHeader
            title="Upcoming Renewals"
            action={
              <Link href="/renewals" className="text-[12px] font-medium text-[var(--accent)] hover:underline">
                Renewal Center
              </Link>
            }
          />
          {upcoming.length === 0 ? (
            <EmptyState icon={CalendarClock} title="No subscriptions expire this week." message="You're all caught up." compact />
          ) : (
            <div className="divide-y divide-[var(--border-subtle)]">
              {upcoming.map((s) => {
                const c = db.customers.find((x) => x.id === s.customer_id);
                const p = db.products.find((x) => x.id === s.product_id);
                const d = daysUntil(s.expiry_date);
                const tone = d < 0 ? 'danger' : d <= 3 ? 'danger' : d <= 7 ? 'warning' : 'neutral';
                return (
                  <div key={s.id} className="flex items-center gap-2.5 px-4 py-2.5">
                    <Avatar name={c?.name ?? '?'} size={26} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12.5px] font-medium leading-tight">{c?.name}</p>
                      <p className="truncate text-[11.5px] leading-tight text-[var(--muted-2)]">{p?.name}</p>
                    </div>
                    <Badge tone={tone}>{d < 0 ? `${Math.abs(d)}d ago` : d === 0 ? 'Today' : `${d}d`}</Badge>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        <Card>
          <CardHeader
            title="Top Products"
            subtitle={range.label}
            action={
              <Link href="/products" className="text-[12px] font-medium text-[var(--accent)] hover:underline">
                All products
              </Link>
            }
          />
          <div className="p-4">
            <RankedBars
              items={products.map((p) => ({
                label: p.name,
                value: p.revenue,
                secondary: `${p.units}u`,
              }))}
              emptyLabel="No sales in this period."
            />
          </div>
        </Card>

        <Card className="lg:col-span-2 xl:col-span-1">
          <CardHeader
            title="Recent Activity"
            action={
              <Link href="/activity" className="text-[12px] font-medium text-[var(--accent)] hover:underline">
                View log
              </Link>
            }
          />
          {db.activity_logs.length === 0 ? (
            <EmptyState icon={ActivityIcon} title="No activity yet" compact />
          ) : (
            <div className="max-h-[290px] space-y-3 overflow-y-auto p-4">
              {db.activity_logs.slice(0, 9).map((a) => (
                <div key={a.id} className="flex gap-2.5">
                  <div className="relative flex flex-col items-center">
                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--accent)]" />
                    <span className="mt-1 w-px flex-1 bg-[var(--border)]" />
                  </div>
                  <div className="min-w-0 flex-1 pb-0.5">
                    <p className="text-[12.5px] leading-snug text-[var(--fg-soft)]">{a.summary}</p>
                    <p className="mt-0.5 text-[11.5px] text-[var(--muted-2)]">
                      {a.actor_name} · {relativeTime(a.created_at)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function BriefRow({
  label,
  value,
  accent,
  tone,
}: {
  label: string;
  value: string;
  accent?: boolean;
  tone?: 'warning' | 'danger';
}) {
  const color = tone === 'danger' ? 'var(--danger)' : tone === 'warning' ? 'var(--warning)' : accent ? 'var(--accent)' : undefined;
  return (
    <div className="flex items-baseline justify-between gap-3 py-[6px]">
      <span className="text-[12.5px] text-[var(--muted)]">{label}</span>
      <span className="text-[13.5px] font-semibold tabular-nums" style={{ color }}>
        {value}
      </span>
    </div>
  );
}
