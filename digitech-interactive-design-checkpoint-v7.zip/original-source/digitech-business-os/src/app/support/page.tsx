'use client';

import { Suspense, useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { DataTable, type Column } from '@/components/ui/data-table';
import { Badge, Button, Field, Input, Modal, Select, StatusBadge, Textarea } from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { useToast } from '@/components/ui/toast';
import { formatDate, relativeTime } from '@/lib/utils';
import { PRIORITY, SUPPORT_STATUS, type Priority, type SupportTicket } from '@/lib/types';
import { LifeBuoy, Plus, Clock, CheckCircle2, AlertTriangle } from 'lucide-react';

const CATEGORIES = ['Activation', 'Billing', 'Technical', 'Renewal', 'Refund', 'General'];

function SupportInner() {
  const { db, createTicket, currentUser } = useStore();
  const router = useRouter();
  const toast = useToast();
  const params = useSearchParams();
  const [open, setOpen] = useState(params.get('new') === '1');
  const [status, setStatus] = useState('all');
  const [f, setF] = useState({ customer_id: '', order_id: '', product_id: '', category: 'General', subject: '', description: '', priority: 'medium' as Priority, assigned_to: currentUser?.id ?? '' });

  const rows = useMemo(() => {
    let list = [...db.support_tickets].sort((a, b) => b.created_at.localeCompare(a.created_at));
    if (status !== 'all') list = list.filter((t) => t.status === status);
    return list;
  }, [db.support_tickets, status]);

  const isOverdue = (t: SupportTicket) => !['resolved', 'closed'].includes(t.status) && t.due_at && new Date(t.due_at) < new Date();
  const resolved = db.support_tickets.filter((t) => t.resolved_at);
  const avgResolutionHrs = resolved.length
    ? Math.round(resolved.reduce((a, t) => a + (new Date(t.resolved_at!).getTime() - new Date(t.created_at).getTime()) / 3600000, 0) / resolved.length)
    : 0;

  const columns: Column<SupportTicket>[] = [
    { key: 'num', header: 'Ticket', sortValue: (t) => t.ticket_number, exportValue: (t) => t.ticket_number, render: (t) => <span className="font-medium text-[var(--accent)]">{t.ticket_number}</span> },
    { key: 'subject', header: 'Subject', sortValue: (t) => t.subject, exportValue: (t) => t.subject, render: (t) => <div><p className="truncate text-[13px]">{t.subject}</p><p className="text-[11.5px] text-[var(--muted)]">{t.category}</p></div> },
    { key: 'customer', header: 'Customer', sortValue: (t) => db.customers.find((c) => c.id === t.customer_id)?.name ?? '', exportValue: (t) => db.customers.find((c) => c.id === t.customer_id)?.name ?? '', render: (t) => <span className="truncate text-[13px]">{db.customers.find((c) => c.id === t.customer_id)?.name ?? '—'}</span> },
    { key: 'priority', header: 'Priority', sortValue: (t) => t.priority, exportValue: (t) => t.priority, render: (t) => <Badge tone={t.priority === 'urgent' ? 'danger' : t.priority === 'high' ? 'warning' : 'neutral'}>{t.priority}</Badge> },
    { key: 'status', header: 'Status', sortValue: (t) => t.status, exportValue: (t) => t.status, render: (t) => <StatusBadge status={t.status} /> },
    { key: 'sla', header: 'SLA', exportValue: (t) => (isOverdue(t) ? 'overdue' : 'ok'), render: (t) => isOverdue(t) ? <Badge tone="danger">overdue</Badge> : <span className="text-[12.5px] text-[var(--muted-2)]">{formatDate(t.due_at)}</span> },
    { key: 'created', header: 'Created', sortValue: (t) => t.created_at, exportValue: (t) => t.created_at, render: (t) => <span className="whitespace-nowrap text-[12.5px] text-[var(--muted)]">{relativeTime(t.created_at)}</span> },
  ];

  const submit = () => {
    if (!f.customer_id || !f.subject.trim()) { toast({ title: 'Customer and subject required', tone: 'error' }); return; }
    const t = createTicket({ ...f, order_id: f.order_id || null, product_id: f.product_id || null, assigned_to: f.assigned_to || null });
    toast({ title: `Ticket ${t.ticket_number} created` });
    setOpen(false);
    router.push(`/support/${t.id}`);
  };

  return (
    <>
      <PageHeader title="Support" description={`${db.support_tickets.length} tickets`}
        actions={<Button variant="primary" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5" /> New Ticket</Button>} />

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiCard label="Open" value={db.support_tickets.filter((t) => t.status === 'open').length} icon={LifeBuoy} tone="warning" />
        <KpiCard label="In progress" value={db.support_tickets.filter((t) => t.status === 'in_progress').length} icon={Clock} />
        <KpiCard label="Overdue (SLA)" value={db.support_tickets.filter(isOverdue).length} icon={AlertTriangle} tone="danger" />
        <KpiCard label="Avg resolution" value={`${avgResolutionHrs}h`} icon={CheckCircle2} tone="success" />
      </div>

      <DataTable
        rows={rows} columns={columns} exportName="support-tickets"
        onRowClick={(t) => router.push(`/support/${t.id}`)}
        searchable={(t) => `${t.ticket_number} ${t.subject} ${t.category} ${db.customers.find((c) => c.id === t.customer_id)?.name}`}
        toolbar={
          <Select value={status} onChange={(e) => setStatus(e.target.value)} className="h-8 w-auto py-0 text-[12.5px]">
            <option value="all">All statuses</option>
            {SUPPORT_STATUS.map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
          </Select>
        }
      />

      <Modal open={open} onClose={() => setOpen(false)} title="New support ticket" width="lg"
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" onClick={submit}>Create ticket</Button></>}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Customer *" className="sm:col-span-2">
            <Select value={f.customer_id} onChange={(e) => setF({ ...f, customer_id: e.target.value })}>
              <option value="">Select customer…</option>
              {db.customers.filter((c) => !c.deleted_at).map((c) => <option key={c.id} value={c.id}>{c.name} — {c.customer_code}</option>)}
            </Select>
          </Field>
          <Field label="Related order">
            <Select value={f.order_id} onChange={(e) => setF({ ...f, order_id: e.target.value })}>
              <option value="">None</option>
              {db.orders.filter((o) => !f.customer_id || o.customer_id === f.customer_id).slice(0, 60).map((o) => <option key={o.id} value={o.id}>{o.order_number}</option>)}
            </Select>
          </Field>
          <Field label="Product">
            <Select value={f.product_id} onChange={(e) => setF({ ...f, product_id: e.target.value })}>
              <option value="">None</option>
              {db.products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </Field>
          <Field label="Category"><Select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}</Select></Field>
          <Field label="Priority"><Select value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value as Priority })}>{PRIORITY.map((p) => <option key={p} value={p}>{p}</option>)}</Select></Field>
          <Field label="Subject *" className="sm:col-span-2"><Input value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value })} /></Field>
          <Field label="Description" className="sm:col-span-2"><Textarea rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
          <Field label="Assign to" className="sm:col-span-2">
            <Select value={f.assigned_to} onChange={(e) => setF({ ...f, assigned_to: e.target.value })}>
              <option value="">Unassigned</option>
              {db.profiles.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
            </Select>
          </Field>
        </div>
      </Modal>
    </>
  );
}

export default function SupportPage() {
  return <Suspense fallback={null}><SupportInner /></Suspense>;
}
