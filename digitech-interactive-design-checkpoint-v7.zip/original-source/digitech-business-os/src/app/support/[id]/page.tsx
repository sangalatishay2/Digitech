'use client';

import { use, useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Avatar, Badge, Button, Card, CardHeader, EmptyState, Field, Select, Textarea, StatusBadge } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { newId, nowIso } from '@/lib/services/business';
import { formatDateTime, relativeTime } from '@/lib/utils';
import { PRIORITY, SUPPORT_STATUS, type Priority, type SupportStatus } from '@/lib/types';
import { ArrowLeft, Send } from 'lucide-react';

export default function TicketDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const store = useStore();
  const { db, updateTicket, update } = store;
  const toast = useToast();
  const [msg, setMsg] = useState('');

  const ticket = db.support_tickets.find((t) => t.id === id);
  if (!ticket) return <EmptyState title="Ticket not found" action={<Link href="/support"><Button>Back</Button></Link>} />;

  const customer = db.customers.find((c) => c.id === ticket.customer_id);
  const order = db.orders.find((o) => o.id === ticket.order_id);
  const messages = db.ticket_messages.filter((m) => m.ticket_id === ticket.id).sort((a, b) => a.created_at.localeCompare(b.created_at));

  const send = () => {
    if (!msg.trim()) return;
    update((d) => {
      d.ticket_messages.push({
        id: newId(),
        organization_id: d.organizations[0].id,
        created_at: nowIso(),
        updated_at: nowIso(),
        deleted_at: null,
        ticket_id: ticket.id,
        author_id: store.currentUser?.id ?? null,
        author_type: 'agent',
        body: msg.trim(),
      });
      const t = d.support_tickets.find((x) => x.id === ticket.id);
      if (t && !t.first_response_at) t.first_response_at = nowIso();
    });
    setMsg('');
    toast({ title: 'Reply added' });
  };

  const firstResponseMins = ticket.first_response_at
    ? Math.round((new Date(ticket.first_response_at).getTime() - new Date(ticket.created_at).getTime()) / 60000)
    : null;
  const resolutionHrs = ticket.resolved_at
    ? Math.round((new Date(ticket.resolved_at).getTime() - new Date(ticket.created_at).getTime()) / 3600000)
    : null;
  const overdue = !['resolved', 'closed'].includes(ticket.status) && ticket.due_at && new Date(ticket.due_at) < new Date();

  return (
    <>
      <div className="mb-3"><Link href="/support" className="inline-flex items-center gap-1 text-[12.5px] text-[var(--muted)] hover:text-[var(--fg)]"><ArrowLeft className="h-3 w-3" /> Support</Link></div>
      <PageHeader title={ticket.subject} description={`${ticket.ticket_number} · ${ticket.category} · opened ${relativeTime(ticket.created_at)}`} />

      <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
        <div className="space-y-4">
          <Card>
            <CardHeader title="Conversation" />
            <div className="space-y-3 p-4">
              <div className="rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] p-3">
                <p className="text-[11.5px] font-semibold text-[var(--muted)]">{customer?.name ?? 'Customer'} · {formatDateTime(ticket.created_at)}</p>
                <p className="mt-1 text-[13px]">{ticket.description}</p>
              </div>
              {messages.map((m) => {
                const author = db.profiles.find((p) => p.id === m.author_id);
                const agent = m.author_type === 'agent';
                return (
                  <div key={m.id} className={`rounded-[10px] border p-3 ${agent ? 'border-[var(--accent)]/30 bg-[var(--accent-soft)]/40' : 'border-[var(--border)] bg-[var(--surface-2)]'}`}>
                    <p className="text-[11.5px] font-semibold text-[var(--muted)]">
                      {agent ? author?.full_name ?? 'Agent' : customer?.name ?? 'Customer'} · {formatDateTime(m.created_at)}
                    </p>
                    <p className="mt-1 text-[13px]">{m.body}</p>
                  </div>
                );
              })}
              <Field label="Reply">
                <Textarea rows={3} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Type your response…" />
              </Field>
              <Button variant="primary" onClick={send}><Send className="h-3.5 w-3.5" /> Send reply</Button>
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader title="Ticket" />
            <div className="space-y-3 p-4">
              <Field label="Status">
                <Select value={ticket.status} onChange={(e) => { updateTicket(ticket.id, { status: e.target.value as SupportStatus }); toast({ title: `Status → ${e.target.value.replace(/_/g, ' ')}` }); }}>
                  {SUPPORT_STATUS.map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
                </Select>
              </Field>
              <Field label="Priority">
                <Select value={ticket.priority} onChange={(e) => updateTicket(ticket.id, { priority: e.target.value as Priority })}>
                  {PRIORITY.map((p) => <option key={p} value={p}>{p}</option>)}
                </Select>
              </Field>
              <Field label="Assignee">
                <Select value={ticket.assigned_to ?? ''} onChange={(e) => updateTicket(ticket.id, { assigned_to: e.target.value || null })}>
                  <option value="">Unassigned</option>
                  {db.profiles.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
                </Select>
              </Field>
              {overdue && <Badge tone="danger">SLA overdue</Badge>}
            </div>
          </Card>

          <Card>
            <CardHeader title="Metrics" />
            <div className="space-y-2 p-4 text-[13px]">
              <Row label="First response" value={firstResponseMins !== null ? `${firstResponseMins} min` : 'pending'} />
              <Row label="Resolution time" value={resolutionHrs !== null ? `${resolutionHrs} h` : '—'} />
              <Row label="Due" value={ticket.due_at ? formatDateTime(ticket.due_at) : '—'} />
              <Row label="Status" value={ticket.status.replace(/_/g, ' ')} />
            </div>
          </Card>

          <Card>
            <CardHeader title="Context" />
            <div className="space-y-2 p-4">
              {customer && (
                <Link href={`/customers/${customer.id}`} className="flex items-center gap-2 hover:opacity-80">
                  <Avatar name={customer.name} size={30} />
                  <div className="min-w-0"><p className="truncate text-[13px] font-medium">{customer.name}</p><p className="truncate text-[11.5px] text-[var(--muted)]">{customer.phone}</p></div>
                </Link>
              )}
              {order && <p className="text-[12.5px]">Order: <Link href={`/orders/${order.id}`} className="text-[var(--accent)] hover:underline">{order.order_number}</Link></p>}
              <StatusBadge status={ticket.status} />
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between gap-2"><span className="text-[12.5px] text-[var(--muted)]">{label}</span><span className="text-[13px] capitalize">{value}</span></div>;
}
