import { sessionFromRequest, sessionErrorResponse } from '@/lib/auth/server-session';
import { getServiceClient } from '@/lib/data/supabase-client';

type Provider = 'openrouter' | 'google';
type InputMessage = { role: 'user' | 'assistant'; content: string };

interface ChatBody {
  provider?: unknown;
  model?: unknown;
  messages?: unknown;
  system?: unknown;
  temperature?: unknown;
  max_output_tokens?: unknown;
}

const MODEL_ID = /^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,159}$/;
const MAX_MESSAGES = 40;
const MAX_TOTAL_CHARS = 32_000;

function json(payload: unknown, status: number): Response {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

export function providerConfigured(provider: Provider): boolean {
  return provider === 'openrouter'
    ? Boolean(process.env.OPENROUTER_API_KEY)
    : Boolean(process.env.GOOGLE_GENERATIVE_AI_API_KEY);
}

function defaultModel(provider: Provider): string {
  return provider === 'openrouter'
    ? process.env.OPENROUTER_DEFAULT_MODEL || 'nvidia/nemotron-3-nano-30b-a3b'
    : process.env.GOOGLE_AI_DEFAULT_MODEL || 'gemini-2.5-flash';
}

export function parseChatBody(raw: ChatBody):
  | {
      ok: true;
      value: {
        provider: Provider;
        model: string;
        messages: InputMessage[];
        system: string;
        temperature: number;
        maxOutputTokens: number;
      };
    }
  | { ok: false; error: string } {
  const provider = raw.provider === 'google' ? 'google' : raw.provider === 'openrouter' ? 'openrouter' : null;
  if (!provider) return { ok: false, error: 'Provider must be openrouter or google.' };

  const model = typeof raw.model === 'string' && raw.model.trim() ? raw.model.trim() : defaultModel(provider);
  if (!MODEL_ID.test(model)) return { ok: false, error: 'Invalid model identifier.' };
  if (!Array.isArray(raw.messages) || raw.messages.length === 0 || raw.messages.length > MAX_MESSAGES) {
    return { ok: false, error: `Messages must contain between 1 and ${MAX_MESSAGES} items.` };
  }

  const messages: InputMessage[] = [];
  for (const item of raw.messages) {
    if (!item || typeof item !== 'object') return { ok: false, error: 'Invalid message.' };
    const candidate = item as Record<string, unknown>;
    if (candidate.role !== 'user' && candidate.role !== 'assistant') {
      return { ok: false, error: 'Message role must be user or assistant.' };
    }
    if (typeof candidate.content !== 'string' || !candidate.content.trim()) {
      return { ok: false, error: 'Message content is required.' };
    }
    messages.push({ role: candidate.role, content: candidate.content.trim() });
  }

  const system = typeof raw.system === 'string' ? raw.system.trim() : '';
  const totalChars = system.length + messages.reduce((sum, message) => sum + message.content.length, 0);
  if (totalChars > MAX_TOTAL_CHARS) return { ok: false, error: 'Conversation is too large.' };

  const temperature = typeof raw.temperature === 'number' ? raw.temperature : 0.5;
  if (!Number.isFinite(temperature) || temperature < 0 || temperature > 2) {
    return { ok: false, error: 'Temperature must be between 0 and 2.' };
  }
  const maxOutputTokens = typeof raw.max_output_tokens === 'number' ? raw.max_output_tokens : 1200;
  if (!Number.isInteger(maxOutputTokens) || maxOutputTokens < 64 || maxOutputTokens > 4096) {
    return { ok: false, error: 'max_output_tokens must be an integer between 64 and 4096.' };
  }

  return { ok: true, value: { provider, model, messages, system, temperature, maxOutputTokens } };
}

export async function GET(req: Request) {
  const outcome = await sessionFromRequest(req);
  if (!outcome.ok) return sessionErrorResponse(outcome);
  return json(
    {
      providers: {
        openrouter: {
          configured: providerConfigured('openrouter'),
          defaultModel: defaultModel('openrouter'),
          customModels: true,
        },
        google: {
          configured: providerConfigured('google'),
          defaultModel: defaultModel('google'),
          customModels: true,
        },
      },
    },
    200,
  );
}

async function callOpenRouter(input: Extract<ReturnType<typeof parseChatBody>, { ok: true }>['value']) {
  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
      'Content-Type': 'application/json',
      ...(process.env.AI_APP_URL ? { 'HTTP-Referer': process.env.AI_APP_URL } : {}),
      'X-Title': 'DigiTech Business OS',
    },
    body: JSON.stringify({
      model: input.model,
      messages: [
        ...(input.system ? [{ role: 'system', content: input.system }] : []),
        ...input.messages,
      ],
      temperature: input.temperature,
      max_tokens: input.maxOutputTokens,
      stream: false,
    }),
  });
  const result = (await response.json().catch(() => ({}))) as {
    choices?: Array<{ message?: { content?: string } }>;
    error?: { message?: string };
    usage?: unknown;
  };
  if (!response.ok) throw new Error(result.error?.message || `OpenRouter returned ${response.status}.`);
  const content = result.choices?.[0]?.message?.content?.trim();
  if (!content) throw new Error('OpenRouter returned an empty response.');
  return { content, usage: result.usage };
}

async function callGoogle(input: Extract<ReturnType<typeof parseChatBody>, { ok: true }>['value']) {
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(input.model)}:generateContent`;
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-goog-api-key': process.env.GOOGLE_GENERATIVE_AI_API_KEY!,
    },
    body: JSON.stringify({
      ...(input.system
        ? { systemInstruction: { parts: [{ text: input.system }] } }
        : {}),
      contents: input.messages.map((message) => ({
        role: message.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: message.content }],
      })),
      generationConfig: {
        temperature: input.temperature,
        maxOutputTokens: input.maxOutputTokens,
      },
    }),
  });
  const result = (await response.json().catch(() => ({}))) as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
    error?: { message?: string };
    usageMetadata?: unknown;
  };
  if (!response.ok) throw new Error(result.error?.message || `Google AI returned ${response.status}.`);
  const content = result.candidates?.[0]?.content?.parts?.map((part) => part.text || '').join('').trim();
  if (!content) throw new Error('Google AI returned an empty response.');
  return { content, usage: result.usageMetadata };
}

export async function POST(req: Request) {
  const outcome = await sessionFromRequest(req);
  if (!outcome.ok) return sessionErrorResponse(outcome);

  let raw: ChatBody;
  try {
    raw = (await req.json()) as ChatBody;
  } catch {
    return json({ error: 'Malformed JSON body.' }, 400);
  }
  const parsed = parseChatBody(raw);
  if (!parsed.ok) return json({ error: parsed.error }, 400);
  if (!providerConfigured(parsed.value.provider)) {
    return json({ error: `${parsed.value.provider} is not configured on this deployment.` }, 503);
  }

  try {
    const result =
      parsed.value.provider === 'openrouter'
        ? await callOpenRouter(parsed.value)
        : await callGoogle(parsed.value);

    // Prompts and responses can contain customer/financial data; audit metadata
    // only, never conversation content.
    await getServiceClient().from('activity_logs').insert({
      organization_id: outcome.session.organizationId,
      actor_id: outcome.session.profile.id,
      action: 'ai_chat_completed',
      record_type: 'ai_chat',
      record_id: null,
      summary: `AI chat completed with ${parsed.value.provider}/${parsed.value.model}`,
      new_values: {
        provider: parsed.value.provider,
        model: parsed.value.model,
        input_message_count: parsed.value.messages.length,
      },
    });

    return json(
      { provider: parsed.value.provider, model: parsed.value.model, content: result.content, usage: result.usage },
      200,
    );
  } catch (error) {
    return json({ error: (error as Error).message || 'AI provider request failed.' }, 502);
  }
}
