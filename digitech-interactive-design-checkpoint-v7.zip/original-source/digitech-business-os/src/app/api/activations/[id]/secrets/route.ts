import { sessionFromRequest, sessionErrorResponse } from '@/lib/auth/server-session';
import { getRequestClient } from '@/lib/data/supabase-client';
import { actorCan } from '@/lib/services/authz';
import {
  decryptActivationFields, encryptActivationFields,
  ENCRYPTED_ACTIVATION_FIELDS, encryptionAvailable,
} from '@/lib/security/crypto';

/**
 * The ONLY route that returns activation credentials in plaintext.
 *
 * Secrets never travel to the browser as part of normal data loading: the
 * SupabaseProvider selects an explicit safe column list for `activations`, so a
 * page render cannot leak them even accidentally. A user who genuinely needs to
 * read a credential (to hand it to the customer) fetches it here, one record at
 * a time, and the access is authorized and logged.
 *
 * Three checks, in order:
 *   1. Valid session  → 401
 *   2. RBAC allows activations.read → 403
 *   3. RLS on the row itself, because the read uses the CALLER's token, not the
 *      service role. A user from another organization gets zero rows even if
 *      they guess a valid UUID.
 */

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const outcome = await sessionFromRequest(req);
  if (!outcome.ok) return sessionErrorResponse(outcome);
  const { session } = outcome;

  if (!actorCan(
    {
      id: session.profile.id,
      organization_id: session.organizationId,
      role: session.role,
      is_active: session.profile.is_active,
      deleted_at: session.profile.deleted_at ?? null,
    },
    'activations.read',
  )) {
    return json({ error: 'Your role cannot read activation credentials.' }, 403);
  }

  if (!encryptionAvailable()) {
    return json({ error: 'ACTIVATION_ENCRYPTION_KEY is not configured on the server.' }, 500);
  }

  const { id } = await ctx.params;

  // The caller's own token: RLS decides whether this row is visible at all.
  const db = getRequestClient(session.accessToken);
  const { data, error } = await db
    .from('activations')
    // Literal list: the typed client cannot parse a template-literal column
    // spec, and keeping it explicit makes the exposed surface auditable.
    .select('id,organization_id,activation_email,activation_password,activation_details,internal_instructions')
    .eq('id', id)
    .limit(1);

  if (error) return json({ error: error.message }, 400);
  const row = ((data ?? []) as unknown as Record<string, unknown>[])[0];
  if (!row) return json({ error: 'Not found.' }, 404);

  // Defence in depth: RLS should already have excluded other organizations.
  if (row.organization_id !== session.organizationId) {
    return json({ error: 'Not found.' }, 404);
  }

  let plain: Record<string, unknown>;
  try {
    plain = decryptActivationFields(row);
  } catch (e) {
    return json({ error: (e as Error).message }, 500);
  }

  // Reading a credential is itself a sensitive event.
  await db.from('activity_logs').insert({
    organization_id: session.organizationId,
    actor_id: session.profile.id,
    actor_name: session.profile.full_name,
    action: 'secret_viewed',
    record_type: 'activation',
    record_id: id,
    summary: `${session.profile.full_name} viewed activation credentials`,
  });

  const out: Record<string, unknown> = { id: row.id };
  for (const f of ENCRYPTED_ACTIVATION_FIELDS) out[f] = plain[f] ?? null;
  return json(out);
}

/** Write credentials. Values are encrypted before they touch the table. */
export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const outcome = await sessionFromRequest(req);
  if (!outcome.ok) return sessionErrorResponse(outcome);
  const { session } = outcome;

  if (!actorCan(
    {
      id: session.profile.id,
      organization_id: session.organizationId,
      role: session.role,
      is_active: session.profile.is_active,
      deleted_at: session.profile.deleted_at ?? null,
    },
    'activations.update',
  )) {
    return json({ error: 'Your role cannot modify activation credentials.' }, 403);
  }

  if (!encryptionAvailable()) {
    return json({ error: 'ACTIVATION_ENCRYPTION_KEY is not configured on the server.' }, 500);
  }

  const { id } = await ctx.params;
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return json({ error: 'Invalid JSON body.' }, 400);
  }

  // Only the known secret fields are writable here.
  const patch: Record<string, unknown> = {};
  for (const f of ENCRYPTED_ACTIVATION_FIELDS) {
    if (f in body) patch[f] = body[f];
  }
  if (Object.keys(patch).length === 0) {
    return json({ error: 'No credential fields supplied.' }, 400);
  }

  const encrypted = encryptActivationFields(patch);
  encrypted.updated_at = new Date().toISOString();

  const db = getRequestClient(session.accessToken);
  const { data, error } = await db.from('activations').update(encrypted).eq('id', id).select('id');
  if (error) return json({ error: error.message }, 400);
  if (!data || data.length === 0) return json({ error: 'Not found or not permitted.' }, 404);

  await db.from('activity_logs').insert({
    organization_id: session.organizationId,
    actor_id: session.profile.id,
    actor_name: session.profile.full_name,
    action: 'secret_updated',
    record_type: 'activation',
    record_id: id,
    summary: `${session.profile.full_name} updated activation credentials`,
  });

  return json({ ok: true, id });
}
