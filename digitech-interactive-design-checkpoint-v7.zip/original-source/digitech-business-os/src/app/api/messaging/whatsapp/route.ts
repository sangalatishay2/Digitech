import { sessionFromRequest, sessionErrorResponse } from '@/lib/auth/server-session';
import { actorCan } from '@/lib/services/authz';
import { getServiceClient } from '@/lib/data/supabase-client';

/**
 * Server-side WhatsApp Cloud API send route.
 *
 * This exists so WHATSAPP_ACCESS_TOKEN never reaches the browser. The token is
 * a long-lived bearer credential for the business' WhatsApp account; leaking it
 * would let anyone send messages as the customer, so it is read from the
 * server-only environment here and never returned in a response.
 *
 * Every send is authenticated, permission-checked and recorded. The recipient
 * must belong to the caller's organization — otherwise a valid session for one
 * tenant could be used to message another tenant's customers.
 */

interface SendBody {
  to?: unknown;
  body?: unknown;
  customer_id?: unknown;
}

function json(payload: unknown, status: number) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

/** E.164-ish: digits only, 8–15 of them, optional leading +. */
function normalizePhone(raw: string): string | null {
  const digits = raw.replace(/\D/g, '');
  if (digits.length < 8 || digits.length > 15) return null;
  return digits;
}

export function cloudApiConfigured(): boolean {
  return Boolean(process.env.WHATSAPP_ACCESS_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID);
}

/** Reports availability without ever revealing the token itself. */
export async function GET(req: Request) {
  const outcome = await sessionFromRequest(req);
  if (!outcome.ok) return sessionErrorResponse(outcome);
  return json({ configured: cloudApiConfigured() }, 200);
}

export async function POST(req: Request) {
  const outcome = await sessionFromRequest(req);
  if (!outcome.ok) return sessionErrorResponse(outcome);
  const { session } = outcome;

  if (!actorCan(session.profile, 'customers.update')) {
    return json({ error: 'You do not have permission to message customers.' }, 403);
  }

  if (!cloudApiConfigured()) {
    // Honest failure: the UI must not be able to report a send as successful.
    return json(
      {
        error:
          'WhatsApp Cloud API is not configured on this deployment. Set WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID.',
      },
      503,
    );
  }

  let payload: SendBody;
  try {
    payload = (await req.json()) as SendBody;
  } catch {
    return json({ error: 'Malformed JSON body.' }, 400);
  }

  const body = typeof payload.body === 'string' ? payload.body.trim() : '';
  const rawTo = typeof payload.to === 'string' ? payload.to : '';
  const customerId = typeof payload.customer_id === 'string' ? payload.customer_id : null;

  if (!body) return json({ error: 'Message body is required.' }, 400);
  if (body.length > 4096) return json({ error: 'Message exceeds 4096 characters.' }, 400);

  const to = normalizePhone(rawTo);
  if (!to) return json({ error: 'A valid recipient phone number is required.' }, 400);

  const svc = getServiceClient();

  // Cross-tenant guard: when the message is tied to a customer record, that
  // record must live in the caller's organization.
  if (customerId) {
    const { data: rows, error } = await svc
      .from('customers')
      .select('id,organization_id')
      .eq('id', customerId)
      .limit(1);
    if (error) return json({ error: 'Could not verify the recipient.' }, 500);
    const customer = ((rows ?? []) as unknown as Array<{ organization_id: string }>)[0];
    if (!customer) return json({ error: 'Customer not found.' }, 404);
    if (customer.organization_id !== session.organizationId) {
      return json({ error: 'Customer not found.' }, 404);
    }
  }

  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID!;
  const version = process.env.WHATSAPP_API_VERSION || 'v21.0';

  let providerMessageId: string | null = null;
  let status: 'sent' | 'failed' = 'failed';
  let errorText: string | null = null;

  try {
    const res = await fetch(`https://graph.facebook.com/${version}/${phoneNumberId}/messages`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to,
        type: 'text',
        text: { preview_url: false, body },
      }),
    });

    const result = (await res.json().catch(() => ({}))) as {
      messages?: Array<{ id?: string }>;
      error?: { message?: string };
    };

    if (res.ok && result.messages?.[0]?.id) {
      status = 'sent';
      providerMessageId = result.messages[0].id ?? null;
    } else {
      // Surface the provider's reason but never echo our own credentials.
      errorText = result.error?.message ?? `WhatsApp API returned ${res.status}.`;
    }
  } catch (e) {
    errorText = `Could not reach the WhatsApp API: ${(e as Error).message}`;
  }

  // Record the attempt — failures included. A messaging log that only contains
  // successes is worse than none, because it hides delivery problems.
  await svc.from('activity_logs').insert({
    organization_id: session.organizationId,
    actor_id: session.profile.id,
    action: status === 'sent' ? 'whatsapp_sent' : 'whatsapp_failed',
    record_type: 'customer',
    record_id: customerId,
    summary:
      status === 'sent'
        ? `WhatsApp message sent to ${to}`
        : `WhatsApp message to ${to} failed: ${errorText}`,
    new_values: { to, length: body.length, provider_message_id: providerMessageId },
  });

  if (status !== 'sent') return json({ status, error: errorText }, 502);
  return json({ status, providerMessageId }, 200);
}
