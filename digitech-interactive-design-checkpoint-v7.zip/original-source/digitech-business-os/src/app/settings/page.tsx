'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { useTheme } from '@/components/theme';
import { PageHeader } from '@/components/shell/app-shell';
import { Badge, Button, Card, CardHeader, ConfirmDialog, Field, Input, Select, Textarea } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { cn, num, clamp } from '@/lib/utils';
import { buildBackup, migrateBackup, validateBackup } from '@/lib/services/backup';
import {
  Building2, Users, Shield, Package, ShoppingCart, RefreshCw, CreditCard, FileText,
  Bell, MessageCircle, Workflow, Plug, Lock, Palette, Database as DbIcon,
} from 'lucide-react';

const SECTIONS = [
  { id: 'business', label: 'Business Profile', icon: Building2 },
  { id: 'team', label: 'Team', icon: Users },
  { id: 'roles', label: 'Roles', icon: Shield },
  { id: 'products', label: 'Products', icon: Package },
  { id: 'orders', label: 'Orders', icon: ShoppingCart },
  { id: 'subscriptions', label: 'Subscriptions & Renewals', icon: RefreshCw },
  { id: 'payments', label: 'Payments', icon: CreditCard },
  { id: 'invoices', label: 'Invoices', icon: FileText },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'whatsapp', label: 'WhatsApp', icon: MessageCircle },
  { id: 'automation', label: 'Automation', icon: Workflow },
  { id: 'integrations', label: 'Integrations', icon: Plug },
  { id: 'security', label: 'Security', icon: Lock },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'backup', label: 'Backup & Data', icon: DbIcon },
];

export default function SettingsPage() {
  const { db, org, update, resetData, can, saveOrgSettings } = useStore();
  const { theme, setTheme } = useTheme();
  const toast = useToast();
  const [section, setSection] = useState('business');
  const [reset, setReset] = useState<null | 'demo' | 'empty'>(null);
  const [pendingRestore, setPendingRestore] = useState<null | {
    data: Record<string, unknown>;
    check: ReturnType<typeof validateBackup>;
  }>(null);
  const [biz, setBiz] = useState({
    name: org.name, email: org.email ?? '', phone: org.phone ?? '', gstin: org.gstin ?? '',
    address: org.address ?? '', currency: org.currency, timezone: org.timezone,
    expiry_threshold_days: org.expiry_threshold_days,
  });

  const saveBiz = () => {
    // Permission-checked and audited with old/new values in the store.
    saveOrgSettings({ ...biz });
    toast({ title: 'Settings saved' });
  };

  const exportBackup = () => {
    const blob = new Blob([buildBackup(db)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `digitech-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'Backup downloaded' });
  };

  /**
   * Restore is a destructive, whole-workspace operation. It now requires the
   * settings.update capability (owner/admin), validates and migrates the file
   * against a versioned schema, checks referential + org consistency, and only
   * then asks for explicit confirmation. Previously it checked two keys and
   * Object.assign'd whatever it was given.
   */
  const importBackup = (file: File) => {
    if (!can('settings.update')) {
      toast({ title: 'Not permitted', description: 'Only an owner or admin can restore a backup.', tone: 'error' });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      let raw: unknown;
      try {
        raw = JSON.parse(String(reader.result));
      } catch {
        toast({ title: 'Invalid backup file', description: 'Not valid JSON.', tone: 'error' });
        return;
      }
      const migrated = migrateBackup((raw ?? {}) as Record<string, unknown>);
      const check = validateBackup(migrated);
      if (!check.ok) {
        toast({
          title: 'Backup rejected',
          description: check.errors.slice(0, 3).join(' · '),
          tone: 'error',
        });
        return;
      }
      setPendingRestore({ data: migrated, check });
    };
    reader.readAsText(file);
  };

  const applyRestore = () => {
    if (!pendingRestore) return;
    update((d) => { Object.assign(d, pendingRestore.data); });
    toast({ title: 'Backup restored', description: `${pendingRestore.check.counts.customers ?? 0} customers restored.` });
    setPendingRestore(null);
  };

  return (
    <>
      <PageHeader title="Settings" description="Configure DigiTech Business OS" />

      <div className="grid gap-5 lg:grid-cols-[212px_1fr]">
        <nav className="lg:sticky lg:top-[68px] lg:self-start">
          <div className="flex gap-1 overflow-x-auto pb-1 lg:flex-col lg:overflow-visible lg:pb-0">
            {SECTIONS.map((s) => (
              <button
                key={s.id}
                onClick={() => setSection(s.id)}
                className={cn(
                  'nav-item relative flex shrink-0 items-center gap-2.5 whitespace-nowrap rounded-[7px] px-2.5 py-[7px] text-left text-[13px] font-medium lg:w-full',
                  section === s.id
                    ? 'bg-[var(--accent-soft)] text-[var(--accent)]'
                    : 'text-[var(--muted)] hover:bg-[var(--surface-2)] hover:text-[var(--fg)]',
                )}
              >
                <s.icon
                  className="h-[15px] w-[15px] shrink-0"
                  strokeWidth={section === s.id ? 2.2 : 1.9}
                />
                {s.label}
              </button>
            ))}
          </div>
        </nav>

        <div className="min-w-0 space-y-4">
          {section === 'business' && (
            <Card>
              <CardHeader title="Business profile" subtitle="Appears on invoices and customer communications" />
              <div className="grid gap-3 p-4 sm:grid-cols-2">
                <Field label="Business name"><Input value={biz.name} onChange={(e) => setBiz({ ...biz, name: e.target.value })} /></Field>
                <Field label="GSTIN"><Input value={biz.gstin} onChange={(e) => setBiz({ ...biz, gstin: e.target.value })} /></Field>
                <Field label="Email"><Input value={biz.email} onChange={(e) => setBiz({ ...biz, email: e.target.value })} /></Field>
                <Field label="Phone"><Input value={biz.phone} onChange={(e) => setBiz({ ...biz, phone: e.target.value })} /></Field>
                <Field label="Currency">
                  <Select value={biz.currency} onChange={(e) => setBiz({ ...biz, currency: e.target.value })}>
                    <option value="INR">INR — Indian Rupee</option>
                  </Select>
                </Field>
                <Field label="Timezone">
                  <Select value={biz.timezone} onChange={(e) => setBiz({ ...biz, timezone: e.target.value })}>
                    <option value="Asia/Kolkata">Asia/Kolkata</option>
                  </Select>
                </Field>
                <Field label="Address" className="sm:col-span-2"><Textarea rows={2} value={biz.address} onChange={(e) => setBiz({ ...biz, address: e.target.value })} /></Field>
                <div className="sm:col-span-2"><Button variant="primary" onClick={saveBiz}>Save changes</Button></div>
              </div>
            </Card>
          )}

          {section === 'subscriptions' && (
            <Card>
              <CardHeader title="Subscriptions & renewals" subtitle="Derived expiry states use this threshold" />
              <div className="grid gap-3 p-4 sm:grid-cols-2">
                <Field label="Expiring threshold (days)" hint="Subscriptions within this window are marked ‘expiring’">
                  <Input type="number" value={biz.expiry_threshold_days} onChange={(e) => setBiz({ ...biz, expiry_threshold_days: clamp(Math.floor(num(e.target.value)), 1, 365) })} />
                </Field>
                <div className="flex items-end pb-1"><Button variant="primary" onClick={saveBiz}>Save</Button></div>
                <p className="text-[12.5px] text-[var(--muted)] sm:col-span-2">
                  Existing subscriptions always keep the duration snapshot taken at purchase — changing a product’s duration later never alters an active subscription’s expiry date.
                </p>
              </div>
            </Card>
          )}

          {section === 'team' && (
            <Card>
              <CardHeader title="Team" subtitle={`${db.profiles.length} members`} />
              <div className="p-4"><Link href="/team"><Button variant="primary">Open team management</Button></Link></div>
            </Card>
          )}

          {section === 'roles' && (
            <Card>
              <CardHeader title="Roles" subtitle="Owner, Admin, Sales, Support, Accounts, Operations, Viewer" />
              <div className="p-4"><Link href="/team"><Button variant="primary">View permission matrix</Button></Link></div>
            </Card>
          )}

          {section === 'products' && (
            <Card>
              <CardHeader title="Product defaults" />
              <div className="space-y-2 p-4 text-[13px]">
                <Row label="Default low-stock threshold" value="5 units" />
                <Row label="Default duration" value="365 days" />
                <Row label="Historical cost handling" value="Immutable snapshot per order item" />
                <Link href="/products"><Button className="mt-2">Manage products</Button></Link>
              </div>
            </Card>
          )}

          {section === 'orders' && (
            <Card>
              <CardHeader title="Order settings" />
              <div className="space-y-2 p-4 text-[13px]">
                <Row label="Numbering" value="ORD-#### (sequential)" />
                <Row label="State machine" value="Enforced (new → awaiting_payment → paid → activation_pending → activated → delivered → completed)" />
                <Row label="Auto-create activation" value="Enabled on order creation" />
              </div>
            </Card>
          )}

          {section === 'payments' && (
            <Card>
              <CardHeader title="Payments" />
              <div className="space-y-2 p-4 text-[13px]">
                <Row label="Methods enabled" value="UPI, Bank Transfer, Cash, Credit/Debit Card, Gateway, Wallet, Other" />
                <Row label="Partial payments" value="Allowed" />
                <Row label="Refunds" value="Full and partial, tracked separately" />
                <Row label="Over-payment guard" value="Blocked — amount cannot exceed outstanding" />
              </div>
            </Card>
          )}

          {section === 'invoices' && (
            <Card>
              <CardHeader title="Invoices" />
              <div className="space-y-2 p-4 text-[13px]">
                <Row label="Numbering" value="INV-### (sequential)" />
                <Row label="Default due" value="7 days from issue" />
                <Row label="Tax" value="0% default — configure GST per invoice" />
                <Row label="PDF" value="Browser print → Save as PDF (server-side PDF ships with backend)" />
              </div>
            </Card>
          )}

          {section === 'notifications' && (
            <Card>
              <CardHeader title="Notifications" subtitle="Rules that generate in-app alerts" />
              <ul className="divide-y divide-[var(--border)] text-[13px]">
                {['Subscription expiring', 'Payment overdue', 'Activation pending', 'New support ticket', 'Task overdue', 'Low stock', 'Supplier payment due', 'Lead follow-up overdue'].map((n) => (
                  <li key={n} className="flex items-center justify-between px-4 py-2.5">
                    <span>{n}</span><Badge tone="success">enabled</Badge>
                  </li>
                ))}
              </ul>
            </Card>
          )}

          {section === 'whatsapp' && (
            <Card>
              <CardHeader title="WhatsApp" subtitle="Provider-agnostic — no vendor lock-in" />
              <div className="space-y-3 p-4 text-[13px]">
                <Row label="Active provider" value="Click-to-Chat (wa.me)" />
                <Row label="Cloud API" value="Not configured" />
                <p className="text-[12.5px] text-[var(--muted)]">
                  Set <code>WHATSAPP_ACCESS_TOKEN</code> and <code>WHATSAPP_PHONE_NUMBER_ID</code> as server-side variables to enable the Cloud API. They are deliberately not <code>NEXT_PUBLIC_</code> — the access token must never reach the browser. Templates and variables stay unchanged.
                </p>
                <Link href="/marketing/whatsapp"><Button>Open WhatsApp console</Button></Link>
              </div>
            </Card>
          )}

          {section === 'automation' && (
            <Card>
              <CardHeader title="Automation" />
              <div className="space-y-2 p-4 text-[13px]">
                <Row label="Active rules" value={String(db.automation_rules.filter((r) => r.is_active).length)} />
                <Row label="Webhook events" value="9 events (n8n-ready)" />
                <Link href="/automations"><Button className="mt-2">Manage automations</Button></Link>
              </div>
            </Card>
          )}

          {section === 'integrations' && (
            <Card>
              <CardHeader title="Integrations" />
              <div className="space-y-3 p-4">
                <IntegrationRow name="Supabase (Postgres + Auth + RLS)" status="Adapter ready — add credentials" />
                <IntegrationRow name="n8n" status="Webhook contract published" />
                <IntegrationRow name="WhatsApp Cloud API" status="Adapter ready — add credentials" />
                <IntegrationRow name="Payment gateway" status="Manual recording available; gateway sync coming soon" />
                <p className="text-[12.5px] text-[var(--muted)]">
                  Copy <code>.env.example</code> → <code>.env.local</code> and fill in the keys. Switching the data provider is a config change, not a rewrite.
                </p>
              </div>
            </Card>
          )}

          {section === 'security' && (
            <Card>
              <CardHeader title="Security" />
              <div className="space-y-2 p-4 text-[13px]">
                <Row label="Input validation" value="Zod schemas on all write forms" />
                <Row label="RBAC" value="Enforced in UI and service layer" />
                <Row label="Organization isolation" value="organization_id on every tenant table" />
                <Row label="Row Level Security" value="Policies shipped in migration 0013_rls.sql" />
                <Row label="Audit log" value={`${db.activity_logs.length} events recorded`} />
                <Row label="Password storage" value="Delegated to Supabase Auth — never stored by the app" />
                <Row label="Destructive actions" value="Confirmation dialogs + soft delete" />
              </div>
            </Card>
          )}

          {section === 'appearance' && (
            <Card>
              <CardHeader title="Appearance" />
              <div className="p-4">
                <p className="label">Theme</p>
                <div className="flex gap-2">
                  {(['light', 'dark', 'system'] as const).map((t) => (
                    <button key={t} onClick={() => setTheme(t)} className={cn(
                      'flex-1 rounded-[10px] border px-3 py-3 text-[13px] capitalize transition-colors',
                      theme === t ? 'border-[var(--accent)] bg-[var(--accent-soft)] text-[var(--accent)]' : 'border-[var(--border-strong)] hover:bg-[var(--surface-2)]',
                    )}>{t}</button>
                  ))}
                </div>
              </div>
            </Card>
          )}

          {section === 'backup' && (
            <>
              <Card>
                <CardHeader title="Backup & restore" subtitle="Full JSON snapshot of the local database" />
                <div className="flex flex-wrap gap-2 p-4">
                  <Button variant="primary" onClick={exportBackup}>Download backup (JSON)</Button>
                  <label>
                    <input type="file" accept="application/json" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) importBackup(f); }} />
                    <span className="inline-flex h-9 cursor-pointer items-center rounded-[10px] border border-[var(--border-strong)] px-3.5 text-[13px] hover:bg-[var(--surface-2)]">Restore from backup</span>
                  </label>
                  <Link href="/import-export"><Button variant="outline">CSV import / export</Button></Link>
                </div>
              </Card>
              <Card>
                <CardHeader title="Demo data" subtitle="Demo data is fully removable" />
                <div className="flex flex-wrap gap-2 p-4">
                  <Button onClick={() => setReset('demo')}>Reset to demo data</Button>
                  <Button variant="danger" onClick={() => setReset('empty')}>Clear all data</Button>
                </div>
              </Card>
            </>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={reset !== null}
        onClose={() => setReset(null)}
        onConfirm={async () => {
          await resetData(reset === 'empty' ? 'empty' : 'demo');
          toast({ title: reset === 'empty' ? 'All data cleared' : 'Demo data restored', tone: 'warning' });
        }}
        title={reset === 'empty' ? 'Clear all data?' : 'Reset to demo data?'}
        message={reset === 'empty'
          ? 'This permanently deletes every record in the local database. Download a backup first if you need it.'
          : 'This replaces the current local database with a fresh demo dataset.'}
        confirmLabel={reset === 'empty' ? 'Clear everything' : 'Reset'}
        danger
      />

      <ConfirmDialog
        open={pendingRestore !== null}
        onClose={() => setPendingRestore(null)}
        onConfirm={applyRestore}
        title="Restore this backup?"
        message={
          pendingRestore
            ? `This REPLACES the entire workspace. The file passed validation and contains ` +
              `${pendingRestore.check.counts.customers ?? 0} customers, ` +
              `${pendingRestore.check.counts.orders ?? 0} orders, ` +
              `${pendingRestore.check.counts.payments ?? 0} payments.` +
              (pendingRestore.check.warnings.length
                ? ` Warnings: ${pendingRestore.check.warnings.join(' · ')}`
                : '')
            : ''
        }
        confirmLabel="Replace all data"
        danger
      />
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex flex-wrap justify-between gap-2 border-b border-[var(--border)] pb-1.5 last:border-0"><span className="text-[12.5px] text-[var(--muted)]">{label}</span><span className="text-[13px]">{value}</span></div>;
}
function IntegrationRow({ name, status }: { name: string; status: string }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-[10px] border border-[var(--border)] p-3">
      <div><p className="text-[13px] font-medium">{name}</p><p className="text-[11.5px] text-[var(--muted)]">{status}</p></div>
      <Badge tone="warning">not connected</Badge>
    </div>
  );
}
