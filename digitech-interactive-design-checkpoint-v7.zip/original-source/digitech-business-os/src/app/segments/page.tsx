'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Badge, Button, Card, CardHeader, EmptyState, Table, Td, Th } from '@/components/ui/primitives';
import { customerStats } from '@/lib/services/analytics';
import { daysUntil, formatINR, cn } from '@/lib/utils';
import type { Customer } from '@/lib/types';
import { Layers, MessageCircle } from 'lucide-react';

interface Segment {
  id: string;
  name: string;
  description: string;
  match: (c: Customer) => boolean;
}

export default function SegmentsPage() {
  const { db } = useStore();
  const [active, setActive] = useState('vip');

  const segments: Segment[] = useMemo(() => [
    { id: 'vip', name: 'VIP customers', description: 'Lifetime revenue above ₹25,000', match: (c) => customerStats(db, c.id).revenue > 25000 },
    { id: 'repeat', name: 'Repeat buyers', description: '2 or more orders', match: (c) => customerStats(db, c.id).orders >= 2 },
    { id: 'one_time', name: 'One-time buyers', description: 'Exactly one order — upsell opportunity', match: (c) => customerStats(db, c.id).orders === 1 },
    { id: 'outstanding', name: 'Payment pending', description: 'Has outstanding balance', match: (c) => customerStats(db, c.id).outstanding > 0 },
    { id: 'expiring', name: 'Renewal window', description: 'Has a subscription expiring within 30 days', match: (c) => db.subscriptions.some((s) => s.customer_id === c.id && s.status !== 'renewed' && daysUntil(s.expiry_date) >= 0 && daysUntil(s.expiry_date) <= 30) },
    { id: 'lapsed', name: 'Lapsed customers', description: 'Had a subscription that expired without renewal', match: (c) => db.subscriptions.some((s) => s.customer_id === c.id && s.status === 'expired') },
    { id: 'dormant', name: 'Dormant (180d+)', description: 'No purchase in 180 days', match: (c) => { const s = customerStats(db, c.id); return !!s.lastPurchase && daysUntil(s.lastPurchase) < -180; } },
    { id: 'no_orders', name: 'Never purchased', description: 'Registered but no orders', match: (c) => customerStats(db, c.id).orders === 0 },
  ], [db]);

  const activeSeg = segments.find((s) => s.id === active)!;
  const members = db.customers.filter((c) => !c.deleted_at && activeSeg.match(c));
  const segRevenue = members.reduce((a, c) => a + customerStats(db, c.id).revenue, 0);

  const exportCsv = () => {
    const head = 'Name,Phone,WhatsApp,Email,City,Revenue,Orders\n';
    const body = members.map((c) => {
      const s = customerStats(db, c.id);
      return [c.name, c.phone ?? '', c.whatsapp ?? '', c.email ?? '', c.city ?? '', s.revenue, s.orders].map((v) => `"${v}"`).join(',');
    }).join('\n');
    const url = URL.createObjectURL(new Blob([head + body], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url; a.download = `segment-${activeSeg.id}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <PageHeader title="Segments" description="Dynamic customer segments computed live from your data" />

      <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
        <div className="space-y-2">
          {segments.map((s) => {
            const count = db.customers.filter((c) => !c.deleted_at && s.match(c)).length;
            return (
              <button key={s.id} onClick={() => setActive(s.id)} className={cn(
                'w-full rounded-[10px] border p-3 text-left transition-colors',
                active === s.id ? 'border-[var(--accent)] bg-[var(--accent-soft)]' : 'border-[var(--border)] bg-[var(--surface)] hover:bg-[var(--surface-2)]',
              )}>
                <div className="flex items-center justify-between gap-2">
                  <p className="text-[13px] font-medium">{s.name}</p>
                  <Badge tone={active === s.id ? 'accent' : 'neutral'}>{count}</Badge>
                </div>
                <p className="mt-0.5 text-[11.5px] text-[var(--muted)]">{s.description}</p>
              </button>
            );
          })}
        </div>

        <Card>
          <CardHeader
            title={activeSeg.name}
            subtitle={`${members.length} customers · ${formatINR(segRevenue)} combined revenue`}
            action={
              <div className="flex gap-2">
                <Button size="sm" onClick={exportCsv}>Export CSV</Button>
                <Link href="/marketing/whatsapp"><Button size="sm" variant="primary"><MessageCircle className="h-3.5 w-3.5" /> Message</Button></Link>
              </div>
            }
          />
          {members.length === 0 ? <EmptyState icon={Layers} title="No customers in this segment" /> : (
            <Table>
              <thead><tr><Th>Customer</Th><Th>Phone</Th><Th>City</Th><Th className="text-right">Orders</Th><Th className="text-right">Revenue</Th><Th className="text-right">Outstanding</Th></tr></thead>
              <tbody>
                {members.slice(0, 80).map((c) => {
                  const s = customerStats(db, c.id);
                  return (
                    <tr key={c.id}>
                      <Td><Link href={`/customers/${c.id}`} className="text-[var(--accent)] hover:underline">{c.name}</Link></Td>
                      <Td className="text-[12.5px]">{c.phone ?? '—'}</Td>
                      <Td className="text-[12.5px]">{c.city ?? '—'}</Td>
                      <Td className="text-right tabular-nums">{s.orders}</Td>
                      <Td className="text-right tabular-nums">{formatINR(s.revenue)}</Td>
                      <Td className="text-right tabular-nums" style={s.outstanding > 0 ? { color: 'var(--danger)' } : undefined}>{formatINR(s.outstanding)}</Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          )}
        </Card>
      </div>
    </>
  );
}
