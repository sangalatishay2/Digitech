'use client';

import { Suspense, useMemo, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { DataTable, type Column } from '@/components/ui/data-table';
import { Badge, Button, Card, CardHeader, EmptyState, Field, Input, Modal, Select, StatusBadge, Table, Td, Th } from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { useToast } from '@/components/ui/toast';
import { formatDateTime, formatINR, round2, num } from '@/lib/utils';
import { PAYMENT_METHOD, type Payment, type PaymentMethod } from '@/lib/types';
import { AlertCircle, IndianRupee, Plus, RotateCcw } from 'lucide-react';

function PaymentsInner() {
  const { db, addPayment } = useStore();
  const toast = useToast();
  const params = useSearchParams();
  const [open, setOpen] = useState(params.get('new') === '1');
  const [orderId, setOrderId] = useState('');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('upi');
  const [ref, setRef] = useState('');
  const [tab, setTab] = useState<'payments' | 'outstanding'>('payments');

  const payments = useMemo(() => [...db.payments].sort((a, b) => b.paid_at.localeCompare(a.paid_at)), [db.payments]);
  const outstandingOrders = useMemo(() => db.orders.filter((o) => o.outstanding > 0 && o.status !== 'cancelled').sort((a, b) => b.outstanding - a.outstanding), [db.orders]);

  const collected = round2(payments.filter((p) => !p.is_refund).reduce((a, p) => a + p.amount, 0));
  const refunded = round2(payments.filter((p) => p.is_refund).reduce((a, p) => a + p.amount, 0));
  const outstanding = round2(outstandingOrders.reduce((a, o) => a + o.outstanding, 0));

  const selectedOrder = db.orders.find((o) => o.id === orderId);

  const columns: Column<Payment>[] = [
    { key: 'date', header: 'Date', sortValue: (p) => p.paid_at, exportValue: (p) => p.paid_at, render: (p) => <span className="whitespace-nowrap text-[12.5px]">{formatDateTime(p.paid_at)}</span> },
    {
      key: 'order', header: 'Order',
      sortValue: (p) => db.orders.find((o) => o.id === p.order_id)?.order_number ?? '',
      exportValue: (p) => db.orders.find((o) => o.id === p.order_id)?.order_number ?? '',
      render: (p) => {
        const o = db.orders.find((x) => x.id === p.order_id);
        return o ? <Link href={`/orders/${o.id}`} className="text-[var(--accent)] hover:underline">{o.order_number}</Link> : '—';
      },
    },
    {
      key: 'customer', header: 'Customer',
      sortValue: (p) => db.customers.find((c) => c.id === p.customer_id)?.name ?? '',
      exportValue: (p) => db.customers.find((c) => c.id === p.customer_id)?.name ?? '',
      render: (p) => <span className="truncate text-[13px]">{db.customers.find((c) => c.id === p.customer_id)?.name ?? '—'}</span>,
    },
    { key: 'method', header: 'Method', sortValue: (p) => p.method, exportValue: (p) => p.method, render: (p) => <span className="text-[12.5px] capitalize">{p.method.replace('_', ' ')}</span> },
    { key: 'ref', header: 'Reference', exportValue: (p) => p.reference ?? '', render: (p) => <span className="text-[12.5px] text-[var(--muted)]">{p.reference ?? '—'}</span> },
    { key: 'type', header: 'Type', sortValue: (p) => String(p.is_refund), exportValue: (p) => (p.is_refund ? 'refund' : 'payment'), render: (p) => <Badge tone={p.is_refund ? 'danger' : 'success'}>{p.is_refund ? 'refund' : 'payment'}</Badge> },
    { key: 'amount', header: 'Amount', className: 'text-right', sortValue: (p) => p.amount, exportValue: (p) => p.amount, render: (p) => <span className="tabular-nums font-medium" style={p.is_refund ? { color: 'var(--danger)' } : undefined}>{p.is_refund ? '-' : ''}{formatINR(p.amount)}</span> },
  ];

  const submit = () => {
    const amt = num(amount);
    if (!selectedOrder || amt <= 0) return;
    if (amt > selectedOrder.outstanding + 0.01) {
      toast({ title: 'Amount exceeds outstanding', tone: 'error' });
      return;
    }
    addPayment(selectedOrder.id, amt, method, { reference: ref });
    toast({ title: 'Payment recorded' });
    setOpen(false); setAmount(''); setRef(''); setOrderId('');
  };

  return (
    <>
      <PageHeader
        title="Payments"
        description="All received payments, refunds and outstanding balances"
        actions={<Button variant="primary" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5" /> Record Payment</Button>}
      />

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiCard label="Collected" value={formatINR(collected, { compact: true })} icon={IndianRupee} tone="success" />
        <KpiCard label="Refunded" value={formatINR(refunded, { compact: true })} icon={RotateCcw} tone="danger" />
        <KpiCard label="Outstanding" value={formatINR(outstanding, { compact: true })} sub={`${outstandingOrders.length} orders`} icon={AlertCircle} tone="warning" />
        <KpiCard label="Net received" value={formatINR(round2(collected - refunded), { compact: true })} icon={IndianRupee} />
      </div>

      <div className="mb-3 flex gap-1.5">
        <Button size="sm" variant={tab === 'payments' ? 'primary' : 'outline'} onClick={() => setTab('payments')}>Payment ledger</Button>
        <Button size="sm" variant={tab === 'outstanding' ? 'primary' : 'outline'} onClick={() => setTab('outstanding')}>Outstanding ({outstandingOrders.length})</Button>
      </div>

      {tab === 'payments' ? (
        <DataTable rows={payments} columns={columns} exportName="payments" searchable={(p) => `${p.reference} ${db.orders.find((o) => o.id === p.order_id)?.order_number} ${db.customers.find((c) => c.id === p.customer_id)?.name}`} />
      ) : (
        <Card>
          <CardHeader title="Outstanding balances" subtitle={`${formatINR(outstanding)} to collect`} />
          {outstandingOrders.length === 0 ? <EmptyState title="Everything collected 🎉" /> : (
            <Table>
              <thead><tr><Th>Order</Th><Th>Customer</Th><Th>Status</Th><Th className="text-right">Total</Th><Th className="text-right">Paid</Th><Th className="text-right">Outstanding</Th><Th /></tr></thead>
              <tbody>
                {outstandingOrders.map((o) => {
                  const c = db.customers.find((x) => x.id === o.customer_id);
                  return (
                    <tr key={o.id}>
                      <Td><Link href={`/orders/${o.id}`} className="text-[var(--accent)] hover:underline">{o.order_number}</Link></Td>
                      <Td className="truncate text-[13px]">{c?.name ?? '—'}</Td>
                      <Td><StatusBadge status={o.payment_status} /></Td>
                      <Td className="text-right tabular-nums">{formatINR(o.total)}</Td>
                      <Td className="text-right tabular-nums">{formatINR(o.amount_paid)}</Td>
                      <Td className="text-right tabular-nums" style={{ color: 'var(--danger)' }}>{formatINR(o.outstanding)}</Td>
                      <Td className="text-right">
                        <Button size="sm" onClick={() => { setOrderId(o.id); setAmount(String(o.outstanding)); setOpen(true); }}>Collect</Button>
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          )}
        </Card>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Record payment"
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" onClick={submit} disabled={!orderId}>Record</Button></>}>
        <div className="space-y-3">
          <Field label="Order">
            <Select value={orderId} onChange={(e) => { setOrderId(e.target.value); const o = db.orders.find((x) => x.id === e.target.value); if (o) setAmount(String(o.outstanding)); }}>
              <option value="">Select an order with outstanding…</option>
              {outstandingOrders.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.order_number} — {db.customers.find((c) => c.id === o.customer_id)?.name} — {formatINR(o.outstanding)} due
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Amount (₹)"><Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
          <Field label="Method"><Select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>{PAYMENT_METHOD.map((m) => <option key={m} value={m}>{m.replace('_', ' ')}</option>)}</Select></Field>
          <Field label="Reference"><Input value={ref} onChange={(e) => setRef(e.target.value)} /></Field>
        </div>
      </Modal>
    </>
  );
}

export default function PaymentsPage() {
  return <Suspense fallback={null}><PaymentsInner /></Suspense>;
}
