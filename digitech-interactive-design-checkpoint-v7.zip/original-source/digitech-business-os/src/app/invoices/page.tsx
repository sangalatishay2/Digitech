'use client';

import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { DataTable, type Column } from '@/components/ui/data-table';
import { Select, StatusBadge } from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { formatDate, formatINR, round2 } from '@/lib/utils';
import type { Invoice } from '@/lib/types';
import { FileText, IndianRupee, AlertCircle } from 'lucide-react';

export default function InvoicesPage() {
  const { db } = useStore();
  const router = useRouter();
  const [status, setStatus] = useState('all');

  const rows = useMemo(() => {
    let list = [...db.invoices].sort((a, b) => b.issue_date.localeCompare(a.issue_date));
    if (status !== 'all') list = list.filter((i) => i.status === status);
    return list;
  }, [db.invoices, status]);

  const billed = round2(rows.reduce((a, i) => a + i.total, 0));
  const collected = round2(rows.reduce((a, i) => a + i.amount_paid, 0));

  const columns: Column<Invoice>[] = [
    { key: 'num', header: 'Invoice', sortValue: (i) => i.invoice_number, exportValue: (i) => i.invoice_number, render: (i) => <span className="font-medium text-[var(--accent)]">{i.invoice_number}</span> },
    { key: 'customer', header: 'Customer', sortValue: (i) => db.customers.find((c) => c.id === i.customer_id)?.name ?? '', exportValue: (i) => db.customers.find((c) => c.id === i.customer_id)?.name ?? '', render: (i) => <span className="truncate text-[13px]">{db.customers.find((c) => c.id === i.customer_id)?.name ?? '—'}</span> },
    { key: 'issued', header: 'Issued', sortValue: (i) => i.issue_date, exportValue: (i) => i.issue_date, render: (i) => <span className="text-[12.5px]">{formatDate(i.issue_date)}</span> },
    { key: 'due', header: 'Due', sortValue: (i) => i.due_date, exportValue: (i) => i.due_date, render: (i) => <span className="text-[12.5px]">{formatDate(i.due_date)}</span> },
    { key: 'status', header: 'Status', sortValue: (i) => i.status, exportValue: (i) => i.status, render: (i) => <StatusBadge status={i.status} /> },
    { key: 'paid', header: 'Paid', className: 'text-right', sortValue: (i) => i.amount_paid, exportValue: (i) => i.amount_paid, render: (i) => <span className="tabular-nums">{formatINR(i.amount_paid)}</span> },
    { key: 'total', header: 'Total', className: 'text-right', sortValue: (i) => i.total, exportValue: (i) => i.total, render: (i) => <span className="tabular-nums font-medium">{formatINR(i.total)}</span> },
  ];

  return (
    <>
      <PageHeader title="Invoices" description={`${rows.length} invoices`} />
      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-3">
        <KpiCard label="Billed" value={formatINR(billed, { compact: true })} icon={FileText} tone="accent" />
        <KpiCard label="Collected" value={formatINR(collected, { compact: true })} icon={IndianRupee} tone="success" />
        <KpiCard label="Unpaid" value={formatINR(round2(billed - collected), { compact: true })} icon={AlertCircle} tone="danger" />
      </div>
      <DataTable rows={rows} columns={columns} exportName="invoices" onRowClick={(i) => router.push(`/invoices/${i.id}`)}
        searchable={(i) => `${i.invoice_number} ${db.customers.find((c) => c.id === i.customer_id)?.name}`}
        toolbar={
          <Select value={status} onChange={(e) => setStatus(e.target.value)} className="h-8 w-auto py-0 text-[12.5px]">
            <option value="all">All statuses</option>
            {['draft', 'sent', 'paid', 'partial', 'overdue', 'void'].map((s) => <option key={s} value={s}>{s}</option>)}
          </Select>
        } />
    </>
  );
}
