'use client';

import { use } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { Button, Card, EmptyState, StatusBadge } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { formatDate, formatINR } from '@/lib/utils';
import { ArrowLeft, Download, Printer, Share2 } from 'lucide-react';

export default function InvoiceDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { db, org } = useStore();
  const toast = useToast();

  const invoice = db.invoices.find((i) => i.id === id);
  if (!invoice) return <EmptyState title="Invoice not found" action={<Link href="/invoices"><Button>Back</Button></Link>} />;

  const customer = db.customers.find((c) => c.id === invoice.customer_id);
  const order = db.orders.find((o) => o.id === invoice.order_id);
  const balance = invoice.total - invoice.amount_paid;

  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: invoice.invoice_number, url });
      else {
        await navigator.clipboard.writeText(url);
        toast({ title: 'Invoice link copied' });
      }
    } catch {
      toast({ title: 'Share cancelled', tone: 'info' });
    }
  };

  return (
    <>
      <div className="no-print mb-3 flex flex-wrap items-center justify-between gap-2">
        <Link href="/invoices" className="inline-flex items-center gap-1 text-[12.5px] text-[var(--muted)] hover:text-[var(--fg)]"><ArrowLeft className="h-3 w-3" /> Invoices</Link>
        <div className="flex gap-2">
          <Button onClick={share}><Share2 className="h-3.5 w-3.5" /> Share</Button>
          <Button onClick={() => window.print()}><Printer className="h-3.5 w-3.5" /> Print</Button>
          <Button variant="primary" onClick={() => { toast({ title: 'Use Print → Save as PDF', description: 'Server-side PDF generation ships with the Supabase backend.', tone: 'info' }); window.print(); }}>
            <Download className="h-3.5 w-3.5" /> PDF
          </Button>
        </div>
      </div>

      <Card className="mx-auto max-w-3xl p-8 print:border-0 print:shadow-none">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[var(--border)] pb-6">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">{org.name}</h1>
            <p className="mt-1 max-w-xs text-[12.5px] text-[var(--muted)]">{org.address}</p>
            <p className="text-[12.5px] text-[var(--muted)]">{org.email} · {org.phone}</p>
            {org.gstin && <p className="text-[12.5px] text-[var(--muted)]">GSTIN: {org.gstin}</p>}
          </div>
          <div className="text-right">
            <p className="text-[12.5px] font-semibold uppercase tracking-wider text-[var(--muted-2)]">Invoice</p>
            <p className="text-[16px] font-semibold">{invoice.invoice_number}</p>
            <div className="mt-1"><StatusBadge status={invoice.status} /></div>
          </div>
        </div>

        <div className="grid gap-6 py-6 sm:grid-cols-2">
          <div>
            <p className="text-[11.5px] font-semibold uppercase tracking-wider text-[var(--muted-2)]">Billed to</p>
            <p className="mt-1 font-medium">{customer?.name ?? '—'}</p>
            <p className="text-[12.5px] text-[var(--muted)]">{customer?.company}</p>
            <p className="text-[12.5px] text-[var(--muted)]">{customer?.phone}</p>
            <p className="text-[12.5px] text-[var(--muted)]">{customer?.email}</p>
            <p className="text-[12.5px] text-[var(--muted)]">{[customer?.city, customer?.state].filter(Boolean).join(', ')}</p>
          </div>
          <div className="sm:text-right">
            <p className="text-[11.5px] font-semibold uppercase tracking-wider text-[var(--muted-2)]">Details</p>
            <p className="mt-1 text-[12.5px]">Issue date: {formatDate(invoice.issue_date)}</p>
            <p className="text-[12.5px]">Due date: {formatDate(invoice.due_date)}</p>
            {order && <p className="text-[12.5px]">Order: {order.order_number}</p>}
            <p className="text-[12.5px]">Currency: {org.currency}</p>
          </div>
        </div>

        <table className="w-full border-collapse text-[13px]">
          <thead>
            <tr className="border-y border-[var(--border)] bg-[var(--surface-2)]">
              <th className="px-2 py-2 text-left text-[11.5px] font-semibold uppercase tracking-wide text-[var(--muted)]">Description</th>
              <th className="px-2 py-2 text-right text-[11.5px] font-semibold uppercase tracking-wide text-[var(--muted)]">Qty</th>
              <th className="px-2 py-2 text-right text-[11.5px] font-semibold uppercase tracking-wide text-[var(--muted)]">Unit price</th>
              <th className="px-2 py-2 text-right text-[11.5px] font-semibold uppercase tracking-wide text-[var(--muted)]">Amount</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((i) => (
              <tr key={i.id} className="border-b border-[var(--border)]">
                <td className="px-2 py-2.5">{i.description}</td>
                <td className="px-2 py-2.5 text-right tabular-nums">{i.quantity}</td>
                <td className="px-2 py-2.5 text-right tabular-nums">{formatINR(i.unit_price)}</td>
                <td className="px-2 py-2.5 text-right tabular-nums">{formatINR(i.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="mt-4 ml-auto max-w-xs space-y-1.5 text-[13px]">
          <Row label="Subtotal" value={formatINR(invoice.subtotal)} />
          <Row label="Discount" value={`- ${formatINR(invoice.discount)}`} />
          <Row label="Tax" value={formatINR(invoice.tax)} />
          <div className="border-t border-[var(--border)] pt-1.5">
            <Row label="Total" value={formatINR(invoice.total)} bold />
          </div>
          <Row label="Paid" value={formatINR(invoice.amount_paid)} />
          <Row label="Balance due" value={formatINR(balance)} bold tone={balance > 0 ? 'danger' : 'success'} />
        </div>

        <div className="mt-8 border-t border-[var(--border)] pt-4 text-[11.5px] text-[var(--muted)]">
          <p>Thank you for your business. Digital products are non-refundable once activated unless stated otherwise.</p>
          <p className="mt-1">This is a computer-generated invoice from {org.name} Business OS.</p>
        </div>
      </Card>
    </>
  );
}

function Row({ label, value, bold, tone }: { label: string; value: string; bold?: boolean; tone?: 'danger' | 'success' }) {
  return (
    <div className="flex justify-between gap-3">
      <span className={bold ? 'font-semibold' : 'text-[var(--muted)]'}>{label}</span>
      <span className={`tabular-nums ${bold ? 'font-semibold' : ''}`} style={tone ? { color: `var(--${tone})` } : undefined}>{value}</span>
    </div>
  );
}
