'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { DataTable, type Column } from '@/components/ui/data-table';
import { Button, Select, StatusBadge } from '@/components/ui/primitives';
import { formatDate, formatINR } from '@/lib/utils';
import { ORDER_STATUS, type Order } from '@/lib/types';
import { Plus } from 'lucide-react';

export default function OrdersPage() {
  const { db } = useStore();
  const router = useRouter();
  const [status, setStatus] = useState('all');
  const [pay, setPay] = useState('all');

  const rows = useMemo(() => {
    let list = [...db.orders].sort((a, b) => b.ordered_at.localeCompare(a.ordered_at));
    if (status !== 'all') list = list.filter((o) => o.status === status);
    if (pay !== 'all') list = list.filter((o) => o.payment_status === pay);
    return list;
  }, [db.orders, status, pay]);

  const columns: Column<Order>[] = [
    { key: 'num', header: 'Order', sortValue: (o) => o.order_number, exportValue: (o) => o.order_number, render: (o) => <span className="font-medium text-[var(--accent)]">{o.order_number}</span> },
    {
      key: 'customer', header: 'Customer',
      sortValue: (o) => db.customers.find((c) => c.id === o.customer_id)?.name ?? '',
      exportValue: (o) => db.customers.find((c) => c.id === o.customer_id)?.name ?? '',
      render: (o) => <span className="truncate">{db.customers.find((c) => c.id === o.customer_id)?.name ?? '—'}</span>,
    },
    { key: 'items', header: 'Items', exportValue: (o) => o.items.map((i) => i.product_name).join(' | '), render: (o) => <span className="block max-w-[220px] truncate text-[12.5px] text-[var(--muted)]">{o.items.map((i) => i.product_name).join(', ')}</span> },
    { key: 'status', header: 'Status', sortValue: (o) => o.status, exportValue: (o) => o.status, render: (o) => <StatusBadge status={o.status} /> },
    { key: 'payment', header: 'Payment', sortValue: (o) => o.payment_status, exportValue: (o) => o.payment_status, render: (o) => <StatusBadge status={o.payment_status} /> },
    { key: 'total', header: 'Total', className: 'text-right', sortValue: (o) => o.total, exportValue: (o) => o.total, render: (o) => <span className="tabular-nums font-medium">{formatINR(o.total)}</span> },
    { key: 'profit', header: 'Profit', className: 'text-right', sortValue: (o) => o.profit, exportValue: (o) => o.profit, render: (o) => <span className="tabular-nums" style={{ color: o.profit >= 0 ? 'var(--success)' : 'var(--danger)' }}>{formatINR(o.profit)}</span> },
    { key: 'outstanding', header: 'Outstanding', className: 'text-right', sortValue: (o) => o.outstanding, exportValue: (o) => o.outstanding, render: (o) => <span className="tabular-nums" style={{ color: o.outstanding > 0 ? 'var(--danger)' : undefined }}>{o.outstanding > 0 ? formatINR(o.outstanding) : '—'}</span> },
    { key: 'date', header: 'Date', sortValue: (o) => o.ordered_at, exportValue: (o) => o.ordered_at, render: (o) => <span className="whitespace-nowrap text-[12.5px] text-[var(--muted)]">{formatDate(o.ordered_at)}</span> },
  ];

  return (
    <>
      <PageHeader
        title="Orders"
        description={`${rows.length} orders · ${formatINR(rows.reduce((a, o) => a + o.total, 0))} value`}
        actions={<Link href="/orders/new"><Button variant="primary"><Plus className="h-3.5 w-3.5" /> New Order</Button></Link>}
      />
      <DataTable
        rows={rows}
        columns={columns}
        exportName="orders"
        onRowClick={(o) => router.push(`/orders/${o.id}`)}
        searchable={(o) => `${o.order_number} ${db.customers.find((c) => c.id === o.customer_id)?.name ?? ''} ${o.items.map((i) => i.product_name).join(' ')}`}
        toolbar={
          <>
            <Select value={status} onChange={(e) => setStatus(e.target.value)} className="h-8 w-auto py-0 text-[12.5px]">
              <option value="all">All statuses</option>
              {ORDER_STATUS.map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
            </Select>
            <Select value={pay} onChange={(e) => setPay(e.target.value)} className="h-8 w-auto py-0 text-[12.5px]">
              <option value="all">All payments</option>
              {['pending', 'partial', 'paid', 'refunded', 'partially_refunded'].map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
            </Select>
          </>
        }
      />
    </>
  );
}
