'use client';

import { Suspense, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useStore, type NewOrderLine } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Avatar, Badge, Button, Callout, Card, CardHeader, Field, Input, Select, Textarea } from '@/components/ui/primitives';
import { CustomerForm } from '@/components/forms/customer-form';
import { useToast } from '@/components/ui/toast';
import { formatINR, round2, cn, num, clamp } from '@/lib/utils';
import { PAYMENT_METHOD, type PaymentMethod } from '@/lib/types';
import { ArrowLeft, AlertTriangle, Check, Plus, Trash2, UserPlus, Search } from 'lucide-react';

function NewOrderInner() {
  const { db, createOrder, currentUser } = useStore();
  const router = useRouter();
  const params = useSearchParams();
  const toast = useToast();

  const renewalSubId = params.get('renew');
  const renewalSub = renewalSubId ? db.subscriptions.find((s) => s.id === renewalSubId) : undefined;

  const [step, setStep] = useState(renewalSub || params.get('customer') ? 2 : 1);
  const [customerId, setCustomerId] = useState(params.get('customer') ?? renewalSub?.customer_id ?? '');
  const [q, setQ] = useState('');
  const [newCust, setNewCust] = useState(false);
  const [lines, setLines] = useState<NewOrderLine[]>(
    renewalSub?.product_id
      ? [{ product_id: renewalSub.product_id, quantity: 1, unit_price: renewalSub.purchase_amount, discount: 0 }]
      : [],
  );
  const [notes, setNotes] = useState(renewalSub ? `Renewal of subscription for ${renewalSub.product_name}` : '');
  const [assigned, setAssigned] = useState(currentUser?.id ?? '');
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState<PaymentMethod>('upi');
  const [payRef, setPayRef] = useState('');

  const customer = db.customers.find((c) => c.id === customerId);
  const matches = useMemo(() => {
    const term = q.trim().toLowerCase();
    const list = db.customers.filter((c) => !c.deleted_at);
    if (!term) return list.slice(0, 8);
    return list.filter((c) => `${c.name} ${c.phone} ${c.email} ${c.customer_code}`.toLowerCase().includes(term)).slice(0, 8);
  }, [q, db.customers]);

  const totals = useMemo(() => {
    let subtotal = 0, discount = 0, cost = 0;
    for (const l of lines) {
      const p = db.products.find((x) => x.id === l.product_id);
      if (!p) continue;
      subtotal += l.unit_price * l.quantity;
      discount += l.discount;
      cost += p.cost_price * l.quantity;
    }
    const total = round2(subtotal - discount);
    const profit = round2(total - cost);
    return { subtotal: round2(subtotal), discount: round2(discount), total, cost: round2(cost), profit, margin: total ? round2((profit / total) * 100) : 0 };
  }, [lines, db.products]);

  const oversoldLines = useMemo(
    () =>
      lines
        .map((l) => {
          const p = db.products.find((x) => x.id === l.product_id);
          return p && p.stock !== null && l.quantity > p.stock ? p.name : null;
        })
        .filter((n): n is string => n !== null),
    [lines, db.products],
  );

  const addLine = (productId: string) => {
    const p = db.products.find((x) => x.id === productId);
    if (!p) return;
    setLines((l) => [...l, { product_id: p.id, quantity: 1, unit_price: p.selling_price, discount: 0 }]);
  };

  const submit = () => {
    if (!customerId || lines.length === 0) {
      toast({ title: 'Incomplete order', description: 'Select a customer and at least one product.', tone: 'error' });
      return;
    }
    const amt = Number(payAmount) || 0;
    if (amt > totals.total) {
      toast({ title: 'Payment exceeds order total', tone: 'error' });
      return;
    }
    const order = createOrder({
      customer_id: customerId,
      lines,
      notes,
      assigned_to: assigned || null,
      renewal_of_subscription_id: renewalSub?.id ?? null,
      payment: amt > 0 ? { amount: amt, method: payMethod, reference: payRef } : null,
    });
    toast({ title: `Order ${order.order_number} created`, description: amt > 0 ? 'Payment recorded, activation queued.' : 'Awaiting payment.' });
    router.push(`/orders/${order.id}`);
  };

  return (
    <>
      <div className="mb-3"><Link href="/orders" className="inline-flex items-center gap-1 text-[12.5px] text-[var(--muted)] hover:text-[var(--fg)]"><ArrowLeft className="h-3 w-3" /> Orders</Link></div>
      <PageHeader
        title={renewalSub ? 'Renewal Order' : 'New Order'}
        description={renewalSub ? `Renewing ${renewalSub.product_name} — previous price ${formatINR(renewalSub.purchase_amount)}` : 'Customer → Product → Payment. Costs are snapshotted at creation.'}
      />

      <div className="mb-5 mt-4">
        <div className="flex items-center">
          {[['1', 'Customer'], ['2', 'Products'], ['3', 'Pricing & Payment']].map(([n, label], i, arr) => {
            const num = Number(n);
            const done = step > num;
            const current = step === num;
            return (
              <div key={n} className={cn('flex items-center', i < arr.length - 1 && 'flex-1')}>
                <button
                  onClick={() => setStep(num)}
                  className="press group flex items-center gap-2.5 focusable rounded-[7px] py-1 pr-2"
                >
                  <span
                    className={cn(
                      'flex h-[26px] w-[26px] shrink-0 items-center justify-center rounded-full border text-[12px] font-semibold transition-all duration-200',
                      done
                        ? 'border-[var(--accent)] bg-[var(--accent)] text-white'
                        : current
                          ? 'border-[var(--accent)] bg-[var(--accent-soft)] text-[var(--accent)] shadow-[var(--ring)]'
                          : 'border-[var(--border-strong)] bg-[var(--surface)] text-[var(--muted-2)]',
                    )}
                  >
                    {done ? <Check className="h-3.5 w-3.5" strokeWidth={3} /> : n}
                  </span>
                  <span
                    className={cn(
                      'whitespace-nowrap text-[12.5px] font-medium transition-colors',
                      current ? 'text-[var(--fg)]' : done ? 'text-[var(--fg-soft)]' : 'text-[var(--muted-2)]',
                    )}
                  >
                    {label}
                  </span>
                </button>
                {i < arr.length - 1 && (
                  <span className="mx-2 hidden h-px flex-1 bg-[var(--border)] sm:block">
                    <span
                      className="block h-px bg-[var(--accent)] transition-all duration-300"
                      style={{ width: done ? '100%' : '0%' }}
                    />
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <div className="space-y-4">
          {/* STEP 1 */}
          <Card>
            <CardHeader title="1 · Customer" action={<Button size="sm" onClick={() => setNewCust(true)}><UserPlus className="h-3.5 w-3.5" /> New</Button>} />
            <div className="p-4">
              {customer ? (
                <div className="flex items-center gap-3 rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] p-3">
                  <Avatar name={customer.name} size={36} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{customer.name}</p>
                    <p className="truncate text-[12.5px] text-[var(--muted)]">{customer.customer_code} · {customer.phone ?? customer.email}</p>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => { setCustomerId(''); setStep(1); }}>Change</Button>
                </div>
              ) : (
                <>
                  <div className="relative">
                    <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[var(--muted-2)]" />
                    <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name, phone, email…" className="field pl-8" />
                  </div>
                  <ul className="mt-2 divide-y divide-[var(--border)] rounded-[10px] border border-[var(--border)]">
                    {matches.map((c) => (
                      <li key={c.id}>
                        <button onClick={() => { setCustomerId(c.id); setStep(2); }} className="flex w-full items-center gap-2.5 px-3 py-2 text-left hover:bg-[var(--surface-2)]">
                          <Avatar name={c.name} size={26} />
                          <span className="flex-1 truncate text-[13px]">{c.name}</span>
                          <span className="text-[12.5px] text-[var(--muted)]">{c.phone}</span>
                        </button>
                      </li>
                    ))}
                    {matches.length === 0 && <li className="px-3 py-6 text-center text-[12.5px] text-[var(--muted)}">No customers match “{q}”</li>}
                  </ul>
                </>
              )}
            </div>
          </Card>

          {/* STEP 2 */}
          <Card>
            <CardHeader title="2 · Products" subtitle="Product cost, price, duration and supplier are snapshotted onto the order" />
            <div className="space-y-3 p-4">
              <Select defaultValue="" onChange={(e) => { if (e.target.value) { addLine(e.target.value); e.target.value = ''; setStep(2); } }}>
                <option value="">+ Add product…</option>
                {db.products.filter((p) => p.is_active && !p.deleted_at).map((p) => (
                  <option key={p.id} value={p.id}>{p.name} — {formatINR(p.selling_price)}</option>
                ))}
              </Select>

              {lines.length === 0 && <p className="py-4 text-center text-[12.5px] text-[var(--muted)]">No products added yet.</p>}

              {lines.map((l, idx) => {
                const p = db.products.find((x) => x.id === l.product_id);
                if (!p) return null;
                const lineTotal = round2(l.unit_price * l.quantity - l.discount);
                const lineProfit = round2(lineTotal - p.cost_price * l.quantity);
                const oversold = p.stock !== null && l.quantity > p.stock;
                return (
                  <div key={idx} className="rounded-[10px] border border-[var(--border)] p-3">
                    <div className="mb-2 flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-[13px] font-medium">{p.name}</p>
                        <p className="text-[11.5px] text-[var(--muted)]">
                          {p.code} · cost {formatINR(p.cost_price)} · {p.duration_days ? `${p.duration_days}d` : 'one-time'} · {p.delivery_type.replace('_', ' ')}
                          {p.stock !== null && <> · <span style={oversold ? { color: 'var(--danger)', fontWeight: 600 } : undefined}>{p.stock} in stock</span></>}
                        </p>
                      </div>
                      <button onClick={() => setLines((ls) => ls.filter((_, i) => i !== idx))} className="rounded p-1 text-[var(--danger)] hover:bg-[var(--danger-soft)]">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                      <Field label="Qty">
                        <Input type="number" min={1} value={l.quantity} onChange={(e) => setLines((ls) => ls.map((x, i) => i === idx ? { ...x, quantity: Math.max(1, Math.floor(num(e.target.value)) || 1) } : x))} />
                      </Field>
                      <Field label="Selling price">
                        <Input type="number" min={0} value={l.unit_price} onChange={(e) => setLines((ls) => ls.map((x, i) => i === idx ? { ...x, unit_price: Math.max(0, num(e.target.value)) } : x))} />
                      </Field>
                      <Field label="Discount">
                        <Input
                          type="number"
                          min={0}
                          max={round2(l.unit_price * l.quantity)}
                          value={l.discount}
                          onChange={(e) =>
                            setLines((ls) =>
                              ls.map((x, i) =>
                                // Clamp to the line value: a discount larger than the
                                // line total would produce a negative order.
                                i === idx ? { ...x, discount: clamp(num(e.target.value), 0, round2(x.unit_price * x.quantity)) } : x,
                              ),
                            )
                          }
                        />
                      </Field>
                      <div className="flex flex-col justify-end pb-1">
                        <p className="text-[12.5px] text-[var(--muted)]">Line total</p>
                        <p className="text-[13.5px] font-semibold tabular-nums">{formatINR(lineTotal)}</p>
                        <p className="text-[11.5px]" style={{ color: lineProfit >= 0 ? 'var(--success)' : 'var(--danger)' }}>profit {formatINR(lineProfit)}</p>
                      </div>
                    </div>
                  </div>
                );
              })}

              <Field label="Order notes"><Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
              <Field label="Assigned to">
                <Select value={assigned} onChange={(e) => setAssigned(e.target.value)}>
                  <option value="">Unassigned</option>
                  {db.profiles.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
                </Select>
              </Field>
            </div>
          </Card>

          {/* STEP 3 */}
          <Card>
            <CardHeader title="3 · Payment (optional)" subtitle="Record full or partial payment now — or leave blank to create an awaiting-payment order" />
            <div className="grid gap-3 p-4 sm:grid-cols-3">
              <Field label="Amount received (₹)">
                <Input type="number" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} placeholder={String(totals.total)} />
              </Field>
              <Field label="Method">
                <Select value={payMethod} onChange={(e) => setPayMethod(e.target.value as PaymentMethod)}>
                  {PAYMENT_METHOD.map((m) => <option key={m} value={m}>{m.replace('_', ' ')}</option>)}
                </Select>
              </Field>
              <Field label="Reference"><Input value={payRef} onChange={(e) => setPayRef(e.target.value)} placeholder="UTR / txn id" /></Field>
              <div className="sm:col-span-3">
                <Button size="sm" variant="outline" onClick={() => setPayAmount(String(totals.total))}>Mark full payment ({formatINR(totals.total)})</Button>
              </div>
            </div>
          </Card>
        </div>

        <div className="lg:sticky lg:top-20 lg:self-start">
          <Card>
            <CardHeader title="Order summary" />
            <div className="space-y-2 p-4 text-[13px]">
              <Row label="Subtotal" value={formatINR(totals.subtotal)} />
              <Row label="Discount" value={`- ${formatINR(totals.discount)}`} />
              <div className="my-2 border-t border-[var(--border)]" />
              <Row label="Total" value={formatINR(totals.total)} bold />
              <Row label="Cost" value={formatINR(totals.cost)} muted />
              <Row label="Profit" value={formatINR(totals.profit)} tone={totals.profit >= 0 ? 'success' : 'danger'} />
              <Row label="Margin" value={`${totals.margin}%`} muted />
              {num(payAmount) > 0 && (
                <>
                  <div className="my-2 border-t border-[var(--border)]" />
                  <Row label="Paying now" value={formatINR(Math.min(num(payAmount), totals.total))} />
                  <Row label="Outstanding" value={formatINR(Math.max(0, totals.total - num(payAmount)))} tone="danger" />
                </>
              )}
              {lines.length > 0 && totals.margin < 15 && (
                <Callout tone={totals.margin < 0 ? 'danger' : 'warning'} icon={AlertTriangle} className="mt-3">
                  {totals.margin < 0
                    ? `This order loses ${formatINR(Math.abs(totals.profit))}. Selling below cost.`
                    : `Low margin — only ${totals.margin}%. Consider raising the price.`}
                </Callout>
              )}
              {oversoldLines.length > 0 && (
                <Callout tone="warning" icon={AlertTriangle} className="mt-3">
                  Insufficient stock for {oversoldLines.join(', ')}. The order can still be placed — stock will show as 0.
                </Callout>
              )}
              {renewalSub && <Badge tone="accent" className="mt-2">Linked renewal chain</Badge>}
              <Button variant="primary" className="mt-3 w-full" onClick={submit} disabled={!customerId || lines.length === 0}>
                <Plus className="h-3.5 w-3.5" /> Create Order
              </Button>
            </div>
          </Card>
        </div>
      </div>

      <CustomerForm open={newCust} onClose={() => setNewCust(false)} onSaved={(c) => { setCustomerId(c.id); setStep(2); }} />
    </>
  );
}

function Row({ label, value, bold, muted, tone }: { label: string; value: string; bold?: boolean; muted?: boolean; tone?: 'success' | 'danger' }) {
  return (
    <div className="flex justify-between gap-2">
      <span className={cn('text-[12.5px]', muted ? 'text-[var(--muted-2)]' : 'text-[var(--muted)]')}>{label}</span>
      <span className={cn('tabular-nums', bold ? 'text-[14.5px] font-semibold' : 'text-[13px]')} style={tone ? { color: `var(--${tone})` } : undefined}>{value}</span>
    </div>
  );
}

export default function NewOrderPage() {
  return <Suspense fallback={null}><NewOrderInner /></Suspense>;
}
