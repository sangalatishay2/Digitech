'use client';

import { use, useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import {
  Avatar, Badge, Button, Card, CardHeader, EmptyState, Field, Input, Modal,
  Select, StatusBadge, Table, Td, Th,
} from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { ORDER_TRANSITIONS } from '@/lib/services/business';
import { formatDate, formatDateTime, formatINR, num } from '@/lib/utils';
import { PAYMENT_METHOD, type OrderStatus, type PaymentMethod } from '@/lib/types';
import { ArrowLeft, FileText, IndianRupee, RotateCcw, Zap } from 'lucide-react';

export default function OrderDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { db, addPayment, updateOrderStatus, createInvoiceForOrder, completeActivation } = useStore();
  const toast = useToast();
  const [payOpen, setPayOpen] = useState(false);
  const [refundOpen, setRefundOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('upi');
  const [ref, setRef] = useState('');

  const order = db.orders.find((o) => o.id === id);
  if (!order) return <EmptyState title="Order not found" action={<Link href="/orders"><Button>Back</Button></Link>} />;

  const customer = db.customers.find((c) => c.id === order.customer_id);
  const payments = db.payments.filter((p) => p.order_id === order.id).sort((a, b) => b.paid_at.localeCompare(a.paid_at));
  const activations = db.activations.filter((a) => a.order_id === order.id);
  const subs = db.subscriptions.filter((s) => s.order_id === order.id);
  const invoice = db.invoices.find((i) => i.order_id === order.id);
  const prevSub = order.renewal_of_subscription_id ? db.subscriptions.find((s) => s.id === order.renewal_of_subscription_id) : null;
  const nextStatuses = ORDER_TRANSITIONS[order.status];

  const record = (isRefund: boolean) => {
    const amt = num(amount);
    if (amt <= 0) return;
    if (!isRefund && amt > order.outstanding + 0.01) {
      toast({ title: 'Amount exceeds outstanding', description: `Outstanding is ${formatINR(order.outstanding)}`, tone: 'error' });
      return;
    }
    if (isRefund && amt > order.amount_paid - order.amount_refunded + 0.01) {
      toast({ title: 'Refund exceeds paid amount', tone: 'error' });
      return;
    }
    addPayment(order.id, amt, method, { reference: ref, isRefund });
    toast({ title: isRefund ? 'Refund recorded' : 'Payment recorded', tone: isRefund ? 'warning' : 'success' });
    setAmount(''); setRef(''); setPayOpen(false); setRefundOpen(false);
  };

  return (
    <>
      <div className="mb-3"><Link href="/orders" className="inline-flex items-center gap-1 text-[12.5px] text-[var(--muted)] hover:text-[var(--fg)]"><ArrowLeft className="h-3 w-3" /> Orders</Link></div>
      <PageHeader
        title={order.order_number}
        description={`Placed ${formatDateTime(order.ordered_at)}${prevSub ? ' · renewal order' : ''}`}
        actions={
          <>
            {order.outstanding > 0 && <Button variant="primary" onClick={() => setPayOpen(true)}><IndianRupee className="h-3.5 w-3.5" /> Add Payment</Button>}
            {order.amount_paid > order.amount_refunded && <Button variant="outline" onClick={() => setRefundOpen(true)}><RotateCcw className="h-3.5 w-3.5" /> Refund</Button>}
            {invoice ? (
              <Link href={`/invoices/${invoice.id}`}><Button variant="outline"><FileText className="h-3.5 w-3.5" /> View Invoice</Button></Link>
            ) : (
              <Button variant="outline" onClick={() => { const i = createInvoiceForOrder(order.id); toast({ title: i ? `Invoice ${i.invoice_number} created` : 'Failed' }); }}>
                <FileText className="h-3.5 w-3.5" /> Generate Invoice
              </Button>
            )}
          </>
        }
      />

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <div className="space-y-4">
          <Card>
            <CardHeader title="Line items" subtitle="Costs shown are the immutable snapshot from the time of sale" />
            <Table>
              <thead><tr><Th>Product</Th><Th>Supplier</Th><Th className="text-right">Qty</Th><Th className="text-right">Price</Th><Th className="text-right">Disc</Th><Th className="text-right">Cost</Th><Th className="text-right">Total</Th><Th className="text-right">Profit</Th></tr></thead>
              <tbody>
                {order.items.map((i) => (
                  <tr key={i.id}>
                    <Td>
                      <p className="font-medium">{i.product_name}</p>
                      <p className="text-[11.5px] text-[var(--muted)]">{i.product_code} · {i.duration_days ? `${i.duration_days}d` : 'one-time'} · {i.delivery_type.replace('_', ' ')}</p>
                    </Td>
                    <Td className="text-[12.5px] text-[var(--muted)]">{i.supplier_name ?? '—'}</Td>
                    <Td className="text-right tabular-nums">{i.quantity}</Td>
                    <Td className="text-right tabular-nums">{formatINR(i.unit_price)}</Td>
                    <Td className="text-right tabular-nums">{i.discount ? formatINR(i.discount) : '—'}</Td>
                    <Td className="text-right tabular-nums text-[var(--muted)]">{formatINR(i.line_cost)}</Td>
                    <Td className="text-right tabular-nums font-medium">{formatINR(i.line_total)}</Td>
                    <Td className="text-right tabular-nums" style={{ color: i.line_profit >= 0 ? 'var(--success)' : 'var(--danger)' }}>{formatINR(i.line_profit)}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Card>

          <Card>
            <CardHeader title="Activations" subtitle="Delivery queue for this order" action={<Link href="/activations" className="text-[12.5px] text-[var(--accent)] hover:underline">Queue</Link>} />
            {activations.length === 0 ? <EmptyState compact icon={Zap} title="No activations" message="Activations are created automatically once the order is paid." /> : (
              <ul className="divide-y divide-[var(--border)]">
                {activations.map((a) => (
                  <li key={a.id} className="flex flex-wrap items-center gap-2 px-4 py-2.5">
                    <Zap className="h-3.5 w-3.5 text-[var(--muted)]" />
                    <span className="flex-1 truncate text-[13px]">{a.product_name}</span>
                    <StatusBadge status={a.status} />
                    {a.expiry_date && <span className="text-[11.5px] text-[var(--muted)]">exp {formatDate(a.expiry_date)}</span>}
                    {!['delivered', 'cancelled'].includes(a.status) && (
                      <Button size="sm" onClick={() => { completeActivation(a.id); toast({ title: 'Marked delivered', description: 'Subscription created if applicable.' }); }}>
                        Mark Delivered
                      </Button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card>
            <CardHeader title="Payments" subtitle={`${formatINR(order.amount_paid)} received · ${formatINR(order.outstanding)} outstanding`} />
            {payments.length === 0 ? <EmptyState title="No payments recorded" message="Add a payment to move this order forward." /> : (
              <Table>
                <thead><tr><Th>Date</Th><Th>Method</Th><Th>Reference</Th><Th>Type</Th><Th className="text-right">Amount</Th></tr></thead>
                <tbody>
                  {payments.map((p) => (
                    <tr key={p.id}>
                      <Td className="text-[12.5px]">{formatDateTime(p.paid_at)}</Td>
                      <Td className="text-[12.5px] capitalize">{p.method.replace('_', ' ')}</Td>
                      <Td className="text-[12.5px] text-[var(--muted)]">{p.reference ?? '—'}</Td>
                      <Td><Badge tone={p.is_refund ? 'danger' : 'success'}>{p.is_refund ? 'refund' : 'payment'}</Badge></Td>
                      <Td className="text-right tabular-nums" style={p.is_refund ? { color: 'var(--danger)' } : undefined}>{p.is_refund ? '-' : ''}{formatINR(p.amount)}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            )}
          </Card>

          {subs.length > 0 && (
            <Card>
              <CardHeader title="Subscriptions created" />
              <ul className="divide-y divide-[var(--border)]">
                {subs.map((s) => (
                  <li key={s.id} className="flex items-center gap-2 px-4 py-2.5 text-[13px]">
                    <span className="flex-1 truncate">{s.product_name}</span>
                    <span className="text-[12.5px] text-[var(--muted)]">{formatDate(s.start_date)} → {formatDate(s.expiry_date)}</span>
                    <StatusBadge status={s.status} />
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader title="Customer" />
            <div className="p-4">
              {customer ? (
                <Link href={`/customers/${customer.id}`} className="flex items-center gap-3 hover:opacity-80">
                  <Avatar name={customer.name} size={38} />
                  <div className="min-w-0">
                    <p className="truncate font-medium">{customer.name}</p>
                    <p className="truncate text-[12.5px] text-[var(--muted)]">{customer.phone ?? customer.email}</p>
                  </div>
                </Link>
              ) : <p className="text-[12.5px] text-[var(--muted)]">Unknown customer</p>}
            </div>
          </Card>

          <Card>
            <CardHeader title="Financials" />
            <div className="space-y-2 p-4 text-[13px]">
              <Row label="Subtotal" value={formatINR(order.subtotal)} />
              <Row label="Discount" value={`- ${formatINR(order.discount)}`} />
              <Row label="Total" value={formatINR(order.total)} bold />
              <Row label="Cost" value={formatINR(order.total_cost)} />
              <Row label="Profit" value={formatINR(order.profit)} tone={order.profit >= 0 ? 'success' : 'danger'} />
              <Row label="Margin" value={`${order.margin}%`} />
              <div className="my-1 border-t border-[var(--border)]" />
              <Row label="Paid" value={formatINR(order.amount_paid)} />
              {order.amount_refunded > 0 && <Row label="Refunded" value={formatINR(order.amount_refunded)} tone="danger" />}
              <Row label="Outstanding" value={formatINR(order.outstanding)} tone={order.outstanding > 0 ? 'danger' : 'success'} />
            </div>
          </Card>

          <Card>
            <CardHeader title="Order state" subtitle="Transitions are enforced by the state machine" />
            <div className="space-y-3 p-4">
              <div className="flex flex-wrap gap-2">
                <StatusBadge status={order.status} />
                <StatusBadge status={order.payment_status} />
              </div>
              {nextStatuses.length === 0 ? (
                <p className="text-[12.5px] text-[var(--muted)]">This order is in a terminal state.</p>
              ) : (
                <div className="flex flex-wrap gap-1.5">
                  {nextStatuses.map((s) => (
                    <Button key={s} size="sm" variant="outline" onClick={() => { updateOrderStatus(order.id, s as OrderStatus); toast({ title: `Order → ${s.replace(/_/g, ' ')}` }); }}>
                      {s.replace(/_/g, ' ')}
                    </Button>
                  ))}
                </div>
              )}
              {prevSub && (
                <div className="rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] p-2.5">
                  <p className="text-[11.5px] font-semibold">Renewal chain</p>
                  <p className="mt-0.5 text-[11.5px] text-[var(--muted)]">Renews: {prevSub.product_name} (expired {formatDate(prevSub.expiry_date)})</p>
                </div>
              )}
              {order.notes && <p className="rounded-md bg-[var(--surface-2)] p-2 text-[12.5px] text-[var(--muted)]">{order.notes}</p>}
            </div>
          </Card>
        </div>
      </div>

      <Modal open={payOpen} onClose={() => setPayOpen(false)} title="Add payment" description={`Outstanding: ${formatINR(order.outstanding)}`}
        footer={<><Button onClick={() => setPayOpen(false)}>Cancel</Button><Button variant="primary" onClick={() => record(false)}>Record payment</Button></>}>
        <div className="space-y-3">
          <Field label="Amount (₹)"><Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder={String(order.outstanding)} /></Field>
          <Field label="Method"><Select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>{PAYMENT_METHOD.map((m) => <option key={m} value={m}>{m.replace('_', ' ')}</option>)}</Select></Field>
          <Field label="Reference"><Input value={ref} onChange={(e) => setRef(e.target.value)} /></Field>
          <Button size="sm" variant="outline" onClick={() => setAmount(String(order.outstanding))}>Full outstanding</Button>
        </div>
      </Modal>

      <Modal open={refundOpen} onClose={() => setRefundOpen(false)} title="Record refund" description={`Refundable: ${formatINR(order.amount_paid - order.amount_refunded)}`}
        footer={<><Button onClick={() => setRefundOpen(false)}>Cancel</Button><Button variant="danger" onClick={() => record(true)}>Record refund</Button></>}>
        <div className="space-y-3">
          <Field label="Amount (₹)"><Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
          <Field label="Method"><Select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>{PAYMENT_METHOD.map((m) => <option key={m} value={m}>{m.replace('_', ' ')}</option>)}</Select></Field>
          <Field label="Reference"><Input value={ref} onChange={(e) => setRef(e.target.value)} /></Field>
        </div>
      </Modal>
    </>
  );
}

function Row({ label, value, bold, tone }: { label: string; value: string; bold?: boolean; tone?: 'success' | 'danger' }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-[12.5px] text-[var(--muted)]">{label}</span>
      <span className={bold ? 'text-[14.5px] font-semibold tabular-nums' : 'text-[13px] tabular-nums'} style={tone ? { color: `var(--${tone})` } : undefined}>{value}</span>
    </div>
  );
}
