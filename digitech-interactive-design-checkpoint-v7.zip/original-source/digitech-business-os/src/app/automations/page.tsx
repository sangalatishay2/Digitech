'use client';

import { useState } from 'react';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Badge, Button, Card, CardHeader, EmptyState, Field, Input, Modal, Select, Switch, Table, Tabs, Td, Textarea, Th, Tooltip } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { newId, nowIso, WEBHOOK_EVENTS } from '@/lib/services/business';
import { formatDateTime, relativeTime, cn } from '@/lib/utils';
import type { AutomationRule } from '@/lib/types';
import { ArrowRight, Copy, Plus, Workflow, Zap } from 'lucide-react';

const TRIGGERS = [
  'subscription.expiring', 'subscription.expired', 'payment.overdue', 'lead.followup_due',
  'activation.overdue', 'support.sla_breach', 'product.low_stock', 'supplier.payment_due',
  'customer.inactive_90d', 'order.created', 'payment.received', 'renewal.completed',
];

export default function AutomationsPage() {
  const { db, update } = useStore();
  const toast = useToast();
  const [tab, setTab] = useState('rules');
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: '', description: '', trigger_event: TRIGGERS[0], action_type: 'notification' as AutomationRule['action_type'], webhook_url: '', template: '' });

  const toggle = (r: AutomationRule) => {
    update((d) => {
      const rule = d.automation_rules.find((x) => x.id === r.id);
      if (rule) rule.is_active = !rule.is_active;
    });
    toast({ title: r.is_active ? 'Rule paused' : 'Rule activated' });
  };

  const runNow = (r: AutomationRule) => {
    update((d) => {
      const rule = d.automation_rules.find((x) => x.id === r.id);
      if (!rule) return;
      rule.last_run_at = nowIso();
      rule.run_count += 1;
      let matched = 0;
      if (r.trigger_event === 'subscription.expiring') matched = d.subscriptions.filter((s) => s.status === 'expiring').length;
      else if (r.trigger_event === 'payment.overdue') matched = d.orders.filter((o) => o.outstanding > 0).length;
      else if (r.trigger_event === 'product.low_stock') matched = d.products.filter((p) => p.stock !== null && p.stock <= p.low_stock_threshold).length;
      else if (r.trigger_event === 'activation.overdue') matched = d.activations.filter((a) => ['ready', 'waiting_supplier'].includes(a.status)).length;
      else if (r.trigger_event === 'lead.followup_due') matched = d.leads.filter((l) => l.follow_up_at && new Date(l.follow_up_at) <= new Date()).length;
      else if (r.trigger_event === 'support.sla_breach') matched = d.support_tickets.filter((t) => t.due_at && new Date(t.due_at) < new Date() && !['resolved', 'closed'].includes(t.status)).length;
      d.automation_logs.unshift({
        id: newId(),
        organization_id: d.organizations[0].id,
        created_at: nowIso(),
        updated_at: nowIso(),
        deleted_at: null,
        rule_id: r.id,
        event: r.trigger_event,
        status: matched > 0 ? 'success' : 'skipped',
        message: matched > 0 ? `Matched ${matched} record(s) — ${r.action_type} action dispatched` : 'No records matched the trigger conditions',
      });
    });
    toast({ title: 'Rule evaluated', description: 'See the run history tab for the result.' });
  };

  const create = () => {
    if (!f.name.trim()) return;
    update((d) => {
      d.automation_rules.unshift({
        id: newId(),
        organization_id: d.organizations[0].id,
        created_at: nowIso(),
        updated_at: nowIso(),
        deleted_at: null,
        name: f.name,
        description: f.description || null,
        trigger_event: f.trigger_event,
        conditions: {},
        action_type: f.action_type,
        action_config: { webhook_url: f.webhook_url, template: f.template },
        is_active: true,
        last_run_at: null,
        run_count: 0,
      });
    });
    toast({ title: 'Automation rule created' });
    setF({ name: '', description: '', trigger_event: TRIGGERS[0], action_type: 'notification', webhook_url: '', template: '' });
    setOpen(false);
  };

  const samplePayload = JSON.stringify({
    event: 'subscription.expiring',
    organization_id: db.organizations[0].id,
    occurred_at: new Date().toISOString(),
    data: {
      subscription_id: 'uuid',
      customer: { id: 'uuid', name: 'Rahul Sharma', whatsapp: '+919876543210' },
      product_name: 'Canva Pro — 12 Months',
      expiry_date: '2026-09-15',
      days_remaining: 7,
      renewal_price: 1299,
    },
  }, null, 2);

  return (
    <>
      <PageHeader title="Automations" description="Rule engine + n8n-ready webhook events"
        actions={<Button variant="primary" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5" /> New Rule</Button>} />

      <Card className="mb-4">
        <Tabs value={tab} onChange={setTab} className="px-2" tabs={[
          { id: 'rules', label: 'Rules', count: db.automation_rules.length },
          { id: 'logs', label: 'Run History', count: db.automation_logs.length },
          { id: 'webhooks', label: 'Webhooks & n8n' },
        ]} />
      </Card>

      {tab === 'rules' && (
        <Card>
          {db.automation_rules.length === 0 ? (
            <EmptyState
              icon={Workflow}
              title="No automation rules yet"
              message="Create a rule to react automatically to expiries, payments and SLA breaches."
            />
          ) : (
            <div className="divide-y divide-[var(--border-subtle)]">
              {db.automation_rules.map((r) => {
                const ok = db.automation_logs.filter((l) => l.rule_id === r.id && l.status === 'success').length;
                const total = db.automation_logs.filter((l) => l.rule_id === r.id).length;
                const rate = total ? Math.round((ok / total) * 100) : null;
                return (
                  <div
                    key={r.id}
                    className="flex flex-wrap items-center gap-x-4 gap-y-3 px-4 py-3.5 transition-colors hover:bg-[var(--surface-2)]/50"
                  >
                    <span
                      className={cn(
                        'flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-[9px]',
                        r.is_active ? 'bg-[var(--accent-soft)]' : 'bg-[var(--surface-3)]',
                      )}
                    >
                      <Zap
                        className="h-[16px] w-[16px]"
                        style={{ color: r.is_active ? 'var(--accent)' : 'var(--muted-2)' }}
                      />
                    </span>

                    <div className="min-w-[210px] flex-1">
                      <p className="text-[13.5px] font-medium leading-tight">{r.name}</p>
                      <p className="mt-1 flex flex-wrap items-center gap-1.5 text-[11.5px] text-[var(--muted)]">
                        <code className="rounded-[4px] bg-[var(--surface-3)] px-1.5 py-[1px] font-mono text-[10.5px]">
                          {r.trigger_event}
                        </code>
                        <ArrowRight className="h-3 w-3 opacity-50" />
                        <span className="capitalize">{r.action_type.replace(/_/g, ' ')}</span>
                      </p>
                    </div>

                    <div className="w-[104px] shrink-0">
                      <p className="text-[10.5px] font-medium uppercase tracking-[0.04em] text-[var(--muted-2)]">
                        Last run
                      </p>
                      <p className="mt-0.5 text-[12px] tabular-nums text-[var(--fg-soft)]">
                        {r.last_run_at ? relativeTime(r.last_run_at) : 'Never'}
                      </p>
                    </div>

                    <div className="w-[86px] shrink-0">
                      <p className="text-[10.5px] font-medium uppercase tracking-[0.04em] text-[var(--muted-2)]">
                        Success
                      </p>
                      <p className="mt-0.5 text-[12px] font-medium tabular-nums">
                        {rate === null ? (
                          <span className="text-[var(--muted-2)]">—</span>
                        ) : (
                          <span style={{ color: rate >= 90 ? 'var(--success)' : rate >= 60 ? 'var(--warning)' : 'var(--danger)' }}>
                            {rate}%
                          </span>
                        )}
                        <span className="ml-1 text-[10.5px] font-normal text-[var(--muted-2)]">
                          ({r.run_count})
                        </span>
                      </p>
                    </div>

                    <div className="flex shrink-0 items-center gap-2">
                      <Button size="sm" variant="outline" onClick={() => runNow(r)}>
                        Run now
                      </Button>
                      <Tooltip label={r.is_active ? 'Pause rule' : 'Activate rule'}>
                        <Switch checked={r.is_active} onChange={() => toggle(r)} label={r.name} />
                      </Tooltip>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      )}

      {tab === 'logs' && (
        <Card>
          <CardHeader title="Run history" />
          {db.automation_logs.length === 0 ? <EmptyState title="No runs yet" message="Trigger a rule with “Run now” to see results." /> : (
            <Table>
              <thead><tr><Th>Time</Th><Th>Rule</Th><Th>Event</Th><Th>Status</Th><Th>Message</Th></tr></thead>
              <tbody>
                {db.automation_logs.map((l) => (
                  <tr key={l.id}>
                    <Td className="whitespace-nowrap text-[12.5px]">{formatDateTime(l.created_at)}</Td>
                    <Td className="text-[13px]">{db.automation_rules.find((r) => r.id === l.rule_id)?.name ?? '—'}</Td>
                    <Td><code className="text-[11.5px]">{l.event}</code></Td>
                    <Td><Badge tone={l.status === 'success' ? 'success' : l.status === 'failed' ? 'danger' : 'neutral'}>{l.status}</Badge></Td>
                    <Td className="text-[12.5px] text-[var(--muted)]">{l.message}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>
      )}

      {tab === 'webhooks' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader title="Emitted events" subtitle="Point an n8n Webhook node at your endpoint and subscribe" />
            <ul className="divide-y divide-[var(--border)]">
              {WEBHOOK_EVENTS.map((e) => (
                <li key={e} className="flex items-center gap-2 px-4 py-2">
                  <code className="text-[12.5px]">{e}</code>
                  <button
                    onClick={() => { navigator.clipboard.writeText(e); toast({ title: 'Event name copied' }); }}
                    className="ml-auto rounded p-1 text-[var(--muted)] hover:bg-[var(--surface-2)]"
                  >
                    <Copy className="h-3 w-3" />
                  </button>
                </li>
              ))}
            </ul>
          </Card>
          <Card>
            <CardHeader title="Sample payload" subtitle="Stable JSON contract for every event" />
            <pre className="overflow-x-auto p-4 text-[11.5px] leading-relaxed text-[var(--muted)]">{samplePayload}</pre>
          </Card>
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="New automation rule" width="lg"
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" onClick={create}>Create rule</Button></>}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Rule name *" className="sm:col-span-2"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
          <Field label="Trigger event">
            <Select value={f.trigger_event} onChange={(e) => setF({ ...f, trigger_event: e.target.value })}>
              {TRIGGERS.map((t) => <option key={t} value={t}>{t}</option>)}
            </Select>
          </Field>
          <Field label="Action">
            <Select value={f.action_type} onChange={(e) => setF({ ...f, action_type: e.target.value as AutomationRule['action_type'] })}>
              {['notification', 'whatsapp', 'email', 'task', 'webhook'].map((a) => <option key={a} value={a}>{a}</option>)}
            </Select>
          </Field>
          {f.action_type === 'webhook' && (
            <Field label="Webhook URL (e.g. n8n)" className="sm:col-span-2"><Input value={f.webhook_url} onChange={(e) => setF({ ...f, webhook_url: e.target.value })} placeholder="https://n8n.example.com/webhook/digitech" /></Field>
          )}
          {(f.action_type === 'whatsapp' || f.action_type === 'email') && (
            <Field label="Template" className="sm:col-span-2">
              <Select value={f.template} onChange={(e) => setF({ ...f, template: e.target.value })}>
                <option value="">Select template…</option>
                {db.message_templates.map((t) => <option key={t.id} value={t.name}>{t.name}</option>)}
              </Select>
            </Field>
          )}
          <Field label="Description" className="sm:col-span-2"><Textarea rows={2} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
        </div>
      </Modal>
    </>
  );
}
