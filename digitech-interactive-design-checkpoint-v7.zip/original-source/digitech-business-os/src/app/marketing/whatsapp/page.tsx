'use client';

import { useMemo, useState } from 'react';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Badge, Button, Card, CardHeader, EmptyState, Field, Input, Modal, Select, Table, Tabs, Td, Textarea, Th } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { newId, nowIso, renderTemplate } from '@/lib/services/business';
import { activeProvider, TEMPLATE_VARIABLES, WhatsAppLinkProvider } from '@/lib/services/whatsapp';
import { daysUntil, formatDate, formatDateTime } from '@/lib/utils';
import type { MessageTemplate } from '@/lib/types';
import { MessageCircle, Plus, Send } from 'lucide-react';

export default function WhatsAppPage() {
  const { db, update } = useStore();
  const toast = useToast();
  const [tab, setTab] = useState('compose');
  const [templateId, setTemplateId] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [body, setBody] = useState('');
  const [tplOpen, setTplOpen] = useState(false);
  const [tpl, setTpl] = useState({ name: '', body: '' });

  const provider = activeProvider();
  const linkProvider = new WhatsAppLinkProvider();
  const customer = db.customers.find((c) => c.id === customerId);

  const vars = useMemo(() => {
    const sub = db.subscriptions.find((s) => s.customer_id === customerId && (s.status === 'active' || s.status === 'expiring'));
    const order = db.orders.find((o) => o.customer_id === customerId);
    return {
      customer_name: customer?.name ?? 'Customer',
      product_name: sub?.product_name ?? 'your subscription',
      expiry_date: sub ? formatDate(sub.expiry_date) : '—',
      days_remaining: sub ? daysUntil(sub.expiry_date) : 0,
      order_id: order?.order_number ?? '—',
      payment_due: order?.outstanding ?? 0,
      renewal_price: sub?.purchase_amount ?? 0,
    };
  }, [customerId, customer, db]);

  const preview = renderTemplate(body, vars);

  const applyTemplate = (id: string) => {
    setTemplateId(id);
    const t = db.message_templates.find((x) => x.id === id);
    if (t) setBody(t.body);
  };

  const send = async () => {
    if (!customer || !preview.trim()) { toast({ title: 'Pick a customer and write a message', tone: 'error' }); return; }
    const to = customer.whatsapp ?? customer.phone ?? '';
    if (!to) { toast({ title: 'Customer has no WhatsApp number', tone: 'error' }); return; }
    const res = await linkProvider.send({ to, body: preview, channel: 'whatsapp' });
    update((d) => {
      d.communication_logs.unshift({
        id: newId(),
        organization_id: d.organizations[0].id,
        created_at: nowIso(),
        updated_at: nowIso(),
        deleted_at: null,
        channel: 'whatsapp',
        direction: 'outbound',
        customer_id: customer.id,
        template_id: templateId || null,
        to_address: to,
        body: preview,
        status: res.status === 'sent' ? 'sent' : 'failed',
        provider: linkProvider.id,
        error: res.error ?? null,
      });
    });
    toast({ title: 'WhatsApp opened', description: 'Message logged to the communication history.' });
  };

  const saveTemplate = () => {
    if (!tpl.name.trim() || !tpl.body.trim()) return;
    const used = TEMPLATE_VARIABLES.filter((v) => tpl.body.includes(`{{${v}}}`));
    update((d) => {
      const t: MessageTemplate = {
        id: newId(),
        organization_id: d.organizations[0].id,
        created_at: nowIso(),
        updated_at: nowIso(),
        deleted_at: null,
        name: tpl.name,
        channel: 'whatsapp',
        subject: null,
        body: tpl.body,
        variables: used,
        is_active: true,
      };
      d.message_templates.unshift(t);
    });
    toast({ title: 'Template saved' });
    setTpl({ name: '', body: '' });
    setTplOpen(false);
  };

  return (
    <>
      <PageHeader
        title="WhatsApp"
        description={`Provider-agnostic messaging · active: ${provider.label}`}
        actions={<Button variant="primary" onClick={() => setTplOpen(true)}><Plus className="h-3.5 w-3.5" /> New Template</Button>}
      />

      <Card className="mb-4">
        <Tabs value={tab} onChange={setTab} className="px-2" tabs={[
          { id: 'compose', label: 'Compose' },
          { id: 'templates', label: 'Templates', count: db.message_templates.length },
          { id: 'logs', label: 'History', count: db.communication_logs.length },
        ]} />
      </Card>

      {tab === 'compose' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader title="Compose message" />
            <div className="space-y-3 p-4">
              <Field label="Customer">
                <Select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
                  <option value="">Select customer…</option>
                  {db.customers.filter((c) => !c.deleted_at).map((c) => <option key={c.id} value={c.id}>{c.name} — {c.phone}</option>)}
                </Select>
              </Field>
              <Field label="Template">
                <Select value={templateId} onChange={(e) => applyTemplate(e.target.value)}>
                  <option value="">Free-form message</option>
                  {db.message_templates.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </Select>
              </Field>
              <Field label="Message body" hint={`Variables: ${TEMPLATE_VARIABLES.map((v) => `{{${v}}}`).join(' ')}`}>
                <Textarea rows={6} value={body} onChange={(e) => setBody(e.target.value)} />
              </Field>
              <Button variant="primary" onClick={send} disabled={!customerId}><Send className="h-3.5 w-3.5" /> Send via WhatsApp</Button>
            </div>
          </Card>

          <Card>
            <CardHeader title="Preview" subtitle="Variables resolved against live data" />
            <div className="p-4">
              <div className="rounded-[10px] rounded-tl-none bg-[var(--success-soft)] p-3 text-[13px]" style={{ color: 'var(--fg)' }}>
                {preview || <span className="text-[var(--muted)]">Your message preview appears here…</span>}
              </div>
              <div className="mt-3 space-y-1 text-[11.5px] text-[var(--muted)]">
                {Object.entries(vars).map(([k, v]) => (
                  <p key={k}><code>{`{{${k}}}`}</code> → {String(v)}</p>
                ))}
              </div>
            </div>
          </Card>
        </div>
      )}

      {tab === 'templates' && (
        <Card>
          <CardHeader title="Message templates" />
          {db.message_templates.length === 0 ? <EmptyState icon={MessageCircle} title="No templates" /> : (
            <ul className="divide-y divide-[var(--border)]">
              {db.message_templates.map((t) => (
                <li key={t.id} className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <p className="text-[13px] font-medium">{t.name}</p>
                    <Badge tone="accent">{t.channel}</Badge>
                    {t.is_active && <Badge tone="success">active</Badge>}
                  </div>
                  <p className="mt-1 text-[12.5px] text-[var(--muted)]">{t.body}</p>
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {t.variables.map((v) => <Badge key={v}>{`{{${v}}}`}</Badge>)}
                  </div>
                  <Button size="sm" className="mt-2" onClick={() => { setTab('compose'); applyTemplate(t.id); }}>Use template</Button>
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}

      {tab === 'logs' && (
        <Card>
          <CardHeader title="Communication history" />
          {db.communication_logs.length === 0 ? <EmptyState icon={MessageCircle} title="No messages sent yet" /> : (
            <Table>
              <thead><tr><Th>Sent</Th><Th>Customer</Th><Th>To</Th><Th>Message</Th><Th>Status</Th></tr></thead>
              <tbody>
                {db.communication_logs.map((l) => (
                  <tr key={l.id}>
                    <Td className="whitespace-nowrap text-[12.5px]">{formatDateTime(l.created_at)}</Td>
                    <Td className="text-[13px]">{db.customers.find((c) => c.id === l.customer_id)?.name ?? '—'}</Td>
                    <Td className="text-[12.5px]">{l.to_address}</Td>
                    <Td className="max-w-[280px] truncate text-[12.5px] text-[var(--muted)]">{l.body}</Td>
                    <Td><Badge tone={l.status === 'failed' ? 'danger' : 'success'}>{l.status}</Badge></Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>
      )}

      <Modal open={tplOpen} onClose={() => setTplOpen(false)} title="New message template" width="lg"
        footer={<><Button onClick={() => setTplOpen(false)}>Cancel</Button><Button variant="primary" onClick={saveTemplate}>Save template</Button></>}>
        <div className="space-y-3">
          <Field label="Template name"><Input value={tpl.name} onChange={(e) => setTpl({ ...tpl, name: e.target.value })} /></Field>
          <Field label="Body" hint={`Available variables: ${TEMPLATE_VARIABLES.map((v) => `{{${v}}}`).join(', ')}`}>
            <Textarea rows={5} value={tpl.body} onChange={(e) => setTpl({ ...tpl, body: e.target.value })} placeholder="Hi {{customer_name}}, your {{product_name}} expires on {{expiry_date}}…" />
          </Field>
        </div>
      </Modal>
    </>
  );
}
