'use client';

import { useMemo } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Badge, Button, Card, CardHeader } from '@/components/ui/primitives';
import { customerStats } from '@/lib/services/analytics';
import { daysUntil, formatINR } from '@/lib/utils';
import { Megaphone, MessageCircle, Users } from 'lucide-react';

export default function CampaignsPage() {
  const { db } = useStore();

  const playbooks = useMemo(() => {
    const expiring = db.customers.filter((c) => db.subscriptions.some((s) => s.customer_id === c.id && s.status === 'expiring'));
    const lapsed = db.customers.filter((c) => db.subscriptions.some((s) => s.customer_id === c.id && s.status === 'expired'));
    const outstanding = db.customers.filter((c) => customerStats(db, c.id).outstanding > 0);
    const oneTime = db.customers.filter((c) => customerStats(db, c.id).orders === 1);
    const dormant = db.customers.filter((c) => { const s = customerStats(db, c.id); return !!s.lastPurchase && daysUntil(s.lastPurchase) < -180; });
    return [
      { id: 'renewal', name: 'Renewal Drive', goal: 'Recover expiring subscriptions before they lapse', audience: expiring, template: 'Subscription Expiry Reminder' },
      { id: 'winback', name: 'Win-Back', goal: 'Reactivate expired subscriptions with an offer', audience: lapsed, template: 'Subscription Expiry Reminder' },
      { id: 'dues', name: 'Payment Recovery', goal: 'Collect outstanding balances', audience: outstanding, template: 'Payment Reminder' },
      { id: 'upsell', name: 'Upsell One-Timers', goal: 'Convert single-purchase customers into repeat buyers', audience: oneTime, template: 'Activation Delivered' },
      { id: 'reactivate', name: 'Dormant Reactivation', goal: 'Re-engage customers inactive for 180+ days', audience: dormant, template: 'Subscription Expiry Reminder' },
    ];
  }, [db]);

  return (
    <>
      <PageHeader
        title="Campaigns"
        description="Ready-made playbooks built from live segments — open the WhatsApp console to execute"
      />

      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {playbooks.map((p) => {
          const value = p.audience.reduce((a, c) => a + customerStats(db, c.id).revenue, 0);
          return (
            <Card key={p.id} className="flex flex-col p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="rounded-[10px] bg-[var(--accent-soft)] p-2"><Megaphone className="h-4 w-4 text-[var(--accent)]" /></div>
                <Badge tone={p.audience.length > 0 ? 'accent' : 'neutral'}>{p.audience.length} recipients</Badge>
              </div>
              <p className="mt-3 text-[13.5px] font-semibold">{p.name}</p>
              <p className="mt-1 flex-1 text-[12.5px] text-[var(--muted)]">{p.goal}</p>
              <div className="mt-3 space-y-1 text-[11.5px] text-[var(--muted)]">
                <p className="flex items-center gap-1.5"><Users className="h-3 w-3" /> Audience value: {formatINR(value, { compact: true })}</p>
                <p className="flex items-center gap-1.5"><MessageCircle className="h-3 w-3" /> Template: {p.template}</p>
              </div>
              <div className="mt-3 flex gap-2">
                <Link href="/segments" className="flex-1"><Button size="sm" className="w-full">View audience</Button></Link>
                <Link href="/marketing/whatsapp" className="flex-1"><Button size="sm" variant="primary" className="w-full">Run</Button></Link>
              </div>
            </Card>
          );
        })}
      </div>

      <Card className="mt-4">
        <CardHeader title="Scheduled bulk sending" subtitle="Requires a WhatsApp Business API provider" />
        <div className="p-4 text-[12.5px] text-[var(--muted)]">
          <p>Bulk scheduling and delivery receipts activate automatically once a Cloud API provider is configured in Settings → WhatsApp. Until then, campaigns run through click-to-chat, one conversation at a time — fully logged in the communication history.</p>
        </div>
      </Card>
    </>
  );
}
