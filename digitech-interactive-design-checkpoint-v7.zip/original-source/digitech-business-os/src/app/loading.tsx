import { KpiSkeleton, Skeleton, TableSkeleton } from '@/components/ui/primitives';

/** Route-level skeleton that mirrors the common page shape: header → KPIs → table. */
export default function Loading() {
  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <Skeleton className="h-6 w-52" />
          <Skeleton className="mt-2.5 h-3 w-72" />
        </div>
        <Skeleton className="h-[34px] w-32 rounded-[7px]" />
      </div>

      <KpiSkeleton count={4} />

      <div className="card overflow-hidden">
        <div className="flex items-center gap-2 border-b border-[var(--border)] p-2.5">
          <Skeleton className="h-8 flex-1 rounded-[7px]" />
          <Skeleton className="h-8 w-24 rounded-[7px]" />
          <Skeleton className="h-8 w-20 rounded-[7px]" />
        </div>
        <TableSkeleton rows={7} cols={6} />
      </div>
    </div>
  );
}
