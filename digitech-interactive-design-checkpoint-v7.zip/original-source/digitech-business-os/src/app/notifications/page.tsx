'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Badge, Button, Card, EmptyState, Tabs } from '@/components/ui/primitives';
import { relativeTime, cn } from '@/lib/utils';
import { Bell, Check } from 'lucide-react';

const HREF: Record<string, (id: string) => string> = {
  subscription: () => '/renewals',
  order: (id) => `/orders/${id}`,
  activation: () => '/activations',
  ticket: (id) => `/support/${id}`,
  task: () => '/tasks',
  product: (id) => `/products/${id}`,
};

export default function NotificationsPage() {
  const { db, markNotificationRead, markAllNotificationsRead } = useStore();
  const [tab, setTab] = useState('all');

  const rows = db.notifications.filter((n) => {
    if (tab === 'unread') return !n.read_at;
    if (tab === 'all') return true;
    return n.severity === tab;
  });

  return (
    <>
      <PageHeader
        title="Notifications"
        description={`${db.notifications.filter((n) => !n.read_at).length} unread`}
        actions={<Button onClick={markAllNotificationsRead}><Check className="h-3.5 w-3.5" /> Mark all read</Button>}
      />
      <Card className="mb-4">
        <Tabs value={tab} onChange={setTab} className="px-2" tabs={[
          { id: 'all', label: 'All', count: db.notifications.length },
          { id: 'unread', label: 'Unread', count: db.notifications.filter((n) => !n.read_at).length },
          { id: 'critical', label: 'Critical', count: db.notifications.filter((n) => n.severity === 'critical').length },
          { id: 'warning', label: 'Warning', count: db.notifications.filter((n) => n.severity === 'warning').length },
          { id: 'info', label: 'Info', count: db.notifications.filter((n) => n.severity === 'info').length },
        ]} />
      </Card>

      {rows.length === 0 ? (
        <Card><EmptyState icon={Bell} title="All clear" message="No notifications in this view." /></Card>
      ) : (
        <div className="space-y-2">
          {rows.map((n) => {
            const href = n.entity_type && HREF[n.entity_type] ? HREF[n.entity_type](n.entity_id ?? '') : null;
            const body = (
              <Card className={cn('flex flex-wrap items-center gap-3 p-3.5', !n.read_at && 'border-[var(--accent)]/30 bg-[var(--accent-soft)]/25')}>
                <Badge tone={n.severity === 'critical' ? 'danger' : n.severity === 'warning' ? 'warning' : n.severity === 'success' ? 'success' : 'info'}>{n.severity}</Badge>
                <div className="min-w-[200px] flex-1">
                  <p className="text-[13px] font-medium">{n.title}</p>
                  <p className="text-[12.5px] text-[var(--muted)]">{n.body}</p>
                </div>
                <span className="text-[11.5px] text-[var(--muted-2)]">{relativeTime(n.created_at)}</span>
                {!n.read_at && (
                  <Button size="sm" variant="ghost" onClick={(e) => { e.preventDefault(); markNotificationRead(n.id); }}>Mark read</Button>
                )}
              </Card>
            );
            return href ? <Link key={n.id} href={href}>{body}</Link> : <div key={n.id}>{body}</div>;
          })}
        </div>
      )}
    </>
  );
}
