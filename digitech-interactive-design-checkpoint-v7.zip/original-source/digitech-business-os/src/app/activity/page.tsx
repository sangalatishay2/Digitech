'use client';

import { useMemo, useState } from 'react';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Avatar, Badge, Card, EmptyState, Select } from '@/components/ui/primitives';
import { formatDateTime, relativeTime } from '@/lib/utils';
import { History } from 'lucide-react';

export default function ActivityPage() {
  const { db } = useStore();
  const [type, setType] = useState('all');
  const [actor, setActor] = useState('all');

  const rows = useMemo(() => {
    let list = db.activity_logs;
    if (type !== 'all') list = list.filter((a) => a.record_type === type);
    if (actor !== 'all') list = list.filter((a) => a.actor_id === actor);
    return list;
  }, [db.activity_logs, type, actor]);

  const types = Array.from(new Set(db.activity_logs.map((a) => a.record_type)));

  return (
    <>
      <PageHeader title="Activity Log" description={`${db.activity_logs.length} recorded events`} actions={
        <>
          <Select value={type} onChange={(e) => setType(e.target.value)} className="h-9 w-auto text-[12.5px]">
            <option value="all">All record types</option>
            {types.map((t) => <option key={t} value={t}>{t}</option>)}
          </Select>
          <Select value={actor} onChange={(e) => setActor(e.target.value)} className="h-9 w-auto text-[12.5px]">
            <option value="all">All users</option>
            {db.profiles.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
          </Select>
        </>
      } />

      {rows.length === 0 ? (
        <Card><EmptyState icon={History} title="No activity recorded" /></Card>
      ) : (
        <Card>
          <ul className="divide-y divide-[var(--border)]">
            {rows.slice(0, 200).map((a) => (
              <li key={a.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <Avatar name={a.actor_name} size={28} />
                <div className="min-w-[200px] flex-1">
                  <p className="text-[13px]">{a.summary}</p>
                  <p className="text-[11.5px] text-[var(--muted-2)]">{a.actor_name} · {formatDateTime(a.created_at)}</p>
                </div>
                <Badge tone="accent">{a.action.replace(/_/g, ' ')}</Badge>
                <Badge>{a.record_type}</Badge>
                <span className="text-[11.5px] text-[var(--muted-2)]">{relativeTime(a.created_at)}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </>
  );
}
