'use client';

import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { DataTable, type Column } from '@/components/ui/data-table';
import { Badge, Button, Field, Input, Modal } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { supplierBalance } from '@/lib/services/suppliers';
import { formatINR } from '@/lib/utils';
import type { Supplier } from '@/lib/types';
import { Plus } from 'lucide-react';

export default function SuppliersPage() {
  const { db, createSupplier } = useStore();
  const router = useRouter();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: '', contact_person: '', email: '', phone: '', website: '', payment_terms: 'Prepaid' });

  const rows = useMemo(() => db.suppliers.filter((s) => !s.deleted_at), [db.suppliers]);

  const columns: Column<Supplier>[] = [
    { key: 'name', header: 'Supplier', sortValue: (s) => s.name, exportValue: (s) => s.name, render: (s) => (
      <div><p className="font-medium">{s.name}</p><p className="text-[11.5px] text-[var(--muted)]">{s.contact_person ?? '—'}</p></div>
    ) },
    { key: 'contact', header: 'Contact', sortValue: (s) => s.email ?? '', exportValue: (s) => `${s.phone ?? ''} ${s.email ?? ''}`, render: (s) => (
      <div className="text-[12.5px]"><p>{s.phone ?? '—'}</p><p className="text-[var(--muted)]">{s.email ?? '—'}</p></div>
    ) },
    { key: 'terms', header: 'Terms', sortValue: (s) => s.payment_terms ?? '', exportValue: (s) => s.payment_terms ?? '', render: (s) => <span className="text-[12.5px]">{s.payment_terms ?? '—'}</span> },
    { key: 'products', header: 'Products', className: 'text-right', sortValue: (s) => db.products.filter((p) => p.supplier_id === s.id).length, exportValue: (s) => db.products.filter((p) => p.supplier_id === s.id).length, render: (s) => <span className="tabular-nums">{db.products.filter((p) => p.supplier_id === s.id).length}</span> },
    { key: 'purchased', header: 'Purchased (cost)', className: 'text-right', sortValue: (s) => supplierBalance(db, s.id).purchased, exportValue: (s) => supplierBalance(db, s.id).purchased, render: (s) => <span className="tabular-nums">{formatINR(supplierBalance(db, s.id).purchased)}</span> },
    { key: 'paid', header: 'Paid', className: 'text-right', sortValue: (s) => supplierBalance(db, s.id).paid, exportValue: (s) => supplierBalance(db, s.id).paid, render: (s) => <span className="tabular-nums">{formatINR(supplierBalance(db, s.id).paid)}</span> },
    { key: 'balance', header: 'Outstanding', className: 'text-right', sortValue: (s) => supplierBalance(db, s.id).balance, exportValue: (s) => supplierBalance(db, s.id).balance, render: (s) => {
      const b = supplierBalance(db, s.id).balance;
      return b > 0 ? <Badge tone="danger">{formatINR(b)}</Badge> : <Badge tone="success">settled</Badge>;
    } },
  ];

  const submit = () => {
    if (!f.name.trim()) return;
    createSupplier(f);
    toast({ title: 'Supplier created' });
    setF({ name: '', contact_person: '', email: '', phone: '', website: '', payment_terms: 'Prepaid' });
    setOpen(false);
  };

  return (
    <>
      <PageHeader title="Suppliers" description={`${rows.length} suppliers`} actions={<Button variant="primary" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5" /> New Supplier</Button>} />
      <DataTable rows={rows} columns={columns} exportName="suppliers" onRowClick={(s) => router.push(`/suppliers/${s.id}`)} searchable={(s) => `${s.name} ${s.email} ${s.contact_person}`} />
      <Modal open={open} onClose={() => setOpen(false)} title="New supplier" width="lg"
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" onClick={submit}>Create</Button></>}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Name *" className="sm:col-span-2"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
          <Field label="Contact person"><Input value={f.contact_person} onChange={(e) => setF({ ...f, contact_person: e.target.value })} /></Field>
          <Field label="Phone"><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
          <Field label="Email"><Input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
          <Field label="Website"><Input value={f.website} onChange={(e) => setF({ ...f, website: e.target.value })} /></Field>
          <Field label="Payment terms"><Input value={f.payment_terms} onChange={(e) => setF({ ...f, payment_terms: e.target.value })} /></Field>
        </div>
      </Modal>
    </>
  );
}
