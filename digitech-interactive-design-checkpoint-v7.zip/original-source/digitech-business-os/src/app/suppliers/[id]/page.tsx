'use client';

import { use, useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Button, Card, EmptyState, Field, Input, Modal, Select, Table, Tabs, Td, Th } from '@/components/ui/primitives';
import { supplierBalance, supplierPurchaseHistory } from '@/lib/services/suppliers';
import { formatDate, formatINR } from '@/lib/utils';
import { newId, nowIso } from '@/lib/services/business';
import { useToast } from '@/components/ui/toast';
import { PAYMENT_METHOD, type PaymentMethod } from '@/lib/types';
import { ArrowLeft, Plus } from 'lucide-react';

export default function SupplierDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { db, update } = useStore();
  const toast = useToast();
  const [tab, setTab] = useState('overview');
  const [payOpen, setPayOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('bank_transfer');
  const [ref, setRef] = useState('');

  const supplier = db.suppliers.find((s) => s.id === id);
  if (!supplier) return <EmptyState title="Supplier not found" action={<Link href="/suppliers"><Button>Back</Button></Link>} />;

  const bal = supplierBalance(db, supplier.id);
  const products = db.products.filter((p) => p.supplier_id === supplier.id);
  const payments = db.supplier_payments.filter((p) => p.supplier_id === supplier.id).sort((a, b) => b.paid_at.localeCompare(a.paid_at));
  const history = supplierPurchaseHistory(db, supplier.id);

  const recordPayment = () => {
    const amt = Number(amount);
    if (!amt || amt <= 0) return;
    update((d) => {
      d.supplier_payments.unshift({
        id: newId(),
        organization_id: d.organizations[0].id,
        created_at: nowIso(),
        updated_at: nowIso(),
        deleted_at: null,
        supplier_id: supplier.id,
        amount: amt,
        method,
        paid_at: nowIso(),
        reference: ref || null,
        notes: null,
      });
    });
    toast({ title: 'Supplier payment recorded' });
    setAmount('');
    setRef('');
    setPayOpen(false);
  };

  return (
    <>
      <div className="mb-3"><Link href="/suppliers" className="inline-flex items-center gap-1 text-[12.5px] text-[var(--muted)] hover:text-[var(--fg)]"><ArrowLeft className="h-3 w-3" /> Suppliers</Link></div>
      <PageHeader
        title={supplier.name}
        description={`${supplier.contact_person ?? '—'} · ${supplier.payment_terms ?? '—'}`}
        actions={<Button variant="primary" onClick={() => setPayOpen(true)}><Plus className="h-3.5 w-3.5" /> Record Payment</Button>}
      />

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Total purchased" value={formatINR(bal.purchased)} />
        <Stat label="Total paid" value={formatINR(bal.paid)} />
        <Stat label="Outstanding" value={formatINR(bal.balance)} tone={bal.balance > 0 ? 'danger' : 'success'} />
        <Stat label="Products supplied" value={String(products.length)} />
      </div>

      <Card>
        <Tabs value={tab} onChange={setTab} className="px-2" tabs={[
          { id: 'overview', label: 'Overview' },
          { id: 'products', label: 'Products', count: products.length },
          { id: 'purchases', label: 'Purchase History', count: history.length },
          { id: 'payments', label: 'Payments', count: payments.length },
        ]} />
        <div className="p-4">
          {tab === 'overview' && (
            <div className="space-y-2 text-[13px]">
              <Row label="Email" value={supplier.email ?? '—'} />
              <Row label="Phone" value={supplier.phone ?? '—'} />
              <Row label="Website" value={supplier.website ?? '—'} />
              <Row label="Payment terms" value={supplier.payment_terms ?? '—'} />
              <Row label="Notes" value={supplier.notes ?? '—'} />
            </div>
          )}
          {tab === 'products' && (products.length === 0 ? <EmptyState title="No products" /> : (
            <Table>
              <thead><tr><Th>Product</Th><Th className="text-right">Cost</Th><Th className="text-right">Price</Th><Th>Duration</Th></tr></thead>
              <tbody>{products.map((p) => (
                <tr key={p.id}>
                  <Td><Link href={`/products/${p.id}`} className="text-[var(--accent)] hover:underline">{p.name}</Link></Td>
                  <Td className="text-right tabular-nums">{formatINR(p.cost_price)}</Td>
                  <Td className="text-right tabular-nums">{formatINR(p.selling_price)}</Td>
                  <Td className="text-[12.5px]">{p.duration_days ? `${p.duration_days} days` : 'One-time'}</Td>
                </tr>
              ))}</tbody>
            </Table>
          ))}
          {tab === 'purchases' && (history.length === 0 ? <EmptyState title="No purchases" /> : (
            <Table>
              <thead><tr><Th>Order</Th><Th>Product</Th><Th>Date</Th><Th className="text-right">Cost</Th></tr></thead>
              <tbody>{history.slice(0, 80).map((h) => (
                <tr key={h.item.id}>
                  <Td><Link href={`/orders/${h.order.id}`} className="text-[var(--accent)] hover:underline">{h.order.order_number}</Link></Td>
                  <Td className="text-[12.5px]">{h.item.product_name}</Td>
                  <Td className="text-[12.5px]">{formatDate(h.order.ordered_at)}</Td>
                  <Td className="text-right tabular-nums">{formatINR(h.item.line_cost)}</Td>
                </tr>
              ))}</tbody>
            </Table>
          ))}
          {tab === 'payments' && (payments.length === 0 ? <EmptyState title="No payments recorded" /> : (
            <Table>
              <thead><tr><Th>Date</Th><Th>Method</Th><Th>Reference</Th><Th className="text-right">Amount</Th></tr></thead>
              <tbody>{payments.map((p) => (
                <tr key={p.id}>
                  <Td className="text-[12.5px]">{formatDate(p.paid_at)}</Td>
                  <Td className="text-[12.5px] capitalize">{p.method.replace('_', ' ')}</Td>
                  <Td className="text-[12.5px] text-[var(--muted)]">{p.reference ?? '—'}</Td>
                  <Td className="text-right tabular-nums">{formatINR(p.amount)}</Td>
                </tr>
              ))}</tbody>
            </Table>
          ))}
        </div>
      </Card>

      <Modal open={payOpen} onClose={() => setPayOpen(false)} title="Record supplier payment"
        footer={<><Button onClick={() => setPayOpen(false)}>Cancel</Button><Button variant="primary" onClick={recordPayment}>Record</Button></>}>
        <div className="space-y-3">
          <Field label="Amount (₹)"><Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder={String(bal.balance)} /></Field>
          <Field label="Method">
            <Select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
              {PAYMENT_METHOD.map((m) => <option key={m} value={m}>{m.replace('_', ' ')}</option>)}
            </Select>
          </Field>
          <Field label="Reference"><Input value={ref} onChange={(e) => setRef(e.target.value)} placeholder="NEFT / UTR" /></Field>
        </div>
      </Modal>
    </>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: 'danger' | 'success' }) {
  return (
    <div className="card p-3">
      <p className="text-[11.5px] text-[var(--muted)]">{label}</p>
      <p className="mt-1 text-[16px] font-semibold tabular-nums" style={tone ? { color: `var(--${tone})` } : undefined}>{value}</p>
    </div>
  );
}
function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between gap-3 border-b border-[var(--border)] py-1.5 last:border-0"><span className="text-[12.5px] text-[var(--muted)]">{label}</span><span className="text-[13px]">{value}</span></div>;
}
