'use client';

import { Suspense, useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { DataTable, type Column } from '@/components/ui/data-table';
import { ProductForm } from '@/components/forms/product-form';
import { Badge, Button, Select } from '@/components/ui/primitives';
import { formatINR, round2 } from '@/lib/utils';
import type { Product } from '@/lib/types';
import { Plus } from 'lucide-react';

function ProductsInner() {
  const { db } = useStore();
  const router = useRouter();
  const params = useSearchParams();
  const [open, setOpen] = useState(params.get('new') === '1');
  const [cat, setCat] = useState('all');
  const [active, setActive] = useState('all');

  const rows = useMemo(() => {
    let list = db.products.filter((p) => !p.deleted_at);
    if (cat !== 'all') list = list.filter((p) => p.category_id === cat);
    if (active !== 'all') list = list.filter((p) => String(p.is_active) === active);
    return list;
  }, [db.products, cat, active]);

  const unitsSold = (id: string) =>
    db.orders.reduce((a, o) => a + o.items.filter((i) => i.product_id === id).reduce((b, i) => b + i.quantity, 0), 0);

  const columns: Column<Product>[] = [
    {
      key: 'name', header: 'Product', sortValue: (p) => p.name, exportValue: (p) => p.name,
      render: (p) => (
        <div className="min-w-0">
          <p className="truncate text-[13px] font-medium text-[var(--fg)]">{p.name}</p>
          <p className="mt-0.5 text-[11.5px] text-[var(--muted-2)]">
            {p.code} · {p.product_type.replace('_', ' ')}
          </p>
        </div>
      ),
    },
    {
      key: 'category', header: 'Category',
      sortValue: (p) => db.product_categories.find((c) => c.id === p.category_id)?.name ?? '',
      exportValue: (p) => db.product_categories.find((c) => c.id === p.category_id)?.name ?? '',
      render: (p) => <span className="text-[12.5px]">{db.product_categories.find((c) => c.id === p.category_id)?.name ?? '—'}</span>,
    },
    {
      key: 'duration', header: 'Duration', sortValue: (p) => p.duration_days, exportValue: (p) => p.duration_days,
      render: (p) => <span className="whitespace-nowrap text-[12.5px]">{p.duration_days ? `${p.duration_days} days` : 'One-time'}</span>,
    },
    {
      key: 'supplier', header: 'Supplier',
      sortValue: (p) => db.suppliers.find((s) => s.id === p.supplier_id)?.name ?? '',
      exportValue: (p) => db.suppliers.find((s) => s.id === p.supplier_id)?.name ?? '',
      render: (p) => (
        <span className="text-[12.5px] text-[var(--muted)]">
          {db.suppliers.find((s) => s.id === p.supplier_id)?.name ?? '—'}
        </span>
      ),
    },
    { key: 'cost', header: 'Cost', numeric: true, sortValue: (p) => p.cost_price, exportValue: (p) => p.cost_price, render: (p) => <span className="text-[var(--muted)]">{formatINR(p.cost_price)}</span> },
    { key: 'price', header: 'Selling', numeric: true, sortValue: (p) => p.selling_price, exportValue: (p) => p.selling_price, render: (p) => <span className="font-semibold text-[var(--fg)]">{formatINR(p.selling_price)}</span> },
    {
      key: 'profit', header: 'Profit', numeric: true,
      sortValue: (p) => p.selling_price - p.cost_price, exportValue: (p) => p.selling_price - p.cost_price,
      render: (p) => {
        const pr = round2(p.selling_price - p.cost_price);
        return (
          <span className="font-semibold" style={{ color: pr >= 0 ? 'var(--success)' : 'var(--danger)' }}>
            {formatINR(pr)}
          </span>
        );
      },
    },
    {
      key: 'margin', header: 'Margin', numeric: true,
      sortValue: (p) => (p.selling_price ? (p.selling_price - p.cost_price) / p.selling_price : 0),
      exportValue: (p) => (p.selling_price ? round2(((p.selling_price - p.cost_price) / p.selling_price) * 100) : 0),
      render: (p) => {
        const m = p.selling_price ? round2(((p.selling_price - p.cost_price) / p.selling_price) * 100) : 0;
        const tone = m >= 50 ? 'success' : m >= 25 ? 'info' : m >= 10 ? 'warning' : 'danger';
        return (
          <div className="flex items-center justify-end gap-2">
            <div className="h-1 w-9 overflow-hidden rounded-full bg-[var(--surface-3)]">
              <div
                className="h-full rounded-full"
                style={{
                  width: `${Math.max(0, Math.min(100, m))}%`,
                  background: `var(--${tone === 'info' ? 'info' : tone})`,
                }}
              />
            </div>
            <span className="w-10 text-right font-semibold" style={{ color: `var(--${tone === 'info' ? 'info' : tone})` }}>
              {m}%
            </span>
          </div>
        );
      },
    },
    {
      key: 'stock', header: 'Stock', sortValue: (p) => p.stock ?? 9999, exportValue: (p) => p.stock ?? 'unlimited',
      render: (p) =>
        p.stock === null ? <span className="text-[12.5px] text-[var(--muted-2)]">Unlimited</span>
          : <Badge tone={p.stock <= p.low_stock_threshold ? 'danger' : 'neutral'}>{p.stock} left</Badge>,
    },
    { key: 'sold', header: 'Units Sold', numeric: true, sortValue: (p) => unitsSold(p.id), exportValue: (p) => unitsSold(p.id), render: (p) => <span>{unitsSold(p.id)}</span> },
    { key: 'status', header: 'Status', sortValue: (p) => String(p.is_active), exportValue: (p) => (p.is_active ? 'active' : 'inactive'), render: (p) => <Badge tone={p.is_active ? 'success' : 'neutral'}>{p.is_active ? 'active' : 'inactive'}</Badge> },
  ];

  return (
    <>
      <PageHeader
        title="Products"
        description={`${rows.length} products in catalog`}
        actions={<Button variant="primary" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5" /> New Product</Button>}
      />
      <DataTable
        rows={rows}
        columns={columns}
        exportName="products"
        onRowClick={(p) => router.push(`/products/${p.id}`)}
        searchable={(p) => `${p.name} ${p.code} ${p.brand}`}
        toolbar={
          <>
            <Select value={cat} onChange={(e) => setCat(e.target.value)} className="h-8 w-auto py-0 text-[12.5px]">
              <option value="all">All categories</option>
              {db.product_categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
            <Select value={active} onChange={(e) => setActive(e.target.value)} className="h-8 w-auto py-0 text-[12.5px]">
              <option value="all">All</option>
              <option value="true">Active</option>
              <option value="false">Inactive</option>
            </Select>
          </>
        }
      />
      <ProductForm open={open} onClose={() => setOpen(false)} />
    </>
  );
}

export default function ProductsPage() {
  return <Suspense fallback={null}><ProductsInner /></Suspense>;
}
