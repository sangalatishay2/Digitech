'use client';

import { use, useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Badge, Button, Card, CardHeader, EmptyState, StatusBadge, Table, Td, Th } from '@/components/ui/primitives';
import { ProductForm } from '@/components/forms/product-form';
import { formatDate, formatINR, round2 } from '@/lib/utils';
import { ArrowLeft, Pencil } from 'lucide-react';

export default function ProductDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { db } = useStore();
  const [edit, setEdit] = useState(false);
  const product = db.products.find((p) => p.id === id);

  if (!product) return <EmptyState title="Product not found" action={<Link href="/products"><Button>Back</Button></Link>} />;

  const lines = db.orders.flatMap((o) => o.items.filter((i) => i.product_id === product.id).map((i) => ({ order: o, item: i })));
  const units = lines.reduce((a, l) => a + l.item.quantity, 0);
  const revenue = round2(lines.reduce((a, l) => a + l.item.line_total, 0));
  const profit = round2(lines.reduce((a, l) => a + l.item.line_profit, 0));
  const subs = db.subscriptions.filter((s) => s.product_id === product.id);
  const supplier = db.suppliers.find((s) => s.id === product.supplier_id);
  const currentProfit = round2(product.selling_price - product.cost_price);

  return (
    <>
      <div className="mb-3">
        <Link href="/products" className="inline-flex items-center gap-1 text-[12.5px] text-[var(--muted)] hover:text-[var(--fg)]"><ArrowLeft className="h-3 w-3" /> Products</Link>
      </div>
      <PageHeader
        title={product.name}
        description={`${product.code} · ${product.product_type.replace('_', ' ')} · ${product.delivery_type.replace('_', ' ')}`}
        actions={<Button onClick={() => setEdit(true)}><Pencil className="h-3.5 w-3.5" /> Edit</Button>}
      />

      <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
        <div className="space-y-4">
          <Card>
            <CardHeader title="Current pricing" subtitle="Applies to new orders only" />
            <div className="space-y-2 p-4 text-[13px]">
              <Row label="Cost price" value={formatINR(product.cost_price)} />
              <Row label="Selling price" value={formatINR(product.selling_price)} />
              <Row label="Profit" value={formatINR(currentProfit)} />
              <Row label="Margin" value={`${product.selling_price ? round2((currentProfit / product.selling_price) * 100) : 0}%`} />
              <Row label="Duration" value={product.duration_days ? `${product.duration_days} days` : 'One-time'} />
              <Row label="Supplier" value={supplier?.name ?? '—'} />
              <Row label="Stock" value={product.stock === null ? 'Unlimited' : `${product.stock}`} />
              <Row label="Status" value={product.is_active ? 'Active' : 'Inactive'} />
            </div>
          </Card>
          <Card>
            <CardHeader title="Performance" subtitle="Based on historical snapshots" />
            <div className="space-y-2 p-4 text-[13px]">
              <Row label="Units sold" value={String(units)} />
              <Row label="Revenue" value={formatINR(revenue)} />
              <Row label="Realised profit" value={formatINR(profit)} />
              <Row label="Active subscriptions" value={String(subs.filter((s) => s.status === 'active' || s.status === 'expiring').length)} />
            </div>
          </Card>
          {product.description && (
            <Card><CardHeader title="Description" /><p className="p-4 text-[12.5px] text-[var(--muted)]">{product.description}</p></Card>
          )}
        </div>

        <Card>
          <CardHeader title="Sales history" subtitle="Each line shows the cost recorded at the time of sale" />
          {lines.length === 0 ? <EmptyState title="No sales yet" /> : (
            <Table>
              <thead><tr><Th>Order</Th><Th>Date</Th><Th>Qty</Th><Th className="text-right">Sold at</Th><Th className="text-right">Cost then</Th><Th className="text-right">Profit</Th><Th>Status</Th></tr></thead>
              <tbody>
                {lines.slice(0, 60).map((l) => (
                  <tr key={l.item.id}>
                    <Td><Link href={`/orders/${l.order.id}`} className="text-[var(--accent)] hover:underline">{l.order.order_number}</Link></Td>
                    <Td className="text-[12.5px]">{formatDate(l.order.ordered_at)}</Td>
                    <Td className="tabular-nums">{l.item.quantity}</Td>
                    <Td className="text-right tabular-nums">{formatINR(l.item.unit_price)}</Td>
                    <Td className="text-right tabular-nums">
                      {formatINR(l.item.unit_cost)}
                      {l.item.unit_cost !== product.cost_price && <Badge tone="warning" className="ml-1">snapshot</Badge>}
                    </Td>
                    <Td className="text-right tabular-nums">{formatINR(l.item.line_profit)}</Td>
                    <Td><StatusBadge status={l.order.status} /></Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>
      </div>

      <ProductForm open={edit} onClose={() => setEdit(false)} product={product} />
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between gap-2"><span className="text-[12.5px] text-[var(--muted)]">{label}</span><span className="text-[13px] font-medium tabular-nums">{value}</span></div>;
}
