'use client';

import { useMemo, useState } from 'react';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Card, CardHeader, Table, Tabs, Td, Th } from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { RangePicker, useDateRange } from '@/components/range-picker';
import { RevenueAreaChart, SimpleBarChart, SimplePieChart } from '@/components/charts';
import {
  buildSeries, computeKpis, customerLifetimeValue, customerStats, refundRate,
  renewalRate, repeatRate, topProducts,
} from '@/lib/services/analytics';
import { supplierBalance } from '@/lib/services/suppliers';
import { formatINR, round2 } from '@/lib/utils';

export default function AnalyticsPage() {
  const { db } = useStore();
  const { key, setKey, custom, setCustom, range } = useDateRange('30d');
  const [tab, setTab] = useState('overview');

  const kpis = useMemo(() => computeKpis(db, range), [db, range]);
  const series = useMemo(() => buildSeries(db, range), [db, range]);
  const products = useMemo(() => topProducts(db, range, 10), [db, range]);
  const seriesData = series as unknown as Record<string, string | number>[];

  const topCustomers = useMemo(
    () => db.customers.map((c) => ({ c, s: customerStats(db, c.id) })).sort((a, b) => b.s.revenue - a.s.revenue).slice(0, 10),
    [db],
  );

  const subsByStatus = useMemo(() => {
    const m = new Map<string, number>();
    for (const s of db.subscriptions) m.set(s.status, (m.get(s.status) ?? 0) + 1);
    return Array.from(m.entries()).map(([name, value]) => ({ name, value }));
  }, [db.subscriptions]);

  const ticketsByCategory = useMemo(() => {
    const m = new Map<string, number>();
    for (const t of db.support_tickets) m.set(t.category, (m.get(t.category) ?? 0) + 1);
    return Array.from(m.entries()).map(([name, value]) => ({ name, value }));
  }, [db.support_tickets]);

  const renewals = renewalRate(db);
  const refunds = refundRate(db);
  const clv = customerLifetimeValue(db);
  const repeat = repeatRate(db);

  return (
    <>
      <PageHeader title="Analytics" description={`Business intelligence · ${range.label}`}
        actions={<RangePicker value={key} onChange={setKey} custom={custom} onCustomChange={setCustom} />} />

      <Card className="mb-4">
        <Tabs value={tab} onChange={setTab} className="px-2" tabs={[
          { id: 'overview', label: 'Business Overview' },
          { id: 'sales', label: 'Sales' },
          { id: 'products', label: 'Products' },
          { id: 'customers', label: 'Customers' },
          { id: 'subscriptions', label: 'Subscriptions' },
          { id: 'renewals', label: 'Renewals' },
          { id: 'profit', label: 'Profit' },
          { id: 'suppliers', label: 'Suppliers' },
          { id: 'support', label: 'Support' },
        ]} />
      </Card>

      {tab === 'overview' && (
        <>
          <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            <KpiCard label="Revenue" value={formatINR(kpis.revenue, { compact: true })} tone="accent" />
            <KpiCard label="Gross Margin" value={`${kpis.grossMargin}%`} tone="success" />
            <KpiCard label="Net Margin" value={`${kpis.netMargin}%`} tone={kpis.netMargin >= 0 ? 'success' : 'danger'} />
            <KpiCard label="Renewal Rate" value={`${renewals}%`} tone="accent" />
            <KpiCard label="Refund Rate" value={`${refunds}%`} tone={refunds > 3 ? 'danger' : 'neutral'} />
            <KpiCard label="Repeat Rate" value={`${repeat}%`} />
          </div>
          <Card>
            <CardHeader title="Revenue, profit & expenses" />
            <div className="p-3">
              <RevenueAreaChart data={seriesData} height={300} keys={[
                { key: 'revenue', label: 'Revenue', color: '#5b5bd6' },
                { key: 'profit', label: 'Profit', color: '#12874a' },
                { key: 'expenses', label: 'Expenses', color: '#b45309' },
              ]} />
            </div>
          </Card>
        </>
      )}

      {tab === 'sales' && (
        <>
          <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
            <KpiCard label="Orders" value={kpis.orders} />
            <KpiCard label="Revenue" value={formatINR(kpis.revenue, { compact: true })} tone="accent" />
            <KpiCard label="Avg Order Value" value={formatINR(kpis.aov)} />
            <KpiCard label="Outstanding" value={formatINR(kpis.outstanding, { compact: true })} tone="danger" />
          </div>
          <Card><CardHeader title="Orders trend" /><div className="p-3"><SimpleBarChart data={seriesData} dataKey="orders" label="Orders" currency={false} height={280} /></div></Card>
        </>
      )}

      {tab === 'products' && (
        <Card>
          <CardHeader title="Product performance" subtitle={range.label} />
          <Table>
            <thead><tr><Th>Product</Th><Th className="text-right">Units</Th><Th className="text-right">Revenue</Th><Th className="text-right">Profit</Th><Th className="text-right">Margin</Th></tr></thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.name}>
                  <Td className="text-[13px]">{p.name}</Td>
                  <Td className="text-right tabular-nums">{p.units}</Td>
                  <Td className="text-right tabular-nums">{formatINR(p.revenue)}</Td>
                  <Td className="text-right tabular-nums" style={{ color: 'var(--success)' }}>{formatINR(p.profit)}</Td>
                  <Td className="text-right tabular-nums">{p.revenue ? round2((p.profit / p.revenue) * 100) : 0}%</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      {tab === 'customers' && (
        <>
          <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
            <KpiCard label="Total customers" value={db.customers.length} />
            <KpiCard label="Avg lifetime value" value={formatINR(clv)} tone="accent" />
            <KpiCard label="Repeat rate" value={`${repeat}%`} tone="success" />
            <KpiCard label="New in range" value={kpis.newCustomers} />
          </div>
          <Card>
            <CardHeader title="Top customers by lifetime revenue" />
            <Table>
              <thead><tr><Th>Customer</Th><Th className="text-right">Orders</Th><Th className="text-right">Revenue</Th><Th className="text-right">Profit</Th><Th className="text-right">Outstanding</Th></tr></thead>
              <tbody>
                {topCustomers.map(({ c, s }) => (
                  <tr key={c.id}>
                    <Td className="text-[13px]">{c.name}</Td>
                    <Td className="text-right tabular-nums">{s.orders}</Td>
                    <Td className="text-right tabular-nums">{formatINR(s.revenue)}</Td>
                    <Td className="text-right tabular-nums" style={{ color: 'var(--success)' }}>{formatINR(s.profit)}</Td>
                    <Td className="text-right tabular-nums">{formatINR(s.outstanding)}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Card>
        </>
      )}

      {tab === 'subscriptions' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card><CardHeader title="Subscriptions by status" /><div className="p-3"><SimplePieChart data={subsByStatus} height={280} /></div></Card>
          <Card>
            <CardHeader title="Subscription metrics" />
            <div className="space-y-2 p-4 text-[13px]">
              <Row label="Total subscriptions" value={String(db.subscriptions.length)} />
              <Row label="Active" value={String(db.subscriptions.filter((s) => s.status === 'active').length)} />
              <Row label="Expiring" value={String(db.subscriptions.filter((s) => s.status === 'expiring').length)} />
              <Row label="Expired" value={String(db.subscriptions.filter((s) => s.status === 'expired').length)} />
              <Row label="Renewed" value={String(db.subscriptions.filter((s) => s.status === 'renewed').length)} />
              <Row label="Renewal rate" value={`${renewals}%`} />
            </div>
          </Card>
        </div>
      )}

      {tab === 'renewals' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader title="Renewal funnel" />
            <div className="space-y-2 p-4 text-[13px]">
              <Row label="Renewal rate" value={`${renewals}%`} />
              <Row label="Renewed subscriptions" value={String(db.subscriptions.filter((s) => s.status === 'renewed').length)} />
              <Row label="Lost (expired, not renewed)" value={String(db.subscriptions.filter((s) => s.status === 'expired').length)} />
              <Row label="In follow-up" value={String(db.subscriptions.filter((s) => s.reminder_state === 'follow_up').length)} />
              <Row label="Marked interested" value={String(db.subscriptions.filter((s) => s.reminder_state === 'interested').length)} />
            </div>
          </Card>
          <Card>
            <CardHeader title="Renewal revenue" />
            <div className="space-y-2 p-4 text-[13px]">
              <Row label="Renewal orders" value={String(db.orders.filter((o) => o.renewal_of_subscription_id).length)} />
              <Row label="Renewal revenue" value={formatINR(round2(db.orders.filter((o) => o.renewal_of_subscription_id).reduce((a, o) => a + o.total, 0)))} />
              <Row label="Renewal profit" value={formatINR(round2(db.orders.filter((o) => o.renewal_of_subscription_id).reduce((a, o) => a + o.profit, 0)))} />
            </div>
          </Card>
        </div>
      )}

      {tab === 'profit' && (
        <Card>
          <CardHeader title="Profit trend" subtitle={range.label} />
          <div className="p-3">
            <RevenueAreaChart data={seriesData} height={300} keys={[{ key: 'profit', label: 'Gross Profit', color: '#12874a' }, { key: 'expenses', label: 'Expenses', color: '#b45309' }]} />
          </div>
        </Card>
      )}

      {tab === 'suppliers' && (
        <Card>
          <CardHeader title="Supplier spend" />
          <Table>
            <thead><tr><Th>Supplier</Th><Th className="text-right">Purchased</Th><Th className="text-right">Paid</Th><Th className="text-right">Outstanding</Th></tr></thead>
            <tbody>
              {db.suppliers.map((s) => {
                const b = supplierBalance(db, s.id);
                return (
                  <tr key={s.id}>
                    <Td className="text-[13px]">{s.name}</Td>
                    <Td className="text-right tabular-nums">{formatINR(b.purchased)}</Td>
                    <Td className="text-right tabular-nums">{formatINR(b.paid)}</Td>
                    <Td className="text-right tabular-nums" style={b.balance > 0 ? { color: 'var(--danger)' } : undefined}>{formatINR(b.balance)}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Card>
      )}

      {tab === 'support' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card><CardHeader title="Tickets by category" /><div className="p-3"><SimplePieChart data={ticketsByCategory} height={280} /></div></Card>
          <Card>
            <CardHeader title="Support metrics" />
            <div className="space-y-2 p-4 text-[13px]">
              <Row label="Total tickets" value={String(db.support_tickets.length)} />
              <Row label="Open" value={String(db.support_tickets.filter((t) => t.status === 'open').length)} />
              <Row label="Resolved" value={String(db.support_tickets.filter((t) => ['resolved', 'closed'].includes(t.status)).length)} />
              <Row label="Urgent" value={String(db.support_tickets.filter((t) => t.priority === 'urgent').length)} />
            </div>
          </Card>
        </div>
      )}
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between gap-2 border-b border-[var(--border)] pb-1.5 last:border-0"><span className="text-[12.5px] text-[var(--muted)]">{label}</span><span className="text-[13px] font-medium tabular-nums capitalize">{value}</span></div>;
}
