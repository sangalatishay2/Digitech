'use client';

import { useMemo, useState } from 'react';
import {
  AlertTriangle, CheckCircle2, Clock3, IndianRupee, Plus, ShieldCheck, Sparkles, XCircle,
} from 'lucide-react';
import { useStore } from '@/lib/store';
import {
  Badge, Button, Card, EmptyState, Field, Input, Modal, PageHeader, Select, Tabs, Textarea,
} from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { inferApprovalRisk } from '@/lib/services/approvals';
import type { ApprovalRequest, ApprovalType } from '@/lib/types';
import { APPROVAL_TYPES } from '@/lib/types';
import { cn, formatDateTime, formatINR } from '@/lib/utils';

type Tab = 'pending' | 'approved' | 'rejected' | 'all';

const TYPE_LABELS: Record<ApprovalType, string> = {
  refund: 'Customer refund', discount: 'Special discount', expense: 'Expense',
  supplier_payment: 'Supplier payment', bulk_message: 'Bulk message',
  secret_access: 'Secret access', data_export: 'Data export',
  account_change: 'Account change', ai_action: 'AI-proposed action', other: 'Other',
};

const RISK_TONE = { low: 'neutral', medium: 'info', high: 'warning', critical: 'danger' } as const;

const blankForm = {
  request_type: 'refund' as ApprovalType,
  title: '', description: '', reason: '', financial_impact: '', expires_at: '',
};

export default function ApprovalsPage() {
  const { db, can, createApproval, reviewApproval, profileById } = useStore();
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('pending');
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState(blankForm);
  const [review, setReview] = useState<ApprovalRequest | null>(null);
  const [decision, setDecision] = useState<'approved' | 'rejected'>('approved');
  const [reviewNote, setReviewNote] = useState('');
  const [error, setError] = useState<string | null>(null);

  const active = db.approval_requests.filter((item) => !item.deleted_at);
  const filtered = useMemo(
    () => tab === 'all' ? active : active.filter((item) => item.status === tab),
    [active, tab],
  );
  const pending = active.filter((item) => item.status === 'pending');
  const risk = inferApprovalRisk(form.request_type, Number(form.financial_impact || 0));
  const totalPendingValue = pending.reduce((sum, item) => sum + item.financial_impact, 0);

  function submitRequest() {
    setError(null);
    try {
      createApproval({
        request_type: form.request_type,
        title: form.title,
        description: form.description,
        reason: form.reason,
        financial_impact: Number(form.financial_impact || 0),
        expires_at: form.expires_at ? new Date(form.expires_at).toISOString() : null,
        payload: {},
      });
      toast({ title: 'Approval request submitted', description: 'An owner or admin can now review it.' });
      setForm(blankForm);
      setCreateOpen(false);
    } catch (cause) {
      setError((cause as Error).message);
    }
  }

  function openReview(item: ApprovalRequest, nextDecision: 'approved' | 'rejected') {
    setReview(item);
    setDecision(nextDecision);
    setReviewNote('');
    setError(null);
  }

  function submitReview() {
    if (!review) return;
    setError(null);
    try {
      reviewApproval(review.id, decision, reviewNote);
      toast({
        title: decision === 'approved' ? 'Request approved' : 'Request rejected',
        description: decision === 'approved'
          ? 'The trusted server queue will process the action idempotently.'
          : 'No action was queued.',
      });
      setReview(null);
    } catch (cause) {
      setError((cause as Error).message);
    }
  }

  return (
    <div className="space-y-4">
      <PageHeader
        title="Approval Center"
        description="A human checkpoint before refunds, payments, exports, bulk outreach, or AI-proposed actions run."
        actions={can('approvals.create') ? (
          <Button variant="primary" onClick={() => { setError(null); setCreateOpen(true); }}>
            <Plus className="h-3.5 w-3.5" /> New request
          </Button>
        ) : undefined}
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Metric icon={Clock3} label="Awaiting review" value={String(pending.length)} tone="accent" />
        <Metric icon={AlertTriangle} label="Critical risk" value={String(pending.filter((item) => item.risk_level === 'critical').length)} tone="danger" />
        <Metric icon={IndianRupee} label="Pending impact" value={formatINR(totalPendingValue, { compact: true })} tone="warning" />
        <Metric icon={CheckCircle2} label="Reviewed" value={String(active.filter((item) => item.reviewed_at).length)} tone="success" />
      </div>

      <Card className="overflow-hidden">
        <Tabs
          value={tab}
          onChange={(value) => setTab(value as Tab)}
          className="px-2"
          tabs={[
            { id: 'pending', label: 'Pending', count: pending.length },
            { id: 'approved', label: 'Approved', count: active.filter((item) => item.status === 'approved').length },
            { id: 'rejected', label: 'Rejected', count: active.filter((item) => item.status === 'rejected').length },
            { id: 'all', label: 'All', count: active.length },
          ]}
        />

        {filtered.length === 0 ? (
          <EmptyState
            icon={ShieldCheck}
            title={tab === 'pending' ? 'Nothing is waiting' : `No ${tab} requests`}
            message={tab === 'pending' ? 'Consequential work will appear here before it can run.' : 'Try another status filter.'}
          />
        ) : (
          <div className="divide-y divide-[var(--border-subtle)]">
            {filtered.map((item) => {
              const expired = Boolean(item.expires_at && new Date(item.expires_at) <= new Date());
              return (
                <article key={item.id} className="grid gap-3 px-4 py-4 transition-colors hover:bg-[var(--surface-2)]/50 lg:grid-cols-[minmax(0,1fr)_150px_150px_auto] lg:items-center">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      {item.request_type === 'ai_action' && <Sparkles className="h-3.5 w-3.5 text-[var(--accent)]" />}
                      <h2 className="truncate text-[13.5px] font-semibold">{item.title}</h2>
                      <Badge tone={RISK_TONE[item.risk_level]}>{item.risk_level} risk</Badge>
                      <Badge tone={item.status === 'approved' ? 'success' : item.status === 'rejected' ? 'danger' : expired ? 'danger' : 'warning'}>
                        {item.status === 'pending' && expired ? 'expired' : item.status}
                      </Badge>
                    </div>
                    <p className="mt-1 line-clamp-2 text-[12.5px] leading-relaxed text-[var(--muted)]">{item.reason}</p>
                    <p className="mt-1.5 text-[11px] text-[var(--muted-2)]">
                      {TYPE_LABELS[item.request_type]} · requested by {profileById(item.requested_by)?.full_name ?? 'Unknown'} · {formatDateTime(item.created_at)}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10.5px] font-semibold uppercase tracking-[0.06em] text-[var(--muted-2)]">Financial impact</p>
                    <p className="mt-1 text-[13px] font-semibold tabular-nums">{formatINR(item.financial_impact)}</p>
                  </div>
                  <div>
                    <p className="text-[10.5px] font-semibold uppercase tracking-[0.06em] text-[var(--muted-2)]">Reviewer</p>
                    <p className="mt-1 text-[12.5px] text-[var(--fg-soft)]">{item.reviewed_by ? profileById(item.reviewed_by)?.full_name ?? 'Unknown' : 'Not assigned'}</p>
                  </div>
                  {item.status === 'pending' && can('approvals.review') && (
                    <div className="flex gap-2 lg:justify-end">
                      <Button size="sm" variant="outline" onClick={() => openReview(item, 'rejected')}>
                        <XCircle className="h-3.5 w-3.5" /> Reject
                      </Button>
                      <Button size="sm" variant="primary" disabled={expired} onClick={() => openReview(item, 'approved')}>
                        <CheckCircle2 className="h-3.5 w-3.5" /> Approve
                      </Button>
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        )}
      </Card>

      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Request approval"
        description="The request is locked after submission so its contents cannot be swapped during review."
        width="lg"
        footer={<><Button onClick={() => setCreateOpen(false)}>Cancel</Button><Button variant="primary" onClick={submitRequest}>Submit request</Button></>}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Request type" required>
            <Select value={form.request_type} onChange={(event) => setForm({ ...form, request_type: event.target.value as ApprovalType })}>
              {APPROVAL_TYPES.map((type) => <option key={type} value={type}>{TYPE_LABELS[type]}</option>)}
            </Select>
          </Field>
          <Field label="Expected financial impact" hint="Use 0 when there is no direct monetary effect.">
            <Input type="number" min="0" step="0.01" inputMode="decimal" value={form.financial_impact} onChange={(event) => setForm({ ...form, financial_impact: event.target.value })} placeholder="0.00" />
          </Field>
          <Field label="Title" required className="sm:col-span-2">
            <Input maxLength={160} value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} placeholder="What needs approval?" />
          </Field>
          <Field label="Business reason" required className="sm:col-span-2">
            <Textarea rows={3} maxLength={1000} value={form.reason} onChange={(event) => setForm({ ...form, reason: event.target.value })} placeholder="Why is this necessary, and what happens if it is not approved?" />
          </Field>
          <Field label="Supporting detail" className="sm:col-span-2">
            <Textarea rows={3} maxLength={4000} value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} placeholder="Scope, customer context, calculations, or constraints" />
          </Field>
          <Field label="Approval expires" hint="Optional. Approval is blocked after this time.">
            <Input type="datetime-local" value={form.expires_at} onChange={(event) => setForm({ ...form, expires_at: event.target.value })} />
          </Field>
          <div className="rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] p-3">
            <p className="text-[10.5px] font-semibold uppercase tracking-[0.06em] text-[var(--muted-2)]">Automatic risk rating</p>
            <Badge tone={RISK_TONE[risk]} className="mt-2">{risk} risk</Badge>
            <p className="mt-2 text-[11.5px] leading-relaxed text-[var(--muted)]">Based on request type and financial impact; requesters cannot lower it manually.</p>
          </div>
        </div>
        {error && <p role="alert" className="mt-4 rounded-[8px] bg-[var(--danger-soft)] px-3 py-2 text-[12px] text-[var(--danger)]">{error}</p>}
      </Modal>

      <Modal
        open={Boolean(review)}
        onClose={() => setReview(null)}
        title={decision === 'approved' ? 'Approve request' : 'Reject request'}
        description={review?.title}
        footer={<><Button onClick={() => setReview(null)}>Cancel</Button><Button variant={decision === 'approved' ? 'primary' : 'danger'} onClick={submitReview}>{decision === 'approved' ? 'Approve & queue' : 'Reject request'}</Button></>}
      >
        {review && (
          <div className="space-y-4">
            <div className={cn('rounded-[10px] border p-3 text-[12.5px] leading-relaxed', decision === 'approved' ? 'border-[var(--accent-border)] bg-[var(--accent-soft)]' : 'border-[var(--danger-border)] bg-[var(--danger-soft)]')}>
              {decision === 'approved'
                ? 'Approval creates one idempotent server-side job. It does not expose provider secrets to this browser.'
                : 'Rejection is final and does not create an action job.'}
            </div>
            <Field label="Review note" hint="Recommended for high-risk and critical requests.">
              <Textarea rows={4} maxLength={1000} value={reviewNote} onChange={(event) => setReviewNote(event.target.value)} placeholder="Record your decision rationale" />
            </Field>
            {error && <p role="alert" className="rounded-[8px] bg-[var(--danger-soft)] px-3 py-2 text-[12px] text-[var(--danger)]">{error}</p>}
          </div>
        )}
      </Modal>
    </div>
  );
}

function Metric({ icon: Icon, label, value, tone }: { icon: typeof Clock3; label: string; value: string; tone: 'accent' | 'danger' | 'warning' | 'success' }) {
  const colors = {
    accent: 'bg-[var(--accent-soft)] text-[var(--accent)]', danger: 'bg-[var(--danger-soft)] text-[var(--danger)]',
    warning: 'bg-[var(--warning-soft)] text-[var(--warning)]', success: 'bg-[var(--success-soft)] text-[var(--success)]',
  };
  return (
    <Card className="flex items-center gap-3 p-3.5">
      <span className={cn('grid h-9 w-9 place-items-center rounded-[10px]', colors[tone])}><Icon className="h-4 w-4" /></span>
      <div className="min-w-0"><p className="truncate text-[10.5px] font-semibold uppercase tracking-[0.05em] text-[var(--muted-2)]">{label}</p><p className="mt-0.5 text-[19px] font-semibold tracking-[-0.02em] tabular-nums">{value}</p></div>
    </Card>
  );
}
