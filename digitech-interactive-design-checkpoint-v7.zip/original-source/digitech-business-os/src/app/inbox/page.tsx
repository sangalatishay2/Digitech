'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { Inbox, Mail, MessageCircle, Phone, Plus, Send, TicketCheck } from 'lucide-react';
import { useStore } from '@/lib/store';
import {
  Avatar, Badge, Button, Card, EmptyState, Field, Input, Modal, PageHeader, Select, Textarea,
} from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { buildInboxThreads } from '@/lib/services/intelligence';
import type { CommunicationLog } from '@/lib/types';
import { cn, formatDateTime, relativeTime } from '@/lib/utils';

type ChannelFilter = 'all' | CommunicationLog['channel'];
const channels: { id: ChannelFilter; label: string }[] = [
  { id: 'all', label: 'All' }, { id: 'whatsapp', label: 'WhatsApp' },
  { id: 'email', label: 'Email' }, { id: 'sms', label: 'SMS' }, { id: 'call', label: 'Calls' },
];

const channelIcon = { whatsapp: MessageCircle, email: Mail, sms: MessageCircle, call: Phone };

export default function InboxPage() {
  const { db, can, queueCommunication } = useStore();
  const toast = useToast();
  const threads = useMemo(() => buildInboxThreads(db), [db]);
  const [filter, setFilter] = useState<ChannelFilter>('all');
  const visible = threads.filter((thread) => filter === 'all' || thread.channel === filter);
  const [activeId, setActiveId] = useState<string | null>(null);
  const active = threads.find((thread) => thread.id === activeId) ?? visible[0] ?? null;
  const [composeOpen, setComposeOpen] = useState(false);
  const [form, setForm] = useState({ customer_id: '', channel: 'whatsapp' as CommunicationLog['channel'], to_address: '', body: '' });
  const [error, setError] = useState<string | null>(null);

  function chooseCustomer(id: string) {
    const customer = db.customers.find((item) => item.id === id);
    const address = form.channel === 'email'
      ? customer?.email ?? ''
      : customer?.whatsapp ?? customer?.phone ?? '';
    setForm({ ...form, customer_id: id, to_address: address });
  }

  function chooseChannel(channel: CommunicationLog['channel']) {
    const customer = db.customers.find((item) => item.id === form.customer_id);
    const address = channel === 'email' ? customer?.email ?? '' : customer?.whatsapp ?? customer?.phone ?? '';
    setForm({ ...form, channel, to_address: address });
  }

  function submit() {
    setError(null);
    try {
      const queued = queueCommunication({
        customer_id: form.customer_id || null,
        channel: form.channel,
        to_address: form.to_address,
        body: form.body,
      });
      toast({ title: 'Message queued', description: 'Delivery status will update when the configured provider accepts it.' });
      setComposeOpen(false);
      setForm({ customer_id: '', channel: 'whatsapp', to_address: '', body: '' });
      setActiveId(queued.customer_id ?? `${queued.channel}:${queued.to_address.trim().toLowerCase()}`);
    } catch (cause) {
      setError((cause as Error).message);
    }
  }

  function replyToThread() {
    if (!active) return;
    setForm({ customer_id: active.customerId ?? '', channel: active.channel, to_address: active.address, body: '' });
    setError(null);
    setComposeOpen(true);
  }

  return (
    <div className="space-y-4">
      <PageHeader
        title="Unified Inbox"
        description="Customer WhatsApp, email, SMS, calls, and support context in one chronological workspace."
        actions={can('communications.create') ? <Button variant="primary" onClick={() => { setError(null); setComposeOpen(true); }}><Plus className="h-3.5 w-3.5" /> Compose</Button> : undefined}
      />

      <Card className="overflow-hidden">
        <div className="flex gap-1 overflow-x-auto border-b border-[var(--border)] p-2">
          {channels.map((channel) => (
            <button key={channel.id} onClick={() => setFilter(channel.id)} className={cn('rounded-[7px] px-3 py-1.5 text-[12.5px] font-medium', filter === channel.id ? 'bg-[var(--accent-soft)] text-[var(--accent)]' : 'text-[var(--muted)] hover:bg-[var(--surface-2)]')}>{channel.label}</button>
          ))}
        </div>

        {visible.length === 0 ? (
          <EmptyState icon={Inbox} title="No conversations yet" message="Compose a message or connect a communication provider to start the customer timeline." />
        ) : (
          <div className="grid min-h-[620px] lg:grid-cols-[330px_minmax(0,1fr)]">
            <aside className="border-b border-[var(--border)] lg:border-b-0 lg:border-r">
              {visible.map((thread) => {
                const Icon = channelIcon[thread.channel];
                return (
                  <button key={thread.id} onClick={() => setActiveId(thread.id)} className={cn('flex w-full items-start gap-3 border-b border-[var(--border-subtle)] px-3.5 py-3 text-left transition-colors', active?.id === thread.id ? 'bg-[var(--accent-soft)]' : 'hover:bg-[var(--surface-2)]')}>
                    <Avatar name={thread.customerName} size={34} />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2"><strong className="min-w-0 flex-1 truncate text-[13px]">{thread.customerName}</strong><span className="shrink-0 text-[10.5px] text-[var(--muted-2)]">{relativeTime(thread.latestAt)}</span></span>
                      <span className="mt-1 flex items-center gap-1.5 text-[11.5px] text-[var(--muted)]"><Icon className="h-3 w-3 shrink-0" /><span className="truncate">{thread.latestBody}</span></span>
                      {(thread.openTickets > 0 || thread.inboundCount > 0) && <span className="mt-1.5 flex gap-1.5"><Badge tone={thread.openTickets ? 'warning' : 'neutral'}>{thread.openTickets} open tickets</Badge><Badge>{thread.inboundCount} inbound</Badge></span>}
                    </span>
                  </button>
                );
              })}
            </aside>

            {active && (
              <section className="flex min-w-0 flex-col">
                <header className="flex flex-wrap items-center gap-3 border-b border-[var(--border)] px-4 py-3">
                  <Avatar name={active.customerName} size={34} />
                  <div className="min-w-0 flex-1"><h2 className="truncate text-[13.5px] font-semibold">{active.customerName}</h2><p className="truncate text-[11.5px] text-[var(--muted)]">{active.address}</p></div>
                  {active.customerId && <Link href={`/customers/${active.customerId}`}><Button size="sm" variant="outline">Customer 360</Button></Link>}
                  {can('communications.create') && <Button size="sm" variant="primary" onClick={replyToThread}><Send className="h-3.5 w-3.5" /> Reply</Button>}
                </header>
                <div className="flex-1 space-y-3 overflow-y-auto bg-[var(--surface-2)]/30 p-4 sm:p-6">
                  {active.openTickets > 0 && <div className="flex items-center gap-2 rounded-[9px] border border-[var(--warning-border)] bg-[var(--warning-soft)] px-3 py-2 text-[12px]"><TicketCheck className="h-3.5 w-3.5 text-[var(--warning)]" /> {active.openTickets} support ticket{active.openTickets === 1 ? '' : 's'} still open for this customer.</div>}
                  {active.messages.map((message) => {
                    const Icon = channelIcon[message.channel];
                    return (
                      <div key={message.id} className={cn('flex', message.direction === 'outbound' ? 'justify-end' : 'justify-start')}>
                        <div className={cn('max-w-[82%] rounded-[12px] border px-3.5 py-3', message.direction === 'outbound' ? 'border-[var(--accent-border)] bg-[var(--accent-soft)]' : 'border-[var(--border)] bg-[var(--surface)]')}>
                          <p className="whitespace-pre-wrap text-[13px] leading-5">{message.body}</p>
                          <p className="mt-2 flex items-center gap-1.5 text-[10.5px] text-[var(--muted)]"><Icon className="h-3 w-3" /> {message.channel} · {message.status} · {formatDateTime(message.created_at)}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}
          </div>
        )}
      </Card>

      <Modal open={composeOpen} onClose={() => setComposeOpen(false)} title="Compose customer message" description="Messages enter a delivery queue; queued is never shown as sent." width="lg" footer={<><Button onClick={() => setComposeOpen(false)}>Cancel</Button><Button variant="primary" onClick={submit}><Send className="h-3.5 w-3.5" /> Queue message</Button></>}>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Customer">
            <Select value={form.customer_id} onChange={(event) => chooseCustomer(event.target.value)}><option value="">Select customer</option>{db.customers.filter((item) => !item.deleted_at).map((customer) => <option key={customer.id} value={customer.id}>{customer.name}</option>)}</Select>
          </Field>
          <Field label="Channel" required>
            <Select value={form.channel} onChange={(event) => chooseChannel(event.target.value as CommunicationLog['channel'])}>{channels.filter((item) => item.id !== 'all').map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</Select>
          </Field>
          <Field label={form.channel === 'email' ? 'Email address' : 'Phone / destination'} required className="sm:col-span-2">
            <Input value={form.to_address} onChange={(event) => setForm({ ...form, to_address: event.target.value })} placeholder={form.channel === 'email' ? 'customer@example.com' : '+91…'} />
          </Field>
          <Field label="Message" required className="sm:col-span-2">
            <Textarea rows={7} maxLength={4000} value={form.body} onChange={(event) => setForm({ ...form, body: event.target.value })} placeholder="Write a clear, helpful customer message…" />
          </Field>
        </div>
        {error && <p role="alert" className="mt-4 rounded-[8px] bg-[var(--danger-soft)] px-3 py-2 text-[12px] text-[var(--danger)]">{error}</p>}
      </Modal>
    </div>
  );
}
