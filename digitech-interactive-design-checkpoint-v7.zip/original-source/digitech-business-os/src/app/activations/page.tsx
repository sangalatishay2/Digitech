'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import {
  fetchActivationSecrets,
  saveActivationSecrets,
  secretsAreServerSide,
} from '@/lib/services/activation-secrets';
import {
  Avatar, Badge, Button, Card, EmptyState, Field, IdentityCell, Input, Modal, PageHeader,
  Select, Table, Td, Th, Tabs, Textarea, Tooltip,
} from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { useToast } from '@/components/ui/toast';
import { ageSince, cn } from '@/lib/utils';
import {
  ACTIVATION_STATUS, PRIORITY, type Activation, type ActivationStatus, type Priority,
} from '@/lib/types';
import { Zap, ExternalLink, CheckCircle2, Clock, AlertTriangle, Truck } from 'lucide-react';

/** SLA thresholds in hours for the ageing indicator. */
const SLA_WARN = 12;
const SLA_BREACH = 24;

export default function ActivationsPage() {
  const { db, updateActivation, completeActivation } = useStore();
  const toast = useToast();
  const [tab, setTab] = useState<string>('queue');
  const [editing, setEditing] = useState<Activation | null>(null);
  const [secretsBusy, setSecretsBusy] = useState(false);
  const [secretsError, setSecretsError] = useState<string | null>(null);
  const [form, setForm] = useState({
    activation_email: '',
    activation_password: '',
    activation_details: '',
    internal_instructions: '',
    proof_url: '',
    priority: 'medium' as Priority,
    assigned_to: '',
    supplier_id: '',
  });

  const queueStatuses: ActivationStatus[] = ['waiting_payment', 'ready', 'processing', 'waiting_supplier'];

  const rows = useMemo(() => {
    const list = [...db.activations].sort((a, b) => {
      const pr = { urgent: 0, high: 1, medium: 2, low: 3 } as Record<string, number>;
      const d = (pr[a.priority] ?? 9) - (pr[b.priority] ?? 9);
      if (d !== 0) return d;
      return a.created_at.localeCompare(b.created_at);
    });
    if (tab === 'queue') return list.filter((a) => queueStatuses.includes(a.status));
    if (tab === 'all') return list;
    return list.filter((a) => a.status === tab);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [db.activations, tab]);

  const openEdit = (a: Activation) => {
    setEditing(a);
    setSecretsError(null);
    setForm({
      activation_email: a.activation_email ?? '',
      activation_password: '',
      activation_details: a.activation_details ?? '',
      internal_instructions: a.internal_instructions ?? '',
      proof_url: a.proof_url ?? '',
      priority: a.priority,
      assigned_to: a.assigned_to ?? '',
      supplier_id: a.supplier_id ?? '',
    });

    // In production the credentials are encrypted server-side and are not part
    // of the loaded snapshot, so fetch them on demand. Each read is audited.
    if (secretsAreServerSide()) {
      setSecretsBusy(true);
      fetchActivationSecrets(a.id)
        .then((sec) => setForm((f) => ({ ...f, ...sec })))
        .catch((e: Error) => setSecretsError(e.message))
        .finally(() => setSecretsBusy(false));
    }
  };

  const save = async () => {
    if (!editing) return;

    // Non-secret fields go through the normal store path.
    const patch: Record<string, unknown> = {
      proof_url: form.proof_url || null,
      priority: form.priority,
      assigned_to: form.assigned_to || null,
      supplier_id: form.supplier_id || null,
    };

    if (secretsAreServerSide()) {
      // Secrets must never travel through the snapshot diff — they are written
      // by the encrypting, permission-checked endpoint instead.
      try {
        setSecretsBusy(true);
        await saveActivationSecrets(editing.id, {
          activation_email: form.activation_email,
          activation_password: form.activation_password,
          activation_details: form.activation_details,
          internal_instructions: form.internal_instructions,
        });
      } catch (e) {
        setSecretsError((e as Error).message);
        setSecretsBusy(false);
        return;
      }
      setSecretsBusy(false);
    } else {
      patch.activation_email = form.activation_email || null;
      patch.activation_details = form.activation_details || null;
      patch.internal_instructions = form.internal_instructions || null;
    }

    updateActivation(editing.id, patch);
    toast({ title: 'Activation updated' });
    setEditing(null);
  };

  const counts = (s: string) => db.activations.filter((a) => a.status === s).length;
  const queue = db.activations.filter((a) => queueStatuses.includes(a.status));
  const overdue = queue.filter((a) => ageSince(a.created_at).hours > SLA_BREACH).length;
  const urgent = queue.filter((a) => a.priority === 'urgent').length;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Activation Queue"
        description="Deliver every paid order — payment → ready → processing → activated → delivered."
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KpiCard label="In Queue" value={queue.length} icon={Zap} tone="accent" />
        <KpiCard label="Ready to Action" value={counts('ready')} icon={CheckCircle2} tone="info" />
        <KpiCard label="Overdue (24h+)" value={overdue} icon={AlertTriangle} tone={overdue ? 'danger' : 'neutral'} />
        <KpiCard label="Urgent Priority" value={urgent} icon={AlertTriangle} tone={urgent ? 'warning' : 'neutral'} />
      </div>

      <Card>
        <Tabs
          value={tab}
          onChange={setTab}
          className="px-2"
          tabs={[
            { id: 'queue', label: 'Queue', count: queue.length },
            ...ACTIVATION_STATUS.map((s) => ({ id: s, label: s.replace(/_/g, ' '), count: counts(s) })),
            { id: 'all', label: 'All', count: db.activations.length },
          ]}
        />

        {rows.length === 0 ? (
          <EmptyState
            icon={Zap}
            title="Nothing in this view."
            message="New paid orders automatically create activation tasks."
          />
        ) : (
          <Table>
            <thead className="sticky-head">
              <tr>
                <Th>Product / Order</Th>
                <Th>Customer</Th>
                <Th>Status</Th>
                <Th>Priority</Th>
                <Th>Waiting</Th>
                <Th>Assignee</Th>
                <Th>Supplier</Th>
                <Th align="right">Action</Th>
              </tr>
            </thead>
            <tbody>
              {rows.slice(0, 80).map((a) => {
                const customer = db.customers.find((c) => c.id === a.customer_id);
                const order = db.orders.find((o) => o.id === a.order_id);
                const assignee = db.profiles.find((p) => p.id === a.assigned_to);
                const supplier = db.suppliers.find((s) => s.id === a.supplier_id);
                const age = ageSince(a.created_at);
                const settled = ['delivered', 'activated', 'cancelled'].includes(a.status);
                const ageColor = settled
                  ? 'var(--muted-2)'
                  : age.hours > SLA_BREACH
                    ? 'var(--danger)'
                    : age.hours > SLA_WARN
                      ? 'var(--warning)'
                      : 'var(--muted)';

                return (
                  <tr
                    key={a.id}
                    className={cn(
                      'row-hover',
                      a.priority === 'urgent' && !settled && 'bg-[var(--danger-soft)]/25',
                    )}
                  >
                    <Td>
                      <p className="max-w-[210px] truncate text-[12.5px] font-medium text-[var(--fg)]">
                        {a.product_name}
                      </p>
                      {order && (
                        <Link
                          href={`/orders/${order.id}`}
                          className="text-[11.5px] text-[var(--accent)] hover:underline"
                        >
                          {order.order_number}
                        </Link>
                      )}
                    </Td>
                    <Td>
                      <Link href={`/customers/${customer?.id}`} className="hover:opacity-80">
                        <IdentityCell name={customer?.name ?? '—'} secondary={customer?.customer_code} size={26} />
                      </Link>
                    </Td>
                    <Td>
                      <Select
                        value={a.status}
                        onChange={(e) => {
                          updateActivation(a.id, { status: e.target.value as ActivationStatus });
                          toast({ title: `Status → ${e.target.value.replace(/_/g, ' ')}` });
                        }}
                        className="h-7 w-auto min-w-[132px] py-0 text-[11.5px] capitalize"
                      >
                        {ACTIVATION_STATUS.map((s) => (
                          <option key={s} value={s}>
                            {s.replace(/_/g, ' ')}
                          </option>
                        ))}
                      </Select>
                    </Td>
                    <Td>
                      <Badge
                        tone={
                          a.priority === 'urgent' ? 'danger' : a.priority === 'high' ? 'warning' : 'neutral'
                        }
                        dot={a.priority === 'urgent' || a.priority === 'high'}
                      >
                        {a.priority}
                      </Badge>
                    </Td>
                    <Td>
                      <span
                        className="inline-flex items-center gap-1.5 whitespace-nowrap text-[12px] font-medium tabular-nums"
                        style={{ color: ageColor }}
                      >
                        <Clock className="h-3 w-3" />
                        {settled ? '—' : age.label}
                      </span>
                    </Td>
                    <Td>
                      {assignee ? (
                        <div className="flex items-center gap-1.5">
                          <Avatar name={assignee.full_name} size={20} />
                          <span className="max-w-[92px] truncate text-[12px]">{assignee.full_name}</span>
                        </div>
                      ) : (
                        <span className="text-[12px] text-[var(--muted-2)]">Unassigned</span>
                      )}
                    </Td>
                    <Td className="text-[12px] text-[var(--muted)]">
                      <span className="flex items-center gap-1.5">
                        {supplier ? (
                          <>
                            <Truck className="h-3 w-3 opacity-60" />
                            <span className="max-w-[92px] truncate">{supplier.name}</span>
                          </>
                        ) : (
                          '—'
                        )}
                      </span>
                    </Td>
                    <Td align="right">
                      <div className="flex items-center justify-end gap-1.5">
                        {a.proof_url && (
                          <Tooltip label="Open activation proof">
                            <a href={a.proof_url} target="_blank" rel="noreferrer">
                              <Button size="icon-sm" variant="ghost" aria-label="Proof">
                                <ExternalLink className="h-3.5 w-3.5" />
                              </Button>
                            </a>
                          </Tooltip>
                        )}
                        <Button size="sm" variant="outline" onClick={() => openEdit(a)}>
                          Details
                        </Button>
                        {!['delivered', 'cancelled'].includes(a.status) && (
                          <Button
                            size="sm"
                            variant="primary"
                            onClick={() => {
                              completeActivation(a.id);
                              toast({
                                title: 'Delivered',
                                description: 'Subscription created if the product has a duration.',
                              });
                            }}
                          >
                            Deliver
                          </Button>
                        )}
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        )}
      </Card>

      <Modal
        open={!!editing}
        onClose={() => setEditing(null)}
        title="Activation details"
        description={editing?.product_name}
        width="lg"
        footer={
          <>
            <Button onClick={() => setEditing(null)}>Cancel</Button>
            <Button variant="primary" onClick={save} disabled={secretsBusy}>
              {secretsBusy ? 'Saving…' : 'Save changes'}
            </Button>
          </>
        }
      >
        {secretsError && (
          <div
            className="mb-3 rounded-[7px] px-2.5 py-2 text-xs"
            style={{
              background: 'var(--danger-soft)',
              color: 'var(--danger)',
              border: '1px solid var(--danger-border)',
            }}
          >
            {secretsError}
          </div>
        )}
        {secretsAreServerSide() && (
          <div className="mb-3 text-[11px]" style={{ color: 'var(--muted)' }}>
            Credentials are encrypted at rest and fetched only when you open this
            activation. Every view and change is recorded in the audit log.
          </div>
        )}
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Activation email">
            <Input
              autoComplete="off"
              value={form.activation_email}
              onChange={(e) => setForm({ ...form, activation_email: e.target.value })}
            />
          </Field>
          <Field label="Activation password">
            <Input
              type="password"
              autoComplete="new-password"
              placeholder={secretsBusy ? 'Loading…' : ''}
              value={form.activation_password}
              onChange={(e) => setForm({ ...form, activation_password: e.target.value })}
            />
          </Field>
          <Field label="Priority">
            <Select
              value={form.priority}
              onChange={(e) => setForm({ ...form, priority: e.target.value as Priority })}
            >
              {PRIORITY.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Assigned to">
            <Select
              value={form.assigned_to}
              onChange={(e) => setForm({ ...form, assigned_to: e.target.value })}
            >
              <option value="">Unassigned</option>
              {db.profiles.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.full_name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Supplier">
            <Select
              value={form.supplier_id}
              onChange={(e) => setForm({ ...form, supplier_id: e.target.value })}
            >
              <option value="">None</option>
              {db.suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Activation details / credentials" className="sm:col-span-2">
            <Textarea
              rows={3}
              value={form.activation_details}
              onChange={(e) => setForm({ ...form, activation_details: e.target.value })}
              placeholder="Invite sent to …, license key …"
            />
          </Field>
          <Field label="Internal instructions" className="sm:col-span-2">
            <Textarea
              rows={2}
              value={form.internal_instructions}
              onChange={(e) => setForm({ ...form, internal_instructions: e.target.value })}
            />
          </Field>
          <Field
            label="Activation proof URL"
            className="sm:col-span-2"
            hint="Attachment upload requires object storage — paste a link for now."
          >
            <Input
              value={form.proof_url}
              onChange={(e) => setForm({ ...form, proof_url: e.target.value })}
              placeholder="https://…"
            />
          </Field>
        </div>
      </Modal>
    </div>
  );
}
