'use client';

import { useMemo } from 'react';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Card, CardHeader, Table, Td } from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { RangePicker, useDateRange } from '@/components/range-picker';
import { RevenueAreaChart, SimplePieChart } from '@/components/charts';
import { buildSeries } from '@/lib/services/analytics';
import { computeProfit } from '@/lib/services/business';
import { formatINR, round2 } from '@/lib/utils';
import { IndianRupee, PiggyBank, Receipt, TrendingUp } from 'lucide-react';

export default function ProfitPage() {
  const { db } = useStore();
  const { key, setKey, custom, setCustom, range } = useDateRange('30d');

  const p = useMemo(() => computeProfit(db.orders, db.expenses, range), [db, range]);
  const series = useMemo(() => buildSeries(db, range), [db, range]);

  const expenseSplit = useMemo(() => {
    const m = new Map<string, number>();
    for (const e of db.expenses) {
      const t = new Date(e.spent_at);
      if (t < range.from || t > range.to) continue;
      m.set(e.category, round2((m.get(e.category) ?? 0) + e.amount));
    }
    return Array.from(m.entries()).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [db.expenses, range]);

  const rows: [string, number, string?][] = [
    ['Gross Revenue', p.grossRevenue],
    ['Product / supplier cost', -p.productCost],
    ['Refunds', -p.refunds],
    ['Gross Profit', p.grossProfit, 'bold'],
    ['Operating expenses', -p.operatingExpenses],
    ['Net Profit', p.netProfit, 'bold'],
  ];

  return (
    <>
      <PageHeader title="Profit" description={`${range.label} · Revenue − product cost − refunds − operating expenses`}
        actions={<RangePicker value={key} onChange={setKey} custom={custom} onCustomChange={setCustom} />} />

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <KpiCard label="Gross Revenue" value={formatINR(p.grossRevenue, { compact: true })} icon={IndianRupee} tone="accent" />
        <KpiCard label="Gross Profit" value={formatINR(p.grossProfit, { compact: true })} icon={TrendingUp} tone="success" />
        <KpiCard label="Operating Expenses" value={formatINR(p.operatingExpenses, { compact: true })} icon={Receipt} tone="warning" />
        <KpiCard label="Net Profit" value={formatINR(p.netProfit, { compact: true })} icon={PiggyBank} tone={p.netProfit >= 0 ? 'success' : 'danger'} />
        <KpiCard label="Gross Margin" value={`${p.grossMargin}%`} icon={TrendingUp} />
        <KpiCard label="Net Margin" value={`${p.netMargin}%`} icon={PiggyBank} />
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader title="Profit vs revenue vs expenses" subtitle={range.label} />
          <div className="p-3">
            <RevenueAreaChart
              data={series as unknown as Record<string, string | number>[]}
              keys={[
                { key: 'revenue', label: 'Revenue', color: '#5b5bd6' },
                { key: 'profit', label: 'Gross Profit', color: '#12874a' },
                { key: 'expenses', label: 'Expenses', color: '#b45309' },
              ]}
              height={300}
            />
          </div>
        </Card>

        <Card>
          <CardHeader title="P&L statement" subtitle={range.label} />
          <Table className="min-w-0">
            <tbody>
              {rows.map(([label, value, bold]) => (
                <tr key={label}>
                  <Td className={bold ? 'font-semibold' : 'text-[13px] text-[var(--muted)]'}>{label}</Td>
                  <Td className={`text-right tabular-nums ${bold ? 'font-semibold' : ''}`} style={value < 0 ? { color: 'var(--danger)' } : bold ? { color: 'var(--success)' } : undefined}>
                    {formatINR(value)}
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader title="Expense breakdown" subtitle={range.label} />
        <div className="p-3">
          {expenseSplit.length ? <SimplePieChart data={expenseSplit} height={280} /> : <p className="py-10 text-center text-[12.5px] text-[var(--muted)]">No expenses in range</p>}
        </div>
      </Card>
    </>
  );
}
