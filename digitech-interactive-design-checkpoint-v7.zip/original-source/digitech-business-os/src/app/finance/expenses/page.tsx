'use client';

import { Suspense, useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { DataTable, type Column } from '@/components/ui/data-table';
import { Badge, Button, ConfirmDialog, Field, Input, Modal, Select, Textarea } from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { useToast } from '@/components/ui/toast';
import { formatDate, formatINR, round2, num } from '@/lib/utils';
import { EXPENSE_CATEGORY, PAYMENT_METHOD, type Expense, type ExpenseCategory, type PaymentMethod } from '@/lib/types';
import { Plus, Receipt, Repeat, Trash2 } from 'lucide-react';

function ExpensesInner() {
  const { db, createExpense, updateExpense, deleteExpense } = useStore();
  const toast = useToast();
  const params = useSearchParams();
  const [open, setOpen] = useState(params.get('new') === '1');
  const [editing, setEditing] = useState<Expense | null>(null);
  const [del, setDel] = useState<Expense | null>(null);
  const [cat, setCat] = useState('all');
  const [f, setF] = useState({ category: 'miscellaneous' as ExpenseCategory, description: '', amount: 0, vendor: '', spent_at: new Date().toISOString().slice(0, 10), method: 'upi' as PaymentMethod, is_recurring: false });

  const rows = useMemo(() => {
    let list = [...db.expenses].sort((a, b) => b.spent_at.localeCompare(a.spent_at));
    if (cat !== 'all') list = list.filter((e) => e.category === cat);
    return list;
  }, [db.expenses, cat]);

  const total = round2(rows.reduce((a, e) => a + e.amount, 0));
  const thisMonth = round2(db.expenses.filter((e) => new Date(e.spent_at) >= new Date(new Date().getFullYear(), new Date().getMonth(), 1)).reduce((a, e) => a + e.amount, 0));
  const recurring = db.expenses.filter((e) => e.is_recurring).length;

  const openNew = () => { setEditing(null); setF({ category: 'miscellaneous', description: '', amount: 0, vendor: '', spent_at: new Date().toISOString().slice(0, 10), method: 'upi', is_recurring: false }); setOpen(true); };
  const openEdit = (e: Expense) => {
    setEditing(e);
    setF({ category: e.category, description: e.description, amount: e.amount, vendor: e.vendor ?? '', spent_at: e.spent_at.slice(0, 10), method: e.method, is_recurring: e.is_recurring });
    setOpen(true);
  };
  const submit = () => {
    if (!f.description.trim() || !f.amount) { toast({ title: 'Description and amount required', tone: 'error' }); return; }
    const payload = { ...f, spent_at: new Date(f.spent_at).toISOString() };
    if (editing) { updateExpense(editing.id, payload); toast({ title: 'Expense updated' }); }
    else { createExpense(payload); toast({ title: 'Expense recorded' }); }
    setOpen(false);
  };

  const columns: Column<Expense>[] = [
    { key: 'date', header: 'Date', sortValue: (e) => e.spent_at, exportValue: (e) => e.spent_at, render: (e) => <span className="whitespace-nowrap text-[12.5px]">{formatDate(e.spent_at)}</span> },
    { key: 'desc', header: 'Description', sortValue: (e) => e.description, exportValue: (e) => e.description, render: (e) => <div><p className="text-[13px]">{e.description}</p><p className="text-[11.5px] text-[var(--muted)]">{e.vendor ?? '—'}</p></div> },
    { key: 'cat', header: 'Category', sortValue: (e) => e.category, exportValue: (e) => e.category, render: (e) => <Badge tone="accent">{e.category}</Badge> },
    { key: 'method', header: 'Method', sortValue: (e) => e.method, exportValue: (e) => e.method, render: (e) => <span className="text-[12.5px] capitalize">{e.method.replace('_', ' ')}</span> },
    { key: 'rec', header: 'Recurring', exportValue: (e) => (e.is_recurring ? 'yes' : 'no'), render: (e) => e.is_recurring ? <Repeat className="h-3.5 w-3.5 text-[var(--accent)]" /> : <span className="text-[12.5px] text-[var(--muted-2)]">—</span> },
    { key: 'amount', header: 'Amount', className: 'text-right', sortValue: (e) => e.amount, exportValue: (e) => e.amount, render: (e) => <span className="tabular-nums font-medium">{formatINR(e.amount)}</span> },
    { key: 'act', header: '', className: 'text-right', exportValue: () => '', render: (e) => (
      <button onClick={(ev) => { ev.stopPropagation(); setDel(e); }} className="rounded p-1 text-[var(--danger)] hover:bg-[var(--danger-soft)]"><Trash2 className="h-3.5 w-3.5" /></button>
    ) },
  ];

  return (
    <>
      <PageHeader title="Expenses" description="Operating costs feeding the net profit engine"
        actions={<Button variant="primary" onClick={openNew}><Plus className="h-3.5 w-3.5" /> New Expense</Button>} />

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiCard label="Filtered total" value={formatINR(total, { compact: true })} icon={Receipt} tone="warning" />
        <KpiCard label="This month" value={formatINR(thisMonth, { compact: true })} icon={Receipt} />
        <KpiCard label="Recurring items" value={recurring} icon={Repeat} tone="accent" />
        <KpiCard label="Entries" value={rows.length} icon={Receipt} />
      </div>

      <DataTable rows={rows} columns={columns} exportName="expenses" onRowClick={openEdit} searchable={(e) => `${e.description} ${e.vendor} ${e.category}`}
        toolbar={
          <Select value={cat} onChange={(e) => setCat(e.target.value)} className="h-8 w-auto py-0 text-[12.5px]">
            <option value="all">All categories</option>
            {EXPENSE_CATEGORY.map((c) => <option key={c} value={c}>{c}</option>)}
          </Select>
        } />

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit expense' : 'New expense'} width="lg"
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" onClick={submit}>{editing ? 'Save' : 'Record'}</Button></>}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Description *" className="sm:col-span-2"><Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} placeholder="Meta Ads campaign" /></Field>
          <Field label="Category"><Select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value as ExpenseCategory })}>{EXPENSE_CATEGORY.map((c) => <option key={c} value={c}>{c}</option>)}</Select></Field>
          <Field label="Amount (₹) *"><Input type="number" value={f.amount} onChange={(e) => setF({ ...f, amount: Math.max(0, num(e.target.value)) })} /></Field>
          <Field label="Vendor"><Input value={f.vendor} onChange={(e) => setF({ ...f, vendor: e.target.value })} /></Field>
          <Field label="Date"><Input type="date" value={f.spent_at} onChange={(e) => setF({ ...f, spent_at: e.target.value })} /></Field>
          <Field label="Payment method"><Select value={f.method} onChange={(e) => setF({ ...f, method: e.target.value as PaymentMethod })}>{PAYMENT_METHOD.map((m) => <option key={m} value={m}>{m.replace('_', ' ')}</option>)}</Select></Field>
          <label className="flex items-center gap-2 self-end pb-2 text-[13px]">
            <input type="checkbox" checked={f.is_recurring} onChange={(e) => setF({ ...f, is_recurring: e.target.checked })} /> Recurring expense
          </label>
          <Field label="Attachment" className="sm:col-span-2" hint="File storage requires Supabase — coming soon">
            <Textarea rows={1} disabled placeholder="Receipt upload — Coming Soon" />
          </Field>
        </div>
      </Modal>

      <ConfirmDialog open={!!del} onClose={() => setDel(null)} onConfirm={() => { if (del) { deleteExpense(del.id); toast({ title: 'Expense deleted', tone: 'warning' }); } }}
        title="Delete expense?" message="This permanently removes the expense and affects net profit calculations." confirmLabel="Delete" danger />
    </>
  );
}

export default function ExpensesPage() {
  return <Suspense fallback={null}><ExpensesInner /></Suspense>;
}
