'use client';

import { useMemo } from 'react';
import Link from 'next/link';
import { AlertTriangle, ArrowRight, Landmark, Receipt, ScanSearch, ShieldAlert, Users } from 'lucide-react';
import { useStore } from '@/lib/store';
import { Badge, Card, CardHeader, EmptyState, PageHeader, Progress } from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { buildFinanceSignals } from '@/lib/services/intelligence';
import { supplierBalance } from '@/lib/services/suppliers';
import { formatINR } from '@/lib/utils';

export default function FinanceIntelligencePage() {
  const { db } = useStore();
  const signals = useMemo(() => buildFinanceSignals(db), [db]);
  const receivables = db.orders.filter((order) => order.outstanding > 0 && !['cancelled', 'refunded'].includes(order.status));
  const outstanding = receivables.reduce((sum, order) => sum + order.outstanding, 0);
  const supplierDue = db.suppliers.reduce((sum, item) => sum + supplierBalance(db, item.id).balance, 0);
  const recurringBurn = db.expenses.filter((item) => item.is_recurring).reduce((sum, item) => sum + item.amount, 0);
  const byCustomer = new Map<string, number>();
  for (const order of receivables) byCustomer.set(order.customer_id, (byCustomer.get(order.customer_id) ?? 0) + order.outstanding);
  const concentration = [...byCustomer.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
  const topShare = outstanding > 0 && concentration[0] ? Math.round((concentration[0][1] / outstanding) * 100) : 0;

  return (
    <div className="space-y-4">
      <PageHeader title="Finance Intelligence" description="Exception-first monitoring for receivables, margin leakage, supplier dues, and cash concentration." />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KpiCard label="Receivables" value={formatINR(outstanding, { compact: true })} sub={`${receivables.length} open orders`} icon={Landmark} tone="danger" />
        <KpiCard label="Supplier Due" value={formatINR(supplierDue, { compact: true })} icon={Receipt} tone="warning" />
        <KpiCard label="Recurring Burn" value={formatINR(recurringBurn, { compact: true })} sub="recorded recurring items" icon={ShieldAlert} tone="accent" />
        <KpiCard label="Top Customer Share" value={`${topShare}%`} sub="of open receivables" icon={Users} tone={topShare >= 50 ? 'danger' : 'info'} />
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.4fr)_minmax(320px,0.6fr)]">
        <Card>
          <CardHeader title="Risk signals" subtitle="Ranked by severity and amount" />
          {signals.length === 0 ? <EmptyState icon={ScanSearch} title="No material exceptions" message="No large receivables, negative-margin orders, or overdue supplier payments were found." /> : (
            <div className="divide-y divide-[var(--border-subtle)]">
              {signals.map((signal) => <Link key={signal.id} href={signal.href} className="group flex items-start gap-3 px-4 py-3.5 transition-colors hover:bg-[var(--surface-2)]">
                <span className={`mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-[9px] ${signal.severity === 'critical' ? 'bg-[var(--danger-soft)] text-[var(--danger)]' : signal.severity === 'high' ? 'bg-[var(--warning-soft)] text-[var(--warning)]' : 'bg-[var(--info-soft)] text-[var(--info)]'}`}><AlertTriangle className="h-4 w-4" /></span>
                <span className="min-w-0 flex-1"><span className="flex flex-wrap items-center gap-2"><strong className="text-[13px]">{signal.title}</strong><Badge tone={signal.severity === 'critical' ? 'danger' : signal.severity === 'high' ? 'warning' : 'info'}>{signal.severity}</Badge></span><span className="mt-1 block text-[12px] leading-relaxed text-[var(--muted)]">{signal.detail}</span></span>
                <span className="shrink-0 text-right"><strong className="block text-[12.5px] tabular-nums">{formatINR(signal.amount)}</strong><ArrowRight className="ml-auto mt-2 h-3.5 w-3.5 text-[var(--muted-2)] transition-transform group-hover:translate-x-0.5" /></span>
              </Link>)}
            </div>
          )}
        </Card>

        <Card>
          <CardHeader title="Receivable concentration" subtitle="Largest customer exposure" />
          {concentration.length === 0 ? <EmptyState title="No open receivables" message="Paid orders will keep this panel clear." /> : <div className="space-y-4 p-4">
            {concentration.map(([customerId, amount], index) => {
              const customer = db.customers.find((item) => item.id === customerId);
              const share = outstanding ? Math.round((amount / outstanding) * 100) : 0;
              return <div key={customerId}><div className="mb-1.5 flex items-center justify-between gap-3 text-[12px]"><Link href={`/customers/${customerId}`} className="truncate font-medium hover:text-[var(--accent)]">{index + 1}. {customer?.name ?? 'Unknown customer'}</Link><span className="shrink-0 font-semibold tabular-nums">{formatINR(amount)} · {share}%</span></div><Progress value={share} tone={share >= 50 ? 'danger' : share >= 30 ? 'warning' : 'accent'} /></div>;
            })}
            <p className="border-t border-[var(--border)] pt-3 text-[11.5px] leading-relaxed text-[var(--muted)]">A high single-customer share can create cash-flow risk even when total sales look healthy.</p>
          </div>}
        </Card>
      </div>
    </div>
  );
}
