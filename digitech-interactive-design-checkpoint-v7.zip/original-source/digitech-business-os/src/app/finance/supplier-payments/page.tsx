'use client';

import { useMemo } from 'react';
import Link from 'next/link';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Badge, Button, Card, CardHeader, EmptyState, Table, Td, Th } from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { supplierBalance } from '@/lib/services/suppliers';
import { formatDate, formatINR, round2 } from '@/lib/utils';
import { AlertCircle, Banknote, Truck } from 'lucide-react';

export default function SupplierPaymentsPage() {
  const { db } = useStore();

  const balances = useMemo(
    () => db.suppliers.map((s) => ({ supplier: s, ...supplierBalance(db, s.id) })).sort((a, b) => b.balance - a.balance),
    [db],
  );
  const totalDue = round2(balances.reduce((a, b) => a + b.balance, 0));
  const totalPaid = round2(balances.reduce((a, b) => a + b.paid, 0));
  const payments = [...db.supplier_payments].sort((a, b) => b.paid_at.localeCompare(a.paid_at));

  return (
    <>
      <PageHeader title="Supplier Payments" description="Track what you owe suppliers against cost snapshots on sold orders" />

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-3">
        <KpiCard label="Total outstanding" value={formatINR(totalDue, { compact: true })} icon={AlertCircle} tone="danger" />
        <KpiCard label="Total paid" value={formatINR(totalPaid, { compact: true })} icon={Banknote} tone="success" />
        <KpiCard label="Suppliers" value={db.suppliers.length} icon={Truck} />
      </div>

      <Card className="mb-4">
        <CardHeader title="Supplier balances" />
        <Table>
          <thead><tr><Th>Supplier</Th><Th>Terms</Th><Th className="text-right">Purchased</Th><Th className="text-right">Paid</Th><Th className="text-right">Outstanding</Th><Th /></tr></thead>
          <tbody>
            {balances.map((b) => (
              <tr key={b.supplier.id}>
                <Td><Link href={`/suppliers/${b.supplier.id}`} className="font-medium text-[var(--accent)] hover:underline">{b.supplier.name}</Link></Td>
                <Td className="text-[12.5px]">{b.supplier.payment_terms ?? '—'}</Td>
                <Td className="text-right tabular-nums">{formatINR(b.purchased)}</Td>
                <Td className="text-right tabular-nums">{formatINR(b.paid)}</Td>
                <Td className="text-right">{b.balance > 0 ? <Badge tone="danger">{formatINR(b.balance)}</Badge> : <Badge tone="success">settled</Badge>}</Td>
                <Td className="text-right"><Link href={`/suppliers/${b.supplier.id}`}><Button size="sm">Pay</Button></Link></Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Card>

      <Card>
        <CardHeader title="Payment history" subtitle={`${payments.length} payments`} />
        {payments.length === 0 ? <EmptyState icon={Banknote} title="No supplier payments recorded" message="Record a payment to track what you owe each supplier." /> : (
          <Table>
            <thead><tr><Th>Date</Th><Th>Supplier</Th><Th>Method</Th><Th>Reference</Th><Th className="text-right">Amount</Th></tr></thead>
            <tbody>
              {payments.slice(0, 60).map((p) => (
                <tr key={p.id}>
                  <Td className="text-[12.5px]">{formatDate(p.paid_at)}</Td>
                  <Td className="text-[13px]">{db.suppliers.find((s) => s.id === p.supplier_id)?.name ?? '—'}</Td>
                  <Td className="text-[12.5px] capitalize">{p.method.replace('_', ' ')}</Td>
                  <Td className="text-[12.5px] text-[var(--muted)]">{p.reference ?? '—'}</Td>
                  <Td className="text-right tabular-nums">{formatINR(p.amount)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
