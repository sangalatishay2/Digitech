'use client';

import { useMemo } from 'react';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Card, CardHeader, Table, Td, Th } from '@/components/ui/primitives';
import { KpiCard } from '@/components/kpi-card';
import { RangePicker, useDateRange } from '@/components/range-picker';
import { RevenueAreaChart, SimplePieChart } from '@/components/charts';
import { buildSeries, computeKpis, topProducts } from '@/lib/services/analytics';
import { formatINR, round2 } from '@/lib/utils';
import { IndianRupee, ShoppingCart, TrendingUp, Users } from 'lucide-react';

export default function RevenuePage() {
  const { db } = useStore();
  const { key, setKey, custom, setCustom, range } = useDateRange('30d');

  const kpis = useMemo(() => computeKpis(db, range), [db, range]);
  const series = useMemo(() => buildSeries(db, range), [db, range]);
  const products = useMemo(() => topProducts(db, range, 8), [db, range]);

  const byMethod = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of db.payments) {
      if (p.is_refund) continue;
      const t = new Date(p.paid_at);
      if (t < range.from || t > range.to) continue;
      m.set(p.method, round2((m.get(p.method) ?? 0) + p.amount));
    }
    return Array.from(m.entries()).map(([name, value]) => ({ name: name.replace('_', ' '), value }));
  }, [db.payments, range]);

  const byCategory = useMemo(() => {
    const m = new Map<string, number>();
    for (const o of db.orders) {
      const t = new Date(o.ordered_at);
      if (t < range.from || t > range.to || o.status === 'cancelled') continue;
      for (const i of o.items) {
        const prod = db.products.find((p) => p.id === i.product_id);
        const cat = db.product_categories.find((c) => c.id === prod?.category_id)?.name ?? 'Uncategorised';
        m.set(cat, round2((m.get(cat) ?? 0) + i.line_total));
      }
    }
    return Array.from(m.entries()).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [db, range]);

  return (
    <>
      <PageHeader title="Revenue" description={range.label}
        actions={<RangePicker value={key} onChange={setKey} custom={custom} onCustomChange={setCustom} />} />

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiCard label="Gross Revenue" value={formatINR(kpis.revenue, { compact: true })} icon={IndianRupee} tone="accent" />
        <KpiCard label="Orders" value={kpis.orders} icon={ShoppingCart} />
        <KpiCard label="Average Order Value" value={formatINR(kpis.aov)} icon={TrendingUp} tone="success" />
        <KpiCard label="New Customers" value={kpis.newCustomers} icon={Users} />
      </div>

      <Card className="mb-4">
        <CardHeader title="Revenue trend" subtitle={range.label} />
        <div className="p-3">
          <RevenueAreaChart data={series as unknown as Record<string, string | number>[]} keys={[{ key: 'revenue', label: 'Revenue', color: '#5b5bd6' }]} height={280} />
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Revenue by payment method" />
          <div className="p-3">{byMethod.length ? <SimplePieChart data={byMethod} /> : <p className="py-10 text-center text-[12.5px] text-[var(--muted)]">No payments in range</p>}</div>
        </Card>
        <Card>
          <CardHeader title="Revenue by category" />
          <div className="p-3">{byCategory.length ? <SimplePieChart data={byCategory} /> : <p className="py-10 text-center text-[12.5px] text-[var(--muted)]">No sales in range</p>}</div>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader title="Top products by revenue" subtitle={range.label} />
        <Table>
          <thead><tr><Th>Product</Th><Th className="text-right">Units</Th><Th className="text-right">Revenue</Th><Th className="text-right">Profit</Th><Th className="text-right">Margin</Th></tr></thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.name}>
                <Td className="text-[13px]">{p.name}</Td>
                <Td className="text-right tabular-nums">{p.units}</Td>
                <Td className="text-right tabular-nums">{formatINR(p.revenue)}</Td>
                <Td className="text-right tabular-nums" style={{ color: 'var(--success)' }}>{formatINR(p.profit)}</Td>
                <Td className="text-right tabular-nums">{p.revenue ? round2((p.profit / p.revenue) * 100) : 0}%</Td>
              </tr>
            ))}
            {products.length === 0 && <tr><Td className="py-8 text-center text-[12.5px] text-[var(--muted)]">No sales in range</Td></tr>}
          </tbody>
        </Table>
      </Card>
    </>
  );
}
