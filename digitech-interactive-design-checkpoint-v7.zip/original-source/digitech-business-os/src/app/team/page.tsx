'use client';

import { useState } from 'react';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Avatar, Badge, Button, Card, CardHeader, Field, Input, Modal, Select, Table, Tabs, Td, Th } from '@/components/ui/primitives';
import { useToast } from '@/components/ui/toast';
import { formatDate } from '@/lib/utils';
import { ROLES, type Role } from '@/lib/types';
import { Check, Plus, X } from 'lucide-react';

const PERMISSION_MATRIX: Record<string, Role[]> = {
  'View dashboard': ['owner', 'admin', 'sales', 'support', 'accounts', 'operations', 'viewer'],
  'Manage customers': ['owner', 'admin', 'sales'],
  'Create orders': ['owner', 'admin', 'sales'],
  'Record payments / refunds': ['owner', 'admin', 'accounts'],
  'Manage activations': ['owner', 'admin', 'operations'],
  'Manage subscriptions & renewals': ['owner', 'admin', 'sales', 'operations'],
  'Manage leads': ['owner', 'admin', 'sales'],
  'Manage support tickets': ['owner', 'admin', 'support'],
  'Manage products & suppliers': ['owner', 'admin', 'operations'],
  'Manage expenses & invoices': ['owner', 'admin', 'accounts'],
  'View finance & profit': ['owner', 'admin', 'accounts'],
  'Manage automations': ['owner', 'admin'],
  'Manage team & roles': ['owner', 'admin'],
  'Change business settings': ['owner', 'admin'],
  'Reset / import data': ['owner'],
};

export default function TeamPage() {
  const { db, currentUser, can, addTeamMember, setMemberRole, setMemberActive } = useStore();
  const toast = useToast();
  const [tab, setTab] = useState('members');
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ full_name: '', email: '', phone: '', role: 'sales' as Role });

  const invite = () => {
    if (!f.full_name.trim() || !f.email.trim()) { toast({ title: 'Name and email required', tone: 'error' }); return; }
    addTeamMember({ full_name: f.full_name, email: f.email, phone: f.phone || null, role: f.role });
    toast({ title: 'Team member added', description: 'Auth linkage happens automatically when Supabase is connected.' });
    setF({ full_name: '', email: '', phone: '', role: 'sales' });
    setOpen(false);
  };

  const setRole = (id: string, role: Role) => {
    setMemberRole(id, role);
    toast({ title: 'Role updated' });
  };

  const toggleActive = (id: string) => {
    const p = db.profiles.find((x) => x.id === id);
    if (p) setMemberActive(id, !p.is_active);
  };

  const canManage = can('team.manage') || can('*');

  return (
    <>
      <PageHeader title="Team" description={`${db.profiles.length} members · role-based access control`}
        actions={canManage ? <Button variant="primary" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5" /> Add Member</Button> : undefined} />

      <Card className="mb-4">
        <Tabs value={tab} onChange={setTab} className="px-2" tabs={[
          { id: 'members', label: 'Members', count: db.profiles.length },
          { id: 'roles', label: 'Roles & Permissions' },
        ]} />
      </Card>

      {tab === 'members' && (
        <Card>
          <CardHeader title="Team members" subtitle="Switch the active user from the avatar menu to test permissions" />
          <Table>
            <thead><tr><Th>Member</Th><Th>Email</Th><Th>Phone</Th><Th>Role</Th><Th>Status</Th><Th>Joined</Th></tr></thead>
            <tbody>
              {db.profiles.map((p) => (
                <tr key={p.id}>
                  <Td>
                    <div className="flex items-center gap-2.5">
                      <Avatar name={p.full_name} size={30} />
                      <div>
                        <p className="font-medium">{p.full_name}</p>
                        {p.id === currentUser?.id && <p className="text-[11.5px] text-[var(--accent)]">You</p>}
                      </div>
                    </div>
                  </Td>
                  <Td className="text-[12.5px]">{p.email}</Td>
                  <Td className="text-[12.5px]">{p.phone ?? '—'}</Td>
                  <Td>
                    {canManage && p.role !== 'owner' ? (
                      <Select value={p.role} onChange={(e) => setRole(p.id, e.target.value as Role)} className="h-7 w-auto py-0 text-[12.5px] capitalize">
                        {ROLES.filter((r) => r !== 'owner').map((r) => <option key={r} value={r}>{r}</option>)}
                      </Select>
                    ) : <Badge tone="accent">{p.role}</Badge>}
                  </Td>
                  <Td>
                    <button onClick={() => canManage && p.role !== 'owner' && toggleActive(p.id)} disabled={!canManage || p.role === 'owner'}>
                      <Badge tone={p.is_active ? 'success' : 'neutral'}>{p.is_active ? 'active' : 'disabled'}</Badge>
                    </button>
                  </Td>
                  <Td className="text-[12.5px] text-[var(--muted)]">{formatDate(p.created_at)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      {tab === 'roles' && (
        <Card>
          <CardHeader title="Permission matrix" subtitle="Enforced in the UI and in the data/service layer" />
          <Table>
            <thead>
              <tr>
                <Th>Capability</Th>
                {ROLES.map((r) => <Th key={r} className="text-center capitalize">{r}</Th>)}
              </tr>
            </thead>
            <tbody>
              {Object.entries(PERMISSION_MATRIX).map(([cap, roles]) => (
                <tr key={cap}>
                  <Td className="text-[13px]">{cap}</Td>
                  {ROLES.map((r) => (
                    <Td key={r} className="text-center">
                      {roles.includes(r)
                        ? <Check className="mx-auto h-3.5 w-3.5" style={{ color: 'var(--success)' }} />
                        : <X className="mx-auto h-3.5 w-3.5" style={{ color: 'var(--muted-2)' }} />}
                    </Td>
                  ))}
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Add team member"
        description="Standalone-first: profiles do not require an auth user. auth_user_id stays null until Supabase Auth is connected."
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" onClick={invite}>Add member</Button></>}>
        <div className="space-y-3">
          <Field label="Full name *"><Input value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></Field>
          <Field label="Email *"><Input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
          <Field label="Phone"><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
          <Field label="Role">
            <Select value={f.role} onChange={(e) => setF({ ...f, role: e.target.value as Role })}>
              {ROLES.filter((r) => r !== 'owner').map((r) => <option key={r} value={r}>{r}</option>)}
            </Select>
          </Field>
        </div>
      </Modal>
    </>
  );
}
