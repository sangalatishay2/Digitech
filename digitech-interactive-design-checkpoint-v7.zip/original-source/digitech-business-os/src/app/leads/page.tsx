'use client';

import { Suspense, useMemo, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useStore } from '@/lib/store';
import { PageHeader } from '@/components/shell/app-shell';
import { Avatar, Button, Card, EmptyState, Field, Input, Modal, Select, StatusBadge, Textarea } from '@/components/ui/primitives';
import { DataTable, type Column } from '@/components/ui/data-table';
import { useToast } from '@/components/ui/toast';
import { formatDate, formatINR, cn, num, clamp } from '@/lib/utils';
import { LEAD_STATUS, type Lead, type LeadStatus } from '@/lib/types';

/** Subtle per-stage accent used only as a thin indicator bar. */
const STAGE_COLOR: Record<string, string> = {
  new: 'var(--info)',
  contacted: 'var(--chart-3)',
  qualified: 'var(--accent)',
  interested: 'var(--chart-5)',
  negotiation: 'var(--warning)',
  follow_up: 'var(--chart-4)',
  won: 'var(--success)',
  lost: 'var(--muted-2)',
};
import { LayoutGrid, List, Plus, UserCheck, UserPlus } from 'lucide-react';

const SOURCES = ['Instagram', 'WhatsApp', 'Referral', 'Google', 'Website', 'Facebook', 'Walk-in', 'YouTube', 'Other'];

function LeadsInner() {
  const { db, createLead, updateLead, convertLead } = useStore();
  const router = useRouter();
  const toast = useToast();
  const params = useSearchParams();
  const [mode, setMode] = useState<'kanban' | 'list'>('kanban');
  const [open, setOpen] = useState(params.get('new') === '1');
  const [editing, setEditing] = useState<Lead | null>(null);
  const [f, setF] = useState({ name: '', phone: '', email: '', company: '', source: '', interested_product_id: '', value: 0, probability: 30, status: 'new' as LeadStatus, assigned_to: '', follow_up_at: '', notes: '' });

  const leads = db.leads;
  const byStatus = useMemo(() => {
    const m: Record<string, Lead[]> = {};
    for (const s of LEAD_STATUS) m[s] = leads.filter((l) => l.status === s);
    return m;
  }, [leads]);

  const pipelineValue = leads.filter((l) => !['won', 'lost'].includes(l.status)).reduce((a, l) => a + l.value, 0);
  const weighted = leads.filter((l) => !['won', 'lost'].includes(l.status)).reduce((a, l) => a + (l.value * l.probability) / 100, 0);

  const openNew = () => {
    setEditing(null);
    setF({ name: '', phone: '', email: '', company: '', source: '', interested_product_id: '', value: 0, probability: 30, status: 'new', assigned_to: '', follow_up_at: '', notes: '' });
    setOpen(true);
  };
  const openEdit = (l: Lead) => {
    setEditing(l);
    setF({
      name: l.name, phone: l.phone ?? '', email: l.email ?? '', company: l.company ?? '', source: l.source ?? '',
      interested_product_id: l.interested_product_id ?? '', value: l.value, probability: l.probability,
      status: l.status, assigned_to: l.assigned_to ?? '', follow_up_at: l.follow_up_at?.slice(0, 10) ?? '', notes: l.notes ?? '',
    });
    setOpen(true);
  };

  const submit = () => {
    if (!f.name.trim()) return;
    const payload: Partial<Lead> = {
      ...f,
      interested_product_id: f.interested_product_id || null,
      assigned_to: f.assigned_to || null,
      follow_up_at: f.follow_up_at ? new Date(f.follow_up_at).toISOString() : null,
    };
    if (editing) { updateLead(editing.id, payload); toast({ title: 'Lead updated' }); }
    else { createLead(payload); toast({ title: 'Lead created' }); }
    setOpen(false);
  };

  const columns: Column<Lead>[] = [
    { key: 'name', header: 'Lead', sortValue: (l) => l.name, exportValue: (l) => l.name, render: (l) => <div><p className="font-medium">{l.name}</p><p className="text-[11.5px] text-[var(--muted)]">{l.company ?? l.phone ?? '—'}</p></div> },
    { key: 'contact', header: 'Contact', exportValue: (l) => `${l.phone ?? ''} ${l.email ?? ''}`, render: (l) => <div className="text-[12.5px]"><p>{l.phone ?? '—'}</p><p className="text-[var(--muted)]">{l.email ?? '—'}</p></div> },
    { key: 'source', header: 'Source', sortValue: (l) => l.source ?? '', exportValue: (l) => l.source ?? '', render: (l) => <span className="text-[12.5px]">{l.source ?? '—'}</span> },
    { key: 'status', header: 'Stage', sortValue: (l) => l.status, exportValue: (l) => l.status, render: (l) => <StatusBadge status={l.status} /> },
    { key: 'value', header: 'Value', className: 'text-right', sortValue: (l) => l.value, exportValue: (l) => l.value, render: (l) => <span className="tabular-nums">{formatINR(l.value)}</span> },
    { key: 'prob', header: 'Probability', className: 'text-right', sortValue: (l) => l.probability, exportValue: (l) => l.probability, render: (l) => <span className="tabular-nums">{l.probability}%</span> },
    { key: 'follow', header: 'Follow-up', sortValue: (l) => l.follow_up_at ?? '', exportValue: (l) => l.follow_up_at ?? '', render: (l) => {
      const overdue = l.follow_up_at && new Date(l.follow_up_at) < new Date() && !['won', 'lost'].includes(l.status);
      return <span className="text-[12.5px]" style={overdue ? { color: 'var(--danger)' } : undefined}>{formatDate(l.follow_up_at)}</span>;
    } },
  ];

  return (
    <>
      <PageHeader
        title="Leads"
        description={`${leads.length} leads · ${formatINR(pipelineValue)} pipeline · ${formatINR(weighted)} weighted`}
        actions={
          <>
            <div className="flex overflow-hidden rounded-[10px] border border-[var(--border-strong)]">
              <button onClick={() => setMode('kanban')} className={cn('px-2.5 py-1.5', mode === 'kanban' && 'bg-[var(--accent-soft)] text-[var(--accent)]')}><LayoutGrid className="h-3.5 w-3.5" /></button>
              <button onClick={() => setMode('list')} className={cn('px-2.5 py-1.5', mode === 'list' && 'bg-[var(--accent-soft)] text-[var(--accent)]')}><List className="h-3.5 w-3.5" /></button>
            </div>
            <Button variant="primary" onClick={openNew}><Plus className="h-3.5 w-3.5" /> New Lead</Button>
          </>
        }
      />

      {mode === 'list' ? (
        <DataTable rows={leads} columns={columns} exportName="leads" onRowClick={openEdit} searchable={(l) => `${l.name} ${l.phone} ${l.email} ${l.company}`} />
      ) : (
        <div className="flex gap-3 overflow-x-auto pb-3">
          {LEAD_STATUS.map((stage) => {
            const items = byStatus[stage];
            const stageValue = items.reduce((a, l) => a + l.value, 0);
            return (
              <div key={stage} className="w-[264px] shrink-0">
                <div className="mb-2.5 flex items-center gap-2 px-0.5">
                  <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: STAGE_COLOR[stage] }} />
                  <p className="text-[12.5px] font-semibold capitalize">{stage.replace('_', ' ')}</p>
                  <span className="rounded-[5px] bg-[var(--surface-3)] px-1.5 text-[10.5px] font-semibold tabular-nums text-[var(--muted)]">
                    {items.length}
                  </span>
                  {stageValue > 0 && (
                    <span className="ml-auto text-[11.5px] font-medium tabular-nums text-[var(--muted-2)]">
                      {formatINR(stageValue, { compact: true })}
                    </span>
                  )}
                </div>
                <div className="space-y-2">
                  {items.map((l) => {
                    const overdue = l.follow_up_at && new Date(l.follow_up_at) < new Date();
                    const owner = db.profiles.find((p) => p.id === l.assigned_to);
                    return (
                      <Card
                        key={l.id}
                        className="card-hover relative cursor-pointer overflow-hidden p-3"
                        onClick={() => openEdit(l)}
                      >
                        <span
                          className="absolute inset-y-0 left-0 w-[2.5px]"
                          style={{ background: STAGE_COLOR[stage] }}
                        />
                        <div className="flex items-start gap-2 pl-1">
                          <Avatar name={l.name} size={26} />
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-[12.5px] font-medium leading-tight">{l.name}</p>
                            <p className="mt-0.5 truncate text-[11.5px] leading-tight text-[var(--muted-2)]">
                              {l.company ?? l.phone ?? '—'}
                            </p>
                          </div>
                        </div>

                        {(() => {
                          const prod = db.products.find((p) => p.id === l.interested_product_id);
                          return prod ? (
                            <p className="mt-2 truncate pl-1 text-[11.5px] text-[var(--muted)]">{prod.name}</p>
                          ) : null;
                        })()}

                        <div className="mt-2.5 flex items-center justify-between pl-1">
                          <span className="text-[13px] font-semibold tabular-nums">{formatINR(l.value)}</span>
                          <span className="text-[11.5px] font-medium tabular-nums text-[var(--muted)]">
                            {l.probability}%
                          </span>
                        </div>

                        <div className="mt-2 flex items-center gap-2 border-t border-[var(--border-subtle)] pt-2 pl-1">
                          {owner ? (
                            <span title={owner.full_name}>
                              <Avatar name={owner.full_name} size={18} />
                            </span>
                          ) : (
                            <span className="text-[10.5px] text-[var(--muted-2)]">Unassigned</span>
                          )}
                          {l.follow_up_at && (
                            <span
                              className="ml-auto text-[10.5px] font-medium tabular-nums"
                              style={{ color: overdue ? 'var(--danger)' : 'var(--muted-2)' }}
                            >
                              {formatDate(l.follow_up_at)}
                            </span>
                          )}
                        </div>

                        <select
                          value={l.status}
                          onClick={(e) => e.stopPropagation()}
                          onChange={(e) => {
                            e.stopPropagation();
                            updateLead(l.id, { status: e.target.value as LeadStatus });
                            toast({ title: `Moved to ${e.target.value.replace('_', ' ')}` });
                          }}
                          className="mt-2 w-full cursor-pointer rounded-[6px] border border-[var(--border)] bg-[var(--surface-2)] px-1.5 py-1 text-[11.5px] capitalize outline-none transition-colors hover:border-[var(--border-strong)] focus:border-[var(--accent)]"
                        >
                          {LEAD_STATUS.map((s) => (
                            <option key={s} value={s}>
                              {s.replace('_', ' ')}
                            </option>
                          ))}
                        </select>
                      </Card>
                    );
                  })}
                  {items.length === 0 && (
                    <div className="rounded-[10px] border border-dashed border-[var(--border)] py-7 text-center text-[11.5px] text-[var(--muted-2)]">
                      No leads
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {leads.length === 0 && mode === 'list' && <EmptyState icon={UserPlus} title="No leads yet" message="Add your first lead to start building the pipeline." />}

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit lead' : 'New lead'} width="lg"
        footer={
          <>
            {editing && !editing.converted_customer_id && (
              <Button variant="outline" onClick={() => { const c = convertLead(editing.id); toast({ title: 'Converted to customer' }); setOpen(false); router.push(`/customers/${c.id}`); }}>
                <UserCheck className="h-3.5 w-3.5" /> Convert to customer
              </Button>
            )}
            <Button onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={submit}>{editing ? 'Save' : 'Create'}</Button>
          </>
        }>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Lead name *" className="sm:col-span-2"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
          <Field label="Phone"><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
          <Field label="Email"><Input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
          <Field label="Company"><Input value={f.company} onChange={(e) => setF({ ...f, company: e.target.value })} /></Field>
          <Field label="Source">
            <Select value={f.source} onChange={(e) => setF({ ...f, source: e.target.value })}>
              <option value="">Select…</option>
              {SOURCES.map((s) => <option key={s} value={s}>{s}</option>)}
            </Select>
          </Field>
          <Field label="Interested product">
            <Select value={f.interested_product_id} onChange={(e) => setF({ ...f, interested_product_id: e.target.value })}>
              <option value="">None</option>
              {db.products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </Field>
          <Field label="Deal value (₹)"><Input type="number" value={f.value} onChange={(e) => setF({ ...f, value: Math.max(0, num(e.target.value)) })} /></Field>
          <Field label="Probability (%)"><Input type="number" min={0} max={100} value={f.probability} onChange={(e) => setF({ ...f, probability: clamp(num(e.target.value), 0, 100) })} /></Field>
          <Field label="Stage">
            <Select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as LeadStatus })}>
              {LEAD_STATUS.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
            </Select>
          </Field>
          <Field label="Assigned to">
            <Select value={f.assigned_to} onChange={(e) => setF({ ...f, assigned_to: e.target.value })}>
              <option value="">Unassigned</option>
              {db.profiles.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
            </Select>
          </Field>
          <Field label="Follow-up date"><Input type="date" value={f.follow_up_at} onChange={(e) => setF({ ...f, follow_up_at: e.target.value })} /></Field>
          <Field label="Notes" className="sm:col-span-2"><Textarea rows={2} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
        </div>
      </Modal>
    </>
  );
}

export default function LeadsPage() {
  return <Suspense fallback={null}><LeadsInner /></Suspense>;
}
