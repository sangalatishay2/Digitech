'use client';

import { FormEvent, useMemo, useState } from 'react';
import Link from 'next/link';
import { Bot, Check, Copy, KeyRound, Send, ShieldCheck, Sparkles, UserRound, Workflow } from 'lucide-react';
import { Badge, Button, Card, Field, Input, Modal, PageHeader, Textarea } from '@/components/ui/primitives';
import { getSupabaseClient } from '@/lib/data/supabase-client';
import { useStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { formatINR } from '@/lib/utils';

type Provider = 'openrouter' | 'google';
type Message = { id: string; role: 'user' | 'assistant'; content: string; model?: string };

const DEFAULT_MODELS: Record<Provider, string> = {
  openrouter: 'nvidia/nemotron-3-nano-30b-a3b',
  google: 'gemini-2.5-flash',
};

const PROMPTS = [
  'Summarize renewals due in the next 7 days and suggest a follow-up plan.',
  'Review our revenue and profit position. Highlight the three biggest risks.',
  'Draft a concise WhatsApp renewal reminder that feels personal, not pushy.',
];

export default function CopilotPage() {
  const { db, currentUser, can, createApproval } = useStore();
  const toast = useToast();
  const [provider, setProvider] = useState<Provider>('openrouter');
  const [model, setModel] = useState(DEFAULT_MODELS.openrouter);
  const [includeContext, setIncludeContext] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionOpen, setActionOpen] = useState(false);
  const [action, setAction] = useState({ title: '', command: '', reason: '', financial_impact: '' });
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: 'I am ready to help with renewals, operations, margins and customer communication. Business context stays off until you explicitly enable it.',
      model: DEFAULT_MODELS.openrouter,
    },
  ]);

  const businessContext = useMemo(() => {
    const revenue = db.orders.reduce((sum, order) => sum + order.total, 0);
    const outstanding = db.orders.reduce((sum, order) => sum + order.outstanding, 0);
    const expiring = db.subscriptions.filter((item) => item.status === 'expiring').length;
    const pending = db.activations.filter((item) => ['ready', 'processing', 'waiting_supplier'].includes(item.status)).length;
    return [
      `Organization: ${db.organizations[0]?.name ?? 'DigiTech'}`,
      `Orders: ${db.orders.length}`,
      `Revenue: ${formatINR(revenue)}`,
      `Outstanding: ${formatINR(outstanding)}`,
      `Expiring subscriptions: ${expiring}`,
      `Pending activations: ${pending}`,
    ].join('\n');
  }, [db]);

  function chooseProvider(next: Provider) {
    setProvider(next);
    setModel(DEFAULT_MODELS[next]);
  }

  async function send(content: string) {
    const text = content.trim();
    if (!text || loading) return;
    const userMessage: Message = { id: crypto.randomUUID(), role: 'user', content: text };
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setInput('');
    setError(null);
    setLoading(true);

    try {
      const client = getSupabaseClient();
      const { data } = client ? await client.auth.getSession() : { data: { session: null } };
      const token = (data as { session?: { access_token?: string } | null }).session?.access_token;
      if (!token) throw new Error('Sign in with your DigiTech organization account to use AI Copilot.');

      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider,
          model,
          messages: nextMessages
            .filter((message) => message.id !== 'welcome')
            .map(({ role, content: messageContent }) => ({ role, content: messageContent })),
          system: [
            'You are DigiTech Business OS Copilot. Be concise, operationally useful, and explicit about assumptions.',
            'Never invent customer, payment, activation, or financial facts.',
            includeContext ? `User-enabled business snapshot:\n${businessContext}` : '',
          ].filter(Boolean).join('\n\n'),
        }),
      });
      const result = (await response.json()) as { content?: string; error?: string; model?: string };
      if (!response.ok || !result.content) throw new Error(result.error || 'The AI provider returned no answer.');
      setMessages((current) => [...current, {
        id: crypto.randomUUID(), role: 'assistant', content: result.content!, model: result.model || model,
      }]);
    } catch (cause) {
      setError((cause as Error).message);
    } finally {
      setLoading(false);
    }
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    void send(input);
  }

  function prepareAction() {
    const latest = [...messages].reverse().find((message) => message.role === 'assistant' && message.id !== 'welcome');
    setAction({
      title: '',
      command: input.trim() || latest?.content || '',
      reason: '',
      financial_impact: '',
    });
    setError(null);
    setActionOpen(true);
  }

  function submitActionProposal() {
    setError(null);
    try {
      createApproval({
        request_type: 'ai_action',
        title: action.title,
        description: 'Prepared from DigiTech AI Copilot. This is a proposal, not an executed action.',
        reason: action.reason,
        financial_impact: Number(action.financial_impact || 0),
        payload: { command: action.command, provider, model },
      });
      toast({ title: 'AI action sent for approval', description: 'Nothing runs until an owner or admin approves it.' });
      setActionOpen(false);
    } catch (cause) {
      setError((cause as Error).message);
    }
  }

  return (
    <div className="mx-auto max-w-[1180px] space-y-5">
      <PageHeader
        title="AI Copilot"
        description="One secure workspace for OpenRouter, Nemotron, Google AI, and custom model IDs."
        actions={<>
          <Badge tone="success" dot><ShieldCheck className="h-3 w-3" /> Server-side keys</Badge>
          {can('approvals.create') && <Button variant="outline" onClick={prepareAction}><Workflow className="h-3.5 w-3.5" /> Prepare action</Button>}
        </>}
      />

      <div className="grid gap-4 lg:grid-cols-[280px_minmax(0,1fr)]">
        <div className="space-y-4">
          <Card className="p-4">
            <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-[var(--muted)]">Provider</p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              {(['openrouter', 'google'] as Provider[]).map((item) => (
                <Button key={item} variant={provider === item ? 'primary' : 'outline'} onClick={() => chooseProvider(item)}>
                  {provider === item && <Check className="h-3.5 w-3.5" />}{item === 'openrouter' ? 'OpenRouter' : 'Google'}
                </Button>
              ))}
            </div>
            <label className="mt-4 block text-[12px] font-medium text-[var(--fg-soft)]">
              Model ID
              <input className="field mt-1.5 w-full font-mono text-[12px]" value={model} onChange={(event) => setModel(event.target.value)} />
            </label>
            <p className="mt-2 flex items-start gap-1.5 text-[11.5px] leading-relaxed text-[var(--muted)]">
              <KeyRound className="mt-0.5 h-3.5 w-3.5 shrink-0" /> No provider key is stored in the browser or Android package.
            </p>
          </Card>

          <Card className="p-4">
            <button className="flex w-full items-start gap-3 text-left" onClick={() => setIncludeContext((value) => !value)}>
              <span className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-[6px] border ${includeContext ? 'border-[var(--accent)] bg-[var(--accent)] text-white' : 'border-[var(--border-strong)]'}`}>
                {includeContext && <Check className="h-3.5 w-3.5" />}
              </span>
              <span>
                <span className="block text-[13px] font-semibold">Business context</span>
                <span className="mt-1 block text-[11.5px] leading-relaxed text-[var(--muted)]">Off by default. When enabled, only a compact operational snapshot is attached.</span>
              </span>
            </button>
          </Card>
        </div>

        <Card className="flex min-h-[640px] flex-col overflow-hidden">
          <div className="flex items-center justify-between border-b border-[var(--border)] px-4 py-3">
            <div className="flex items-center gap-2.5">
              <span className="grid h-8 w-8 place-items-center rounded-[9px] bg-[var(--accent-soft)] text-[var(--accent)]"><Sparkles className="h-4 w-4" /></span>
              <div><p className="text-[13.5px] font-semibold">DigiTech Copilot</p><p className="text-[11px] text-[var(--muted)]">{provider} · {model}</p></div>
            </div>
            <Badge tone={includeContext ? 'warning' : 'neutral'}>{includeContext ? 'Context on' : 'Context off'}</Badge>
          </div>

          <div className="flex-1 space-y-4 overflow-y-auto p-4 sm:p-6">
            {messages.map((message) => (
              <div key={message.id} className={`flex gap-2.5 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {message.role === 'assistant' && <span className="grid h-7 w-7 shrink-0 place-items-center rounded-[8px] bg-[var(--accent-soft)] text-[var(--accent)]"><Bot className="h-3.5 w-3.5" /></span>}
                <div className={`group max-w-[82%] rounded-[12px] border px-3.5 py-3 text-[13px] leading-6 ${message.role === 'user' ? 'border-[var(--accent-border)] bg-[var(--accent)] text-white' : 'border-[var(--border)] bg-[var(--surface-2)] text-[var(--fg-soft)]'}`}>
                  <p className="whitespace-pre-wrap">{message.content}</p>
                  {message.role === 'assistant' && (
                    <div className="mt-2 flex items-center justify-between gap-3 border-t border-[var(--border)] pt-2 text-[10.5px] text-[var(--muted)]">
                      <span className="truncate font-mono">{message.model}</span>
                      <button aria-label="Copy response" onClick={() => void navigator.clipboard.writeText(message.content)} className="hover:text-[var(--fg)]"><Copy className="h-3.5 w-3.5" /></button>
                    </div>
                  )}
                </div>
                {message.role === 'user' && <span className="grid h-7 w-7 shrink-0 place-items-center rounded-[8px] bg-[var(--surface-2)] text-[var(--muted)]"><UserRound className="h-3.5 w-3.5" /></span>}
              </div>
            ))}
            {loading && <div className="flex items-center gap-2 text-[12px] text-[var(--muted)]"><span className="h-2 w-2 animate-pulse rounded-full bg-[var(--accent)]" />Copilot is working…</div>}
            {error && <div role="alert" className="rounded-[10px] border border-[var(--danger-border)] bg-[var(--danger-soft)] px-3 py-2.5 text-[12.5px] text-[var(--danger)]">{error}</div>}
          </div>

          <div className="border-t border-[var(--border)] bg-[var(--surface)] p-3 sm:p-4">
            <div className="mb-3 flex gap-2 overflow-x-auto pb-1">
              {PROMPTS.map((prompt) => <button key={prompt} disabled={loading} onClick={() => void send(prompt)} className="shrink-0 rounded-full border border-[var(--border)] bg-[var(--surface-2)] px-3 py-1.5 text-[11.5px] text-[var(--fg-soft)] hover:border-[var(--accent-border)] hover:text-[var(--accent)] disabled:opacity-50">{prompt.split('.')[0]}</button>)}
            </div>
            <form onSubmit={submit} className="flex items-end gap-2">
              <textarea aria-label="Message" className="field min-h-[44px] flex-1 resize-none py-3" rows={1} maxLength={8000} placeholder={`Ask ${currentUser?.full_name.split(' ')[0] ?? 'Copilot'} about operations, renewals or finance…`} value={input} onChange={(event) => setInput(event.target.value)} />
              <Button type="submit" variant="primary" size="lg" disabled={!input.trim() || loading}><Send className="h-4 w-4" /><span className="hidden sm:inline">Send</span></Button>
            </form>
          </div>
        </Card>
      </div>

      <Modal
        open={actionOpen}
        onClose={() => setActionOpen(false)}
        title="Prepare AI action for approval"
        description="Review the exact instruction before sending it to a human decision maker. Copilot never executes it directly."
        width="lg"
        footer={<>
          <Button onClick={() => setActionOpen(false)}>Cancel</Button>
          <Button variant="primary" onClick={submitActionProposal}>Send for approval</Button>
        </>}
      >
        <div className="space-y-4">
          <div className="rounded-[10px] border border-[var(--accent-border)] bg-[var(--accent-soft)] p-3 text-[12px] leading-relaxed text-[var(--fg-soft)]">
            <ShieldCheck className="mr-1.5 inline h-3.5 w-3.5 text-[var(--accent)]" />
            Safe path: action preview → owner/admin approval → one idempotent server job. Provider keys remain server-side.
          </div>
          <Field label="Action title" required>
            <Input maxLength={160} value={action.title} onChange={(event) => setAction({ ...action, title: event.target.value })} placeholder="Example: Send 7-day renewal reminders" />
          </Field>
          <Field label="Exact proposed instruction" required hint="Remove sensitive credentials or private secrets before submitting.">
            <Textarea rows={7} maxLength={8000} value={action.command} onChange={(event) => setAction({ ...action, command: event.target.value })} placeholder="Describe the records, filters, and intended result." />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Business reason" required>
              <Textarea rows={3} maxLength={1000} value={action.reason} onChange={(event) => setAction({ ...action, reason: event.target.value })} placeholder="Why should this action run?" />
            </Field>
            <Field label="Expected financial impact" hint="Use 0 when there is no direct monetary effect.">
              <Input type="number" min="0" step="0.01" inputMode="decimal" value={action.financial_impact} onChange={(event) => setAction({ ...action, financial_impact: event.target.value })} placeholder="0.00" />
            </Field>
          </div>
          {error && <p role="alert" className="rounded-[8px] bg-[var(--danger-soft)] px-3 py-2 text-[12px] text-[var(--danger)]">{error}</p>}
          <p className="text-[11.5px] text-[var(--muted)]">Track every decision in the <Link href="/approvals" className="font-medium text-[var(--accent)] hover:underline">Approval Center</Link>.</p>
        </div>
      </Modal>
    </div>
  );
}
