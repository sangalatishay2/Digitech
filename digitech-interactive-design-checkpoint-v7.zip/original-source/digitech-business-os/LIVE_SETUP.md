# Live Supabase Setup — exact values to copy

Create `.env.local` in the project root (it is gitignored) with the values below.
**Do not paste these into chat if you would rather not** — writing them into
`.env.local` yourself is enough; I only need to know when it exists.

---

## 1. From Supabase Dashboard → Project Settings → **Data API**

| Dashboard field | Variable | Public? |
|---|---|---|
| Project URL | `NEXT_PUBLIC_SUPABASE_URL` | yes — safe in browser |

Example: `https://abcdefghijklm.supabase.co`

## 2. From Supabase Dashboard → Project Settings → **API Keys**

| Dashboard field | Variable | Public? |
|---|---|---|
| `anon` / `publishable` key | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | yes — safe in browser |
| `service_role` / `secret` key | `SUPABASE_SERVICE_ROLE_KEY` | **NO — server only** |

The `anon` key is designed to be public and grants nothing on its own, because
every table is protected by RLS. The `service_role` key **bypasses RLS entirely**
— if it reaches the browser, every tenant's data is exposed. It must never carry
the `NEXT_PUBLIC_` prefix.

## 3. From Supabase Dashboard → Project Settings → **Database → Connection string → URI**

| Variable | Public? |
|---|---|
| `DATABASE_URL` | **NO — server only** |

Copy the **URI** (session pooler is fine) and replace `[YOUR-PASSWORD]` with your
database password. Used only by the migration runner and the live test suite.

Example: `postgresql://postgres.abcdefghijklm:PASSWORD@aws-0-ap-south-1.pooler.supabase.com:5432/postgres`

## 4. Generate locally (not from Supabase)

```bash
openssl rand -base64 32
```

| Variable | Public? |
|---|---|
| `ACTIVATION_ENCRYPTION_KEY` | **NO — server only** |

Encrypts activation credentials at rest (AES-256-GCM). **Store a backup of this
key.** If it is lost, every stored activation credential becomes permanently
unreadable — they cannot be recovered from the database.

## 5. Switch the app to production mode

```
NEXT_PUBLIC_DATA_PROVIDER=supabase
```

Without this the app stays in demo mode even when credentials are present.

## 6. Optional — WhatsApp Cloud API

From Meta → WhatsApp → API Setup. Leave blank to keep Click-to-Chat (wa.me),
which needs no credentials and works today.

```
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=
```

---

## Complete `.env.local` template

```bash
NEXT_PUBLIC_DATA_PROVIDER=supabase
NEXT_PUBLIC_SUPABASE_URL=https://YOURPROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOi...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOi...
DATABASE_URL=postgresql://postgres.YOURPROJECT:PASSWORD@aws-0-REGION.pooler.supabase.com:5432/postgres
ACTIVATION_ENCRYPTION_KEY=<openssl rand -base64 32>
```

---

## Then run, in this order

```bash
# 1. Apply all 18 migrations to the live database
npm run migrate

# 2. Verify tables, enums, indexes, triggers, functions, RLS, grants
npm run verify:schema

# 3. Two-org RLS + RBAC against the hosted database
npm run test:live

# 4. Full offline gate
npm run verify
```

`npm run verify:live` runs steps 1–3 in sequence.

`npm run migrate` is safe to re-run: applied files are recorded in
`schema_migrations` and skipped. If you edit a migration that was already
applied, it fails rather than letting the live schema silently diverge from the
repository.

---

## Creating the first user

Migrations create the schema but no login. After `npm run migrate`:

1. Supabase Dashboard → **Authentication → Users → Add user** (set a password,
   confirm the email).
2. Copy that user's UUID.
3. SQL Editor — create an organization and link a profile to that auth user:

```sql
insert into organizations (id, name, currency, timezone)
values (gen_random_uuid(), 'DigiTech', 'INR', 'Asia/Kolkata')
returning id;
-- copy the returned organization id

insert into profiles (organization_id, auth_user_id, full_name, role, is_active)
values ('<ORG_ID_FROM_ABOVE>', '<AUTH_USER_UUID>', 'Your Name', 'owner', true);
```

The profile must exist and be `is_active = true`, otherwise sign-in succeeds but
the app correctly refuses to give the account any identity — a disabled or
unlinked account is treated as having no access at all.
