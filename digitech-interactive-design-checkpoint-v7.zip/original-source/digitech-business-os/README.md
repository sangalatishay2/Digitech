# DigiTech Business OS

A premium, all-in-one **ERP + CRM + Subscription Management + Sales + Finance + Support + Automation + Analytics** platform built for DigiTech — a business selling SaaS subscriptions, AI tools, licenses, email/account activations and digital services.

**Standalone-first, Supabase-ready.**

---

## The core lifecycle

```
CUSTOMER → ORDER → PAYMENT → ACTIVATION → DELIVERY → SUBSCRIPTION → EXPIRY → RENEWAL → NEW ORDER
```

This works end-to-end in the app today:

1. Create a customer (`/customers`) — duplicate phone/email/WhatsApp raises a **warning**, never a hard block.
2. Create an order (`/orders/new`) — cost, price, duration, supplier and delivery type are **snapshotted** onto the order item.
3. Record a payment (full or partial) — order moves `awaiting_payment → activation_pending`, activation moves `waiting_payment → ready`.
4. Work the activation queue (`/activations`) — set details, proof, assignee, then **Deliver**.
5. Delivery auto-creates a **subscription** with the duration snapshot; status derives to `active / expiring / expired`.
6. Work the **Renewal Center** (`/renewals`) — WhatsApp, call, mark contacted/interested/follow-up, or **Renew Now**.
7. Renew Now opens a pre-filled order referencing the previous subscription, and on delivery marks the old subscription `renewed` — preserving the full **renewal chain**.

---

## Quick start

```bash
npm install
npm run dev          # http://localhost:3000
```

No database, no credentials, no configuration required. The app boots with realistic Indian demo data (INR, Asia/Kolkata) persisted in browser storage.

```bash
npm run build        # production build
npm start            # serve production build
npx tsc --noEmit     # type check
npm run lint         # lint
```

**Requirements:** Node 20+, npm 10+.

---

## Architecture

```
src/
  lib/
    types.ts                    Domain model + all business state enums
    store.tsx                   React store: mutations, RBAC, derived state, audit log
    utils.ts                    INR formatting, dates, rounding
    data/
      provider.ts               DataProvider contract (the seam)
      local-provider.ts         Standalone provider (browser persistence)
      supabase-provider.ts      Supabase adapter (drop-in, credential-gated)
      seed.ts                   Deterministic demo dataset
    services/
      business.ts               State machine, money math, snapshots, duplicates, profit
      analytics.ts              KPIs, series, ranges, CLV, renewal/refund rate
      suppliers.ts              Supplier balances & purchase history
      whatsapp.ts               Provider-agnostic messaging interface
  components/
    shell/                      Sidebar, topbar, command palette, global search
    ui/                         Primitives, data table, toasts
    charts.tsx                  Recharts wrappers
  app/                          Next.js App Router pages
supabase/migrations/            0001 … 0014 incremental SQL
```

### Why the UI never touches the database

Pages call `useStore()`. The store calls a `DataProvider`. Swapping `LocalProvider` for `SupabaseProvider` is a **configuration change**, not a rewrite — no page imports demo data or Supabase directly.

### Financial immutability

- `order_items.unit_cost` / `unit_price` / `duration_days` / `supplier_name` are **snapshots**. Editing a product's cost today does **not** change the profit on last month's order.
- `subscriptions.duration_days` is a snapshot. Changing a product's duration does **not** move an existing subscription's expiry date.
- Money is `numeric(12,2)` in SQL — never float.

### Duplicate policy

Phone / email / WhatsApp are **not** hard-unique. `findDuplicateCustomers()` surfaces matches as warnings with an explicit override checkbox; CSV import highlights them but still imports. Only `customer_code` is organization-unique.

### Profiles are standalone-first

`profiles.auth_user_id` is **nullable with no hard dependency on `auth.users`**. Migration `0003` attaches the FK only if the `auth` schema exists. The app creates and manages team members with no auth backend present.

---

## Connecting Supabase

1. Create a Supabase project.
2. Run the migrations in order:
   ```bash
   supabase link --project-ref <ref>
   supabase db push
   # or paste supabase/migrations/0001…0014 into the SQL editor in order
   ```
3. `cp .env.example .env.local` and set:
   ```
   NEXT_PUBLIC_DATA_PROVIDER=supabase
   NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...
   ```
4. `npm i @supabase/supabase-js`
5. Implement the table reads/writes in `src/lib/data/supabase-provider.ts` — each table maps 1:1 to a type in `src/lib/types.ts`.

RLS policies (`0013_rls.sql`) enforce organization isolation via `current_org_id()` and role gates via `has_role()`. Demo data (`0014`) is removable with one statement:

```sql
delete from organizations where id = '00000000-0000-4000-8000-000000000001';
```

---

## Modules

| Area | Route | Highlights |
|---|---|---|
| Dashboard | `/` | 10 live KPIs, date filters, action-required queue, charts, business brief |
| Orders | `/orders`, `/orders/new` | 3-step flow, snapshots, custom pricing, discounts, state machine |
| Payments | `/payments` | Partial payments, refunds, outstanding ledger, over-payment guard |
| Activations | `/activations` | Queue with 8 statuses, priority, assignee, proof, credentials |
| Subscriptions | `/subscriptions`, `/expiring`, `/expired` | Derived states, configurable threshold |
| Renewal Center | `/renewals` | Today/3/7/15/30/expired/follow-up, WhatsApp + full action set, renewal chain |
| Customers | `/customers` | Saved views, Customer 360 with 10 tabs, lifetime metrics |
| Leads | `/leads` | Kanban + list, 8 stages, weighted pipeline, convert to customer |
| Products / Suppliers | `/products`, `/suppliers` | Margin math, stock, cost-snapshot history, supplier balances |
| Support / Tasks | `/support`, `/tasks` | Threaded tickets, SLA tracking, polymorphic tasks |
| Finance | `/finance/*` | Revenue, profit engine (P&L), expenses, supplier payments |
| Invoices | `/invoices` | Printable invoice, share, print-to-PDF |
| Analytics | `/analytics` | 9 tabs, CLV, renewal rate, refund rate, retention |
| Automations | `/automations` | Rule engine, run history, 9 n8n webhook events |
| WhatsApp | `/marketing/whatsapp` | Provider-agnostic, templates, variable preview, logged history |
| Segments / Campaigns | `/segments`, `/marketing/campaigns` | Live dynamic segments and playbooks |
| Team | `/team` | 7 roles, permission matrix, user switching for RBAC testing |
| Import / Export | `/import-export` | Field mapping, preview, duplicate detection, result report |
| Settings | `/settings` | 15 sections, backup/restore, removable demo data |

**Keyboard:** `⌘K` / `Ctrl+K` opens the command palette (search + quick actions).

---

## Security

- Zod validation on write forms; totals guarded against over-payment/over-refund.
- RBAC enforced in the UI **and** in the store's `can()` gate; mirrored by RLS policies.
- `organization_id` on every tenant table.
- Append-only activity log.
- Soft deletes and confirmation dialogs for destructive actions.
- Customer passwords are never stored — auth is delegated to Supabase Auth.
- Secrets stay server-side; only `NEXT_PUBLIC_*` values reach the browser.

---

## Known limitations

- File/attachment upload requires object storage (Supabase Storage) — proof URLs are pasted for now.
- Server-side PDF generation ships with the backend; invoices currently use browser print → Save as PDF.
- Bulk WhatsApp scheduling needs a Cloud API provider; click-to-chat works today.
- CSV import creates customers/products/suppliers; order and subscription import validates and previews but defers creation to the order form (it needs linked records).
