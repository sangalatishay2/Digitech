# BUILD_STATUS — DigiTech Business OS

**Last updated:** 2026-09-01
**Workspace:** `/home/user/digitech-business-os` (sandbox root; the requested macOS path does not exist in this environment — copy this folder to your local project directory)
**Validation state (Phase 4, re-verified):** `npm ci` from lockfile clean · `tsc --noEmit` clean · `eslint src tests` 0 errors 0 warnings · `next build` succeeds (46 routes) · **296 automated tests passing across 24 files, plus 17 live-database tests that skip without `DATABASE_URL`** · all 18 migrations execute on a clean PostgreSQL 18 database (PGlite) · production server 200 OK

> **Not production-ready.** Every Supabase assertion below is made against PGlite or an injected fake client. Nothing in this document has been verified against a hosted Supabase project. See *Known issues*.

---

## Checkpoint status

| # | Checkpoint | Status |
|---|---|---|
| 0 | Recovery + project/environment inspection | ✅ COMPLETE |
| 1 | Database foundation | ✅ COMPLETE |
| 2 | Database business modules | ✅ COMPLETE |
| 3 | Indexes + triggers + RLS + seed | ✅ COMPLETE |
| 4 | Data/repository/service layer | ✅ COMPLETE |
| 5 | Authentication + RBAC foundation | ✅ COMPLETE (RBAC + sign-in UI + server session; live-credential verification pending) |
| 6 | App shell + responsive nav + themes | ✅ COMPLETE |
| 7 | Dashboard | ✅ COMPLETE |
| 8 | Customers | ✅ COMPLETE |
| 9 | Products + Suppliers | ✅ COMPLETE |
| 10 | Orders + Payments | ✅ COMPLETE |
| 11 | Activations | ✅ COMPLETE |
| 12 | Subscriptions + Renewals | ✅ COMPLETE |
| 13 | Leads + Tasks + Support | ✅ COMPLETE |
| 14 | Expenses + Invoices + Profit | ✅ COMPLETE |
| 15 | Notifications + Activity Logs | ✅ COMPLETE |
| 16 | Analytics | ✅ COMPLETE |
| 17 | Automation + n8n foundation | ✅ COMPLETE |
| 18 | WhatsApp / communication foundation | ✅ COMPLETE |
| 19 | Settings + Team + Permissions | ✅ COMPLETE |
| 20 | Global Search + Command Palette | ✅ COMPLETE |
| 21 | Import / Export | 🟡 PARTIAL — customers/products/suppliers create; orders/subscriptions map+preview only |
| 22 | Responsive / PWA polish | ✅ COMPLETE (manifest, icon, theme-color, viewport, print CSS) |
| 23 | Final QA and production-readiness audit | ✅ COMPLETE |
| 24 | Phase 3 — production hardening | 🟡 IN PROGRESS — P0/P1/P2 code complete and tested locally; **not yet verified against a live Supabase project** |

---

## Architecture fixes applied first (as instructed)

1. **Profiles are standalone-first.** `profiles` has no hard dependency on `auth.users`. Migration `0003` attaches the FK conditionally, only when the `auth` schema exists.
2. **`auth_user_id` is nullable and modular.** Team members are created and managed with no auth backend present.
3. **Duplicate warnings, not hard uniqueness.** No unique constraint on customer phone/email/WhatsApp. `findDuplicateCustomers()` warns with an explicit override; CSV import highlights but still imports. Only `(organization_id, customer_code)` is unique.
4. **Migrations validated** — 14 incremental files, correct dependency order, forward-declared FK (`orders.renewal_of_subscription_id`) resolved in `0008`.

---

## Completed functionality

**Database (18 migrations)** — UUID PKs, `organization_id` on every tenant table, `timestamptz`, `numeric(12,2)` for money (never float), explicit FKs with explicit `ON DELETE`, soft deletes, 16 enums covering every required business state, 25+ indexes incl. trigram indexes for partial search and duplicate detection, `updated_at` triggers, order-payment recalc trigger, subscription-status derivation trigger, full RLS with `current_org_id()` / `has_role()`, removable demo seed.

**Data layer** — `DataProvider` contract; `LocalProvider` (standalone) and `SupabaseProvider` (credential-gated stub). No page imports demo data or Supabase directly.

**Business logic** — order state machine with enforced transitions; immutable cost/price/duration/supplier snapshots on order items and subscriptions; payment recalculation with over-payment and over-refund guards; partial payments, multiple payments per order, full and partial refunds; profit engine (revenue − cost − refunds − opex); derived subscription states against a configurable threshold; renewal chain linkage; template variable rendering; 9 webhook events.

**End-to-end lifecycle verified:** Customer → Order → Payment → Activation → Delivery → Subscription → Expiry → Renewal Center → Renewal Order → new Subscription, with the previous subscription marked `renewed` and chained.

**UI** — 46 build routes. Collapsible sidebar with live counts, breadcrumbs, global search (partial matching across 8 entity types), ⌘K command palette, notification center, quick-create, user/role switcher, light/dark/system themes, responsive desktop/tablet/mobile, loading/empty/error states, toasts, confirmation dialogs. Shared data table with search, sort, pagination, column visibility, saved views and CSV export.

---

## Phase 3 — Production hardening

Defects were reproduced with automated tests, fixed at the root cause, then re-verified.

### Database defects found by executing the migrations (PGlite = real Postgres 18)

The migrations had never actually been run. Executing them exposed five real bugs
that would each have broken a clean deployment:

| # | Defect | Fix |
|---|---|---|
| 1 | `0013` defined `public.current_role()` — `current_role` is a reserved SQL keyword, so the migration aborted with a syntax error on any clean database | Renamed to `current_app_role()` |
| 2 | `0015` created a unique index on `subscriptions.order_item_id`, a column that was never added | Column added before the index |
| 3 | `0015` compared `invoice_status` against `'cancelled'`, which is not a member of that enum — every payment on such an order raised `invalid input value for enum` | Compares against `'void'`/`'draft'`, matching `projectInvoice()` |
| 4 | `0015` wrote to `invoices.balance_due`, a column that does not exist | Removed; balance is derived as `total - amount_paid` |
| 5 | A newly created order never had its ledger initialised, so an unpaid order reported `outstanding = 0` and never appeared as a receivable until its first payment | Added `trg_orders_recalc` |

### Security defects

| Defect | Impact | Fix |
|---|---|---|
| `assert_same_org()` was not `SECURITY DEFINER` | Its parent lookup was filtered by the caller's own RLS, returned NULL for a foreign-org parent, and the cross-org guard **silently passed** | Declared `security definer` with a fixed `search_path`; a cross-org order insert is now rejected (proved by test) |
| No table `GRANT`s in the schema | Every end-user query failed with `permission denied` outside Supabase's bootstrap | Explicit grants to `authenticated`; `anon` revoked |
| `0016` was not re-runnable | Join-table policies lacked drop guards | `drop policy if exists` added |
| WhatsApp Cloud API reported "configured" from a public env flag while `send()` always failed | UI advertised a working integration that silently dropped every message | Implemented `/api/messaging/whatsapp` holding the token server-side; availability is reported by the server, sends are permission-checked and org-scoped, failures surface as failures. The public flag is removed — a bearer token must never be `NEXT_PUBLIC_*` |

### Application defects

| Defect | Fix |
|---|---|
| `deriveSubscriptionStatus` bucketed into whole days first; `Math.ceil(-1h / 1day) === -0` and `-0 < 0` is false, so a subscription that lapsed within the last 24h reported `expiring` and stayed in the active renewal pipeline | Exact timestamp comparison first (`expiry <= now ⇒ expired`) |
| Completing the same activation twice created two subscriptions | Idempotency guard + unique index on `source_activation_id` |
| Invoices snapshotted `amount_paid` at creation and never tracked later payments/refunds | Live projection from the order ledger, reconciled on every mutation |
| CSV import split on newlines before handling quotes, corrupting any field with an embedded newline | RFC4180 parser in `src/lib/services/csv.ts` |
| CSV export was vulnerable to formula injection (`=`, `+`, `-`, `@`) | Sanitised on write |
| Audit log truncated at 500 entries | Cap removed; old/new values recorded |
| Backup restore accepted arbitrary JSON | Versioned Zod validation, migration, referential checks, Owner/Admin + confirmation |
| Workspace selector implied multi-org switching that did not exist | States the single-workspace limit and surfaces demo-mode explicitly |

### P0 — architecture

| Item | State |
|---|---|
| **#1 data provider** | Per-entity `Repository` contract replaces whole-DB `save(db)`. `SupabaseRepository` implements it over PostgREST with optimistic concurrency (`expectedUpdatedAt`) and conflict reporting. Multi-row atomicity via `apply_transaction()` with idempotency keys. Written, migration-tested, **not yet run against live Supabase**. |
| **#2 auth/session** | `src/middleware.ts` redirects unauthenticated production traffic to `/login`. `resolveSession()` is the only identity source; the `profiles[0]` fallback that could hand the app a **disabled** profile is gone. Switching throws outside demo mode. Disabled/removed profiles are unselectable in the UI and inert in the store, service layer and SQL. |
| **#3 RLS** | Rewritten in 0016 and proven by 13 two-org integration tests. |
| **#4 sensitive storage** | Fixed a real leak: a *degraded* production attempt still counted as demo mode, so activation credentials were written to localStorage anyway. `allowBrowserPersistence()` is now strictly narrower than `isDemoMode()` — persistence requires demo to have been genuinely intended. |

### P1/P2 — atomic numbering and transactions (migration 0017)

`next_business_number()` replaces `max(number)+1` derivation, which races: two
concurrent inserts read the same maximum and mint the same code. The counter row
is advanced with `update ... returning`, which takes a row lock, so callers
serialise. Backed by unique indexes on `(organization_id, order_number)`,
`(organization_id, invoice_number)` and `(organization_id, ticket_number)` so the
invariant holds even if application code is bypassed.

`apply_transaction()` gives PostgREST callers real transactions with idempotency
keys — required for "complete this activation" to be safely retryable. It runs as
the *caller*, not SECURITY DEFINER, so RLS still applies to every row it touches
(proved by a test where a viewer's batch is rejected).

### P1 #12 — one canonical financial layer

`src/lib/services/finance.ts` is now the single source of truth; `analytics.ts`
delegates to it. Three real inconsistencies are fixed:

- **Revenue ignored refunds.** The dashboard summed `order.total` while the P&L
  subtracted refunds, so the two pages reported different revenue for the same
  period.
- **Refunds were not date-aware.** They were attributed to the *order's* date, so
  a January order refunded in March retroactively reduced January's profit — a
  closed month's reported numbers could change. Refunds now land in the period
  the money actually moved.
- **CLV and refund rate ignored refunds entirely**, and top products ranked by
  gross, so a fully refunded product could sit at the top of the chart. Refunds
  are now apportioned across line items by value share.

`reconcile()` asserts the identities hold; the tests run it over every monthly
slice of the seed dataset.

### P2 #18 — import row validation

`src/lib/services/import.ts` validates every row. Previously `Number(x) || 0`
turned a typo in a price column into a **free product**, and the mapped
`status` / `product_type` / `delivery_type` columns were silently discarded
after the user mapped them. Enum lists are re-exported from `src/lib/types.ts`
rather than duplicated — the duplicate copies had already drifted from the
database enums, which TypeScript caught during this fix. Orders/subscriptions
import is now explicitly refused with a reason instead of silently doing nothing.

### P2 #17 — audit trail

Expenses (create/update/delete), invoices and tasks produced **no audit entry at
all**. Worse, role changes and account enable/disable — the most
security-relevant mutations in the product — were performed by the team page
through a raw `update()`, bypassing both the permission check and the audit
trail. Added permission-checked, audited store actions (`addTeamMember`,
`setMemberRole`, `setMemberActive`, `saveOrgSettings`); deletes now capture the
removed row. Ticket numbering still used `2000 + rows.length`, which reuses a
number after a delete — switched to `nextNumber()`.

### Test suite — 296 passing across 24 files (+17 live tests skipped without `DATABASE_URL`)

| Suite | Tests | Covers |
|---|---|---|
| `migrations` | 8 | All 18 migrations on a clean DB; RLS enabled+forced; SECURITY DEFINER helpers; append-only audit; re-runnability |
| `rls-two-org` | 13 | Tenant isolation, 7-role write matrix in **two orgs**, disabled profiles inert, privilege escalation, cross-org rejection (PGlite) |
| `sql-financial-integrity` | 14 | Refund matrix in SQL, over-payment/over-refund rejection, `order_id` immutability, invoice sync |
| `lifecycle-e2e` | 11 | Customer→Order→Payment→Activation→Subscription→Renewal + validation rejections |
| `rls-model` | 14 | Policy-model structure assertions |
| `authz` | 13 | RBAC matrix |
| `csv` | 13 | Injection, RFC4180, enum/number validation |
| `backup` | 9 | Schema validation and migration |
| `refund-matrix` | 8 | Canonical ledger |
| `invoice-sync` | 8 | Invoice projection |
| `order-state-machine` | 6 | Transition enforcement |
| `subscription-boundaries` | 6 | Expiry time boundaries |
| `sql-counters-transactions` | 11 | Atomic numbering, per-org series, transaction rollback, idempotent replay, RLS inside a transaction |
| `session` | 18 | Disabled/removed profiles inert, no `profiles[0]` escalation, switching gated, production identity resolved only from a verified Supabase session (`requestedUserId` cannot escalate) |
| `sensitive-storage` | 8 | No secrets in localStorage in production or degraded-production mode |
| `finance-reconciliation` | 18 | Date-aware refunds, canonical period arithmetic, CLV/top-products net of refunds, every monthly slice of the seed reconciles |
| `import-validation` | 18 | Per-row enum/numeric validation, mapped status/product_type/delivery_type, unsupported entities disabled |
| `audit-log` | 26 | Sensitive mutations logged with old/new values; no 500 cap; team page cannot bypass the audit trail |
| `supabase-provider` | 21 | Per-entity writes only, whole-DB `save()` refused, optimistic concurrency filter, soft delete, secret columns never selected, diff insert/update/delete planning, parent-before-child ordering, cross-org rejection, activation secrets stripped from every generic write |
| `crypto-secrets` | 15 | AES-256-GCM round-trip, unicode, tamper detection via auth tag, version rejection, wrong-key failure, field encryption/redaction, missing key is a hard failure |
| `whatsapp-provider` | 18 | Availability is server-derived not a public flag, token never in a response, unauthenticated/viewer sends rejected, cross-org recipient refused, provider rejection and network failure reported as failed, failures logged, body not stored in the audit trail |
| `server-session` | 13 | Bearer parsing, invalid token 401, org/role resolved from DB, disabled/deleted/org-less profiles denied, lookup errors fail closed |
| `env-boundary` | 7 | No secret carries a `NEXT_PUBLIC_` prefix, no client component reads a server-only secret or imports the crypto module, `.env.example` has no duplicate keys and documents every variable the code reads |
| **`live/live-rls`** | **17 (skipped)** | **Two-org RLS/RBAC against a hosted database. Runs only when `DATABASE_URL` is set — currently NEVER EXECUTED.** |

---

## Known issues

No compile errors, no lint errors or warnings, no broken imports, no placeholder buttons.

**Not production-ready.** Remaining honest blockers:

- **P0 #1 — Supabase provider implemented, not yet executed against a live project.**
  `SupabaseProvider` performs per-entity CRUD over PostgREST with optimistic
  concurrency (`expectedUpdatedAt`); `save(db)` and `reset()` **throw** so the
  whole-database last-writer-wins path cannot be used. `StoreProvider` now
  selects the provider from `resolveMode()` and persists via
  `saveDiff(previous, next, orgId)`, which writes only changed rows.
  `SUPABASE_REPOSITORY_IMPLEMENTED` is now `true`. Covered by 21 tests against a
  recording fake client. **Still unverified against a hosted Supabase project.**

- **P0 #2 — auth complete in code.** `src/middleware.ts` gates every route on a
  Supabase session cookie in production mode; `/login` provides email+password
  sign-in with generic error text (no account enumeration);
  `resolveServerSession()` resolves profile/org/role server-side via the service
  client and **fails closed** on a disabled, soft-deleted or org-less profile.
  13 session tests. The store now feeds the verified session into
  `resolveSession()` (`getSession()` + `onAuthStateChange`) — previously it did
  not, leaving production with **no acting identity at all**. Fixed and covered
  by 6 tests. **Live sign-in against hosted Supabase not yet exercised.**

- **Live verification never run.** `tests/live/live-rls.test.ts` (17 tests)
  skips unless `DATABASE_URL` is set. No hosted Supabase project has been
  connected, so the following are UNVERIFIED: real sign-in/sign-out, session
  persistence, middleware redirects, profile/org/role resolution against real
  `auth.users`, RLS/RBAC under genuine PostgREST + `auth.uid()`, SupabaseProvider
  CRUD over the wire, the live lifecycle, and encrypted activation secrets
  round-tripping through the real database.

- Import for orders/subscriptions previews and validates but defers creation.

## Verified against a real database

Migrations and RLS are executed by the test suite using **PGlite (PostgreSQL 18 compiled to WASM)**, so the SQL is genuinely run, not merely parsed. Two caveats:

- PGlite has no `pgcrypto` / `pg_trgm` / `citext` binaries, so the harness shims `citext` and skips trigram indexes. `gen_random_uuid()` is built into PG18.
- `auth.users` and `auth.uid()` are shimmed. Behaviour against a hosted Supabase project must still be confirmed with `npm run verify:live` (set `DATABASE_URL`) before going live. **This has not been done.**

## Technical debt

- Attachment upload requires object storage; activation proof accepts a URL for now.
- Server-side PDF generation deferred; invoices use browser print → Save as PDF.
- Bulk WhatsApp scheduling runs through the Cloud API route when `WHATSAPP_ACCESS_TOKEN` and `WHATSAPP_PHONE_NUMBER_ID` are set; click-to-chat remains the zero-config default. The Cloud API path is covered by 18 tests against a stubbed Graph API but **has not been exercised against real Meta credentials**.
- CSV import for orders/subscriptions previews and validates but defers creation (needs linked customer/product resolution).
- Lead Kanban uses a stage dropdown rather than drag-and-drop.

## Live validation tooling (ready, not yet executed)

| Command | Does |
|---|---|
| `npm run migrate` | Applies every migration in `supabase/migrations` in filename order, one transaction per file, recorded in `schema_migrations` with a checksum. Re-runnable; refuses to proceed if an already-applied migration was edited. |
| `npm run verify:schema` | Verifies tables, enums, indexes, triggers, functions, RLS and grants. Fails on anon write grants, RLS-enabled-but-no-policy, a `SECURITY DEFINER` `apply_transaction`, or activation secret columns granted to `authenticated`. |
| `npm run test:live` | 17 two-org RLS/RBAC tests against the hosted database. |
| `npm run verify:live` | All three in sequence. |
| `npm run verify` | Offline gate: `tsc` + `eslint` + `vitest` + `next build`. |

## Next automatic action

**Blocked on credentials.** See `LIVE_SETUP.md` for the exact values required and
where each one comes from. Once `.env.local` exists, run `npm run verify:live`.
Production readiness cannot be declared until that passes.

## Correctness audit (v1.1.1)

A deep audit run by executing the business logic headlessly rather than reading code.

| Area | Bug found | Status |
|---|---|---|
| Seed finance | Expenses ~3x revenue — every range showed a loss | Fixed — opex scales with monthly gross profit |
| Seed dates | `int(1,400)` never produced day 0 → "Today"/"This Month" always empty | Fixed — recency-weighted dates |
| Seed discount | ₹200 discount on a ₹199 product → order total −₹1 | Fixed — capped at 40% of line value |
| Inputs | 11 numeric inputs produced `NaN` when cleared | Fixed — `num()` / `clamp()` helpers |
| Order form | Discount could exceed line value → negative order | Fixed — clamped |
| Payments | No store-level cap on payment/refund size | Fixed — clamped to outstanding / collected |
| A11y | `Field` label had no `htmlFor` → all inputs unlabelled | Fixed — `useId` association |
| A11y | Modal/Drawer missing `aria-labelledby` | Fixed |
| Mobile | Left drawer animated in from the right | Fixed — `slide-in-left` |
| Mobile | Escape did not close the nav drawer | Fixed |
| Overlays | Nested modal unlocked body scroll early | Fixed — ref-counted lock |
| Order form | No stock visibility or oversell warning | Fixed |

Integrity harness result: **0 issues** across referential integrity, order/payment/invoice arithmetic and subscription status/date consistency.

Verification method upgraded: routes are now checked for *rendered visible content*, not just HTTP 200. All 31 navigable routes and all 6 dynamic detail routes pass.
