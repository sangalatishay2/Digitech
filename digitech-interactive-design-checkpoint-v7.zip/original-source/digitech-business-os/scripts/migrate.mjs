#!/usr/bin/env node
/**
 * Apply every migration in supabase/migrations to a live Postgres database,
 * in filename order, inside a transaction per file.
 *
 * The list is read from the folder rather than hardcoded, so it cannot drift
 * from what is actually committed. Applied files are recorded in
 * schema_migrations so re-running is safe and only new files execute.
 *
 * Usage:  DATABASE_URL=postgresql://... node scripts/migrate.mjs [--dry-run]
 */
import { readFileSync, readdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const DIR = join(ROOT, 'supabase/migrations');
const DRY = process.argv.includes('--dry-run');

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('DATABASE_URL is required (Supabase → Settings → Database → Connection string).');
  process.exit(2);
}

const files = readdirSync(DIR)
  .filter((f) => f.endsWith('.sql'))
  .sort();

if (files.length === 0) {
  console.error(`No .sql files found in ${DIR}`);
  process.exit(2);
}

console.log(`Found ${files.length} migrations in supabase/migrations`);

// Supabase requires TLS; the pooler presents a cert this client won't chain to
// a local CA bundle, so verification is relaxed for the connection only.
const client = new pg.Client({ connectionString: url, ssl: { rejectUnauthorized: false } });

await client.connect();

await client.query(`
  create table if not exists schema_migrations (
    filename    text primary key,
    applied_at  timestamptz not null default now(),
    checksum    text
  );
`);

const { rows: done } = await client.query('select filename, checksum from schema_migrations');
const applied = new Map(done.map((r) => [r.filename, r.checksum]));

const { createHash } = await import('node:crypto');
let ran = 0;
let skipped = 0;

for (const file of files) {
  const sql = readFileSync(join(DIR, file), 'utf8');
  const checksum = createHash('sha256').update(sql).digest('hex').slice(0, 16);

  if (applied.has(file)) {
    if (applied.get(file) && applied.get(file) !== checksum) {
      // Editing an already-applied migration means the live schema no longer
      // matches the repository. Fail rather than silently diverge.
      console.error(`\n✗ ${file} has changed since it was applied.`);
      console.error('  Add a new migration instead of editing an applied one.');
      await client.end();
      process.exit(1);
    }
    skipped++;
    continue;
  }

  if (DRY) {
    console.log(`  would apply  ${file}`);
    ran++;
    continue;
  }

  process.stdout.write(`  applying ${file} ... `);
  try {
    await client.query('begin');
    await client.query(sql);
    await client.query('insert into schema_migrations(filename, checksum) values ($1,$2)', [
      file,
      checksum,
    ]);
    await client.query('commit');
    console.log('ok');
    ran++;
  } catch (e) {
    await client.query('rollback');
    console.log('FAILED');
    console.error(`\n✗ ${file}\n  ${e.message}`);
    if (e.position) {
      const upto = sql.slice(0, Number(e.position));
      console.error(`  at line ${upto.split('\n').length}`);
    }
    await client.end();
    process.exit(1);
  }
}

console.log(`\n${DRY ? 'Would apply' : 'Applied'} ${ran}, already present ${skipped}.`);
await client.end();
