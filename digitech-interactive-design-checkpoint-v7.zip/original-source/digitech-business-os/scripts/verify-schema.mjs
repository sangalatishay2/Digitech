#!/usr/bin/env node
/**
 * Post-migration verification against the LIVE database.
 *
 * Confirms the objects the application depends on actually exist, and — more
 * importantly — that every table carrying tenant data has RLS enabled and is
 * not readable by the anon role. A missing index is a performance bug; a
 * missing RLS policy is a data breach, so those are reported as failures.
 *
 * Usage:  DATABASE_URL=postgresql://... node scripts/verify-schema.mjs
 */
import pg from 'pg';

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('DATABASE_URL is required.');
  process.exit(2);
}

const client = new pg.Client({ connectionString: url, ssl: { rejectUnauthorized: false } });
await client.connect();

const q = async (sql, params = []) => (await client.query(sql, params)).rows;
let failures = 0;
const fail = (m) => {
  console.log(`  ✗ ${m}`);
  failures++;
};
const pass = (m) => console.log(`  ✓ ${m}`);

/* ── Tables ───────────────────────────────────────────────────────────── */
console.log('\nTABLES');
const tables = await q(`
  select tablename, rowsecurity
    from pg_tables
   where schemaname = 'public'
   order by tablename
`);
console.log(`  ${tables.length} tables in public`);

// Tables that intentionally hold no tenant data.
const NON_TENANT = new Set(['schema_migrations']);

/* ── RLS ──────────────────────────────────────────────────────────────── */
console.log('\nROW LEVEL SECURITY');
const noRls = tables.filter((t) => !t.rowsecurity && !NON_TENANT.has(t.tablename));
if (noRls.length) fail(`RLS disabled on: ${noRls.map((t) => t.tablename).join(', ')}`);
else pass(`RLS enabled on all ${tables.length - NON_TENANT.size} tenant tables`);

const policies = await q(`
  select tablename, count(*)::int as n
    from pg_policies where schemaname = 'public'
   group by tablename
`);
const total = policies.reduce((a, p) => a + p.n, 0);
pass(`${total} policies across ${policies.length} tables`);

const rlsNoPolicy = tables
  .filter((t) => t.rowsecurity && !NON_TENANT.has(t.tablename))
  .filter((t) => !policies.find((p) => p.tablename === t.tablename));
if (rlsNoPolicy.length) {
  // RLS on with no policy denies everything — usually a mistake, not intent.
  fail(`RLS enabled but NO policy (table is fully inaccessible): ${rlsNoPolicy.map((t) => t.tablename).join(', ')}`);
} else pass('every RLS-enabled table has at least one policy');

/* ── Enums ────────────────────────────────────────────────────────────── */
console.log('\nENUMS');
const enums = await q(`
  select t.typname, count(e.enumlabel)::int as labels
    from pg_type t
    join pg_enum e on e.enumtypid = t.oid
    join pg_namespace n on n.oid = t.typnamespace
   where n.nspname = 'public'
   group by t.typname order by t.typname
`);
pass(`${enums.length} enum types`);
if (enums.length < 15) fail(`expected at least 15 enums, found ${enums.length}`);

/* ── Functions ────────────────────────────────────────────────────────── */
console.log('\nFUNCTIONS');
const fns = await q(`
  select p.proname, p.prosecdef
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname = 'public' order by p.proname
`);
pass(`${fns.length} functions`);
for (const required of ['next_business_number', 'apply_transaction', 'set_updated_at']) {
  if (fns.find((f) => f.proname === required)) pass(`${required}() present`);
  else fail(`${required}() MISSING`);
}
// apply_transaction must NOT be SECURITY DEFINER or it would bypass RLS.
const applyTx = fns.find((f) => f.proname === 'apply_transaction');
if (applyTx) {
  if (applyTx.prosecdef) fail('apply_transaction is SECURITY DEFINER — it would bypass RLS');
  else pass('apply_transaction is not SECURITY DEFINER (RLS applies)');
}

/* ── Triggers ─────────────────────────────────────────────────────────── */
console.log('\nTRIGGERS');
const triggers = await q(`
  select tgname, c.relname
    from pg_trigger t join pg_class c on c.oid = t.tgrelid
    join pg_namespace n on n.oid = c.relnamespace
   where not t.tgisinternal and n.nspname = 'public'
`);
pass(`${triggers.length} triggers`);
if (triggers.length === 0) fail('no triggers found — updated_at/ledger triggers are missing');

/* ── Indexes ──────────────────────────────────────────────────────────── */
console.log('\nINDEXES');
const idx = await q(`select indexname, tablename from pg_indexes where schemaname='public'`);
pass(`${idx.length} indexes`);
const uniques = idx.filter((i) => /^uq_/.test(i.indexname));
pass(`${uniques.length} uq_* uniqueness constraints`);

/* ── Grants ───────────────────────────────────────────────────────────── */
console.log('\nGRANTS');
const anonWrite = await q(`
  select table_name, privilege_type
    from information_schema.role_table_grants
   where grantee = 'anon' and table_schema = 'public'
     and privilege_type in ('INSERT','UPDATE','DELETE')
`);
if (anonWrite.length) {
  fail(`anon has write grants: ${anonWrite.map((r) => `${r.table_name}:${r.privilege_type}`).join(', ')}`);
} else pass('anon has no write grants');

// The four activation secret columns must not be selectable by authenticated.
const secretGrants = await q(`
  select column_name
    from information_schema.column_privileges
   where grantee = 'authenticated' and table_schema = 'public'
     and table_name = 'activations'
     and column_name in ('activation_email','activation_password','activation_details','internal_instructions')
     and privilege_type = 'SELECT'
`);
if (secretGrants.length) {
  fail(`authenticated can SELECT activation secrets: ${secretGrants.map((r) => r.column_name).join(', ')}`);
} else pass('activation secret columns not granted to authenticated');

/* ── Migration ledger ─────────────────────────────────────────────────── */
console.log('\nMIGRATIONS APPLIED');
const mig = await q('select filename from schema_migrations order by filename').catch(() => []);
pass(`${mig.length} recorded in schema_migrations`);

console.log(
  failures === 0
    ? `\nSCHEMA VERIFICATION: PASS (${tables.length} tables, ${total} policies, ${enums.length} enums, ${fns.length} functions, ${triggers.length} triggers, ${idx.length} indexes)`
    : `\nSCHEMA VERIFICATION: FAIL — ${failures} problem(s)`,
);

await client.end();
process.exit(failures === 0 ? 0 : 1);
