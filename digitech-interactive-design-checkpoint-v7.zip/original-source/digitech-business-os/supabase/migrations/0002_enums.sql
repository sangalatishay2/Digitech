-- 0002_enums.sql — business state enums
do $$ begin
  create type customer_status as enum ('lead','active','vip','inactive','blocked','lost');
  create type order_status as enum ('new','awaiting_payment','paid','processing','activation_pending','activated','delivered','completed','cancelled','refunded');
  create type payment_status as enum ('pending','partial','paid','failed','refunded','partially_refunded');
  create type payment_method as enum ('upi','bank_transfer','cash','credit_card','debit_card','gateway','wallet','other');
  create type activation_status as enum ('waiting_payment','ready','processing','waiting_supplier','activated','delivered','failed','cancelled');
  create type subscription_status as enum ('pending','active','expiring','expired','renewed','cancelled','paused');
  create type lead_status as enum ('new','contacted','qualified','interested','negotiation','won','lost','follow_up');
  create type support_status as enum ('open','in_progress','waiting_customer','waiting_supplier','resolved','closed');
  create type task_status as enum ('open','in_progress','done','cancelled');
  create type priority_level as enum ('low','medium','high','urgent');
  create type app_role as enum ('owner','admin','sales','support','accounts','operations','viewer');
  create type product_type as enum ('subscription','license','digital_product','service');
  create type delivery_type as enum ('email_activation','account_activation','license_key','invite_link','manual');
  create type expense_category as enum ('advertising','software','salary','supplier','office','internet','freelancers','tools','subscriptions','taxes','refunds','miscellaneous');
  create type invoice_status as enum ('draft','sent','paid','partial','overdue','void');
  create type reminder_state as enum ('none','contacted','interested','follow_up','not_interested','lost');
exception when duplicate_object then null; end $$;
