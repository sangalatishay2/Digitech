-- 0005_products_suppliers.sql
create table if not exists suppliers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  name text not null,
  contact_person text,
  email citext,
  phone text,
  website text,
  payment_terms text,
  notes text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists product_categories (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  name text not null,
  slug text not null,
  description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, slug)
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  name text not null,
  code text not null,
  category_id uuid references product_categories(id) on delete set null,
  brand text,
  description text,
  product_type product_type not null default 'subscription',
  delivery_type delivery_type not null default 'email_activation',
  duration_days int not null default 0 check (duration_days >= 0),
  cost_price numeric(12,2) not null default 0 check (cost_price >= 0),
  selling_price numeric(12,2) not null default 0 check (selling_price >= 0),
  supplier_id uuid references suppliers(id) on delete set null,
  stock int,                                  -- null = unlimited
  low_stock_threshold int not null default 5,
  is_active boolean not null default true,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, code)
);

create table if not exists supplier_products (
  supplier_id uuid not null references suppliers(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  supplier_cost numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  primary key (supplier_id, product_id)
);

create table if not exists supplier_payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  supplier_id uuid not null references suppliers(id) on delete cascade,
  amount numeric(12,2) not null check (amount > 0),
  method payment_method not null default 'bank_transfer',
  paid_at timestamptz not null default now(),
  reference text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create trigger trg_suppliers_updated before update on suppliers for each row execute function set_updated_at();
create trigger trg_products_updated before update on products for each row execute function set_updated_at();
