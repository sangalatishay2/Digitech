-- 0008_subscriptions_renewals.sql
create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  customer_id uuid not null references customers(id) on delete restrict,
  product_id uuid references products(id) on delete set null,
  order_id uuid not null references orders(id) on delete cascade,
  product_name text not null,
  start_date timestamptz not null default now(),
  expiry_date timestamptz not null,
  -- duration_days / purchase_amount / cost_amount are SNAPSHOTS.
  -- Changing a product's duration later must never move an existing expiry date.
  duration_days int not null,
  purchase_amount numeric(12,2) not null default 0,
  cost_amount numeric(12,2) not null default 0,
  profit numeric(12,2) not null default 0,
  supplier_id uuid references suppliers(id) on delete set null,
  status subscription_status not null default 'active',
  reminder_state reminder_state not null default 'none',
  last_contacted_at timestamptz,
  assigned_to uuid references profiles(id) on delete set null,
  previous_subscription_id uuid references subscriptions(id) on delete set null,
  renewed_to_subscription_id uuid references subscriptions(id) on delete set null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  check (expiry_date >= start_date)
);

-- Complete the renewal chain link from orders (declared in 0006).
do $$ begin
  alter table orders
    add constraint orders_renewal_subscription_fk
    foreign key (renewal_of_subscription_id) references subscriptions(id) on delete set null;
exception when duplicate_object then null; end $$;

create table if not exists renewals (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  previous_subscription_id uuid not null references subscriptions(id) on delete cascade,
  new_subscription_id uuid references subscriptions(id) on delete set null,
  new_order_id uuid references orders(id) on delete set null,
  renewed_at timestamptz not null default now(),
  renewed_by uuid references profiles(id) on delete set null,
  previous_price numeric(12,2),
  new_price numeric(12,2),
  created_at timestamptz not null default now()
);

create trigger trg_subscriptions_updated before update on subscriptions for each row execute function set_updated_at();
