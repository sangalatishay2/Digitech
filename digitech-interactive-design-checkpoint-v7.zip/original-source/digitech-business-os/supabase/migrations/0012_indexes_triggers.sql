-- 0012_indexes_triggers.sql
-- Tenant scoping
create index if not exists idx_customers_org on customers(organization_id) where deleted_at is null;
create index if not exists idx_orders_org on orders(organization_id) where deleted_at is null;
create index if not exists idx_products_org on products(organization_id) where deleted_at is null;
create index if not exists idx_subs_org on subscriptions(organization_id) where deleted_at is null;

-- Lookup / join paths
create index if not exists idx_orders_customer on orders(customer_id);
create index if not exists idx_orders_status on orders(status);
create index if not exists idx_orders_ordered_at on orders(ordered_at desc);
create index if not exists idx_order_items_order on order_items(order_id);
create index if not exists idx_order_items_product on order_items(product_id);
create index if not exists idx_payments_order on payments(order_id);
create index if not exists idx_payments_customer on payments(customer_id);
create index if not exists idx_activations_status on activations(status);
create index if not exists idx_activations_order on activations(order_id);
create index if not exists idx_subs_customer on subscriptions(customer_id);
create index if not exists idx_subs_expiry on subscriptions(expiry_date);
create index if not exists idx_subs_status on subscriptions(status);
create index if not exists idx_leads_status on leads(status);
create index if not exists idx_leads_followup on leads(follow_up_at);
create index if not exists idx_tickets_status on support_tickets(status);
create index if not exists idx_tasks_due on tasks(due_at) where status <> 'done';
create index if not exists idx_expenses_spent on expenses(spent_at desc);
create index if not exists idx_invoices_customer on invoices(customer_id);
create index if not exists idx_activity_record on activity_logs(record_type, record_id);
create index if not exists idx_notifications_unread on notifications(organization_id) where read_at is null;

-- Duplicate DETECTION support (warnings, not constraints) + partial global search
create index if not exists idx_customers_phone_trgm on customers using gin (coalesce(phone,'') gin_trgm_ops);
create index if not exists idx_customers_whatsapp_trgm on customers using gin (coalesce(whatsapp,'') gin_trgm_ops);
create index if not exists idx_customers_name_trgm on customers using gin (name gin_trgm_ops);
create index if not exists idx_customers_email on customers(lower(email::text));
create index if not exists idx_products_name_trgm on products using gin (name gin_trgm_ops);

-- Keep order totals consistent with payments
create or replace function public.recalc_order_payments()
returns trigger language plpgsql as $$
declare
  v_order uuid := coalesce(new.order_id, old.order_id);
  v_paid numeric(12,2);
  v_refunded numeric(12,2);
  v_total numeric(12,2);
begin
  select coalesce(sum(amount) filter (where not is_refund), 0),
         coalesce(sum(amount) filter (where is_refund), 0)
    into v_paid, v_refunded
    from payments where order_id = v_order and deleted_at is null;

  select total into v_total from orders where id = v_order;

  update orders set
    amount_paid = v_paid,
    amount_refunded = v_refunded,
    outstanding = greatest(0, v_total - (v_paid - v_refunded)),
    payment_status = case
      when v_refunded >= v_total and v_refunded > 0 then 'refunded'::payment_status
      when v_refunded > 0 then 'partially_refunded'::payment_status
      when (v_paid - v_refunded) <= 0 then 'pending'::payment_status
      when (v_paid - v_refunded) < v_total then 'partial'::payment_status
      else 'paid'::payment_status end,
    updated_at = now()
  where id = v_order;

  return null;
end;
$$;

drop trigger if exists trg_payments_recalc on payments;
create trigger trg_payments_recalc
after insert or update or delete on payments
for each row execute function recalc_order_payments();

-- Derive subscription status from expiry + org threshold
create or replace function public.derive_subscription_status()
returns trigger language plpgsql as $$
declare
  v_threshold int;
  v_days int;
begin
  if new.status in ('renewed','cancelled','paused','pending') then
    return new;
  end if;
  select expiry_threshold_days into v_threshold from organizations where id = new.organization_id;
  v_days := extract(day from (new.expiry_date - now()))::int;
  new.status := case
    when v_days < 0 then 'expired'::subscription_status
    when v_days <= coalesce(v_threshold, 15) then 'expiring'::subscription_status
    else 'active'::subscription_status end;
  return new;
end;
$$;

drop trigger if exists trg_subs_derive on subscriptions;
create trigger trg_subs_derive
before insert or update of expiry_date, status on subscriptions
for each row execute function derive_subscription_status();
