-- 0007_activations.sql
create table if not exists activations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  order_id uuid not null references orders(id) on delete cascade,
  order_item_id uuid not null references order_items(id) on delete cascade,
  customer_id uuid not null references customers(id) on delete restrict,
  product_name text not null,
  status activation_status not null default 'waiting_payment',
  priority priority_level not null default 'medium',
  assigned_to uuid references profiles(id) on delete set null,
  supplier_id uuid references suppliers(id) on delete set null,
  activation_email citext,
  activation_details text,
  internal_instructions text,
  proof_url text,
  activated_at timestamptz,
  delivered_at timestamptz,
  expiry_date timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create trigger trg_activations_updated before update on activations for each row execute function set_updated_at();
