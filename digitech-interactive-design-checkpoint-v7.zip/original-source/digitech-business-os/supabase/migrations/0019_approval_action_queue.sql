-- 0019_approval_action_queue.sql
-- Human approval boundary for consequential actions plus a durable outbox.
-- Clients may request/review approvals through RLS, but they can never insert,
-- update, claim, or complete action jobs directly. Approval -> queue insertion
-- happens atomically inside a guarded database trigger.

create table if not exists approval_requests (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  request_type text not null check (
    request_type in ('refund','discount','expense','supplier_payment','bulk_message',
                     'secret_access','data_export','account_change','ai_action','other')
  ),
  title text not null check (char_length(title) between 3 and 160),
  description text not null default '' check (char_length(description) <= 4000),
  reason text not null check (char_length(reason) between 3 and 1000),
  risk_level text not null default 'medium' check (risk_level in ('low','medium','high','critical')),
  status text not null default 'pending' check (status in ('pending','approved','rejected','cancelled','executed','expired')),
  entity_type text,
  entity_id uuid,
  financial_impact numeric(14,2) not null default 0 check (financial_impact >= 0),
  payload jsonb not null default '{}'::jsonb check (jsonb_typeof(payload) = 'object' and pg_column_size(payload) <= 65536),
  requested_by uuid not null references profiles(id) on delete restrict,
  reviewed_by uuid references profiles(id) on delete restrict,
  reviewed_at timestamptz,
  review_note text check (review_note is null or char_length(review_note) <= 1000),
  expires_at timestamptz,
  executed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists action_jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  approval_id uuid references approval_requests(id) on delete restrict,
  job_type text not null check (job_type ~ '^[a-z][a-z0-9_.-]{1,79}$'),
  payload jsonb not null default '{}'::jsonb check (jsonb_typeof(payload) = 'object' and pg_column_size(payload) <= 65536),
  status text not null default 'queued' check (status in ('queued','processing','succeeded','failed','dead_letter','cancelled')),
  idempotency_key text not null check (char_length(idempotency_key) between 8 and 200),
  attempts integer not null default 0 check (attempts >= 0),
  max_attempts integer not null default 5 check (max_attempts between 1 and 20),
  available_at timestamptz not null default now(),
  locked_at timestamptz,
  locked_by text,
  last_error text,
  result jsonb,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, idempotency_key)
);

create index if not exists idx_approval_requests_org_status_created
  on approval_requests(organization_id, status, created_at desc) where deleted_at is null;
create index if not exists idx_approval_requests_reviewer
  on approval_requests(organization_id, reviewed_by, reviewed_at desc) where reviewed_by is not null;
create index if not exists idx_action_jobs_ready
  on action_jobs(status, available_at, created_at) where status in ('queued','failed') and deleted_at is null;
create index if not exists idx_action_jobs_approval
  on action_jobs(organization_id, approval_id) where approval_id is not null;

drop trigger if exists trg_approval_requests_updated_at on approval_requests;
create trigger trg_approval_requests_updated_at
before update on approval_requests
for each row execute function set_updated_at();

drop trigger if exists trg_action_jobs_updated_at on action_jobs;
create trigger trg_action_jobs_updated_at
before update on action_jobs
for each row execute function set_updated_at();

create or replace function public.current_profile_id()
returns uuid
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select id from public.profiles
   where auth_user_id = auth.uid() and is_active and deleted_at is null
   limit 1;
$$;

revoke execute on function public.current_profile_id() from public;
grant execute on function public.current_profile_id() to authenticated;

-- Approved/rejected requests are immutable. Reviewers may decide a pending
-- request, but cannot rewrite its payload, requester, impact, or risk while
-- approving it.
create or replace function public.protect_approval_transition()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_reviewer uuid := public.current_profile_id();
begin
  if old.status <> 'pending' then
    raise exception 'approval request is already finalized';
  end if;

  if new.status not in ('approved','rejected') then
    raise exception 'invalid approval transition: pending -> %', new.status;
  end if;

  if v_reviewer is null or not public.has_role(array['owner','admin']::app_role[]) then
    raise exception 'approval review requires owner or admin';
  end if;

  if new.request_type is distinct from old.request_type
     or new.title is distinct from old.title
     or new.description is distinct from old.description
     or new.reason is distinct from old.reason
     or new.risk_level is distinct from old.risk_level
     or new.entity_type is distinct from old.entity_type
     or new.entity_id is distinct from old.entity_id
     or new.financial_impact is distinct from old.financial_impact
     or new.payload is distinct from old.payload
     or new.requested_by is distinct from old.requested_by
     or new.expires_at is distinct from old.expires_at
     or new.organization_id is distinct from old.organization_id then
    raise exception 'approval request content is immutable during review';
  end if;

  if new.status = 'approved' and old.expires_at is not null and old.expires_at <= now() then
    raise exception 'approval request has expired';
  end if;

  new.reviewed_by := v_reviewer;
  new.reviewed_at := now();
  return new;
end;
$$;

drop trigger if exists trg_protect_approval_transition on approval_requests;
create trigger trg_protect_approval_transition
before update on approval_requests
for each row
execute function public.protect_approval_transition();

create or replace function public.enqueue_approved_action()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if old.status = 'pending' and new.status = 'approved' then
    insert into public.action_jobs (
      organization_id, approval_id, job_type, payload, idempotency_key
    ) values (
      new.organization_id,
      new.id,
      new.request_type,
      jsonb_build_object(
        'approval_id', new.id,
        'entity_type', new.entity_type,
        'entity_id', new.entity_id,
        'requested_by', new.requested_by,
        'reviewed_by', new.reviewed_by,
        'financial_impact', new.financial_impact,
        'request', new.payload
      ),
      'approval:' || new.id::text
    ) on conflict (organization_id, idempotency_key) do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_enqueue_approved_action on approval_requests;
create trigger trg_enqueue_approved_action
after update of status on approval_requests
for each row when (old.status is distinct from new.status)
execute function public.enqueue_approved_action();

alter table approval_requests enable row level security;
alter table approval_requests force row level security;
alter table action_jobs enable row level security;
alter table action_jobs force row level security;

drop policy if exists approval_requests_select on approval_requests;
create policy approval_requests_select on approval_requests for select
  using (organization_id = public.current_org_id());

drop policy if exists approval_requests_insert on approval_requests;
create policy approval_requests_insert on approval_requests for insert
  with check (
    organization_id = public.current_org_id()
    and requested_by = public.current_profile_id()
    and status = 'pending'
    and public.has_role(array['owner','admin','sales','support','accounts','operations']::app_role[])
  );

drop policy if exists approval_requests_update on approval_requests;
create policy approval_requests_update on approval_requests for update
  using (
    organization_id = public.current_org_id()
    and status = 'pending'
    and public.has_role(array['owner','admin']::app_role[])
  )
  with check (
    organization_id = public.current_org_id()
    and public.has_role(array['owner','admin']::app_role[])
  );

-- Jobs are visible to owners/admins for monitoring, but have deliberately no
-- browser INSERT/UPDATE/DELETE policy. Only the approval trigger and trusted
-- worker/service role can mutate this durable queue.
drop policy if exists action_jobs_select on action_jobs;
create policy action_jobs_select on action_jobs for select
  using (
    organization_id = public.current_org_id()
    and public.has_role(array['owner','admin']::app_role[])
  );

grant select, insert, update on approval_requests to authenticated;
grant select on action_jobs to authenticated;

comment on table approval_requests is 'Human approval boundary for consequential business and AI actions.';
comment on table action_jobs is 'Durable, idempotent server-owned action queue. Clients have read-only monitoring access.';
