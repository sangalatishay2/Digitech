-- 0020_mobile_business_actions.sql
-- Transactional, RLS-aware contracts for mobile business mutations. Android
-- sends intent; Postgres owns numbering, financial snapshots, reservations,
-- activation creation, payment limits, and idempotency.

create or replace function public.mobile_create_order(
  p_customer_id uuid,
  p_product_id uuid,
  p_quantity integer,
  p_unit_price numeric,
  p_discount numeric default 0,
  p_payment_method payment_method default 'upi',
  p_payment_amount numeric default 0,
  p_notes text default null,
  p_renewal_of_subscription_id uuid default null,
  p_idempotency_key text default null
)
returns uuid
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_org uuid := public.current_org_id();
  v_actor uuid := public.current_profile_id();
  v_product products%rowtype;
  v_customer customers%rowtype;
  v_order_id uuid := gen_random_uuid();
  v_item_id uuid := gen_random_uuid();
  v_number text;
  v_subtotal numeric(12,2);
  v_total numeric(12,2);
  v_cost numeric(12,2);
  v_prior jsonb;
begin
  if v_org is null or v_actor is null then raise exception 'no active organization profile'; end if;
  if not public.has_role(array['owner','admin','sales']::app_role[]) then raise exception 'order creation is not permitted'; end if;
  if p_quantity is null or p_quantity <= 0 or p_quantity > 10000 then raise exception 'invalid quantity'; end if;
  if p_unit_price is null or p_unit_price < 0 or p_discount < 0 then raise exception 'invalid price or discount'; end if;

  if p_idempotency_key is not null then
    perform pg_advisory_xact_lock(hashtextextended(v_org::text || ':' || p_idempotency_key, 0));
    select result into v_prior from idempotency_keys where key = p_idempotency_key and organization_id = v_org;
    if found then return (v_prior ->> 'order_id')::uuid; end if;
  end if;

  select * into v_customer from customers where id = p_customer_id and organization_id = v_org and deleted_at is null;
  if not found then raise exception 'customer not found'; end if;
  select * into v_product from products where id = p_product_id and organization_id = v_org and deleted_at is null and is_active;
  if not found then raise exception 'active product not found'; end if;

  if p_renewal_of_subscription_id is not null and not exists (
    select 1 from subscriptions where id = p_renewal_of_subscription_id and organization_id = v_org and customer_id = p_customer_id
  ) then raise exception 'renewal subscription not found for customer'; end if;

  v_subtotal := round(p_unit_price * p_quantity, 2);
  if p_discount > v_subtotal then raise exception 'discount exceeds subtotal'; end if;
  v_total := round(v_subtotal - p_discount, 2);
  v_cost := round(v_product.cost_price * p_quantity, 2);
  if p_payment_amount < 0 or p_payment_amount > v_total then raise exception 'payment exceeds order total'; end if;
  v_number := public.next_business_number('order');

  insert into orders (
    id, organization_id, order_number, customer_id, status, subtotal, discount, tax, total,
    total_cost, profit, margin, notes, renewal_of_subscription_id, assigned_to, ordered_at
  ) values (
    v_order_id, v_org, v_number, p_customer_id,
    case when p_payment_amount >= v_total and v_total > 0 then 'activation_pending'::order_status else 'awaiting_payment'::order_status end,
    v_subtotal, p_discount, 0, v_total, v_cost, v_total - v_cost,
    case when v_total > 0 then round(((v_total - v_cost) / v_total) * 100, 2) else 0 end,
    nullif(trim(p_notes), ''), p_renewal_of_subscription_id, v_actor, now()
  );

  insert into order_items (
    id, organization_id, order_id, product_id, product_name, product_code, supplier_id, supplier_name,
    delivery_type, product_type, duration_days, quantity, unit_cost, unit_price, discount,
    line_total, line_cost, line_profit
  ) values (
    v_item_id, v_org, v_order_id, v_product.id, v_product.name, v_product.code, v_product.supplier_id,
    (select name from suppliers where id = v_product.supplier_id), v_product.delivery_type, v_product.product_type,
    v_product.duration_days, p_quantity, v_product.cost_price, p_unit_price, p_discount,
    v_total, v_cost, v_total - v_cost
  );

  insert into activations (
    organization_id, order_id, order_item_id, customer_id, product_name, status, priority, assigned_to, supplier_id
  ) values (
    v_org, v_order_id, v_item_id, p_customer_id, v_product.name,
    case when p_payment_amount >= v_total and v_total > 0 then 'ready'::activation_status else 'waiting_payment'::activation_status end,
    'medium', v_actor, v_product.supplier_id
  );

  if v_product.stock is not null then
    update products set reserved_stock = coalesce(reserved_stock, 0) + p_quantity where id = v_product.id;
  end if;

  if p_payment_amount > 0 then
    insert into payments (organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
    values (v_org, v_order_id, p_customer_id, p_payment_amount, p_payment_method, 'paid', false, now());
  end if;

  insert into activity_logs (organization_id, actor_id, actor_name, action, record_type, record_id, summary)
  values (v_org, v_actor, coalesce((select full_name from profiles where id = v_actor), 'User'),
          'created', 'order', v_order_id, 'Mobile order ' || v_number || ' created');

  if p_idempotency_key is not null then
    insert into idempotency_keys (key, organization_id, result)
    values (p_idempotency_key, v_org, jsonb_build_object('order_id', v_order_id))
    on conflict (key) do nothing;
  end if;
  return v_order_id;
end;
$$;

revoke execute on function public.mobile_create_order(uuid,uuid,integer,numeric,numeric,payment_method,numeric,text,uuid,text) from public;
grant execute on function public.mobile_create_order(uuid,uuid,integer,numeric,numeric,payment_method,numeric,text,uuid,text) to authenticated;

comment on function public.mobile_create_order is 'Atomic authoritative order creation contract for first-party clients.';

create or replace function public.mobile_add_payment(
  p_order_id uuid,
  p_amount numeric,
  p_method payment_method default 'upi',
  p_reference text default null,
  p_idempotency_key text default null
)
returns uuid
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_org uuid := public.current_org_id();
  v_actor uuid := public.current_profile_id();
  v_order orders%rowtype;
  v_payment uuid := gen_random_uuid();
  v_prior jsonb;
begin
  if v_org is null or v_actor is null or not public.has_role(array['owner','admin','accounts']::app_role[]) then
    raise exception 'payment creation is not permitted';
  end if;
  if p_idempotency_key is not null then
    perform pg_advisory_xact_lock(hashtextextended(v_org::text || ':' || p_idempotency_key, 0));
    select result into v_prior from idempotency_keys where key = p_idempotency_key and organization_id = v_org;
    if found then return (v_prior ->> 'payment_id')::uuid; end if;
  end if;
  select * into v_order from orders where id = p_order_id and organization_id = v_org and deleted_at is null for update;
  if not found then raise exception 'order not found'; end if;
  insert into payments (id, organization_id, order_id, customer_id, amount, method, status, reference, is_refund, paid_at)
  values (v_payment, v_org, v_order.id, v_order.customer_id, p_amount, p_method, 'paid', nullif(trim(p_reference), ''), false, now());
  update orders set status = case when outstanding <= 0 then 'activation_pending'::order_status else status end where id = v_order.id;
  if p_idempotency_key is not null then
    insert into idempotency_keys (key, organization_id, result) values (p_idempotency_key, v_org, jsonb_build_object('payment_id', v_payment));
  end if;
  return v_payment;
end;
$$;

create or replace function public.mobile_complete_activation(
  p_activation_id uuid,
  p_idempotency_key text default null
)
returns uuid
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_org uuid := public.current_org_id();
  v_actor uuid := public.current_profile_id();
  v_activation activations%rowtype;
  v_order orders%rowtype;
  v_item order_items%rowtype;
  v_subscription uuid;
  v_start timestamptz := now();
  v_expiry timestamptz;
  v_prior jsonb;
begin
  if v_org is null or v_actor is null or not public.has_role(array['owner','admin','operations']::app_role[]) then
    raise exception 'activation completion is not permitted';
  end if;
  if p_idempotency_key is not null then
    perform pg_advisory_xact_lock(hashtextextended(v_org::text || ':' || p_idempotency_key, 0));
    select result into v_prior from idempotency_keys where key = p_idempotency_key and organization_id = v_org;
    if found then return (v_prior ->> 'activation_id')::uuid; end if;
  end if;
  select * into v_activation from activations where id = p_activation_id and organization_id = v_org and deleted_at is null for update;
  if not found then raise exception 'activation not found'; end if;
  if v_activation.status = 'delivered' then return v_activation.id; end if;
  if v_activation.status not in ('ready','processing','activated') then raise exception 'activation is not ready for completion'; end if;
  select * into v_order from orders where id = v_activation.order_id and organization_id = v_org for update;
  select * into v_item from order_items where id = v_activation.order_item_id and organization_id = v_org;
  if v_order.id is null or v_item.id is null then raise exception 'activation source records missing'; end if;

  v_expiry := v_start + make_interval(days => greatest(v_item.duration_days, 0));
  update activations set status = 'delivered', activated_at = coalesce(activated_at, v_start), delivered_at = v_start,
    expiry_date = case when v_item.duration_days > 0 then v_expiry else expiry_date end where id = v_activation.id;

  if v_item.duration_days > 0 then
    select id into v_subscription from subscriptions where source_activation_id = v_activation.id;
    if v_subscription is null then
      v_subscription := gen_random_uuid();
      insert into subscriptions (
        id, organization_id, customer_id, product_id, order_id, product_name, start_date, expiry_date,
        duration_days, purchase_amount, cost_amount, profit, supplier_id, status, assigned_to,
        previous_subscription_id, source_activation_id
      ) values (
        v_subscription, v_org, v_order.customer_id, v_item.product_id, v_order.id, v_item.product_name,
        v_start, v_expiry, v_item.duration_days, v_item.line_total, v_item.line_cost, v_item.line_profit,
        v_item.supplier_id, 'active', v_actor, v_order.renewal_of_subscription_id, v_activation.id
      );
      if v_order.renewal_of_subscription_id is not null then
        update subscriptions set status = 'renewed', renewed_to_subscription_id = v_subscription
          where id = v_order.renewal_of_subscription_id and organization_id = v_org and status <> 'renewed';
        insert into renewals (organization_id, previous_subscription_id, new_subscription_id, new_order_id, renewed_by, previous_price, new_price)
        select v_org, s.id, v_subscription, v_order.id, v_actor, s.purchase_amount, v_item.line_total
          from subscriptions s where s.id = v_order.renewal_of_subscription_id
        on conflict do nothing;
      end if;
    end if;
  end if;

  if v_item.product_id is not null then
    update products set
      stock = case when stock is null then null else greatest(0, stock - v_item.quantity) end,
      reserved_stock = greatest(0, coalesce(reserved_stock, 0) - v_item.quantity)
      where id = v_item.product_id and organization_id = v_org;
  end if;
  if not exists (select 1 from activations where order_id = v_order.id and status not in ('delivered','cancelled')) then
    update orders set status = case when payment_status = 'paid' then 'completed'::order_status else 'delivered'::order_status end where id = v_order.id;
  end if;
  insert into activity_logs (organization_id, actor_id, actor_name, action, record_type, record_id, summary)
  values (v_org, v_actor, coalesce((select full_name from profiles where id = v_actor), 'User'),
          'activated', 'activation', v_activation.id, v_item.product_name || ' delivered from Android');
  if p_idempotency_key is not null then
    insert into idempotency_keys (key, organization_id, result)
    values (p_idempotency_key, v_org, jsonb_build_object('activation_id', v_activation.id));
  end if;
  return v_activation.id;
end;
$$;

revoke execute on function public.mobile_add_payment(uuid,numeric,payment_method,text,text) from public;
revoke execute on function public.mobile_complete_activation(uuid,text) from public;
grant execute on function public.mobile_add_payment(uuid,numeric,payment_method,text,text) to authenticated;
grant execute on function public.mobile_complete_activation(uuid,text) to authenticated;

create or replace function public.mobile_transition_order(p_order_id uuid, p_status order_status)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_org uuid := public.current_org_id();
  v_order orders%rowtype;
  v_allowed boolean := false;
begin
  if v_org is null or public.current_profile_id() is null or not public.has_role(array['owner','admin','sales']::app_role[]) then
    raise exception 'order update is not permitted';
  end if;
  select * into v_order from orders where id = p_order_id and organization_id = v_org and deleted_at is null for update;
  if not found then raise exception 'order not found'; end if;
  v_allowed := case v_order.status
    when 'new' then p_status in ('awaiting_payment','paid','cancelled')
    when 'awaiting_payment' then p_status in ('paid','processing','cancelled')
    when 'paid' then p_status in ('processing','activation_pending','refunded','cancelled')
    when 'processing' then p_status in ('activation_pending','activated','cancelled')
    when 'activation_pending' then p_status in ('activated','cancelled','processing')
    when 'activated' then p_status in ('delivered','completed')
    when 'delivered' then p_status = 'completed'
    when 'completed' then p_status = 'refunded'
    else false end;
  if p_status = v_order.status then return; end if;
  if not v_allowed then raise exception 'illegal order transition % -> %', v_order.status, p_status; end if;
  if p_status = 'paid' and v_order.payment_status <> 'paid' then raise exception 'record payment before marking an order paid'; end if;
  if p_status in ('refunded') and v_order.payment_status <> 'refunded' then raise exception 'record refund before marking an order refunded'; end if;
  if p_status = 'cancelled' then
    update products p set reserved_stock = greatest(0, coalesce(p.reserved_stock, 0) - x.qty)
      from (select product_id, sum(quantity)::integer qty from order_items where order_id = v_order.id and product_id is not null group by product_id) x
      where p.id = x.product_id and p.organization_id = v_org;
    update activations set status = 'cancelled' where order_id = v_order.id and status <> 'delivered';
  end if;
  update orders set status = p_status where id = v_order.id;
end;
$$;

revoke execute on function public.mobile_transition_order(uuid,order_status) from public;
grant execute on function public.mobile_transition_order(uuid,order_status) to authenticated;
