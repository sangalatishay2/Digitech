-- 0018_activation_secrets.sql
--
-- Activation credentials handled as secrets rather than ordinary columns.
--
-- Threat being closed: RLS controls WHO can read the row, but the values sat in
-- the table as plaintext, which means they also sat in every backup, every
-- logical replication stream and every `select *` a future feature might write.
-- Values are now encrypted by the application (AES-256-GCM, see
-- src/lib/security/crypto.ts) before insert, and a CHECK constraint refuses
-- anything that is not ciphertext so a code path that forgets to encrypt fails
-- loudly instead of silently storing a password.

alter table activations
  add column if not exists activation_password text;

/* ------------------------------------------------------------------ */
/* Ciphertext enforcement                                              */
/* ------------------------------------------------------------------ */
/**
 * Ciphertext produced by encryptSecret() is `enc:v1:<iv>:<tag>:<ct>`.
 * NULL and '' are allowed (no secret stored).
 *
 * Rows written before this migration are grandfathered: the constraint is
 * added NOT VALID so existing plaintext does not block deployment, and
 * decryptSecret() passes non-prefixed values through unchanged while they are
 * migrated. Run `alter table activations validate constraint ...` once the
 * backfill has completed.
 */
create or replace function public.is_ciphertext(v text)
returns boolean
language sql
immutable
as $$
  select v is null or v = '' or v like 'enc:v1:%';
$$;

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'activations_secrets_encrypted'
  ) then
    alter table activations
      add constraint activations_secrets_encrypted
      check (
        public.is_ciphertext(activation_email)
        and public.is_ciphertext(activation_password)
        and public.is_ciphertext(activation_details)
        and public.is_ciphertext(internal_instructions)
      ) not valid;
  end if;
end $$;

/* ------------------------------------------------------------------ */
/* Column-level revocation                                             */
/* ------------------------------------------------------------------ */
-- Even with a valid session, the anon/authenticated roles must not be able to
-- pull secret columns through PostgREST. Grants are re-issued per column,
-- omitting the four secret ones. The server route uses the service role (or an
-- explicit column grant) after checking permissions itself.
do $$
declare
  c record;
  cols text := '';
begin
  for c in
    select column_name from information_schema.columns
     where table_schema = 'public' and table_name = 'activations'
       and column_name not in
         ('activation_email','activation_password','activation_details','internal_instructions')
     order by ordinal_position
  loop
    cols := cols || case when cols = '' then '' else ',' end || quote_ident(c.column_name);
  end loop;

  execute 'revoke all on public.activations from authenticated';
  execute format('grant select (%s) on public.activations to authenticated', cols);
  execute format('grant insert (%s) on public.activations to authenticated', cols);
  execute format('grant update (%s) on public.activations to authenticated', cols);
  execute 'grant delete on public.activations to authenticated';
end $$;

-- The secret columns remain writable/readable by the service role only, which
-- is what the /api/activations/[id]/secrets route uses after authorizing.

comment on column activations.activation_email is
  'ENCRYPTED (AES-256-GCM). Never select client-side; use /api/activations/[id]/secrets.';
comment on column activations.activation_password is
  'ENCRYPTED (AES-256-GCM). Never select client-side.';
comment on column activations.activation_details is
  'ENCRYPTED (AES-256-GCM). Never select client-side.';
comment on column activations.internal_instructions is
  'ENCRYPTED (AES-256-GCM). Never select client-side.';
