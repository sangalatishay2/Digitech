-- 0016_rls_rewrite.sql — full replacement for the 0013 policy model.
--
-- Defects being fixed:
--   1. current_org_id()/current_role() selected from `profiles`, which itself has
--      RLS enabled -> infinite recursion (42P17) on every policy evaluation.
--      Fixed with SECURITY DEFINER + a stable search_path so the lookup bypasses RLS.
--   2. current_role() shadows the PostgreSQL built-in current_role. Renamed.
--   3. A generic `<table>_org_write FOR ALL` permissive policy existed alongside
--      role-specific policies. Postgres ORs permissive policies together, so the
--      broad policy defeated every role restriction (a viewer could write
--      payments). Replaced with per-command policies and no blanket write.
--   4. activity_logs were not genuinely append-only (no DELETE policy).
--   5. customer_tags / customer_tag_links / supplier_products had no policies.
--   6. profiles INSERT had no WITH CHECK role requirement -> privilege escalation.

/* ------------------------------------------------------------------ */
/* Identity helpers — SECURITY DEFINER to break RLS recursion           */
/* ------------------------------------------------------------------ */
create or replace function public.current_org_id()
returns uuid
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select organization_id from public.profiles
   where auth_user_id = auth.uid() and is_active and deleted_at is null
   limit 1;
$$;

-- Renamed from current_role() which shadowed the PostgreSQL built-in.
create or replace function public.current_app_role()
returns app_role
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select role from public.profiles
   where auth_user_id = auth.uid() and is_active and deleted_at is null
   limit 1;
$$;

-- A disabled profile resolves to NULL org and NULL role, so every policy below
-- evaluates false: disabled users can never act.
create or replace function public.has_role(roles app_role[])
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select coalesce(public.current_app_role() = any(roles), false);
$$;

create or replace function public.is_member_of(p_org uuid)
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select p_org is not null and p_org = public.current_org_id();
$$;

revoke execute on function public.current_org_id() from public;
revoke execute on function public.current_app_role() from public;
revoke execute on function public.has_role(app_role[]) from public;
revoke execute on function public.is_member_of(uuid) from public;
grant execute on function public.current_org_id() to authenticated;
grant execute on function public.current_app_role() to authenticated;
grant execute on function public.has_role(app_role[]) to authenticated;
grant execute on function public.is_member_of(uuid) to authenticated;

/* ------------------------------------------------------------------ */
/* Drop the old broad policies                                          */
/* ------------------------------------------------------------------ */
do $$
declare t text; r record;
begin
  foreach t in array array[
    'organizations','profiles','customers','customer_notes','customer_tags',
    'product_categories','products','suppliers','supplier_payments',
    'orders','order_items','payments','activations','subscriptions','renewals',
    'leads','lead_activities','support_tickets','ticket_messages','tasks',
    'expenses','invoices','invoice_items','notifications','message_templates',
    'communication_logs','automation_rules','automation_logs','activity_logs','attachments'
  ] loop
    if to_regclass('public.'||t) is null then continue; end if;
    for r in select policyname from pg_policies where schemaname='public' and tablename=t loop
      execute format('drop policy if exists %I on public.%I', r.policyname, t);
    end loop;
    execute format('alter table public.%I enable row level security', t);
    execute format('alter table public.%I force row level security', t);
  end loop;
end $$;

-- Tables that may not exist in every deployment
do $$
declare t text;
begin
  foreach t in array array['customer_tag_links','supplier_products'] loop
    if to_regclass('public.'||t) is not null then
      execute format('alter table public.%I enable row level security', t);
      execute format('alter table public.%I force row level security', t);
    end if;
  end loop;
end $$;

/* ------------------------------------------------------------------ */
/* Read access: any member of the org                                   */
/* ------------------------------------------------------------------ */
do $$
declare t text;
begin
  foreach t in array array[
    'customers','customer_notes','customer_tags','product_categories','products',
    'suppliers','supplier_payments','orders','order_items','payments','activations',
    'subscriptions','renewals','leads','lead_activities','support_tickets',
    'ticket_messages','tasks','expenses','invoices','invoice_items','notifications',
    'message_templates','communication_logs','automation_rules','automation_logs',
    'activity_logs','attachments'
  ] loop
    if to_regclass('public.'||t) is null then continue; end if;
    execute format($f$
      create policy %1$I_select on public.%1$I for select
        using (organization_id = public.current_org_id());
    $f$, t);
  end loop;
end $$;

/* ------------------------------------------------------------------ */
/* Write access: explicit per-table, per-command, role gated            */
/* ------------------------------------------------------------------ */
-- helper: build insert/update/delete policies for a table given a role array
create or replace function public.__mk_write_policies(p_table text, p_roles text)
returns void language plpgsql as $$
begin
  if to_regclass('public.'||p_table) is null then return; end if;
  execute format($f$
    create policy %1$I_insert on public.%1$I for insert
      with check (organization_id = public.current_org_id()
                  and public.has_role(array[%2$s]::app_role[]));
    create policy %1$I_update on public.%1$I for update
      using (organization_id = public.current_org_id()
             and public.has_role(array[%2$s]::app_role[]))
      with check (organization_id = public.current_org_id()
                  and public.has_role(array[%2$s]::app_role[]));
    create policy %1$I_delete on public.%1$I for delete
      using (organization_id = public.current_org_id()
             and public.has_role(array[%2$s]::app_role[]));
  $f$, p_table, p_roles);
end;
$$;

select public.__mk_write_policies('customers',           $$'owner','admin','sales','support'$$);
select public.__mk_write_policies('customer_notes',      $$'owner','admin','sales','support'$$);
select public.__mk_write_policies('customer_tags',       $$'owner','admin','sales'$$);
select public.__mk_write_policies('product_categories',  $$'owner','admin','operations'$$);
select public.__mk_write_policies('products',            $$'owner','admin','operations'$$);
select public.__mk_write_policies('suppliers',           $$'owner','admin','operations'$$);
select public.__mk_write_policies('supplier_payments',   $$'owner','admin','accounts'$$);
select public.__mk_write_policies('orders',              $$'owner','admin','sales'$$);
select public.__mk_write_policies('order_items',         $$'owner','admin','sales'$$);
select public.__mk_write_policies('payments',            $$'owner','admin','accounts'$$);
select public.__mk_write_policies('activations',         $$'owner','admin','operations'$$);
select public.__mk_write_policies('subscriptions',       $$'owner','admin','operations','sales'$$);
select public.__mk_write_policies('renewals',            $$'owner','admin','operations','sales'$$);
select public.__mk_write_policies('leads',               $$'owner','admin','sales'$$);
select public.__mk_write_policies('lead_activities',     $$'owner','admin','sales'$$);
select public.__mk_write_policies('support_tickets',     $$'owner','admin','support'$$);
select public.__mk_write_policies('ticket_messages',     $$'owner','admin','support'$$);
select public.__mk_write_policies('tasks',               $$'owner','admin','sales','support','operations'$$);
select public.__mk_write_policies('expenses',            $$'owner','admin','accounts'$$);
select public.__mk_write_policies('invoices',            $$'owner','admin','accounts'$$);
select public.__mk_write_policies('invoice_items',       $$'owner','admin','accounts'$$);
select public.__mk_write_policies('message_templates',   $$'owner','admin'$$);
select public.__mk_write_policies('communication_logs',  $$'owner','admin','sales','support'$$);
select public.__mk_write_policies('automation_rules',    $$'owner','admin'$$);
select public.__mk_write_policies('attachments',         $$'owner','admin','sales','support','operations','accounts'$$);

drop function public.__mk_write_policies(text, text);

/* ------------------------------------------------------------------ */
/* Special cases                                                        */
/* ------------------------------------------------------------------ */
-- Organizations
create policy orgs_select on public.organizations for select
  using (id = public.current_org_id());
create policy orgs_update on public.organizations for update
  using (id = public.current_org_id() and public.has_role(array['owner','admin']::app_role[]))
  with check (id = public.current_org_id() and public.has_role(array['owner','admin']::app_role[]));

-- Profiles: readable in-org; INSERT requires owner/admin *in WITH CHECK*
-- (the previous FOR ALL policy allowed self-insert privilege escalation).
create policy profiles_select on public.profiles for select
  using (organization_id = public.current_org_id());
create policy profiles_insert on public.profiles for insert
  with check (organization_id = public.current_org_id()
              and public.has_role(array['owner','admin']::app_role[]));
create policy profiles_update on public.profiles for update
  using (organization_id = public.current_org_id()
         and public.has_role(array['owner','admin']::app_role[]))
  with check (organization_id = public.current_org_id()
              and public.has_role(array['owner','admin']::app_role[]));
create policy profiles_delete on public.profiles for delete
  using (organization_id = public.current_org_id()
         and public.has_role(array['owner']::app_role[]));

-- Notifications: a user may mark their own read; admins manage all.
create policy notifications_insert on public.notifications for insert
  with check (organization_id = public.current_org_id());
create policy notifications_update on public.notifications for update
  using (organization_id = public.current_org_id())
  with check (organization_id = public.current_org_id());
create policy notifications_delete on public.notifications for delete
  using (organization_id = public.current_org_id()
         and public.has_role(array['owner','admin']::app_role[]));

-- Activity logs: genuinely append-only. INSERT allowed for members; no UPDATE
-- policy and no DELETE policy exist at all, so both are denied for everyone
-- (including owners) under FORCE RLS.
create policy activity_logs_insert on public.activity_logs for insert
  with check (organization_id = public.current_org_id());

-- Automation logs are machine-written and append-only too.
create policy automation_logs_insert on public.automation_logs for insert
  with check (organization_id = public.current_org_id());

-- Join tables keyed indirectly to an org
do $$
begin
  if to_regclass('public.customer_tag_links') is not null then
    -- These two tables are not in the drop loop above (they have no
    -- organization_id column), so drop their policies explicitly to keep this
    -- migration re-runnable.
    execute $p$
      drop policy if exists customer_tag_links_select on public.customer_tag_links;
      drop policy if exists customer_tag_links_write  on public.customer_tag_links;
      create policy customer_tag_links_select on public.customer_tag_links for select
        using (exists (select 1 from public.customers c
                        where c.id = customer_id and c.organization_id = public.current_org_id()));
      create policy customer_tag_links_write on public.customer_tag_links for all
        using (exists (select 1 from public.customers c
                        where c.id = customer_id and c.organization_id = public.current_org_id())
               and public.has_role(array['owner','admin','sales']::app_role[]))
        with check (exists (select 1 from public.customers c
                        where c.id = customer_id and c.organization_id = public.current_org_id())
               and public.has_role(array['owner','admin','sales']::app_role[]));
    $p$;
  end if;

  if to_regclass('public.supplier_products') is not null then
    execute $p$
      drop policy if exists supplier_products_select on public.supplier_products;
      drop policy if exists supplier_products_write  on public.supplier_products;
      create policy supplier_products_select on public.supplier_products for select
        using (exists (select 1 from public.suppliers s
                        where s.id = supplier_id and s.organization_id = public.current_org_id()));
      create policy supplier_products_write on public.supplier_products for all
        using (exists (select 1 from public.suppliers s
                        where s.id = supplier_id and s.organization_id = public.current_org_id())
               and public.has_role(array['owner','admin','operations']::app_role[]))
        with check (exists (select 1 from public.suppliers s
                        where s.id = supplier_id and s.organization_id = public.current_org_id())
               and public.has_role(array['owner','admin','operations']::app_role[]));
    $p$;
  end if;
end $$;

/* ------------------------------------------------------------------ */
/* Cross-org relation rejection at the data layer                       */
/* ------------------------------------------------------------------ */
-- SECURITY DEFINER is essential: the parent lookup below reads a table that has
-- RLS forced. Without it the lookup is filtered by the caller's own policies,
-- returns NULL for a foreign-org parent, and the guard silently passes --
-- exactly the cross-org reference it is meant to reject.
create or replace function public.assert_same_org()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare v_parent uuid;
begin
  if tg_argv[0] is not null then
    execute format('select organization_id from public.%I where id = $1', tg_argv[0])
      into v_parent using (to_jsonb(new) ->> tg_argv[1])::uuid;
    if v_parent is not null and v_parent is distinct from new.organization_id then
      raise exception 'cross-organization reference: %.% belongs to org %, row is org %',
        tg_argv[0], tg_argv[1], v_parent, new.organization_id;
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_orders_same_org on public.orders;
create trigger trg_orders_same_org before insert or update on public.orders
for each row execute function public.assert_same_org('customers','customer_id');

drop trigger if exists trg_subs_same_org on public.subscriptions;
create trigger trg_subs_same_org before insert or update on public.subscriptions
for each row execute function public.assert_same_org('customers','customer_id');

drop trigger if exists trg_activations_same_org on public.activations;
create trigger trg_activations_same_org before insert or update on public.activations
for each row execute function public.assert_same_org('orders','order_id');

drop trigger if exists trg_invoices_same_org on public.invoices;
create trigger trg_invoices_same_org before insert or update on public.invoices
for each row execute function public.assert_same_org('orders','order_id');

/* ------------------------------------------------------------------ */
/* Table privileges                                                     */
/* ------------------------------------------------------------------ */
-- RLS narrows access, it does not grant it: without these GRANTs every query
-- from an end user fails with "permission denied for table ...". Supabase
-- normally applies them during project bootstrap, but keeping them here makes
-- the schema self-sufficient on a plain Postgres database too.
grant usage on schema public to authenticated, anon;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant usage, select on all sequences in schema public to authenticated;

alter default privileges in schema public
  grant select, insert, update, delete on tables to authenticated;
alter default privileges in schema public
  grant usage, select on sequences to authenticated;

-- anon gets nothing by default; RLS would deny it anyway, but be explicit.
revoke all on all tables in schema public from anon;
