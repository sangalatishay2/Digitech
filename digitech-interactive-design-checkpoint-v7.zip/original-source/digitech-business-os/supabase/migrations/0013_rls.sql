-- 0013_rls.sql — Row Level Security (applies when Supabase Auth is connected)
--
-- Standalone-first note: with no auth.uid(), these policies deny by default and the
-- app runs through the local provider instead. Enable RLS only on the Supabase side.

create or replace function public.current_org_id()
returns uuid language sql stable as $$
  select organization_id from profiles where auth_user_id = auth.uid() limit 1;
$$;

-- NOTE: `current_role` is a reserved SQL keyword; a function of that name
-- cannot be called as current_role() and made this migration fail to apply on
-- a clean database. Named current_app_role() instead. Migration 0016 rewrites
-- these helpers to be SECURITY DEFINER (RLS recursion fix); this definition
-- only needs to be syntactically valid so 0013 applies in sequence.
create or replace function public.current_app_role()
returns app_role language sql stable as $$
  select role from profiles where auth_user_id = auth.uid() limit 1;
$$;

create or replace function public.has_role(roles app_role[])
returns boolean language sql stable as $$
  select coalesce(public.current_app_role() = any(roles), false);
$$;

do $$
declare t text;
begin
  foreach t in array array[
    'organizations','profiles','customers','customer_notes','customer_tags',
    'product_categories','products','suppliers','supplier_payments',
    'orders','order_items','payments','activations','subscriptions','renewals',
    'leads','lead_activities','support_tickets','ticket_messages','tasks',
    'expenses','invoices','invoice_items','notifications','message_templates',
    'communication_logs','automation_rules','automation_logs','activity_logs','attachments'
  ] loop
    execute format('alter table %I enable row level security', t);
  end loop;
end $$;

-- Organization isolation: every tenant table is readable/writable only inside the org.
do $$
declare t text;
begin
  foreach t in array array[
    'customers','customer_notes','product_categories','products','suppliers','supplier_payments',
    'orders','order_items','payments','activations','subscriptions','renewals',
    'leads','lead_activities','support_tickets','ticket_messages','tasks',
    'expenses','invoices','invoice_items','notifications','message_templates',
    'communication_logs','automation_rules','automation_logs','activity_logs','attachments'
  ] loop
    execute format($f$
      drop policy if exists %1$I_org_select on %1$I;
      create policy %1$I_org_select on %1$I for select
        using (organization_id = current_org_id());
      drop policy if exists %1$I_org_write on %1$I;
      create policy %1$I_org_write on %1$I for all
        using (organization_id = current_org_id())
        with check (organization_id = current_org_id());
    $f$, t);
  end loop;
end $$;

-- Organizations / profiles
drop policy if exists orgs_select on organizations;
create policy orgs_select on organizations for select using (id = current_org_id());
drop policy if exists orgs_update on organizations;
create policy orgs_update on organizations for update
  using (id = current_org_id() and has_role(array['owner','admin']::app_role[]));

drop policy if exists profiles_select on profiles;
create policy profiles_select on profiles for select using (organization_id = current_org_id());
drop policy if exists profiles_manage on profiles;
create policy profiles_manage on profiles for all
  using (organization_id = current_org_id() and has_role(array['owner','admin']::app_role[]))
  with check (organization_id = current_org_id());

-- Sensitive finance tables: restrict writes to finance-capable roles.
drop policy if exists expenses_write_roles on expenses;
create policy expenses_write_roles on expenses for all
  using (organization_id = current_org_id() and has_role(array['owner','admin','accounts']::app_role[]))
  with check (organization_id = current_org_id());

drop policy if exists payments_write_roles on payments;
create policy payments_write_roles on payments for all
  using (organization_id = current_org_id() and has_role(array['owner','admin','accounts','sales']::app_role[]))
  with check (organization_id = current_org_id());

-- Activity logs are append-only.
drop policy if exists activity_logs_no_update on activity_logs;
create policy activity_logs_no_update on activity_logs for update using (false);
