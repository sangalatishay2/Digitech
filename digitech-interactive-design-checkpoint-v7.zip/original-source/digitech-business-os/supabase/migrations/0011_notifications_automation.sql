-- 0011_notifications_automation.sql
create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  recipient_id uuid references profiles(id) on delete cascade,
  type text not null,
  title text not null,
  body text not null default '',
  severity text not null default 'info' check (severity in ('info','warning','critical','success')),
  entity_type text,
  entity_id uuid,
  read_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists message_templates (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  name text not null,
  channel text not null default 'whatsapp' check (channel in ('whatsapp','email','sms')),
  subject text,
  body text not null,
  variables text[] not null default '{}',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, name)
);

create table if not exists communication_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  channel text not null check (channel in ('whatsapp','email','sms','call')),
  direction text not null default 'outbound' check (direction in ('outbound','inbound')),
  customer_id uuid references customers(id) on delete set null,
  template_id uuid references message_templates(id) on delete set null,
  to_address text not null,
  body text not null,
  status text not null default 'queued' check (status in ('queued','sent','failed','delivered')),
  provider text not null default 'wa_link',
  error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists automation_rules (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  name text not null,
  description text,
  trigger_event text not null,
  conditions jsonb not null default '{}'::jsonb,
  action_type text not null check (action_type in ('notification','whatsapp','email','task','webhook')),
  action_config jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  last_run_at timestamptz,
  run_count int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists automation_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  rule_id uuid not null references automation_rules(id) on delete cascade,
  event text not null,
  status text not null check (status in ('success','failed','skipped')),
  message text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists activity_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  actor_id uuid references profiles(id) on delete set null,
  actor_name text not null default 'System',
  action text not null,
  record_type text not null,
  record_id uuid not null,
  summary text not null default '',
  old_values jsonb,
  new_values jsonb,
  created_at timestamptz not null default now()
);

create table if not exists attachments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  entity_type text not null,
  entity_id uuid not null,
  file_name text not null,
  file_url text not null,
  mime_type text,
  size_bytes bigint not null default 0,
  uploaded_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
