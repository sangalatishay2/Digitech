-- 0003_organizations_profiles.sql
create table if not exists organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  currency text not null default 'INR',
  timezone text not null default 'Asia/Kolkata',
  gstin text,
  address text,
  email citext,
  phone text,
  expiry_threshold_days int not null default 15 check (expiry_threshold_days between 1 and 365),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- STANDALONE-FIRST: profiles do NOT depend on auth.users.
-- auth_user_id stays nullable and is populated only when Supabase Auth is connected.
create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  auth_user_id uuid unique,               -- nullable, no FK to auth.users (modular)
  full_name text not null,
  email citext not null,
  phone text,
  role app_role not null default 'viewer',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, email)
);

-- Optional linkage to Supabase Auth, applied only when the auth schema exists.
do $$
begin
  if exists (select 1 from information_schema.schemata where schema_name = 'auth') then
    begin
      alter table profiles
        add constraint profiles_auth_user_fk
        foreign key (auth_user_id) references auth.users(id) on delete set null;
    exception when duplicate_object then null; end;
  end if;
end $$;

create trigger trg_orgs_updated before update on organizations for each row execute function set_updated_at();
create trigger trg_profiles_updated before update on profiles for each row execute function set_updated_at();
