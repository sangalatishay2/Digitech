-- 0010_finance_invoices.sql
create table if not exists expenses (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  category expense_category not null default 'miscellaneous',
  description text not null,
  amount numeric(12,2) not null check (amount >= 0),
  vendor text,
  spent_at timestamptz not null default now(),
  method payment_method not null default 'upi',
  is_recurring boolean not null default false,
  attachment_url text,
  created_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists invoices (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  invoice_number text not null,
  customer_id uuid not null references customers(id) on delete restrict,
  order_id uuid references orders(id) on delete set null,
  issue_date timestamptz not null default now(),
  due_date timestamptz not null default (now() + interval '7 days'),
  subtotal numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0,
  tax numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  amount_paid numeric(12,2) not null default 0,
  status invoice_status not null default 'draft',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, invoice_number)
);

create table if not exists invoice_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  invoice_id uuid not null references invoices(id) on delete cascade,
  description text not null,
  quantity int not null default 1,
  unit_price numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

create trigger trg_expenses_updated before update on expenses for each row execute function set_updated_at();
create trigger trg_invoices_updated before update on invoices for each row execute function set_updated_at();
