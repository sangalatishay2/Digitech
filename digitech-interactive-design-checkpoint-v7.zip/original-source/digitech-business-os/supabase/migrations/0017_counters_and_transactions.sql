-- 0017_counters_and_transactions.sql
--
-- 1. Atomic DB-side business numbering (P2 #19). Deriving a code from
--    max(number)+1 or from row-count races: two concurrent inserts read the
--    same maximum and produce the same code. A sequence-backed counter row
--    locked with UPDATE ... RETURNING is atomic under concurrency.
-- 2. Transactional multi-row writes with idempotency keys (P1 #8, #13), so a
--    repository caller can apply several mutations atomically and safely retry.

/* ------------------------------------------------------------------ */
/* Atomic per-organization counters                                     */
/* ------------------------------------------------------------------ */
create table if not exists number_counters (
  organization_id uuid not null references organizations(id) on delete cascade,
  kind text not null check (kind in ('order','invoice','customer','ticket')),
  prefix text not null,
  next_value bigint not null,
  updated_at timestamptz not null default now(),
  primary key (organization_id, kind)
);

alter table number_counters enable row level security;
alter table number_counters force row level security;

drop policy if exists number_counters_select on number_counters;
create policy number_counters_select on number_counters for select
  using (organization_id = public.current_org_id());

-- Counters are advanced only through next_business_number(), which is
-- SECURITY DEFINER. No direct write policy is granted on purpose.

/**
 * Atomically reserve the next business number.
 *
 * `update ... returning` takes a row lock, so two concurrent callers serialise
 * and can never receive the same value. Falls back to seeding the counter from
 * the highest number already present, so it is safe to introduce on a database
 * that already has data.
 */
create or replace function public.next_business_number(p_kind text)
returns text
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_org uuid := public.current_org_id();
  v_prefix text;
  v_start bigint;
  v_next bigint;
  v_existing bigint;
begin
  if v_org is null then
    raise exception 'no organization context';
  end if;

  v_prefix := case p_kind
    when 'order' then 'ORD-'
    when 'invoice' then 'INV-'
    when 'customer' then 'DT-'
    when 'ticket' then 'TKT-'
    else null end;
  if v_prefix is null then
    raise exception 'unknown number kind: %', p_kind;
  end if;

  v_start := case p_kind
    when 'order' then 1001
    when 'invoice' then 501
    when 'customer' then 1001
    when 'ticket' then 2000
    end;

  -- Seed from existing data the first time this counter is used.
  if not exists (select 1 from number_counters where organization_id = v_org and kind = p_kind) then
    v_existing := case p_kind
      when 'order' then (select max(nullif(regexp_replace(order_number, '\D', '', 'g'), '')::bigint)
                           from orders where organization_id = v_org)
      when 'invoice' then (select max(nullif(regexp_replace(invoice_number, '\D', '', 'g'), '')::bigint)
                           from invoices where organization_id = v_org)
      when 'customer' then (select max(nullif(regexp_replace(customer_code, '\D', '', 'g'), '')::bigint)
                           from customers where organization_id = v_org)
      when 'ticket' then (select max(nullif(regexp_replace(ticket_number, '\D', '', 'g'), '')::bigint)
                           from support_tickets where organization_id = v_org)
      end;
    insert into number_counters (organization_id, kind, prefix, next_value)
    values (v_org, p_kind, v_prefix, greatest(coalesce(v_existing, 0) + 1, v_start))
    on conflict (organization_id, kind) do nothing;
  end if;

  update number_counters
     set next_value = next_value + 1, updated_at = now()
   where organization_id = v_org and kind = p_kind
   returning next_value - 1 into v_next;

  return v_prefix || v_next::text;
end;
$$;

revoke execute on function public.next_business_number(text) from public;
grant execute on function public.next_business_number(text) to authenticated;

-- Business codes must be unique per organization even if application code is
-- bypassed. (organization_id, customer_code) is already unique from 0004.
create unique index if not exists uq_orders_number_per_org
  on orders(organization_id, order_number);
create unique index if not exists uq_invoices_number_per_org
  on invoices(organization_id, invoice_number);
create unique index if not exists uq_tickets_number_per_org
  on support_tickets(organization_id, ticket_number);

/* ------------------------------------------------------------------ */
/* Idempotency keys                                                     */
/* ------------------------------------------------------------------ */
create table if not exists idempotency_keys (
  key text primary key,
  organization_id uuid not null references organizations(id) on delete cascade,
  result jsonb,
  created_at timestamptz not null default now()
);

alter table idempotency_keys enable row level security;
alter table idempotency_keys force row level security;

drop policy if exists idempotency_keys_select on idempotency_keys;
create policy idempotency_keys_select on idempotency_keys for select
  using (organization_id = public.current_org_id());

-- apply_transaction() runs as the CALLER (so RLS applies to the rows it
-- touches), which means the caller must also be able to record the key it just
-- consumed. Scoped to their own organization; keys are never updated or
-- deleted, so a consumed key cannot be replayed by rewriting it.
drop policy if exists idempotency_keys_insert on idempotency_keys;
create policy idempotency_keys_insert on idempotency_keys for insert
  with check (organization_id = public.current_org_id());

/* ------------------------------------------------------------------ */
/* Transactional multi-row apply                                        */
/* ------------------------------------------------------------------ */
/**
 * Apply a batch of insert/update/delete operations atomically.
 *
 * PostgREST issues one statement per request, so a caller cannot otherwise get
 * transactional semantics. Everything here runs in the function's single
 * transaction: any failure rolls the whole batch back.
 *
 * This is intentionally NOT security definer — the statements execute as the
 * calling user so RLS still applies to every row touched.
 *
 * Replaying the same idempotency key is a no-op and returns the original
 * result, which is what makes "complete this activation" safe to retry.
 */
create or replace function public.apply_transaction(
  p_ops jsonb,
  p_idempotency_key text default null
)
returns integer
language plpgsql
as $$
declare
  v_org uuid := public.current_org_id();
  v_op jsonb;
  v_table text;
  v_applied integer := 0;
  v_prior jsonb;
  v_cols text;
  v_vals text;
begin
  if v_org is null then
    raise exception 'no organization context';
  end if;

  if p_idempotency_key is not null then
    select result into v_prior from idempotency_keys where key = p_idempotency_key;
    if found then
      return coalesce((v_prior ->> 'applied')::integer, 0);
    end if;
  end if;

  for v_op in select * from jsonb_array_elements(p_ops) loop
    v_table := v_op ->> 'table';

    -- Only tables that carry an organization_id and are known to the app.
    if to_regclass('public.' || v_table) is null then
      raise exception 'unknown table %', v_table;
    end if;

    if (v_op ->> 'kind') = 'insert' then
      select string_agg(quote_ident(k), ','), string_agg(format('%L', v), ',')
        into v_cols, v_vals
        from jsonb_each_text(v_op -> 'row') as e(k, v);
      execute format('insert into public.%I (%s) values (%s)', v_table, v_cols, v_vals);

    elsif (v_op ->> 'kind') = 'update' then
      select string_agg(format('%I = %L', k, v), ',')
        into v_cols
        from jsonb_each_text(v_op -> 'patch') as e(k, v);
      execute format('update public.%I set %s where id = %L', v_table, v_cols, v_op ->> 'id');

    elsif (v_op ->> 'kind') = 'delete' then
      execute format('delete from public.%I where id = %L', v_table, v_op ->> 'id');

    else
      raise exception 'unknown op kind %', v_op ->> 'kind';
    end if;

    v_applied := v_applied + 1;
  end loop;

  if p_idempotency_key is not null then
    insert into idempotency_keys (key, organization_id, result)
    values (p_idempotency_key, v_org, jsonb_build_object('applied', v_applied))
    on conflict (key) do nothing;
  end if;

  return v_applied;
end;
$$;

revoke execute on function public.apply_transaction(jsonb, text) from public;
grant execute on function public.apply_transaction(jsonb, text) to authenticated;

grant select on number_counters to authenticated;
grant select, insert on idempotency_keys to authenticated;
