-- 0004_customers.sql
create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  customer_code text not null,
  name text not null,
  email citext,
  phone text,
  whatsapp text,
  company text,
  city text,
  state text,
  status customer_status not null default 'active',
  source text,
  owner_id uuid references profiles(id) on delete set null,
  notes text,
  tags text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  -- customer_code is organization-unique; phone/email/whatsapp are NOT hard-unique.
  -- Duplicates are surfaced as application warnings so legitimate duplicates
  -- (family members, shared numbers, agencies) are never blocked.
  unique (organization_id, customer_code)
);

create table if not exists customer_notes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  customer_id uuid not null references customers(id) on delete cascade,
  author_id uuid references profiles(id) on delete set null,
  body text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists customer_tags (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  name text not null,
  color text,
  created_at timestamptz not null default now(),
  unique (organization_id, name)
);

create table if not exists customer_tag_links (
  customer_id uuid not null references customers(id) on delete cascade,
  tag_id uuid not null references customer_tags(id) on delete cascade,
  primary key (customer_id, tag_id)
);

create trigger trg_customers_updated before update on customers for each row execute function set_updated_at();
