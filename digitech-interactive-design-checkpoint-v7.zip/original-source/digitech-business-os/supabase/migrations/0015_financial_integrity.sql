-- 0015_financial_integrity.sql
-- P1 fixes: refund semantics, payment order_id integrity, payment/refund limits,
-- time-accurate subscription expiry, invoice ledger sync, activation idempotency.

/* ------------------------------------------------------------------ */
/* 1. Canonical order ledger (mirrors computeOrderLedger in TypeScript) */
/* ------------------------------------------------------------------ */
-- net      = collected - refunded
-- billable = max(0, total - refunded)
-- due      = max(0, billable - net)
create or replace function public.apply_order_ledger(p_order uuid)
returns void language plpgsql as $$
declare
  v_paid numeric(12,2);
  v_refunded numeric(12,2);
  v_total numeric(12,2);
  v_net numeric(12,2);
  v_billable numeric(12,2);
  v_due numeric(12,2);
begin
  if p_order is null then return; end if;

  select coalesce(sum(amount) filter (where not is_refund), 0),
         coalesce(sum(amount) filter (where is_refund), 0)
    into v_paid, v_refunded
    from payments where order_id = p_order and deleted_at is null;

  select total into v_total from orders where id = p_order;
  if v_total is null then return; end if;

  v_net      := v_paid - v_refunded;
  v_billable := greatest(0, v_total - v_refunded);
  v_due      := greatest(0, v_billable - v_net);

  update orders set
    amount_paid = v_paid,
    amount_refunded = v_refunded,
    outstanding = v_due,
    payment_status = case
      when v_refunded > 0 and v_refunded >= v_paid and v_paid > 0 then 'refunded'::payment_status
      when v_refunded > 0 then 'partially_refunded'::payment_status
      when v_paid <= 0 then 'pending'::payment_status
      when v_due > 0 then 'partial'::payment_status
      else 'paid'::payment_status end,
    updated_at = now()
  where id = p_order;
end;
$$;

-- Recalculate BOTH sides when a payment moves between orders (previously the
-- old order kept stale totals because only new.order_id was recalculated).
create or replace function public.recalc_order_payments()
returns trigger language plpgsql as $$
begin
  perform public.apply_order_ledger(new.order_id);
  if tg_op = 'UPDATE' and old.order_id is distinct from new.order_id then
    perform public.apply_order_ledger(old.order_id);
  end if;
  if tg_op = 'DELETE' then
    perform public.apply_order_ledger(old.order_id);
  end if;
  return null;
end;
$$;

drop trigger if exists trg_payments_recalc on payments;
create trigger trg_payments_recalc
after insert or update or delete on payments
for each row execute function public.recalc_order_payments();

-- A brand-new order also needs its ledger initialised: without this the
-- derived columns stay at their defaults, so a freshly created unpaid order
-- reported outstanding = 0 and never appeared as a receivable until its first
-- payment arrived. Also re-runs when the order total itself changes.
create or replace function public.recalc_own_order()
returns trigger language plpgsql as $$
begin
  perform public.apply_order_ledger(new.id);
  return null;
end;
$$;

drop trigger if exists trg_orders_recalc on orders;
create trigger trg_orders_recalc
after insert or update of total, subtotal, discount, tax on orders
for each row execute function public.recalc_own_order();

/* ------------------------------------------------------------------ */
/* 2. Payment / refund limits enforced transactionally in the database  */
/* ------------------------------------------------------------------ */
create or replace function public.enforce_payment_limits()
returns trigger language plpgsql as $$
declare
  v_total numeric(12,2);
  v_paid numeric(12,2);
  v_refunded numeric(12,2);
  v_org uuid;
begin
  select total, organization_id into v_total, v_org from orders where id = new.order_id;
  if v_total is null then
    raise exception 'payment references a non-existent order %', new.order_id;
  end if;

  -- cross-org relation rejection
  if new.organization_id is distinct from v_org then
    raise exception 'payment organization_id % does not match order organization %', new.organization_id, v_org;
  end if;

  if new.amount is null or new.amount <= 0 then
    raise exception 'payment amount must be positive (got %)', new.amount;
  end if;

  select coalesce(sum(amount) filter (where not is_refund), 0),
         coalesce(sum(amount) filter (where is_refund), 0)
    into v_paid, v_refunded
    from payments
   where order_id = new.order_id and deleted_at is null
     and (tg_op = 'INSERT' or id <> new.id);

  if new.is_refund then
    if new.amount > (v_paid - v_refunded) + 0.005 then
      raise exception 'refund % exceeds refundable balance %', new.amount, (v_paid - v_refunded);
    end if;
  else
    if new.amount > greatest(0, v_total - v_refunded) - v_paid + 0.005 then
      raise exception 'payment % exceeds amount due %', new.amount, greatest(0, v_total - v_refunded) - v_paid;
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_payments_limits on payments;
create trigger trg_payments_limits
before insert or update on payments
for each row execute function public.enforce_payment_limits();

-- Make order_id effectively immutable: moving cash between orders must be an
-- explicit void + re-record, not a silent UPDATE.
create or replace function public.freeze_payment_order()
returns trigger language plpgsql as $$
begin
  if old.order_id is distinct from new.order_id then
    raise exception 'payment.order_id is immutable; void the payment and record a new one';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_payments_freeze_order on payments;
create trigger trg_payments_freeze_order
before update on payments
for each row execute function public.freeze_payment_order();

/* ------------------------------------------------------------------ */
/* 3. Time-accurate subscription status                                 */
/* ------------------------------------------------------------------ */
-- extract(day from interval) truncates, so a subscription expiring in 3 hours
-- reported 0 days and was classified 'expiring' instead of still-active, and an
-- already-lapsed one could read 0 instead of expired. Compare timestamps first.
create or replace function public.derive_subscription_status()
returns trigger language plpgsql as $$
declare
  v_threshold int;
begin
  if new.status in ('renewed','cancelled','paused','pending') then
    return new;
  end if;
  select expiry_threshold_days into v_threshold from organizations where id = new.organization_id;
  new.status := case
    when new.expiry_date <= now() then 'expired'::subscription_status
    when new.expiry_date <= now() + make_interval(days => coalesce(v_threshold, 15))
      then 'expiring'::subscription_status
    else 'active'::subscription_status end;
  return new;
end;
$$;

-- Status is time-driven, so a row-trigger alone goes stale. This view is the
-- source of truth for reads; schedule refresh_subscription_statuses() (pg_cron)
-- if you need the stored column to converge too.
create or replace view public.subscription_status_live as
select s.*,
       case
         when s.status in ('renewed','cancelled','paused','pending') then s.status
         when s.expiry_date <= now() then 'expired'::subscription_status
         when s.expiry_date <= now() + make_interval(days => coalesce(o.expiry_threshold_days, 15))
           then 'expiring'::subscription_status
         else 'active'::subscription_status
       end as live_status,
       greatest(0, ceil(extract(epoch from (s.expiry_date - now())) / 86400.0))::int as days_remaining
  from subscriptions s
  join organizations o on o.id = s.organization_id;

create or replace function public.refresh_subscription_statuses()
returns integer language plpgsql as $$
declare v_count integer;
begin
  with upd as (
    update subscriptions s
       set status = l.live_status, updated_at = now()
      from public.subscription_status_live l
     where l.id = s.id and s.status is distinct from l.live_status
    returning 1)
  select count(*) into v_count from upd;
  return v_count;
end;
$$;

/* ------------------------------------------------------------------ */
/* 4. Invoice ledger sync                                               */
/* ------------------------------------------------------------------ */
create or replace function public.apply_invoice_ledger(p_order uuid)
returns void language plpgsql as $$
begin
  -- invoices has no balance_due column; the balance is derived as
  -- (total - amount_paid), matching projectInvoice() on the TypeScript side.
  update invoices i set
    amount_paid = o.amount_paid,
    status = case
      when o.outstanding <= 0.005 and o.amount_paid > 0 then 'paid'::invoice_status
      when o.amount_paid > 0 then 'partial'::invoice_status
      when i.due_date is not null and i.due_date < now() then 'overdue'::invoice_status
      else 'sent'::invoice_status end,
    updated_at = now()
  from orders o
  -- 'cancelled' is not a member of invoice_status; the terminal states are
  -- 'void' and 'draft'. Comparing against a non-existent label raised
  -- "invalid input value for enum invoice_status" on every payment for such an
  -- order. Mirrors projectInvoice() in src/lib/services/business.ts, which
  -- leaves void and draft invoices untouched.
  where i.order_id = o.id and o.id = p_order
    and i.status not in ('void'::invoice_status, 'draft'::invoice_status);
end;
$$;

create or replace function public.sync_invoice_from_order()
returns trigger language plpgsql as $$
begin
  perform public.apply_invoice_ledger(new.id);
  return null;
end;
$$;

drop trigger if exists trg_orders_sync_invoice on orders;
create trigger trg_orders_sync_invoice
after update of amount_paid, amount_refunded, outstanding, total on orders
for each row execute function public.sync_invoice_from_order();

-- An invoice created AFTER payments already exist must not start at zero paid.
create or replace function public.sync_invoice_on_insert()
returns trigger language plpgsql as $$
begin
  perform public.apply_invoice_ledger(new.order_id);
  return null;
end;
$$;

drop trigger if exists trg_invoices_sync_insert on invoices;
create trigger trg_invoices_sync_insert
after insert on invoices
for each row execute function public.sync_invoice_on_insert();

/* ------------------------------------------------------------------ */
/* 5. Activation idempotency                                            */
/* ------------------------------------------------------------------ */
-- Completing the same activation twice must never create two subscriptions.
alter table subscriptions
  add column if not exists source_activation_id uuid references activations(id) on delete set null;

-- The unique index below indexes order_item_id, so the column must exist first.
alter table subscriptions
  add column if not exists order_item_id uuid references order_items(id) on delete set null;

create unique index if not exists uq_subscriptions_source_activation
  on subscriptions(source_activation_id) where source_activation_id is not null;

create unique index if not exists uq_subscriptions_order_item
  on subscriptions(order_item_id) where order_item_id is not null;

/* ------------------------------------------------------------------ */
/* 6. Atomic business numbering                                         */
/* ------------------------------------------------------------------ */
create table if not exists public.number_sequences (
  organization_id uuid not null references organizations(id) on delete cascade,
  kind text not null,
  next_value bigint not null default 1,
  primary key (organization_id, kind)
);

create or replace function public.next_business_number(p_org uuid, p_kind text, p_prefix text, p_start bigint)
returns text language plpgsql as $$
declare v_val bigint;
begin
  insert into public.number_sequences(organization_id, kind, next_value)
  values (p_org, p_kind, p_start)
  on conflict (organization_id, kind) do nothing;

  -- atomic: concurrent callers serialise on the row and never collide
  update public.number_sequences
     set next_value = next_value + 1
   where organization_id = p_org and kind = p_kind
  returning next_value - 1 into v_val;

  return p_prefix || v_val::text;
end;
$$;

create unique index if not exists uq_orders_number_org on orders(organization_id, order_number);
create unique index if not exists uq_invoices_number_org on invoices(organization_id, invoice_number);
create unique index if not exists uq_customers_code_org on customers(organization_id, customer_code);
create unique index if not exists uq_tickets_number_org on support_tickets(organization_id, ticket_number);
