-- 0009_leads_support_tasks.sql
create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  name text not null,
  phone text,
  email citext,
  company text,
  source text,
  interested_product_id uuid references products(id) on delete set null,
  value numeric(12,2) not null default 0,
  probability int not null default 20 check (probability between 0 and 100),
  status lead_status not null default 'new',
  assigned_to uuid references profiles(id) on delete set null,
  follow_up_at timestamptz,
  notes text,
  converted_customer_id uuid references customers(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists lead_activities (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  lead_id uuid not null references leads(id) on delete cascade,
  actor_id uuid references profiles(id) on delete set null,
  activity_type text not null,
  body text,
  created_at timestamptz not null default now()
);

create table if not exists support_tickets (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  ticket_number text not null,
  customer_id uuid not null references customers(id) on delete restrict,
  order_id uuid references orders(id) on delete set null,
  product_id uuid references products(id) on delete set null,
  category text not null default 'General',
  subject text not null,
  description text not null default '',
  priority priority_level not null default 'medium',
  status support_status not null default 'open',
  assigned_to uuid references profiles(id) on delete set null,
  first_response_at timestamptz,
  resolved_at timestamptz,
  due_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, ticket_number)
);

create table if not exists ticket_messages (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  ticket_id uuid not null references support_tickets(id) on delete cascade,
  author_id uuid references profiles(id) on delete set null,
  author_type text not null default 'agent' check (author_type in ('agent','customer')),
  body text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists tasks (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  title text not null,
  description text,
  entity_type text not null default 'general'
    check (entity_type in ('customer','lead','order','subscription','supplier','ticket','general')),
  entity_id uuid,
  priority priority_level not null default 'medium',
  status task_status not null default 'open',
  assigned_to uuid references profiles(id) on delete set null,
  due_at timestamptz,
  reminder_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create trigger trg_leads_updated before update on leads for each row execute function set_updated_at();
create trigger trg_tickets_updated before update on support_tickets for each row execute function set_updated_at();
create trigger trg_tasks_updated before update on tasks for each row execute function set_updated_at();
