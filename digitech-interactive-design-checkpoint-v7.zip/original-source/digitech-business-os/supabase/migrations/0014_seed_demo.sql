-- 0014_seed_demo.sql — removable demo data for DigiTech
-- Every seeded row is tagged so it can be deleted in one statement:
--   delete from organizations where id = '00000000-0000-4000-8000-000000000001';

insert into organizations (id, name, currency, timezone, gstin, address, email, phone, expiry_threshold_days)
values ('00000000-0000-4000-8000-000000000001', 'DigiTech', 'INR', 'Asia/Kolkata',
        '09ABCDE1234F1Z5', 'Shop 12, Abu Lane, Meerut, Uttar Pradesh 250001',
        'hello@digitech.in', '+91 98765 43210', 15)
on conflict (id) do nothing;

insert into profiles (organization_id, auth_user_id, full_name, email, phone, role)
values
 ('00000000-0000-4000-8000-000000000001', null, 'Atishay Sangal', 'atishay@digitech.in', '+919876543210', 'owner'),
 ('00000000-0000-4000-8000-000000000001', null, 'Ravi Kumar',     'ravi@digitech.in',    '+919812345678', 'admin'),
 ('00000000-0000-4000-8000-000000000001', null, 'Sonia Bhatia',   'sonia@digitech.in',   '+919845612378', 'sales'),
 ('00000000-0000-4000-8000-000000000001', null, 'Imran Khan',     'imran@digitech.in',   '+919834567812', 'operations'),
 ('00000000-0000-4000-8000-000000000001', null, 'Nidhi Rao',      'nidhi@digitech.in',   '+919867453412', 'support'),
 ('00000000-0000-4000-8000-000000000001', null, 'Vivek Jain',     'vivek@digitech.in',   '+919823456781', 'accounts')
on conflict (organization_id, email) do nothing;

insert into product_categories (organization_id, name, slug, description) values
 ('00000000-0000-4000-8000-000000000001','Design Tools','design-tools','Design subscriptions'),
 ('00000000-0000-4000-8000-000000000001','Professional Networking','professional-networking','LinkedIn and career tools'),
 ('00000000-0000-4000-8000-000000000001','Automation','automation','Workflow automation'),
 ('00000000-0000-4000-8000-000000000001','AI Tools','ai-tools','AI subscriptions'),
 ('00000000-0000-4000-8000-000000000001','Productivity','productivity','Office and productivity'),
 ('00000000-0000-4000-8000-000000000001','Streaming','streaming','OTT and music')
on conflict (organization_id, slug) do nothing;

insert into suppliers (organization_id, name, contact_person, email, phone, payment_terms) values
 ('00000000-0000-4000-8000-000000000001','Global Digital Supply','Ankit Raheja','ankit@gdsupply.in','+919911223344','Net 30'),
 ('00000000-0000-4000-8000-000000000001','CloudKart Wholesale','Meena Iyer','meena@cloudkart.in','+919922334455','Net 15'),
 ('00000000-0000-4000-8000-000000000001','SubHub Partners','Faisal Ahmed','faisal@subhub.io','+919933445566','Prepaid'),
 ('00000000-0000-4000-8000-000000000001','AI Reseller Network','Tarun Sethi','tarun@airesell.net','+919944556677','Net 30');

insert into products (organization_id, name, code, category_id, brand, product_type, delivery_type, duration_days, cost_price, selling_price, low_stock_threshold)
select '00000000-0000-4000-8000-000000000001', p.name, p.code,
       (select id from product_categories c where c.slug = p.slug and c.organization_id='00000000-0000-4000-8000-000000000001'),
       p.brand, p.ptype::product_type, p.dtype::delivery_type, p.days, p.cost, p.price, 5
from (values
 ('Canva Pro — 12 Months','CANVA-12M','design-tools','Canva','subscription','email_activation',365,450,1299),
 ('LinkedIn Premium Career — 12 Months','LIPC-12M','professional-networking','LinkedIn','subscription','account_activation',365,1800,3499),
 ('LinkedIn Premium Business — 12 Months','LIPB-12M','professional-networking','LinkedIn','subscription','account_activation',365,2400,4499),
 ('n8n Starter — 12 Months','N8N-12M','automation','n8n','subscription','invite_link',365,3200,5999),
 ('AI Tool Subscription — 1 Month','AITOOL-1M','ai-tools','AI','subscription','email_activation',30,320,699),
 ('ChatGPT Plus — 1 Month','GPTP-1M','ai-tools','OpenAI','subscription','account_activation',30,1450,1999),
 ('Microsoft 365 Personal — 12 Months','M365-12M','productivity','Microsoft','subscription','license_key',365,1900,3299),
 ('Netflix Premium — 1 Month','NFLX-1M','streaming','Netflix','subscription','account_activation',30,190,349),
 ('Spotify Premium — 12 Months','SPOT-12M','streaming','Spotify','subscription','account_activation',365,700,1199),
 ('Windows 11 Pro License','WIN11-PRO','productivity','Microsoft','license','license_key',0,550,1499)
) as p(name, code, slug, brand, ptype, dtype, days, cost, price)
on conflict (organization_id, code) do nothing;

insert into message_templates (organization_id, name, channel, body, variables) values
 ('00000000-0000-4000-8000-000000000001','Subscription Expiry Reminder','whatsapp',
  'Hi {{customer_name}}, your {{product_name}} expires on {{expiry_date}} ({{days_remaining}} days left). Renew at ₹{{renewal_price}} to stay active. — DigiTech',
  array['customer_name','product_name','expiry_date','days_remaining','renewal_price']),
 ('00000000-0000-4000-8000-000000000001','Payment Reminder','whatsapp',
  'Hi {{customer_name}}, a payment of ₹{{payment_due}} is pending for order {{order_id}}. — DigiTech',
  array['customer_name','payment_due','order_id']),
 ('00000000-0000-4000-8000-000000000001','Activation Delivered','whatsapp',
  'Hi {{customer_name}}, your {{product_name}} is activated and valid till {{expiry_date}}. Thanks for choosing DigiTech!',
  array['customer_name','product_name','expiry_date'])
on conflict (organization_id, name) do nothing;

insert into automation_rules (organization_id, name, trigger_event, action_type, action_config) values
 ('00000000-0000-4000-8000-000000000001','Subscription expiry reminder (7 days)','subscription.expiring','whatsapp','{"template":"Subscription Expiry Reminder"}'),
 ('00000000-0000-4000-8000-000000000001','Payment reminder (48h overdue)','payment.overdue','whatsapp','{"template":"Payment Reminder"}'),
 ('00000000-0000-4000-8000-000000000001','Lead follow-up reminder','lead.followup_due','task','{}'),
 ('00000000-0000-4000-8000-000000000001','Activation overdue escalation','activation.overdue','notification','{}'),
 ('00000000-0000-4000-8000-000000000001','Support escalation (SLA breach)','support.sla_breach','notification','{}'),
 ('00000000-0000-4000-8000-000000000001','Low stock alert','product.low_stock','notification','{}'),
 ('00000000-0000-4000-8000-000000000001','Supplier payment reminder','supplier.payment_due','notification','{}'),
 ('00000000-0000-4000-8000-000000000001','Customer reactivation','customer.inactive_90d','whatsapp','{"template":"Subscription Expiry Reminder"}');

-- Demo customers (removable)
insert into customers (organization_id, customer_code, name, email, phone, whatsapp, city, state, source, status) values
 ('00000000-0000-4000-8000-000000000001','DT-1001','Rahul Sharma','rahul.sharma@gmail.com','+919812345001','+919812345001','Meerut','Uttar Pradesh','Instagram','active'),
 ('00000000-0000-4000-8000-000000000001','DT-1002','Priya Verma','priya.verma@gmail.com','+919812345002','+919812345002','Delhi','Delhi','Referral','vip'),
 ('00000000-0000-4000-8000-000000000001','DT-1003','Amit Gupta','amit.gupta@gmail.com','+919812345003','+919812345003','Mumbai','Maharashtra','Google','active'),
 ('00000000-0000-4000-8000-000000000001','DT-1004','Sneha Singh','sneha.singh@gmail.com','+919812345004','+919812345004','Pune','Maharashtra','WhatsApp','active'),
 ('00000000-0000-4000-8000-000000000001','DT-1005','Vikram Patel','vikram.patel@gmail.com','+919812345005','+919812345005','Ahmedabad','Gujarat','Website','active')
on conflict (organization_id, customer_code) do nothing;
