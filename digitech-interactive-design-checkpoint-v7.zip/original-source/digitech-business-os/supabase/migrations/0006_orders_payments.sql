-- 0006_orders_payments.sql
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  order_number text not null,
  customer_id uuid not null references customers(id) on delete restrict,
  status order_status not null default 'new',
  payment_status payment_status not null default 'pending',
  subtotal numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0,
  tax numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  total_cost numeric(12,2) not null default 0,
  profit numeric(12,2) not null default 0,
  margin numeric(6,2) not null default 0,
  amount_paid numeric(12,2) not null default 0,
  amount_refunded numeric(12,2) not null default 0,
  outstanding numeric(12,2) not null default 0,
  notes text,
  source text,
  renewal_of_subscription_id uuid,     -- FK added in 0008 (subscriptions table)
  assigned_to uuid references profiles(id) on delete set null,
  ordered_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (organization_id, order_number)
);

-- IMMUTABLE FINANCIAL SNAPSHOT.
-- unit_cost / unit_price / duration_days / supplier_name are copied at sale time and
-- must never be back-filled from products when the catalog changes.
create table if not exists order_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid references products(id) on delete set null,
  product_name text not null,
  product_code text not null,
  supplier_id uuid references suppliers(id) on delete set null,
  supplier_name text,
  delivery_type delivery_type not null,
  product_type product_type not null,
  duration_days int not null default 0,
  quantity int not null default 1 check (quantity > 0),
  unit_cost numeric(12,2) not null default 0,
  unit_price numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0,
  line_total numeric(12,2) not null default 0,
  line_cost numeric(12,2) not null default 0,
  line_profit numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  order_id uuid not null references orders(id) on delete cascade,
  customer_id uuid not null references customers(id) on delete restrict,
  amount numeric(12,2) not null check (amount > 0),
  method payment_method not null default 'upi',
  status payment_status not null default 'paid',
  reference text,
  is_refund boolean not null default false,
  paid_at timestamptz not null default now(),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create trigger trg_orders_updated before update on orders for each row execute function set_updated_at();
create trigger trg_payments_updated before update on payments for each row execute function set_updated_at();
