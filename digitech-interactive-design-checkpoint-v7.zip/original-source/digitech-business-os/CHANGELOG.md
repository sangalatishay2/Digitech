# Changelog — DigiTech Business OS

All notable changes to this project.

## Phase 4 — Production enablement

### Added
- **Supabase data provider wired into the app.** `StoreProvider` now selects the
  provider from `resolveMode()` instead of being hardwired to `localProvider`,
  and persists through `saveDiff(previous, next, orgId)` so only changed rows are
  written. `SUPABASE_REPOSITORY_IMPLEMENTED` flipped to `true`.
- **Snapshot diff engine** (`src/lib/data/diff.ts`) — turns two database
  snapshots into per-entity insert/update/delete operations, ordered
  parent-before-child (reversed for deletes), with `assertOrgScope()` rejecting
  any operation that would write into another organization.
- **`/login`** — email + password sign-in. Errors are deliberately generic so the
  form cannot be used to enumerate staff accounts.
- **Server session resolution** (`src/lib/auth/server-session.ts`) — resolves
  profile, organization and role server-side and fails closed for disabled,
  soft-deleted and org-less profiles.
- **Envelope encryption for activation secrets** (`src/lib/security/crypto.ts`,
  AES-256-GCM, `enc:v1:` envelope) plus
  `/api/activations/[id]/secrets`, the only path that returns plaintext, gated on
  a real session and `activations.read`/`activations.update` and audited as
  `secret_viewed` / `secret_updated`.
- **Migration `0018_activation_secrets.sql`** — CHECK constraint refusing any
  activation secret that is not ciphertext (added `NOT VALID` so existing rows do
  not block deployment), and column-level `GRANT`s that remove the four secret
  columns from the `authenticated` role entirely.
- 44 tests across `supabase-provider` (16), `crypto-secrets` (15) and
  `server-session` (13).

### Changed
- **P2 #20 — WhatsApp Cloud API is now genuinely implemented** rather than
  visibly unavailable. Sending goes through `/api/messaging/whatsapp`, which
  holds `WHATSAPP_ACCESS_TOKEN` server-side; the old `NEXT_PUBLIC_WHATSAPP_PROVIDER`
  flag is gone, because a public flag cannot prove a message can actually be
  sent. Availability is reported by the server, sends are permission-checked,
  recipients outside the caller's organization are refused, and both successful
  and failed attempts are logged (the message body is not stored).
- **Activation secrets are excluded from the snapshot diff.** `diff.ts` strips
  the four encrypted columns from every insert/update and ignores them when
  comparing rows, so a UI still bound to those fields cannot send plaintext from
  the browser or emit a stripped no-op UPDATE that looks like a save. The
  activations page now loads and saves credentials through
  `/api/activations/[id]/secrets` in production (demo mode keeps using the local
  snapshot), and gained the previously missing `activation_password` field.
- `SyncBanner` surfaces `syncError` persistently in the shell, so a failed
  server write can no longer look like a successful save.

### Fixed
- `decryptSecret()` returned an unrecognised `enc:` payload verbatim, so a future
  or corrupted envelope would have been handed to the caller as if it were a
  plaintext password. Unsupported versions now throw. Found by test.
- `src/middleware.ts` gated production on a stale `SUPABASE_REPOSITORY_READY`
  environment variable that was never set, so the auth gate could never engage.
  It now mirrors `resolveMode()`.
- A failed load in production no longer falls back to demo seed data — it
  surfaces `syncError` and an empty database rather than presenting fabricated
  records as if they were real.

## [1.5.0] — 2026-09-01 — Audit trail for sensitive mutations

### Fixed — audit log (P2 #17)
- Expenses (create/update/delete), invoices and tasks produced **no audit entry
  at all**.
- **Role changes and account enable/disable were unrecorded and unchecked.** The
  team page mutated `d.profiles` through a raw `update()`, bypassing both the
  permission check and the audit trail — a user's privileges could be escalated
  with nothing written to the log.
- Deletes recorded nothing about what was removed; they now capture the row.
- Ticket numbering still used `2000 + rows.length`, which reuses a number after
  a delete. Switched to the gap-tolerant `nextNumber()`.

### Added
- Permission-checked, audited store actions: `addTeamMember`, `setMemberRole`,
  `setMemberActive`, `saveOrgSettings`.
- `tests/audit-log.test.ts` (26 tests). 189 → **215**.

## [1.4.0] — 2026-09-01 — Canonical finance layer + import validation

### Added
- `src/lib/services/finance.ts` — THE canonical financial calculation layer.
  `analytics.ts` now delegates to it so every surface reconciles.
- `src/lib/services/import.ts` — per-row import validation.
- Tests: `finance-reconciliation` (18), `import-validation` (18). 153 → **189**.

### Fixed — accounting/analytics (P1 #12)
- **Revenue ignored refunds.** The dashboard summed `order.total` while the P&L
  subtracted refunds, so the two disagreed for the same period.
- **Refunds were not date-aware.** They were attributed to the order's date, so a
  January order refunded in March retroactively changed January's profit. Refund
  events now land in the period they settled.
- **CLV and refund rate ignored refunds**; top products ranked by gross, so a
  fully refunded product could top the chart. Refunds are apportioned across
  line items by value share.
- `outstanding` is treated as a balance ("as of now"), identical across period
  slices, instead of being sliced per period and double counted.

### Fixed — import/export (P2 #18)
- `Number(x) || 0` silently coerced an unparseable price to **0**, creating free
  products. Bad rows are now reported with the spreadsheet row number and field.
- Mapped `status`, `product_type` and `delivery_type` columns were accepted in
  the mapper and then **discarded**. They are now validated and imported.
- Enum lists are re-exported from `src/lib/types.ts` instead of duplicated; the
  duplicates had already drifted from the real database enums.
- Email and phone are format-checked; negative prices and fractional
  duration/stock are rejected; currency formatting (`₹1,299`) is stripped.
- Orders/subscriptions import is explicitly refused with a reason rather than
  silently importing nothing.

## [1.3.0] — 2026-09-01 — P0 architecture: repository layer, auth, secret storage

### Added
- `src/lib/data/repository.ts` — per-entity `Repository` contract (select /
  insert / update / remove / transaction) replacing whole-database `save(db)`.
  The old model serialised the entire database on every mutation, so with two
  concurrent users the second write silently discarded the first
  (last-writer-wins), and row-level authorization was impossible to express.
- `src/lib/data/supabase-repository.ts` — PostgREST implementation with
  optimistic concurrency (`expectedUpdatedAt` → explicit `conflict` result) and
  atomic multi-row writes. Dependency-free; swapping in `@supabase/supabase-js`
  later is a drop-in change.
- `supabase/migrations/0017_counters_and_transactions.sql`
  - `next_business_number()` — atomic, per-organization business codes. The old
    `max(number)+1` derivation races: concurrent inserts read the same maximum
    and mint the same code. `update ... returning` takes a row lock so callers
    serialise. Unique indexes on `(organization_id, order_number)`,
    `(organization_id, invoice_number)` and `(organization_id, ticket_number)`
    enforce the invariant even if application code is bypassed.
  - `apply_transaction()` — transactional batches with idempotency keys, so
    "complete this activation" is safely retryable. Runs as the caller (not
    SECURITY DEFINER) so RLS still applies to every row touched.
- `src/lib/auth/session.ts` — `resolveSession()` as the single identity source.
- `src/middleware.ts` — production traffic without a Supabase session cookie is
  redirected to `/login`. Coarse gate only; RLS remains the real boundary.
- Tests: `sql-counters-transactions` (11), `session` (12),
  `sensitive-storage` (7). Total 123 → **153**.

### Fixed — security
- **Activation credentials could reach localStorage in production.** When
  production mode was requested but *degraded* (missing credentials, or the
  repository layer not yet implemented), the effective mode fell back to demo,
  so `isDemoMode()` returned true and the persistence guard passed — writing
  customer account emails, passwords and internal instructions to browser
  storage on a build the operator had pointed at a real project. Added
  `allowBrowserPersistence()`, strictly narrower than `isDemoMode()`.
- **Disabled profiles could act.** The store resolved identity with
  `db.profiles.find(...) ?? db.profiles[0]`, so a disabled or soft-deleted
  profile could become the acting user and pass every UI check, while SQL would
  have denied it. Identity now flows through `resolveSession()`, which refuses
  disabled and removed profiles in *every* mode.
- User switching now throws outside demo mode instead of silently working.
- Disabled and removed accounts are shown but unselectable in the user menu.
- `idempotency_keys` needed an INSERT policy: `apply_transaction()` runs as the
  caller, so it could not record the key it had just consumed.

## [1.2.0] — 2026-09-01 — Production hardening (Phase 3)

Every item below was reproduced with an automated test, fixed at the root cause,
and re-verified. Test count went from 0 to **123 passing across 12 files**.

### Added
- **Real database testing.** `tests/helpers/pg.ts` boots PostgreSQL 18 in-process
  via PGlite and applies all 16 migrations, so SQL is executed rather than parsed.
- `tests/migrations.test.ts` — migrations apply to a clean DB, RLS enabled *and*
  forced, helpers are SECURITY DEFINER, audit append-only, 0016 re-runnable.
- `tests/rls-two-org.test.ts` — tenant isolation, the 7-role write matrix across
  **two organizations**, disabled profiles inert, privilege escalation blocked,
  cross-org relation rejection.
- `tests/sql-financial-integrity.test.ts` — refund matrix in SQL, over-payment and
  over-refund rejection, `payment.order_id` immutability, invoice reconciliation.
- `tests/sql/rls_two_org.sql` + `tests/sql/run.sh` — pgTAP suite for a hosted DB.
- `src/lib/services/` — `numbering.ts`, `csv.ts`, `backup.ts`, `authz.ts`,
  `validation.ts`; `src/lib/runtime/mode.ts`.

### Fixed — database (found by executing the migrations for the first time)
- `0013` declared `public.current_role()`; `current_role` is a **reserved keyword**,
  so the migration failed with a syntax error on any clean database. Renamed to
  `current_app_role()`.
- `0015` created a unique index on `subscriptions.order_item_id` without ever
  adding the column.
- `0015` compared `invoice_status` to `'cancelled'`, not a member of that enum —
  every payment against such an order raised `invalid input value for enum`.
  Now uses `'void'`/`'draft'`, matching `projectInvoice()`.
- `0015` wrote to the non-existent column `invoices.balance_due`.
- A new order never had its ledger initialised, so an unpaid order reported
  `outstanding = 0` and never showed as a receivable. Added `trg_orders_recalc`.

### Fixed — security
- **`assert_same_org()` was not `SECURITY DEFINER`**, so its parent lookup was
  filtered by the caller's own RLS, returned NULL for a foreign-org parent and the
  cross-org guard silently passed. Now correctly rejects cross-org references.
- Added explicit table `GRANT`s for `authenticated` (RLS narrows access, it does
  not grant it) and revoked `anon`.
- `0016` join-table policies now drop before create, making the migration re-runnable.
- WhatsApp Cloud API no longer reports "configured" from a public env flag while
  `send()` always fails; it is visibly unavailable until a server-side route exists.
- Workspace selector no longer implies multi-org switching it cannot perform, and
  surfaces demo-mode storage explicitly.

### Fixed — business logic
- **Subscription expiry off-by-one:** whole-day bucketing made
  `Math.ceil(-1h / 1day) === -0`, and `-0 < 0` is false, so a subscription that
  lapsed within the last 24 hours reported `expiring` and stayed in the active
  renewal pipeline. Exact timestamps are now compared first.
- Completing an activation twice created two subscriptions. Idempotency guard plus
  a unique index on `source_activation_id`.
- Invoices snapshotted `amount_paid` at creation; they are now a live projection of
  the order ledger, reconciled on every mutation.
- Fully refunded orders no longer reappear as customer receivables.
- Order state machine transitions enforced in the service layer.
- Inventory: reservation vs fulfilment separated; stock released on cancel/refund.
- CSV import split on newlines before handling quotes, corrupting fields with
  embedded newlines — replaced with an RFC4180 parser.
- CSV export sanitises formula injection (`=`, `+`, `-`, `@`).
- Audit log no longer truncates at 500 entries and records old/new values.
- Backup restore validates against a versioned Zod schema with migration,
  referential checks, an Owner/Admin requirement and a confirmation dialog.
- Business numbering derives from the maximum issued number, so codes are never
  reused after a delete.

## [1.1.1] — 2026-09-01

Deep correctness audit of the whole application. Findings were reproduced by executing the real business logic headlessly (not by reading code), then fixed and re-verified.

### Data correctness (demo seed)
- **The demo business was insolvent.** Operating expenses ran ~₹125k/month against ~₹37k/month of revenue, so *every* date range reported a loss — the default dashboard showed Revenue ₹69,874 against Net Profit **−₹76,048**. Expense amounts are now right-sized for a small reseller and, crucially, scale with each month's actual gross profit (~55%, with a floor for fixed costs). All ranges now report a healthy 38.9% gross / 15.5% net margin.
- **"Today" and "This Month" were always empty.** Order dates were generated with `int(1, 400)` — a uniform spread that never produced day 0. Dates are now recency-weighted so ~25% of orders fall in the last 30 days and some land today.
- **An order could have a negative total.** A flat ₹50–250 discount was applied without reference to price, so a ₹199 product could receive a ₹200 discount and produce a −₹1 order (ORD-1123). Seed discounts are now capped at 40% of line value.
- Added a headless integrity check over the generated database — referential integrity, order/payment/invoice arithmetic, subscription date and status consistency: **0 issues**.

### Input validation
- Every numeric input in the app used `Number(e.target.value)`, which yields `NaN` for a cleared field and silently poisoned totals. Added `num()` and `clamp()` helpers in `lib/utils` and applied them to all 11 numeric inputs (order lines, expense amount, lead value/probability, product cost/price/duration/stock threshold, expiry threshold).
- Order line **discounts are now clamped to the line value** and prices/quantities floored, so the order form can no longer produce a negative total.
- Lead probability was capped only by the HTML `max` attribute, which does not prevent typing; it is now clamped to 0–100 in state.
- `addPayment` now clamps in the store as defence in depth: a payment can never exceed the outstanding balance, nor a refund exceed what was actually collected. The payments screen also rejects negative amounts.

### Accessibility
- `Field` rendered a bare `<label>` with no `htmlFor`, leaving **every form input in the app unlabelled** for screen readers. It now generates an id, associates the label, and wires `aria-describedby` for hint/error text plus `aria-invalid` / `aria-required`.
- `Modal` and `Drawer` had a visible heading but no `aria-labelledby`; both are now linked to their title.

### Mobile / UI
- The mobile navigation drawer is anchored to the left but animated with `slide-in-right`, so it slid in from the wrong side. Added a `slide-in-left` keyframe and applied it.
- Escape now closes the mobile navigation drawer.
- Body scroll locking is **reference counted**, so closing a nested overlay (e.g. the customer form opened from inside the order flow) no longer unlocks scrolling while the outer modal is still open.

### Order flow
- The order form never showed stock. It now displays available stock per line, highlights oversold lines in red, and shows a non-blocking warning in the order summary.
- "Paying now" is displayed capped at the order total and is `NaN`-safe.

### Validation
- `tsc --noEmit` clean · `eslint src` 0 problems · `next build` 34/34 routes.
- All 31 navigable routes plus **all 6 dynamic detail routes** (`/customers/[id]`, `/orders/[id]`, `/products/[id]`, `/suppliers/[id]`, `/invoices/[id]`, `/support/[id]`) verified to return 200 *and* render real content — measured by stripping scripts/tags and counting visible characters, rather than trusting the status code.

## [1.1.0] — 2026-09-01

Complete frontend redesign into a premium, modern SaaS interface. **No database, business-logic or functional changes** — the data layer, services, state machine and migrations are untouched.

### Design system
- Rebuilt `globals.css` as a full token system: layered surfaces, refined violet primary (`#6C5CE7` light / `#8B7BF0` dark), semantic colours with matching soft/border variants, a 5-colour chart palette, 3-step radius scale (7/11/14px) and a 5-step soft shadow scale.
- **Dark mode** rebuilt on layered charcoal-navy surfaces (`#0E1014` bg, `#16181D` card, `#0A0C0F` sidebar) — no pure black, soft off-white text, low-contrast borders.
- **Light mode** uses a soft off-white app background with white cards and very subtle borders.
- Typography scale tightened: 25px page titles, 14.5px section titles, 13px body, 12.5px tables, 11px labels, tabular numerals on all financial figures via `.tnum`.
- Motion system at 150–250ms (`fade-in`, `scale-in`, `slide-up`, `slide-in-right`, shimmer) with a `prefers-reduced-motion` guard.

### Components
- `primitives.tsx`: reworked Button (6 variants × 6 sizes), Card, Badge, Modal, Tabs — and added `PageHeader`, `Tooltip`, `Dropdown`/`MenuItem`, `Drawer`, `Switch`, `Checkbox`, `FilterPills`, `IdentityCell`, `Callout`, `Delta`, `SectionTitle`, `DetailRow`, `TableSkeleton`, `KpiSkeleton`.
- `DataTable`: sticky headers, checkbox selection with a bulk-action bar, hover row actions, numeric alignment, sort affordances, richer empty states.
- `KpiCard`: label / large value / real period-over-period delta / dependency-free SVG sparkline. Added `MiniStat`.
- `charts.tsx`: token-driven palette, refined tooltips and grids, new `RankedBars` component.
- Toast, command palette and confirm dialogs restyled.

### Shell
- Sidebar regrouped into Overview / Sales / Customers / Subscriptions / Operations / Catalog / Finance / Automation / Admin, with a workspace selector, live count badges, violet active indicator, and icon-only collapse with tooltips.
- Topbar: breadcrumbs, global search with ⌘K hint, quick-create menu, notification panel, theme switcher, user/role switcher.

### Screens
- **Dashboard** rebuilt as a command center: greeting, 6 KPI cards with deltas and sparklines, asymmetric grid (revenue/profit chart + Action Required feed), recent orders, Today's Brief, Renewal Health, upcoming renewals, top products, activity timeline.
- **Renewal Center** converted from stacked cards to a premium table with 5 KPIs, filter pills, coloured days-left indicators and a derived renewal-probability bar.
- **Activation Queue** converted to an operations table with live ageing timers, SLA colouring at 12h/24h, priority-first sorting.
- **Customers** gained a 5-metric KPI row, bulk selection and row action menus.
- **Customer 360** rebuilt with a profile hero over a 5-metric stats strip.
- **Order creation** upgraded to a connected progress stepper with a low-margin warning.
- **Products** now shows supplier, cost, selling, profit and a visual margin bar.
- **Automations** converted to workflow-style rule rows with trigger → action, last run, success rate and a toggle.
- **Leads** Kanban cards redesigned with stage accents, owner avatars and overdue highlighting.
- **Settings** navigation restyled and made sticky.
- Added a route-level skeleton (`app/loading.tsx`).
- Consistency pass normalising every font size, radius and spacing value across all 34 routes.

### Fixes
- **Fixed blank / stuck preview.** `StoreProvider` gated the entire application behind an async `localProvider.load()`, so the server rendered nothing but a "Loading DigiTech Business OS…" spinner and the UI only appeared once client hydration finished — which looked like a broken or endlessly loading preview. State is now seeded synchronously via `buildSeed()`, so the first paint (server and client) contains the real shell, navigation and data; persisted browser storage is merged in immediately after mount, and corrupted storage falls back to the seed instead of hanging.
- Replaced `window.location.href` navigation on the dashboard with `router.push`.
- Resolved a `History` identifier collision with the DOM global in Customer 360.
- Gave 11 bare empty states an icon and a helpful message.
- Removed all unused imports surfaced by lint.

### Validation
- `tsc --noEmit` clean · `eslint` 0 errors 0 warnings · `next build` 34/34 routes · all 31 routes verified 200 · server-rendered HTML confirmed to contain real page content.

## [1.0.0] — 2026-09-01

Initial complete build of the DigiTech Business OS.

### Foundation
- Scaffolded Next.js 16 (App Router) + TypeScript strict + Tailwind v4 + ESLint.
- Added lucide-react, recharts, zod, date-fns, clsx, tailwind-merge.
- Premium design system: CSS custom-property theming, light/dark/system, print styles.

### Database
- Added 14 incremental migrations (`0001_extensions` … `0014_seed_demo`).
- **Fixed:** `profiles` made standalone-first — no hard dependency on `auth.users`; FK attached conditionally only when the `auth` schema exists.
- **Fixed:** `auth_user_id` nullable and modular for later Supabase Auth integration.
- **Fixed:** removed hard uniqueness on customer phone/email/WhatsApp; duplicates now surface as application warnings. Only `(organization_id, customer_code)` is unique.
- UUID PKs, `organization_id` tenancy, `timestamptz`, `numeric(12,2)` money, explicit `ON DELETE`, soft deletes.
- 16 enums covering all required customer/order/payment/activation/subscription/lead/support states.
- 25+ indexes including trigram indexes for partial search and duplicate detection.
- Triggers: `set_updated_at`, `recalc_order_payments`, `derive_subscription_status`.
- Full RLS with `current_org_id()`, `current_role()`, `has_role()`; finance tables role-gated; activity log append-only.
- Removable demo seed keyed to a single organization id.

### Data & service layer
- `DataProvider` contract with `LocalProvider` (standalone) and `SupabaseProvider` (credential-gated adapter).
- Deterministic demo dataset: 48 customers, 14 products, 4 suppliers, ~100 orders with payments, activations, subscriptions, renewal chains, leads, tickets, tasks, expenses, invoices.
- Business services: order state machine, immutable snapshots, payment recalculation, duplicate detection, profit engine, template rendering, webhook event contract.
- Analytics service: date ranges, KPIs, time series bucketing, top products, customer stats, CLV, renewal rate, refund rate, repeat rate.
- Store with RBAC (`can()`), derived state, generated notifications and audit logging on every mutation.

### Application
- App shell: collapsible sidebar with live counts, breadcrumbs, global search, ⌘K command palette, notification center, quick-create, user/role switcher, theme switcher, mobile drawer.
- Dashboard: 10 live KPIs, 8 date filters incl. custom range, action-required queue, revenue/profit/orders charts, recent orders, upcoming renewals, top products, recent activity, today's brief.
- Customers: saved views, filters, Customer 360 with 10 tabs and lifetime metrics, duplicate-warning form with override.
- Products & Suppliers: margin math, stock and low-stock, cost-snapshot sales history, supplier balances and payment recording.
- Orders: 3-step creation flow with snapshots, custom pricing, discounts, live profit; detail page with enforced state transitions, payments, refunds, activations and invoice generation.
- Payments: ledger, outstanding view, over-payment/over-refund guards.
- Activations: queue across 8 statuses with priority, assignee, supplier, credentials, proof, one-click delivery that creates subscriptions.
- Subscriptions: active/expiring/expired views with derived states and configurable threshold.
- Renewal Center: 7 time-window views, WhatsApp/call/contacted/interested/follow-up/not-interested/lost actions, Renew Now with pre-filled pricing and full renewal chaining.
- Leads: Kanban + list across 8 stages, weighted pipeline, convert-to-customer.
- Tasks: polymorphic attachment to 7 entity types, priorities, overdue tracking.
- Support: tickets with threaded messages, SLA and first-response tracking.
- Finance: revenue analytics, profit engine with P&L statement, expenses CRUD, supplier payments.
- Invoices: printable branded invoice with share and print-to-PDF.
- Analytics: 9 tabs — overview, sales, products, customers, subscriptions, renewals, profit, suppliers, support.
- Automations: rule engine with activate/pause/run-now, run history, 9 documented n8n webhook events with sample payload.
- WhatsApp: provider-agnostic messaging, templates with 7 variables, live preview, logged history.
- Segments & Campaigns: 8 live dynamic segments, 5 campaign playbooks, CSV export.
- Team: 7 roles with a full permission matrix, user switching for RBAC testing.
- Settings: 15 sections, JSON backup/restore, removable demo data.
- Import/Export: CSV with field mapping, auto-detection, preview, duplicate highlighting and a result report.
- PWA: manifest, icon, theme-color, viewport.

### Fixes during build
- Recharts v3 tooltip formatter type incompatibility resolved.
- `Th`/`Td` primitives extended to accept inline styles.
- Import/export union-type export narrowing corrected.
- Replaced three `setState`-in-effect patterns: theme moved to `useSyncExternalStore`, sidebar to lazy state init, command palette to key-based remount.
- Removed unused imports flagged by lint.

### Validation
- `tsc --noEmit` clean · `eslint` 0 errors 0 warnings · `next build` 34/34 routes · dev server route smoke test 200 OK.
