import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Sandbox/preview hosts must be allowed or Next.js blocks HMR + dev assets,
  // which makes the preview hang and reconnect in a loop.
  allowedDevOrigins: [
    "*.e2b.app",
    "3000-i52kyc6hg11xprjgi8amk.e2b.app",
  ],
};

export default nextConfig;
