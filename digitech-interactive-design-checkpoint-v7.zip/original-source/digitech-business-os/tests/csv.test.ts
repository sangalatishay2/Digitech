import { describe, it, expect } from 'vitest';
import { parseCsv, toCsv, sanitizeCsvValue, validateEnum, validateNumber } from '@/lib/services/csv';

describe('CSV formula injection', () => {
  it('neutralises every dangerous prefix', () => {
    for (const bad of ['=1+1', '+1', '-1', '@SUM(A1)', '\tx', '\rx']) {
      expect(sanitizeCsvValue(bad).startsWith("'")).toBe(true);
    }
  });
  it('neutralises the classic HYPERLINK payload', () => {
    const out = toCsv(['name'], [['=HYPERLINK("http://evil.test","click")']]);
    expect(out).toContain('\'=HYPERLINK');
  });
  it('leaves ordinary values untouched', () => {
    expect(sanitizeCsvValue('Rahul Sharma')).toBe('Rahul Sharma');
    expect(sanitizeCsvValue(1500)).toBe('1500');
  });
  it('escapes embedded quotes', () => {
    expect(toCsv(['a'], [['say "hi"']])).toContain('"say ""hi"""');
  });
});

describe('RFC4180 parser', () => {
  it('handles quoted commas', () => {
    const { headers, rows } = parseCsv('name,note\n"Sharma, Rahul",ok');
    expect(headers).toEqual(['name', 'note']);
    expect(rows[0]).toEqual(['Sharma, Rahul', 'ok']);
  });
  it('handles embedded newlines', () => {
    const { rows } = parseCsv('a,b\n"line1\nline2",x');
    expect(rows[0][0]).toBe('line1\nline2');
    expect(rows.length).toBe(1);
  });
  it('handles escaped quotes', () => {
    const { rows } = parseCsv('a\n"he said ""no"""');
    expect(rows[0][0]).toBe('he said "no"');
  });
  it('handles CRLF and BOM', () => {
    const { headers, rows } = parseCsv('\uFEFFa,b\r\n1,2\r\n');
    expect(headers).toEqual(['a', 'b']);
    expect(rows).toEqual([['1', '2']]);
  });
  it('round-trips through toCsv', () => {
    const csv = toCsv(['name', 'amt'], [['Sharma, R', 1000], ['say "hi"', 2]]);
    const { rows } = parseCsv(csv);
    expect(rows[0]).toEqual(['Sharma, R', '1000']);
    expect(rows[1]).toEqual(['say "hi"', '2']);
  });
});

describe('row validation', () => {
  it('maps enums case/space insensitively', () => {
    const r = validateEnum('Bank Transfer', ['bank_transfer', 'upi'] as const, 'method', 1);
    expect(r.ok && r.value).toBe('bank_transfer');
  });
  it('rejects unknown enum values with a helpful message', () => {
    const r = validateEnum('crypto', ['upi'] as const, 'method', 3);
    expect(r.ok).toBe(false);
    if (!r.ok) { expect(r.issue.row).toBe(3); expect(r.issue.message).toMatch(/not one of/); }
  });
  it('parses currency-formatted numbers', () => {
    const r = validateNumber('₹1,500', 'amount', 1);
    expect(r.ok && r.value).toBe(1500);
  });
  it('rejects non-numeric and enforces bounds', () => {
    expect(validateNumber('abc', 'amount', 1).ok).toBe(false);
    expect(validateNumber('-5', 'amount', 1, { min: 0 }).ok).toBe(false);
    expect(validateNumber('1.5', 'qty', 1, { integer: true }).ok).toBe(false);
  });
});
