import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';

/**
 * LIVE two-organization RLS + RBAC verification.
 *
 * Skipped unless DATABASE_URL points at a real Postgres/Supabase database.
 * The PGlite suite shims auth.uid() and the authenticated role; this one
 * exercises the genuine article, which is the only way to prove the policies
 * behave the same way in production.
 *
 * Every statement runs as the `authenticated` role with request.jwt.claim.sub
 * set, exactly as PostgREST does.
 */

const URL = process.env.DATABASE_URL;
const d = URL ? describe : describe.skip;

const ORG_A = '00000000-0000-4000-8000-0000000000a1';
const ORG_B = '00000000-0000-4000-8000-0000000000b1';
const users: Record<string, string> = {
  ownerA: '00000000-0000-4000-8000-00000000a001',
  salesA: '00000000-0000-4000-8000-00000000a002',
  viewerA: '00000000-0000-4000-8000-00000000a003',
  supportA: '00000000-0000-4000-8000-00000000a004',
  accountsA: '00000000-0000-4000-8000-00000000a005',
  disabledA: '00000000-0000-4000-8000-00000000a006',
  deletedA: '00000000-0000-4000-8000-00000000a007',
  ownerB: '00000000-0000-4000-8000-00000000b001',
};

let client: pg.Client;

/** Run a statement as a given end user, the way PostgREST would. */
async function as<T = unknown>(uid: string | null, sql: string, params: unknown[] = []) {
  await client.query('begin');
  try {
    await client.query("set local role authenticated");
    await client.query(`select set_config('request.jwt.claim.sub', $1, true)`, [uid]);
    const r = await client.query(sql, params);
    await client.query('commit');
    return r.rows as T[];
  } catch (e) {
    await client.query('rollback');
    throw e;
  }
}

/** Assert a statement is rejected or silently filtered to zero rows. */
async function denied(uid: string | null, sql: string, params: unknown[] = []) {
  try {
    const rows = await as(uid, sql, params);
    // RLS denies writes by error, but reads by filtering — both are "denied".
    return rows.length === 0;
  } catch {
    return true;
  }
}

d('LIVE: two-organization RLS', () => {
  beforeAll(async () => {
    client = new pg.Client({ connectionString: URL, ssl: { rejectUnauthorized: false } });
    await client.connect();

    // Seed two isolated organizations with a full role spread.
    await client.query(`
      insert into organizations (id, name) values
        ('${ORG_A}', 'Live Test Org A'),
        ('${ORG_B}', 'Live Test Org B')
      on conflict (id) do nothing;
    `);

    const rows: Array<[string, string, string, boolean, string | null]> = [
      [users.ownerA, ORG_A, 'owner', true, null],
      [users.salesA, ORG_A, 'sales', true, null],
      [users.viewerA, ORG_A, 'viewer', true, null],
      [users.supportA, ORG_A, 'support', true, null],
      [users.accountsA, ORG_A, 'accounts', true, null],
      [users.disabledA, ORG_A, 'admin', false, null],
      [users.deletedA, ORG_A, 'admin', true, 'now()'],
      [users.ownerB, ORG_B, 'owner', true, null],
    ];
    for (const [id, org, role, active, del] of rows) {
      await client.query(
        `insert into profiles (id, organization_id, auth_user_id, full_name, role, is_active, deleted_at)
         values ($1,$2,$1,$3,$4::app_role,$5, ${del ?? 'null'})
         on conflict (id) do update set role = excluded.role,
              is_active = excluded.is_active, deleted_at = excluded.deleted_at`,
        [id, org, `User ${role}`, role, active],
      );
    }

    // One customer in each org, used for the isolation checks.
    await client.query(
      `insert into customers (id, organization_id, name, customer_code)
       values ('00000000-0000-4000-8000-0000000000c1','${ORG_A}','Cust A','DT-A001'),
              ('00000000-0000-4000-8000-0000000000c2','${ORG_B}','Cust B','DT-B001')
       on conflict (id) do nothing`,
    );
  }, 60_000);

  afterAll(async () => {
    if (!client) return;
    await client.query(`delete from customers where organization_id in ($1,$2)`, [ORG_A, ORG_B]);
    await client.query(`delete from profiles where organization_id in ($1,$2)`, [ORG_A, ORG_B]);
    await client.query(`delete from organizations where id in ($1,$2)`, [ORG_A, ORG_B]);
    await client.end();
  });

  /* ── Tenant isolation ───────────────────────────────────────────────── */
  it('owner sees only their own organization customers', async () => {
    const rows = await as<{ organization_id: string }>(users.ownerA, 'select organization_id from customers');
    expect(rows.length).toBeGreaterThan(0);
    expect(rows.every((r) => r.organization_id === ORG_A)).toBe(true);
  });

  it('org B cannot read org A customers', async () => {
    const rows = await as<{ id: string }>(
      users.ownerB,
      `select id from customers where organization_id = $1`,
      [ORG_A],
    );
    expect(rows).toHaveLength(0);
  });

  it('cross-org UPDATE affects nothing', async () => {
    expect(
      await denied(
        users.ownerB,
        `update customers set name = 'hacked' where organization_id = $1 returning id`,
        [ORG_A],
      ),
    ).toBe(true);
  });

  it('cross-org DELETE affects nothing', async () => {
    expect(
      await denied(users.ownerB, `delete from customers where organization_id = $1 returning id`, [
        ORG_A,
      ]),
    ).toBe(true);
  });

  it('cannot INSERT a row into another organization', async () => {
    expect(
      await denied(
        users.ownerB,
        `insert into customers (organization_id, name, customer_code)
         values ($1,'Injected','DT-X999') returning id`,
        [ORG_A],
      ),
    ).toBe(true);
  });

  /* ── Role matrix ────────────────────────────────────────────────────── */
  it('viewer can read customers', async () => {
    const rows = await as(users.viewerA, 'select id from customers');
    expect(rows.length).toBeGreaterThan(0);
  });

  it('viewer cannot insert a customer', async () => {
    expect(
      await denied(
        users.viewerA,
        `insert into customers (organization_id, name, customer_code)
         values ($1,'Viewer Made','DT-V001') returning id`,
        [ORG_A],
      ),
    ).toBe(true);
  });

  it('viewer cannot update a customer', async () => {
    expect(
      await denied(users.viewerA, `update customers set name='v' where organization_id=$1 returning id`, [
        ORG_A,
      ]),
    ).toBe(true);
  });

  it('viewer cannot delete a customer', async () => {
    expect(
      await denied(users.viewerA, `delete from customers where organization_id=$1 returning id`, [
        ORG_A,
      ]),
    ).toBe(true);
  });

  it('sales can create a customer', async () => {
    const rows = await as<{ id: string }>(
      users.salesA,
      `insert into customers (organization_id, name, customer_code)
       values ($1,'Sales Made','DT-S001') returning id`,
      [ORG_A],
    );
    expect(rows).toHaveLength(1);
  });

  /* ── Inert identities ───────────────────────────────────────────────── */
  it('a disabled profile can read nothing', async () => {
    const rows = await as(users.disabledA, 'select id from customers');
    expect(rows).toHaveLength(0);
  });

  it('a disabled profile cannot write', async () => {
    expect(
      await denied(
        users.disabledA,
        `insert into customers (organization_id, name, customer_code)
         values ($1,'Disabled','DT-D001') returning id`,
        [ORG_A],
      ),
    ).toBe(true);
  });

  it('a soft-deleted profile can read nothing', async () => {
    const rows = await as(users.deletedA, 'select id from customers');
    expect(rows).toHaveLength(0);
  });

  it('an unauthenticated caller can read nothing', async () => {
    const rows = await as(null, 'select id from customers');
    expect(rows).toHaveLength(0);
  });

  /* ── Privilege escalation ───────────────────────────────────────────── */
  it('sales cannot promote themselves to owner', async () => {
    await as(
      users.salesA,
      `update profiles set role = 'owner'::app_role where id = $1`,
      [users.salesA],
    ).catch(() => undefined);
    const [row] = await as<{ role: string }>(
      users.ownerA,
      `select role from profiles where id = $1`,
      [users.salesA],
    );
    expect(row.role).toBe('sales');
  });

  it('a user cannot move their profile to another organization', async () => {
    await as(users.salesA, `update profiles set organization_id = $1 where id = $2`, [
      ORG_B,
      users.salesA,
    ]).catch(() => undefined);
    const [row] = await as<{ organization_id: string }>(
      users.ownerA,
      `select organization_id from profiles where id = $1`,
      [users.salesA],
    );
    expect(row.organization_id).toBe(ORG_A);
  });

  /* ── Append-only audit ──────────────────────────────────────────────── */
  it('activity logs cannot be updated or deleted', async () => {
    await as(
      users.ownerA,
      `insert into activity_logs (organization_id, actor_id, action, record_type, summary)
       values ($1,$2,'live_test','customer','probe')`,
      [ORG_A, users.ownerA],
    );
    let updateBlocked = false;
    try {
      await as(users.ownerA, `update activity_logs set summary='tampered' where action='live_test'`);
    } catch {
      updateBlocked = true;
    }
    let deleteBlocked = false;
    try {
      await as(users.ownerA, `delete from activity_logs where action='live_test'`);
    } catch {
      deleteBlocked = true;
    }
    expect(updateBlocked || deleteBlocked).toBe(true);
  });
});
