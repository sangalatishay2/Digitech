import { PGlite } from '@electric-sql/pglite';
import fs from 'node:fs';
import path from 'node:path';

/**
 * Boots a real PostgreSQL 18 instance (PGlite = Postgres compiled to WASM) and
 * applies every migration, so schema/RLS assertions execute genuine SQL rather
 * than string-matching the files.
 *
 * PGlite ships without the pgcrypto / pg_trgm / citext extension binaries and
 * without Supabase's `auth` schema, so the harness pre-creates compatible
 * shims. The migrations themselves are NOT modified: on real Supabase the
 * genuine extensions and auth.users exist and these become no-ops.
 */
const MIG_DIR = path.join(process.cwd(), 'supabase/migrations');

const SHIM = `
create schema if not exists auth;

create table if not exists auth.users (
  id uuid primary key default gen_random_uuid(),
  email text
);

create or replace function auth.uid() returns uuid language sql stable as $fn$
  select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
$fn$;

do $r$ begin
  if not exists (select 1 from pg_roles where rolname='authenticated') then create role authenticated; end if;
  if not exists (select 1 from pg_roles where rolname='anon') then create role anon; end if;
end $r$;

do $c$ begin
  if not exists (select 1 from pg_type where typname='citext') then
    create domain citext as text;
  end if;
end $c$;
`;

/** Strip statements needing extensions PGlite cannot provide. */
function stripUnsupported(sql: string): string {
  return sql
    .split('\n')
    .filter((l) => !/create extension/i.test(l))
    .join('\n')
    .replace(/create index[^;]*gin_trgm_ops[^;]*;/gi, '')
    .replace(/create index[^;]*using gin[^;]*;/gi, '');
}

export interface BootedDb {
  db: PGlite;
  applied: string[];
}

export async function bootDatabase(): Promise<BootedDb> {
  const db = await PGlite.create();
  await db.exec(SHIM);
  const applied: string[] = [];
  for (const f of MIGRATION_FILES) {
    const sql = stripUnsupported(fs.readFileSync(path.join(MIG_DIR, f), 'utf8'));
    try {
      await db.exec(sql);
      applied.push(f);
    } catch (e) {
      throw new Error(`migration ${f} failed: ${(e as Error).message}`);
    }
  }
  return { db, applied };
}

export const MIGRATION_FILES = fs
  .readdirSync(MIG_DIR)
  .filter((f) => f.endsWith('.sql'))
  .sort();

/** Impersonate a Supabase auth user so RLS policies evaluate for them. */
export async function actAs(db: PGlite, uid: string | null) {
  await db.query(`select set_config('request.jwt.claim.sub', $1, false)`, [uid ?? '']);
}

/** Run a statement and report whether RLS/constraints rejected it. */
export async function denied(db: PGlite, sql: string, params: unknown[] = []): Promise<boolean> {
  try {
    const r = await db.query(sql, params as never[]);
    // An UPDATE/DELETE filtered out by RLS affects zero rows rather than throwing.
    const affected = (r as { affectedRows?: number }).affectedRows;
    if (typeof affected === 'number' && /^\s*(update|delete)/i.test(sql)) return affected === 0;
    return false;
  } catch {
    return true;
  }
}
