import { describe, it, expect } from 'vitest';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

/**
 * Enforces the public/secret environment boundary.
 *
 * Next.js inlines every NEXT_PUBLIC_* variable into the client bundle at build
 * time. A secret that acquires that prefix — or a server-only secret read from
 * a file that ends up in a client component — is published to every visitor.
 * These are structural checks so the mistake is caught at test time rather than
 * discovered in a shipped bundle.
 */

const ROOT = join(__dirname, '..');
const SRC = join(ROOT, 'src');

/** Values that must never be readable by the browser. */
const SECRET_VARS = [
  'SUPABASE_SERVICE_ROLE_KEY',
  'ACTIVATION_ENCRYPTION_KEY',
  'WHATSAPP_ACCESS_TOKEN',
  'DATABASE_URL',
];

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (/\.(ts|tsx)$/.test(p)) out.push(p);
  }
  return out;
}

const FILES = walk(SRC);

function isClientFile(path: string): boolean {
  const head = readFileSync(path, 'utf8').slice(0, 200);
  return /^\s*['"]use client['"]/m.test(head);
}

/** Strip comments and JSX text so we only look at real code. */
function codeOf(path: string): string {
  return readFileSync(path, 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/\/\/.*$/gm, '');
}

describe('no secret carries a NEXT_PUBLIC_ prefix', () => {
  it('.env.example never prefixes a secret with NEXT_PUBLIC_', () => {
    const env = readFileSync(join(ROOT, '.env.example'), 'utf8');
    for (const secret of SECRET_VARS) {
      expect(env).not.toMatch(new RegExp(`NEXT_PUBLIC_\\w*${secret}`));
      expect(env).not.toMatch(new RegExp(`NEXT_PUBLIC_${secret}`));
    }
  });

  it('source never reads a NEXT_PUBLIC_ variable whose name implies a secret', () => {
    for (const file of FILES) {
      const matches = codeOf(file).match(/process\.env\.NEXT_PUBLIC_[A-Z_0-9]*/g) ?? [];
      for (const m of matches) {
        expect(
          /SECRET|SERVICE_ROLE|ACCESS_TOKEN|ENCRYPTION|PASSWORD|PRIVATE|DATABASE_URL/.test(m),
          `${file} reads ${m}, which looks like a secret exposed to the browser`,
        ).toBe(false);
      }
    }
  });

  it('.env.example documents every variable the source actually reads', () => {
    const env = readFileSync(join(ROOT, '.env.example'), 'utf8');
    const used = new Set<string>();
    for (const file of FILES) {
      for (const m of codeOf(file).match(/process\.env\.([A-Z_0-9]+)/g) ?? []) {
        used.add(m.replace('process.env.', ''));
      }
    }
    // NODE_ENV is provided by the runtime, not by the operator.
    used.delete('NODE_ENV');
    for (const name of used) {
      expect(env, `${name} is read by the code but missing from .env.example`).toContain(name);
    }
  });

  it('.env.example declares no variable twice', () => {
    const lines = readFileSync(join(ROOT, '.env.example'), 'utf8')
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('#') && l.includes('='))
      .map((l) => l.split('=')[0]);
    expect(new Set(lines).size, `duplicate keys in .env.example: ${lines}`).toBe(lines.length);
  });
});

describe('secrets are unreachable from client components', () => {
  it('no "use client" file reads a server-only secret', () => {
    for (const file of FILES) {
      if (!isClientFile(file)) continue;
      const code = codeOf(file);
      for (const secret of SECRET_VARS) {
        expect(
          code.includes(`process.env.${secret}`),
          `${file} is a client component but reads ${secret}`,
        ).toBe(false);
      }
    }
  });

  it('the service-role client refuses to run in a browser', () => {
    const code = readFileSync(join(SRC, 'lib/data/supabase-client.ts'), 'utf8');
    const fn = code.slice(code.indexOf('export function getServiceClient'));
    expect(fn.slice(0, 400)).toMatch(/typeof window !== 'undefined'/);
  });

  it('the crypto module is only imported by server-side code', () => {
    for (const file of FILES) {
      if (!isClientFile(file)) continue;
      expect(
        /from '@\/lib\/security\/crypto'/.test(codeOf(file)),
        `${file} is a client component but imports the encryption module`,
      ).toBe(false);
    }
  });
});
