import { describe, it, expect } from 'vitest';
import {
  validateCustomerRow, validateProductRow, importSupported,
  unsupportedReason, displayRow, CUSTOMER_STATUS, PRODUCT_TYPE, DELIVERY_TYPE,
} from '@/lib/services/import';

/** Build a field getter from a plain object, like the importer does. */
const get = (o: Record<string, string>) => (f: string) => o[f] ?? '';

describe('customer row validation', () => {
  it('accepts a good row and maps every field', () => {
    const r = validateCustomerRow(get({
      name: 'Ramesh Kumar', phone: '9876543210', email: 'r@example.com',
      company: 'Acme', city: 'Meerut', state: 'UP', source: 'referral', status: 'Active',
    }), 0);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.name).toBe('Ramesh Kumar');
    expect(r.value.status).toBe('active');       // was previously dropped
    expect(r.value.whatsapp).toBe('9876543210'); // falls back to phone
  });

  it('rejects a missing name with the spreadsheet row number', () => {
    const r = validateCustomerRow(get({ phone: '9876543210' }), 0);
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.issues[0].row).toBe(2); // row 1 is the header
    expect(r.issues[0].field).toBe('name');
  });

  it('rejects a malformed email instead of importing it', () => {
    const r = validateCustomerRow(get({ name: 'A', email: 'not-an-email' }), 3);
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.issues.some((i) => i.field === 'email')).toBe(true);
    expect(r.issues[0].row).toBe(5);
  });

  it('rejects an unknown status rather than silently defaulting', () => {
    const r = validateCustomerRow(get({ name: 'A', status: 'platinum' }), 0);
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.issues[0].message).toMatch(/not one of/);
  });

  it('accepts every declared status, case and spacing insensitive', () => {
    for (const s of CUSTOMER_STATUS) {
      const r = validateCustomerRow(get({ name: 'A', status: s.toUpperCase() }), 0);
      expect(r.ok, s).toBe(true);
    }
  });

  it('reports several problems in one row at once', () => {
    const r = validateCustomerRow(get({ email: 'bad', status: 'nope', phone: '12' }), 0);
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.issues.length).toBeGreaterThanOrEqual(3);
  });

  it('leaves status null when the column is absent', () => {
    const r = validateCustomerRow(get({ name: 'A' }), 0);
    expect(r.ok && r.value.status).toBeUndefined();
  });
});

describe('product row validation', () => {
  it('accepts a good row including both enums', () => {
    const r = validateProductRow(get({
      name: 'Netflix Premium', code: 'NFX-P', brand: 'Netflix',
      product_type: 'Subscription', delivery_type: 'license key',
      duration_days: '30', cost_price: '400', selling_price: '649', stock: '10',
    }), 0);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value.product_type).toBe('subscription');  // previously dropped
    expect(r.value.delivery_type).toBe('license_key');  // space-insensitive; previously dropped
    expect(r.value.selling_price).toBe(649);
  });

  it('rejects a non-numeric price instead of importing zero', () => {
    // The old importer used Number(x) || 0 -> a typo became a free product.
    const r = validateProductRow(get({
      name: 'X', code: 'X1', selling_price: 'six hundred',
    }), 0);
    expect(r.ok).toBe(false);
    if (r.ok) return;
    expect(r.issues.some((i) => i.field === 'selling_price')).toBe(true);
  });

  it('rejects a negative price', () => {
    const r = validateProductRow(get({ name: 'X', code: 'X1', cost_price: '-5' }), 0);
    expect(r.ok).toBe(false);
  });

  it('rejects fractional duration and stock', () => {
    const a = validateProductRow(get({ name: 'X', code: 'X1', duration_days: '30.5' }), 0);
    expect(a.ok).toBe(false);
    const b = validateProductRow(get({ name: 'X', code: 'X1', stock: '2.5' }), 0);
    expect(b.ok).toBe(false);
  });

  it('strips currency formatting', () => {
    const r = validateProductRow(get({
      name: 'X', code: 'X1', selling_price: '₹1,299',
    }), 0);
    expect(r.ok && r.value.selling_price).toBe(1299);
  });

  it('requires both name and code', () => {
    const r = validateProductRow(get({ brand: 'Y' }), 0);
    expect(r.ok).toBe(false);
    if (r.ok) return;
    const fields = r.issues.map((i) => i.field);
    expect(fields).toContain('name');
    expect(fields).toContain('code');
  });

  it('accepts every declared product and delivery type', () => {
    for (const t of PRODUCT_TYPE) {
      expect(validateProductRow(get({ name: 'X', code: 'X1', product_type: t }), 0).ok, t).toBe(true);
    }
    for (const d of DELIVERY_TYPE) {
      expect(validateProductRow(get({ name: 'X', code: 'X1', delivery_type: d }), 0).ok, d).toBe(true);
    }
  });

  it('treats an empty numeric cell as zero, not an error', () => {
    const r = validateProductRow(get({ name: 'X', code: 'X1', cost_price: '' }), 0);
    expect(r.ok && r.value.cost_price).toBe(0);
  });
});

describe('unsupported entities are clearly disabled', () => {
  it('orders and subscriptions are refused with a reason', () => {
    expect(importSupported('orders')).toBe(false);
    expect(importSupported('subscriptions')).toBe(false);
    expect(unsupportedReason('orders')).toMatch(/not available/i);
  });

  it('supported entities pass through', () => {
    for (const e of ['customers', 'products', 'suppliers']) {
      expect(importSupported(e)).toBe(true);
    }
  });
});

describe('row numbering', () => {
  it('maps a zero-based index to a spreadsheet row', () => {
    expect(displayRow(0)).toBe(2);
    expect(displayRow(41)).toBe(43);
  });
});
