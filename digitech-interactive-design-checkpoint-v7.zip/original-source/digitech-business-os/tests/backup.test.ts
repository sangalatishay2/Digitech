import { describe, it, expect } from 'vitest';
import { validateBackup, buildBackup, migrateBackup, BACKUP_FORMAT_VERSION } from '@/lib/services/backup';
import { buildSeed } from '@/lib/data/seed';

describe('backup validation', () => {
  it('accepts a genuine export round-trip', () => {
    const db = buildSeed();
    const res = validateBackup(JSON.parse(buildBackup(db)));
    expect(res.ok).toBe(true);
    expect(res.errors).toEqual([]);
    expect(res.counts.customers).toBe(db.customers.length);
  });

  it('rejects a file missing whole tables (the old check passed these)', () => {
    const res = validateBackup({ organizations: [{ id: 'o' }], customers: [] });
    expect(res.ok).toBe(false);
    expect(res.errors.join(' ')).toMatch(/orders|products|payments/);
  });

  it('rejects non-objects and empty payloads', () => {
    expect(validateBackup(null).ok).toBe(false);
    expect(validateBackup('nope').ok).toBe(false);
    expect(validateBackup({}).ok).toBe(false);
  });

  it('rejects a backup with no organization', () => {
    const db = buildSeed();
    const bad = { ...JSON.parse(buildBackup(db)), organizations: [] };
    expect(validateBackup(bad).ok).toBe(false);
  });

  it('rejects cross-organization contamination', () => {
    const db = buildSeed();
    const raw = JSON.parse(buildBackup(db));
    raw.customers[0].organization_id = 'some-other-org';
    const res = validateBackup(raw);
    expect(res.ok).toBe(false);
    expect(res.errors.join(' ')).toMatch(/organization not in the backup/);
  });

  it('rejects dangling references on the money path', () => {
    const db = buildSeed();
    const raw = JSON.parse(buildBackup(db));
    raw.orders[0].customer_id = 'ghost';
    expect(validateBackup(raw).errors.join(' ')).toMatch(/missing customer/);
  });

  it('rejects duplicate primary keys', () => {
    const db = buildSeed();
    const raw = JSON.parse(buildBackup(db));
    raw.customers.push({ ...raw.customers[0] });
    expect(validateBackup(raw).errors.join(' ')).toMatch(/duplicate ids/);
  });

  it('refuses a backup from a newer app version', () => {
    const db = buildSeed();
    const raw = { ...JSON.parse(buildBackup(db)), __format_version: BACKUP_FORMAT_VERSION + 5 };
    expect(validateBackup(raw).ok).toBe(false);
  });

  it('migrates a v1 backup forward', () => {
    const db = buildSeed();
    const raw = JSON.parse(buildBackup(db));
    delete raw.__format_version;
    for (const p of raw.products) delete p.reserved_stock;
    const migrated = migrateBackup(raw);
    expect(migrated.__format_version).toBe(BACKUP_FORMAT_VERSION);
    expect(validateBackup(migrated).ok).toBe(true);
  });
});
