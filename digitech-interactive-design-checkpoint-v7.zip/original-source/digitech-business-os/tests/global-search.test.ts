import { describe, expect, it } from 'vitest';
import { emptyDb } from '@/lib/data/seed';
import { globalSearch } from '@/components/shell/search';
import type { Activation, Customer, Payment, Product, Task } from '@/lib/types';

const ORG = '00000000-0000-4000-8000-000000000001';
const stamp = '2026-09-02T10:00:00.000Z';
const base = { organization_id: ORG, created_at: stamp, updated_at: stamp, deleted_at: null };

function fixture() {
  const db = emptyDb();
  db.customers = [{
    ...base, id: 'c1', customer_code: 'DT-1001', name: 'Canva', phone: '+91 98765 43210',
    email: 'canva.customer@example.com', status: 'active', tags: [],
  } as Customer];
  db.products = [{
    ...base, id: 'p1', name: 'Canva Pro Annual', code: 'CANVA-12M', brand: 'Canva',
    product_type: 'subscription', delivery_type: 'email_activation', duration_days: 365,
    cost_price: 500, selling_price: 1299, supplier_id: null, stock: null, low_stock_threshold: 5, is_active: true,
  } as Product];
  db.tasks = [{
    ...base, id: 't1', title: 'Verify Canva renewal', description: 'Call customer', entity_type: 'customer',
    entity_id: 'c1', priority: 'high', status: 'open', assigned_to: null,
  } as Task];
  db.payments = [{
    ...base, id: 'pay1', order_id: 'order-1', customer_id: 'c1', amount: 1299, method: 'upi',
    status: 'paid', reference: 'UTR-778899', is_refund: false, paid_at: stamp,
  } as Payment];
  db.activations = [{
    ...base, id: 'a1', order_id: 'order-1', order_item_id: 'item-1', customer_id: 'c1',
    product_name: 'Adobe CC', status: 'ready', priority: 'medium', activation_details: 'TOP-SECRET-CREDENTIAL',
  } as Activation];
  return db;
}

describe('global business search', () => {
  it('ranks an exact business name above partial matches', () => {
    const results = globalSearch(fixture(), 'Canva');
    expect(results[0]).toMatchObject({ type: 'Customer', title: 'Canva' });
    expect(results.map((result) => result.type)).toEqual(expect.arrayContaining(['Product', 'Task']));
  });

  it('finds normalized phone numbers and payment references', () => {
    expect(globalSearch(fixture(), '543210')[0]).toMatchObject({ type: 'Customer' });
    expect(globalSearch(fixture(), 'UTR-778899')[0]).toMatchObject({ type: 'Payment' });
  });

  it('applies permissions before returning results', () => {
    const results = globalSearch(fixture(), 'Canva', 20, (action) => action === 'tasks.read');
    expect(results).toHaveLength(1);
    expect(results[0].type).toBe('Task');
  });

  it('never indexes activation secret fields', () => {
    expect(globalSearch(fixture(), 'TOP-SECRET-CREDENTIAL')).toEqual([]);
  });
});
