import { describe, it, expect } from 'vitest';
import { recalcOrderPayments } from '@/lib/services/business';
import type { Order, Payment } from '@/lib/types';

const ORG = 'org-1';
const baseOrder = (): Order =>
  ({
    id: 'o1', organization_id: ORG, total: 1000, amount_paid: 0, amount_refunded: 0,
    outstanding: 1000, payment_status: 'pending', status: 'new',
  } as unknown as Order);

const pay = (amount: number, is_refund = false): Payment =>
  ({ id: Math.random().toString(), order_id: 'o1', amount, is_refund } as unknown as Payment);

describe('payment / refund matrix', () => {
  it('unpaid order: full amount outstanding', () => {
    const r = recalcOrderPayments(baseOrder(), []);
    expect(r.amount_paid).toBe(0);
    expect(r.outstanding).toBe(1000);
    expect(r.payment_status).toBe('pending');
  });

  it('partial payment', () => {
    const r = recalcOrderPayments(baseOrder(), [pay(400)]);
    expect(r.amount_paid).toBe(400);
    expect(r.outstanding).toBe(600);
    expect(r.payment_status).toBe('partial');
  });

  it('fully paid order has zero outstanding', () => {
    const r = recalcOrderPayments(baseOrder(), [pay(1000)]);
    expect(r.outstanding).toBe(0);
    expect(r.payment_status).toBe('paid');
  });

  it('FULL REFUND must not resurrect a receivable', () => {
    const r = recalcOrderPayments(baseOrder(), [pay(1000), pay(1000, true)]);
    expect(r.amount_paid).toBe(1000);
    expect(r.amount_refunded).toBe(1000);
    expect(r.payment_status).toBe('refunded');
    // The money was collected then returned. Nothing is owed by the customer.
    expect(r.outstanding).toBe(0);
  });

  it('partial refund leaves no phantom receivable', () => {
    // paid 1000 then refunded 300 => customer keeps 700 of value, owes nothing
    const r = recalcOrderPayments(baseOrder(), [pay(1000), pay(300, true)]);
    expect(r.payment_status).toBe('partially_refunded');
    expect(r.outstanding).toBe(0);
  });

  it('partial payment then refunded: billable base shrinks by the refund', () => {
    // total 1000, collected 400, refunded 400.
    // The 400 of value was returned, so billable = 1000-400 = 600 and the
    // customer has effectively paid nothing toward it => still owes 600.
    const r = recalcOrderPayments(baseOrder(), [pay(400), pay(400, true)]);
    expect(r.amount_paid).toBe(400);
    expect(r.amount_refunded).toBe(400);
    expect(r.outstanding).toBe(600);
    expect(r.payment_status).toBe('refunded');
  });

  it('overpayment is never represented as negative due', () => {
    const r = recalcOrderPayments(baseOrder(), [pay(1500)]);
    expect(r.outstanding).toBe(0);
    expect(r.payment_status).toBe('paid');
  });

  it('collected is gross and is not reduced by refunds', () => {
    const r = recalcOrderPayments(baseOrder(), [pay(1000), pay(250, true)]);
    expect(r.amount_paid).toBe(1000);
    expect(r.amount_refunded).toBe(250);
  });
});
