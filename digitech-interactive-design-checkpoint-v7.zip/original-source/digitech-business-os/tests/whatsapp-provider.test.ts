import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

/**
 * P2 #20: the old adapter reported itself "configured" from a *public* env flag
 * while send() always failed, so the UI advertised a working integration that
 * silently dropped every message. These tests pin the two properties that
 * prevent that class of dishonesty:
 *   - availability comes from the server, never from a NEXT_PUBLIC_ flag;
 *   - a failed send is reported as failed.
 */

let sessionOk = true;
let sessionRole = 'admin';
let customerRows: Array<{ id: string; organization_id: string }> = [];
const inserted: Array<Record<string, unknown>> = [];

vi.mock('@/lib/auth/server-session', async () => {
  const actual = await vi.importActual<Record<string, unknown>>('@/lib/auth/server-session');
  return {
    ...actual,
    sessionFromRequest: async () =>
      sessionOk
        ? {
            ok: true,
            session: {
              userId: 'u1',
              email: 'a@b.c',
              accessToken: 't',
              organizationId: 'org-a',
              role: sessionRole,
              profile: {
                id: 'p1',
                organization_id: 'org-a',
                role: sessionRole,
                is_active: true,
                deleted_at: null,
              },
            },
          }
        : { ok: false, status: 401, reason: 'Missing bearer token.' },
    sessionErrorResponse: (o: { status: number; reason: string }) =>
      new Response(JSON.stringify({ error: o.reason }), { status: o.status }),
  };
});

vi.mock('@/lib/data/supabase-client', () => ({
  getServiceClient: () => ({
    from: (table: string) => {
      const api = {
        select: () => api,
        eq: () => api,
        limit: async () => ({ data: customerRows, error: null }),
        insert: async (row: Record<string, unknown>) => {
          inserted.push({ table, ...row });
          return { data: null, error: null };
        },
      };
      return api;
    },
  }),
}));

const route = await import('@/app/api/messaging/whatsapp/route');

function post(body: unknown) {
  return new Request('https://x.test/api/messaging/whatsapp', {
    method: 'POST',
    headers: { authorization: 'Bearer t', 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
}

const ORIG = { ...process.env };

beforeEach(() => {
  sessionOk = true;
  sessionRole = 'admin';
  customerRows = [{ id: 'c1', organization_id: 'org-a' }];
  inserted.length = 0;
  process.env.WHATSAPP_ACCESS_TOKEN = 'secret-token';
  process.env.WHATSAPP_PHONE_NUMBER_ID = '123';
  vi.stubGlobal(
    'fetch',
    vi.fn(async () => ({
      ok: true,
      status: 200,
      json: async () => ({ messages: [{ id: 'wamid.123' }] }),
    })),
  );
});

afterEach(() => {
  process.env = { ...ORIG };
  vi.unstubAllGlobals();
});

describe('availability is server-derived, not a public flag', () => {
  it('reports configured when server credentials exist', async () => {
    const res = await route.GET(post({}));
    expect(await res.json()).toEqual({ configured: true });
  });

  it('reports unconfigured when the token is absent', async () => {
    delete process.env.WHATSAPP_ACCESS_TOKEN;
    const res = await route.GET(post({}));
    expect(await res.json()).toEqual({ configured: false });
  });

  it('requires the phone number id as well as the token', async () => {
    delete process.env.WHATSAPP_PHONE_NUMBER_ID;
    expect(route.cloudApiConfigured()).toBe(false);
  });

  it('never exposes the access token in a response', async () => {
    const res = await route.GET(post({}));
    expect(JSON.stringify(await res.json())).not.toContain('secret-token');
  });

  it('requires a session even to check availability', async () => {
    sessionOk = false;
    expect((await route.GET(post({}))).status).toBe(401);
  });
});

describe('send authorization', () => {
  it('rejects an unauthenticated send', async () => {
    sessionOk = false;
    expect((await route.POST(post({ to: '919812345678', body: 'hi' }))).status).toBe(401);
  });

  it('rejects a role without customer write permission', async () => {
    sessionRole = 'viewer';
    expect((await route.POST(post({ to: '919812345678', body: 'hi' }))).status).toBe(403);
  });

  it('refuses to send when not configured, rather than reporting success', async () => {
    delete process.env.WHATSAPP_ACCESS_TOKEN;
    const res = await route.POST(post({ to: '919812345678', body: 'hi' }));
    expect(res.status).toBe(503);
    expect((await res.json()).error).toMatch(/not configured/i);
  });
});

describe('send validation', () => {
  it('rejects an empty body', async () => {
    expect((await route.POST(post({ to: '919812345678', body: '  ' }))).status).toBe(400);
  });

  it('rejects an over-long body', async () => {
    const res = await route.POST(post({ to: '919812345678', body: 'x'.repeat(5000) }));
    expect(res.status).toBe(400);
  });

  it('rejects an implausible phone number', async () => {
    expect((await route.POST(post({ to: '12', body: 'hi' }))).status).toBe(400);
  });

  it('rejects malformed JSON', async () => {
    const req = new Request('https://x.test/api/messaging/whatsapp', {
      method: 'POST',
      headers: { authorization: 'Bearer t' },
      body: 'not json',
    });
    expect((await route.POST(req)).status).toBe(400);
  });

  it('refuses to message a customer in another organization', async () => {
    customerRows = [{ id: 'c1', organization_id: 'org-b' }];
    const res = await route.POST(post({ to: '919812345678', body: 'hi', customer_id: 'c1' }));
    expect(res.status).toBe(404);
  });
});

describe('send outcome', () => {
  it('returns the provider message id on success', async () => {
    const res = await route.POST(post({ to: '91 98123-45678', body: 'hello' }));
    expect(res.status).toBe(200);
    expect(await res.json()).toMatchObject({ status: 'sent', providerMessageId: 'wamid.123' });
  });

  it('reports a provider rejection as failed instead of swallowing it', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => ({
        ok: false,
        status: 400,
        json: async () => ({ error: { message: 'Recipient not opted in' } }),
      })),
    );
    const res = await route.POST(post({ to: '919812345678', body: 'hi' }));
    expect(res.status).toBe(502);
    expect((await res.json()).error).toMatch(/opted in/);
  });

  it('reports a network failure as failed', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        throw new Error('ECONNREFUSED');
      }),
    );
    const res = await route.POST(post({ to: '919812345678', body: 'hi' }));
    expect(res.status).toBe(502);
  });

  it('logs failed sends, not just successful ones', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => ({ ok: false, status: 500, json: async () => ({}) })),
    );
    await route.POST(post({ to: '919812345678', body: 'hi' }));
    expect(inserted.some((r) => r.action === 'whatsapp_failed')).toBe(true);
  });

  it('records the send in the audit trail without storing the message body', async () => {
    await route.POST(post({ to: '919812345678', body: 'confidential renewal terms' }));
    const entry = inserted.find((r) => r.action === 'whatsapp_sent');
    expect(entry).toBeTruthy();
    expect(JSON.stringify(entry)).not.toContain('confidential renewal terms');
  });
});
