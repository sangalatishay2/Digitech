import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import {
  encryptSecret,
  decryptSecret,
  encryptActivationFields,
  decryptActivationFields,
  redactActivationFields,
  ENCRYPTED_ACTIVATION_FIELDS,
  encryptionAvailable,
} from '@/lib/security/crypto';

const KEY = Buffer.alloc(32, 7).toString('base64');
let previous: string | undefined;

beforeAll(() => {
  previous = process.env.ACTIVATION_ENCRYPTION_KEY;
  process.env.ACTIVATION_ENCRYPTION_KEY = KEY;
});
afterAll(() => {
  process.env.ACTIVATION_ENCRYPTION_KEY = previous;
});

describe('envelope encryption', () => {
  it('reports availability when a key is configured', () => {
    expect(encryptionAvailable()).toBe(true);
  });

  it('round-trips a secret', () => {
    const secret = 'Sup3r$ecret-Password!';
    expect(decryptSecret(encryptSecret(secret))).toBe(secret);
  });

  it('round-trips unicode and long values', () => {
    const secret = 'पासवर्ड-🔐-' + 'x'.repeat(2000);
    expect(decryptSecret(encryptSecret(secret))).toBe(secret);
  });

  it('never emits the plaintext inside the ciphertext', () => {
    const secret = 'NEEDLE-abc123';
    expect(encryptSecret(secret)).not.toContain(secret);
  });

  it('uses the versioned enc:v1 envelope', () => {
    expect(encryptSecret('x')).toMatch(/^enc:v1:[^:]+:[^:]+:/);
  });

  it('produces a different ciphertext each time (random IV)', () => {
    expect(encryptSecret('same')).not.toBe(encryptSecret('same'));
  });

  it('detects tampering via the GCM auth tag', () => {
    const ct = encryptSecret('trusted-value');
    const parts = ct.split(':');
    const body = Buffer.from(parts[4], 'base64');
    body[0] ^= 0xff;
    parts[4] = body.toString('base64');
    expect(() => decryptSecret(parts.join(':'))).toThrow();
  });

  it('rejects a ciphertext re-labelled with a different version', () => {
    const ct = encryptSecret('v').replace('enc:v1:', 'enc:v9:');
    expect(() => decryptSecret(ct)).toThrow();
  });

  it('passes through empty values unchanged', () => {
    expect(encryptSecret('')).toBe('');
    expect(decryptSecret('')).toBe('');
  });

  it('cannot decrypt with a different key', () => {
    const ct = encryptSecret('locked');
    const original = process.env.ACTIVATION_ENCRYPTION_KEY;
    process.env.ACTIVATION_ENCRYPTION_KEY = Buffer.alloc(32, 9).toString('base64');
    expect(() => decryptSecret(ct)).toThrow();
    process.env.ACTIVATION_ENCRYPTION_KEY = original;
  });
});

describe('activation field helpers', () => {
  const plain = {
    id: 'a1',
    organization_id: 'org-a',
    activation_email: 'user@vendor.com',
    activation_password: 'hunter2',
    activation_details: 'license XYZ',
    internal_instructions: 'call vendor first',
    status: 'completed',
  };

  it('encrypts every declared secret field and nothing else', () => {
    const enc = encryptActivationFields(plain);
    for (const f of ENCRYPTED_ACTIVATION_FIELDS) {
      expect(String(enc[f])).toMatch(/^enc:v1:/);
    }
    expect(enc.id).toBe('a1');
    expect(enc.status).toBe('completed');
  });

  it('round-trips the whole record', () => {
    expect(decryptActivationFields(encryptActivationFields(plain))).toMatchObject(plain);
  });

  it('redaction removes secrets entirely rather than masking in place', () => {
    const red = redactActivationFields(plain);
    const serialized = JSON.stringify(red);
    expect(serialized).not.toContain('hunter2');
    expect(serialized).not.toContain('user@vendor.com');
    expect(serialized).not.toContain('call vendor first');
    expect(red.id).toBe('a1');
  });

  it('handles records where secret fields are absent or null', () => {
    const sparse = { id: 'a2', organization_id: 'org-a', activation_password: null };
    expect(() => encryptActivationFields(sparse)).not.toThrow();
    expect(() => redactActivationFields(sparse)).not.toThrow();
  });
});

describe('missing key is a hard failure, never a silent passthrough', () => {
  it('throws instead of storing plaintext when the key is absent', () => {
    const original = process.env.ACTIVATION_ENCRYPTION_KEY;
    delete process.env.ACTIVATION_ENCRYPTION_KEY;
    expect(encryptionAvailable()).toBe(false);
    expect(() => encryptSecret('would-be-plaintext')).toThrow();
    process.env.ACTIVATION_ENCRYPTION_KEY = original;
  });
});
