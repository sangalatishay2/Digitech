import { describe, it, expect } from 'vitest';
import { canTransition, ORDER_TRANSITIONS, TERMINAL_ORDER_STATUSES } from '@/lib/services/business';
import type { OrderStatus } from '@/lib/types';

const ALL: OrderStatus[] = ['new','awaiting_payment','paid','processing','activation_pending','activated','delivered','completed','cancelled','refunded'];

describe('order state machine', () => {
  it('terminal states permit no onward transition', () => {
    for (const t of TERMINAL_ORDER_STATUSES) {
      expect(ORDER_TRANSITIONS[t]).toEqual([]);
      for (const to of ALL) {
        if (to === t) continue;
        expect(canTransition(t, to)).toBe(false);
      }
    }
  });

  it('a status can always "transition" to itself (no-op)', () => {
    for (const s of ALL) expect(canTransition(s, s)).toBe(true);
  });

  it('rejects nonsense jumps', () => {
    expect(canTransition('new', 'delivered')).toBe(false);
    expect(canTransition('new', 'completed')).toBe(false);
    expect(canTransition('awaiting_payment', 'activated')).toBe(false);
    expect(canTransition('cancelled', 'paid')).toBe(false);
    expect(canTransition('refunded', 'completed')).toBe(false);
  });

  it('allows the documented happy path end to end', () => {
    const path: OrderStatus[] = ['new','awaiting_payment','paid','processing','activation_pending','activated','delivered','completed'];
    for (let i = 0; i < path.length - 1; i++) {
      expect(canTransition(path[i], path[i + 1])).toBe(true);
    }
  });

  it('every state maps to a defined transition list', () => {
    for (const s of ALL) expect(Array.isArray(ORDER_TRANSITIONS[s])).toBe(true);
  });

  it('cancellation is reachable from all pre-fulfilment states', () => {
    for (const s of ['new','awaiting_payment','paid','processing','activation_pending'] as OrderStatus[]) {
      expect(canTransition(s, 'cancelled')).toBe(true);
    }
  });
});
