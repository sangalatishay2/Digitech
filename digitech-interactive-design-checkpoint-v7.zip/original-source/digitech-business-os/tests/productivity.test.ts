import { describe, expect, it } from 'vitest';
import { emptyDb } from '@/lib/data/seed';
import { buildCustomerNextActions, buildProductivityQueue, productivitySummary } from '@/lib/services/productivity';
import type { Customer, Database, Lead, Order, Subscription, Task } from '@/lib/types';

const ORG = '00000000-0000-4000-8000-000000000001';
const NOW = new Date('2026-09-02T10:00:00.000Z');
const base = { organization_id: ORG, created_at: NOW.toISOString(), updated_at: NOW.toISOString(), deleted_at: null };

function fixture(): Database {
  const db = emptyDb();
  db.profiles = [{ ...base, id: 'user-1', auth_user_id: null, full_name: 'Atishay', email: 'a@d.test', role: 'owner', is_active: true }];
  db.customers = [{ ...base, id: 'customer-1', customer_code: 'DT-1001', name: 'Rahul Sharma', status: 'active', tags: [] } as Customer];
  db.tasks = [{
    ...base, id: 'task-1', title: 'Call customer', entity_type: 'customer', entity_id: 'customer-1', priority: 'urgent',
    status: 'open', assigned_to: 'user-1', due_at: '2026-09-01T09:00:00.000Z',
  } as Task];
  db.leads = [{
    ...base, id: 'lead-1', name: 'Priya', value: 25_000, probability: 60, status: 'follow_up',
    assigned_to: 'user-1', follow_up_at: '2026-09-02T12:00:00.000Z',
  } as Lead];
  db.subscriptions = [{
    ...base, id: 'sub-1', customer_id: 'customer-1', product_id: null, order_id: 'order-1',
    product_name: 'Canva Pro', start_date: '2025-09-05T00:00:00.000Z', expiry_date: '2026-09-05T00:00:00.000Z',
    duration_days: 365, purchase_amount: 1299, cost_amount: 500, profit: 799, supplier_id: null,
    status: 'expiring', reminder_state: 'none', assigned_to: null,
  } as Subscription];
  db.orders = [{
    ...base, id: 'order-1', order_number: 'ORD-1001', customer_id: 'customer-1', status: 'awaiting_payment',
    payment_status: 'partial', subtotal: 15_000, discount: 0, tax: 0, total: 15_000, total_cost: 10_000,
    profit: 5_000, margin: 33.33, amount_paid: 2_000, amount_refunded: 0, outstanding: 13_000,
    assigned_to: null, ordered_at: '2026-09-01T00:00:00.000Z', items: [],
  } as Order];
  return db;
}

describe('Today productivity queue', () => {
  it('combines cross-module work and ranks critical overdue work first', () => {
    const items = buildProductivityQueue(fixture(), { now: NOW, userId: 'user-1' });
    expect(items.map((item) => item.kind)).toEqual(expect.arrayContaining(['task', 'lead', 'renewal', 'payment']));
    expect(items[0]).toMatchObject({ kind: 'task', severity: 'critical' });
  });

  it('never includes modules denied by the caller RBAC predicate', () => {
    const items = buildProductivityQueue(fixture(), {
      now: NOW,
      can: (action) => action === 'tasks.read',
    });
    expect(items).toHaveLength(1);
    expect(items[0].kind).toBe('task');
  });

  it('summarizes assigned and unassigned work', () => {
    const items = buildProductivityQueue(fixture(), { now: NOW, userId: 'user-1' });
    expect(productivitySummary(items, 'user-1')).toMatchObject({ total: 4, mine: 2, unassigned: 2, critical: 1 });
  });

  it('excludes completed tasks and distant renewals', () => {
    const db = fixture();
    db.tasks[0].status = 'done';
    db.subscriptions[0].expiry_date = '2026-12-01T00:00:00.000Z';
    const items = buildProductivityQueue(db, { now: NOW });
    expect(items.some((item) => item.kind === 'task')).toBe(false);
    expect(items.some((item) => item.kind === 'renewal')).toBe(false);
  });
});

describe('Customer next best actions', () => {
  it('prioritizes money collection and time-sensitive renewals', () => {
    const actions = buildCustomerNextActions(fixture(), 'customer-1', { now: NOW });
    expect(actions[0]).toMatchObject({ id: 'payment-order-1', severity: 'critical' });
    expect(actions.map((action) => action.id)).toEqual(expect.arrayContaining(['renewal-sub-1', 'task-task-1']));
  });

  it('does not recommend records the user cannot read', () => {
    const actions = buildCustomerNextActions(fixture(), 'customer-1', {
      now: NOW,
      can: (action) => action === 'tasks.read',
    });
    expect(actions).toHaveLength(1);
    expect(actions[0].id).toBe('task-task-1');
  });

  it('recommends a first order for a customer with no purchase history', () => {
    const db = fixture();
    db.orders = [];
    db.subscriptions = [];
    db.tasks = [];
    const actions = buildCustomerNextActions(db, 'customer-1', { now: NOW });
    expect(actions).toEqual([expect.objectContaining({ id: 'first-order-customer-1', actionLabel: 'Create order' })]);
  });
});
