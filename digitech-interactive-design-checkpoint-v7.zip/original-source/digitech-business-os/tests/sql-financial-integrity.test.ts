import { describe, it, expect, beforeAll, beforeEach } from 'vitest';
import type { PGlite } from '@electric-sql/pglite';
import { bootDatabase, actAs } from './helpers/pg';

/**
 * Financial integrity enforced by the DATABASE (migration 0015), executed
 * against real Postgres. The TypeScript ledger is covered by
 * tests/refund-matrix.test.ts; these prove the SQL agrees with it.
 */
const ORG = 'aaaaaaaa-0000-4000-8000-000000000001';
const CUST = 'c0000000-0000-4000-8000-00000000000a';
const OWNER = '10000000-0000-4000-8000-000000000001';
const ORDER = 'd0000000-0000-4000-8000-00000000000a';

let db: PGlite;

async function fails(sql: string, params: unknown[] = []) {
  try { await db.query(sql, params as never[]); return false; } catch { return true; }
}
const money = (v: unknown) => Number(v);

async function ledger() {
  const r = await db.query<{ amount_paid: string; outstanding: string; payment_status: string }>(
    `select amount_paid, outstanding, payment_status from orders where id=$1`, [ORDER],
  );
  return {
    paid: money(r.rows[0].amount_paid),
    outstanding: money(r.rows[0].outstanding),
    status: r.rows[0].payment_status,
  };
}

async function pay(amount: number, isRefund = false) {
  await db.query(
    `insert into payments (organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
     values ($1,$2,$3,$4,'upi',$5,$6,now())`,
    [ORG, ORDER, CUST, amount, isRefund ? 'refunded' : 'paid', isRefund],
  );
}

beforeAll(async () => {
  db = (await bootDatabase()).db;
  await db.exec(`delete from payments; delete from order_items; delete from orders;
                 delete from invoices; delete from customers; delete from profiles; delete from organizations;
                 delete from auth.users;`);
  await db.query(`insert into auth.users (id,email) values ($1,'owner@test.local')`, [OWNER]);
  await db.query(`insert into organizations (id,name,currency,timezone) values ($1,'Org A','INR','Asia/Kolkata')`, [ORG]);
  await db.query(
    `insert into profiles (organization_id, auth_user_id, full_name, email, role, is_active)
     values ($1,$2,'Owner','owner@test.local','owner',true)`, [ORG, OWNER]);
  await db.query(
    `insert into customers (id,organization_id,customer_code,name,phone) values ($1,$2,'DT-1','A','9000000001')`,
    [CUST, ORG]);
  await db.exec(`set session role authenticated;`);
  await actAs(db, OWNER);
}, 180_000);

beforeEach(async () => {
  await db.query(`delete from payments where order_id=$1`, [ORDER]);
  await db.query(`delete from orders where id=$1`, [ORDER]);
  await db.query(
    `insert into orders (id, organization_id, order_number, customer_id, status, payment_status,
                         subtotal, discount, tax, total, ordered_at)
     values ($1,$2,'ORD-9001',$3,'new','pending',1000,0,0,1000,now())`, [ORDER, ORG, CUST]);
});

describe('payment ledger in SQL', () => {
  it('an unpaid order owes the full total', async () => {
    const l = await ledger();
    expect(l.paid).toBe(0);
    expect(l.outstanding).toBe(1000);
    expect(l.status).toBe('pending');
  });

  it('a partial payment reduces outstanding', async () => {
    await pay(400);
    const l = await ledger();
    expect(l.paid).toBe(400);
    expect(l.outstanding).toBe(600);
    expect(l.status).toBe('partial');
  });

  it('full payment clears the balance', async () => {
    await pay(1000);
    const l = await ledger();
    expect(l.outstanding).toBe(0);
    expect(l.status).toBe('paid');
  });

  it('rejects an overpayment', async () => {
    await pay(1000);
    expect(await fails(
      `insert into payments (organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
       values ($1,$2,$3,1,'upi','paid',false,now())`, [ORG, ORDER, CUST],
    )).toBe(true);
  });

  it('a FULLY refunded order shows no phantom receivable', async () => {
    await pay(1000);
    await pay(1000, true);
    const l = await ledger();
    expect(l.outstanding).toBe(0);   // must NOT become a receivable again
    expect(l.status).toBe('refunded');
  });

  it('a partial refund does not resurrect a receivable', async () => {
    await pay(1000);
    await pay(300, true);
    const l = await ledger();
    expect(l.outstanding).toBe(0);
    expect(l.status).toBe('partially_refunded');
  });

  it('partial payment then refund of that payment leaves the unbilled remainder', async () => {
    await pay(400);
    await pay(400, true);
    const l = await ledger();
    // billable = total - refunded = 600; net collected = 0
    expect(l.outstanding).toBe(600);
  });

  it('rejects a refund larger than what was collected', async () => {
    await pay(400);
    expect(await fails(
      `insert into payments (organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
       values ($1,$2,$3,500,'upi','refunded',true,now())`, [ORG, ORDER, CUST],
    )).toBe(true);
  });

  it('rejects a non-positive payment', async () => {
    expect(await fails(
      `insert into payments (organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
       values ($1,$2,$3,0,'upi','paid',false,now())`, [ORG, ORDER, CUST],
    )).toBe(true);
  });
});

describe('payment/order linkage integrity', () => {
  it('payment.order_id cannot be moved to another order', async () => {
    await pay(500);
    const other = 'd0000000-0000-4000-8000-00000000000b';
    await db.query(
      `insert into orders (id, organization_id, order_number, customer_id, status, payment_status,
                           subtotal, discount, tax, total, ordered_at)
       values ($1,$2,'ORD-9002',$3,'new','pending',500,0,0,500,now())`, [other, ORG, CUST]);
    expect(await fails(`update payments set order_id=$1 where order_id=$2`, [other, ORDER])).toBe(true);
    await db.query(`delete from orders where id=$1`, [other]);
  });

  it('deleting a payment restores the receivable', async () => {
    await pay(1000);
    expect((await ledger()).outstanding).toBe(0);
    await db.query(`delete from payments where order_id=$1`, [ORDER]);
    expect((await ledger()).outstanding).toBe(1000);
  });

  it('a payment whose org differs from its order is rejected', async () => {
    const orgB = 'bbbbbbbb-0000-4000-8000-000000000002';
    await db.exec(`set session role none;`);
    await db.query(`insert into organizations (id,name,currency,timezone)
                    values ($1,'Org B','INR','Asia/Kolkata') on conflict do nothing`, [orgB]);
    await db.exec(`set session role authenticated;`);
    expect(await fails(
      `insert into payments (organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
       values ($1,$2,$3,10,'upi','paid',false,now())`, [orgB, ORDER, CUST],
    )).toBe(true);
  });
});

describe('invoice reconciliation in SQL', () => {
  it('an invoice created BEFORE payment syncs once paid', async () => {
    await db.query(
      `insert into invoices (organization_id, invoice_number, customer_id, order_id, subtotal, total, status)
       values ($1,'INV-501',$2,$3,1000,1000,'sent')`, [ORG, CUST, ORDER]);
    await pay(1000);
    const r = await db.query<{ amount_paid: string; status: string }>(
      `select amount_paid, status from invoices where order_id=$1`, [ORDER]);
    expect(money(r.rows[0].amount_paid)).toBe(1000);
    expect(r.rows[0].status).toBe('paid');
    await db.query(`delete from invoices where order_id=$1`, [ORDER]);
  });

  it('a void invoice is never resurrected by a payment', async () => {
    await db.query(
      `insert into invoices (organization_id, invoice_number, customer_id, order_id, subtotal, total, status)
       values ($1,'INV-502',$2,$3,1000,1000,'void')`, [ORG, CUST, ORDER]);
    await pay(1000);
    const r = await db.query<{ status: string }>(`select status from invoices where order_id=$1`, [ORDER]);
    expect(r.rows[0].status).toBe('void');
    await db.query(`delete from invoices where order_id=$1`, [ORDER]);
  });
});
