import { describe, it, expect, vi, beforeEach } from 'vitest';

/**
 * Session resolution is the gate every server mutation sits behind, so the
 * cases that matter are the *denials*: a disabled or deleted profile must never
 * be able to act, no matter how valid its token is.
 */

let currentUser: { id: string; email?: string } | null = null;
let profileRows: Record<string, unknown>[] = [];
let profileError: { message: string } | null = null;

vi.mock('@/lib/data/supabase-client', () => ({
  getRequestClient: () => ({
    auth: {
      getUser: async () =>
        currentUser
          ? { data: { user: currentUser }, error: null }
          : { data: { user: null }, error: { message: 'bad token' } },
    },
  }),
  getServiceClient: () => ({
    from: () => {
      const api = {
        select: () => api,
        eq: () => api,
        limit: async () => ({ data: profileRows, error: profileError }),
      };
      return api;
    },
  }),
  supabaseConfigured: () => true,
}));

const { bearerFrom, resolveServerSession, sessionErrorResponse } = await import(
  '@/lib/auth/server-session'
);

function profile(over: Record<string, unknown> = {}) {
  return {
    id: 'p1',
    organization_id: 'org-a',
    auth_user_id: 'u1',
    role: 'sales',
    is_active: true,
    deleted_at: null,
    full_name: 'Asha',
    ...over,
  };
}

beforeEach(() => {
  currentUser = { id: 'u1', email: 'asha@digitech.in' };
  profileRows = [profile()];
  profileError = null;
});

describe('bearerFrom', () => {
  it('extracts a bearer token', () => {
    const req = new Request('https://x.test', { headers: { authorization: 'Bearer abc.def' } });
    expect(bearerFrom(req)).toBe('abc.def');
  });

  it('is case-insensitive on the scheme', () => {
    const req = new Request('https://x.test', { headers: { authorization: 'bearer abc' } });
    expect(bearerFrom(req)).toBe('abc');
  });

  it('returns null when the header is absent', () => {
    expect(bearerFrom(new Request('https://x.test'))).toBeNull();
  });

  it('ignores a non-bearer scheme', () => {
    const req = new Request('https://x.test', { headers: { authorization: 'Basic abc' } });
    expect(bearerFrom(req)).toBeNull();
  });
});

describe('resolveServerSession', () => {
  it('rejects a missing token with 401', async () => {
    const r = await resolveServerSession(null);
    expect(r).toMatchObject({ ok: false, status: 401 });
  });

  it('rejects an invalid token with 401', async () => {
    currentUser = null;
    const r = await resolveServerSession('garbage');
    expect(r).toMatchObject({ ok: false, status: 401 });
  });

  it('resolves org and role from the database, not from the token', async () => {
    const r = await resolveServerSession('good');
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.session.organizationId).toBe('org-a');
      expect(r.session.role).toBe('sales');
      expect(r.session.userId).toBe('u1');
    }
  });

  it('denies a disabled profile even with a valid token', async () => {
    profileRows = [profile({ is_active: false })];
    const r = await resolveServerSession('good');
    expect(r).toMatchObject({ ok: false, status: 403 });
  });

  it('denies a soft-deleted profile', async () => {
    profileRows = [profile({ deleted_at: '2026-01-01T00:00:00Z' })];
    const r = await resolveServerSession('good');
    expect(r).toMatchObject({ ok: false, status: 403 });
  });

  it('denies a profile with no organization', async () => {
    profileRows = [profile({ organization_id: null })];
    const r = await resolveServerSession('good');
    expect(r).toMatchObject({ ok: false, status: 403 });
  });

  it('denies an authenticated user with no linked profile', async () => {
    profileRows = [];
    const r = await resolveServerSession('good');
    expect(r).toMatchObject({ ok: false, status: 403 });
  });

  it('fails closed when the profile lookup itself errors', async () => {
    profileError = { message: 'connection reset' };
    const r = await resolveServerSession('good');
    expect(r.ok).toBe(false);
  });
});

describe('sessionErrorResponse', () => {
  it('returns the outcome status and a JSON reason', async () => {
    const res = sessionErrorResponse({ ok: false, status: 403, reason: 'disabled' });
    expect(res.status).toBe(403);
    expect(await res.json()).toEqual({ error: 'disabled' });
  });
});
