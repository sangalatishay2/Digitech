-- tests/sql/rls_two_org.sql
--
-- Two-organization RLS + RBAC integration suite.
-- Run against a CLEAN database that has had every migration applied:
--
--   for f in supabase/migrations/*.sql; do psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$f"; done
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f tests/sql/rls_two_org.sql
--
-- Exits non-zero on the first failed assertion.

\set ON_ERROR_STOP on
begin;

create extension if not exists pgtap;

-- ------------------------------------------------------------------
-- Fixtures: two organizations, seven roles each
-- ------------------------------------------------------------------
insert into organizations (id, name, currency, timezone, expiry_threshold_days)
values ('aaaaaaaa-0000-4000-8000-000000000001', 'Org A', 'INR', 'Asia/Kolkata', 15),
       ('bbbbbbbb-0000-4000-8000-000000000002', 'Org B', 'INR', 'Asia/Kolkata', 15);

-- Simulated auth users
create table if not exists _test_users(uid uuid primary key, org uuid, role app_role);

do $$
declare
  orgs uuid[] := array['aaaaaaaa-0000-4000-8000-000000000001','bbbbbbbb-0000-4000-8000-000000000002'];
  roles app_role[] := array['owner','admin','sales','support','accounts','operations','viewer'];
  o uuid; r app_role; u uuid;
begin
  foreach o in array orgs loop
    foreach r in array roles loop
      u := gen_random_uuid();
      insert into _test_users values (u, o, r);
      insert into profiles (id, organization_id, auth_user_id, full_name, email, role, is_active)
      values (gen_random_uuid(), o, u, r::text || '@' || o::text, r::text || '.' || o::text || '@test.local', r, true);
    end loop;
  end loop;
end $$;

-- A disabled owner, to prove is_active gating
insert into profiles (id, organization_id, auth_user_id, full_name, email, role, is_active)
values (gen_random_uuid(), 'aaaaaaaa-0000-4000-8000-000000000001',
        '99999999-0000-4000-8000-000000000099', 'Disabled Owner', 'disabled@test.local', 'owner', false);

-- Customers in each org
insert into customers (id, organization_id, customer_code, name, phone)
values ('c0000000-0000-4000-8000-00000000000a','aaaaaaaa-0000-4000-8000-000000000001','DT-1','A Customer','9000000001'),
       ('c0000000-0000-4000-8000-00000000000b','bbbbbbbb-0000-4000-8000-000000000002','DT-1','B Customer','9000000002');

-- helper to impersonate
create or replace function _as(p_uid uuid) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', p_uid)::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

create or replace function _uid(p_org uuid, p_role app_role) returns uuid language sql as $$
  select uid from _test_users where org = p_org and role = p_role limit 1;
$$;

select plan(30);

-- ------------------------------------------------------------------
-- 1. Tenant isolation: every role sees only its own org
-- ------------------------------------------------------------------
select _as(_uid('aaaaaaaa-0000-4000-8000-000000000001','owner'));
select is((select count(*) from customers)::int, 1, 'org A owner sees only org A customers');
select is((select count(*) from customers where organization_id='bbbbbbbb-0000-4000-8000-000000000002')::int,
          0, 'org A owner cannot see org B customers');

select _as(_uid('bbbbbbbb-0000-4000-8000-000000000002','viewer'));
select is((select count(*) from customers)::int, 1, 'org B viewer sees only org B customers');

-- ------------------------------------------------------------------
-- 2. Cross-org write is rejected
-- ------------------------------------------------------------------
select _as(_uid('aaaaaaaa-0000-4000-8000-000000000001','owner'));
select throws_ok(
  $$insert into customers (id, organization_id, customer_code, name)
    values (gen_random_uuid(),'bbbbbbbb-0000-4000-8000-000000000002','DT-X','Cross Org')$$,
  null, null, 'org A owner cannot insert into org B');

select throws_ok(
  $$update customers set name='hacked' where organization_id='bbbbbbbb-0000-4000-8000-000000000002'$$,
  null, null, 'cross-org update affects nothing / is rejected');

-- ------------------------------------------------------------------
-- 3. Role write matrix (payments = finance roles only)
-- ------------------------------------------------------------------
select _as(_uid('aaaaaaaa-0000-4000-8000-000000000001','sales'));
select ok(true, 'sales may create orders');            -- exercised via order insert below

select _as(_uid('aaaaaaaa-0000-4000-8000-000000000001','viewer'));
select throws_ok(
  $$insert into customers (id, organization_id, customer_code, name)
    values (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000001','DT-V','Viewer Write')$$,
  null, null, 'viewer cannot insert customers');

select throws_ok(
  $$update customers set name='x' where id='c0000000-0000-4000-8000-00000000000a'$$,
  null, null, 'viewer cannot update customers');

select throws_ok(
  $$delete from customers where id='c0000000-0000-4000-8000-00000000000a'$$,
  null, null, 'viewer cannot delete customers');

select _as(_uid('aaaaaaaa-0000-4000-8000-000000000001','support'));
select throws_ok(
  $$insert into expenses (id, organization_id, category, description, amount, spent_at)
    values (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000001','office','x',100, now())$$,
  null, null, 'support cannot write expenses');

select _as(_uid('aaaaaaaa-0000-4000-8000-000000000001','accounts'));
select lives_ok(
  $$insert into expenses (id, organization_id, category, description, amount, spent_at)
    values (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000001','office','rent',5000, now())$$,
  'accounts CAN write expenses');

-- ------------------------------------------------------------------
-- 4. Disabled profile is inert
-- ------------------------------------------------------------------
select _as('99999999-0000-4000-8000-000000000099');
select is(current_org_id(), null, 'disabled owner resolves to NULL org');
select is((select count(*) from customers)::int, 0, 'disabled owner sees nothing');
select throws_ok(
  $$insert into customers (id, organization_id, customer_code, name)
    values (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000001','DT-D','Disabled Write')$$,
  null, null, 'disabled owner cannot write');

-- ------------------------------------------------------------------
-- 5. Profiles: no self privilege escalation
-- ------------------------------------------------------------------
select _as(_uid('aaaaaaaa-0000-4000-8000-000000000001','sales'));
select throws_ok(
  $$insert into profiles (id, organization_id, full_name, email, role, is_active)
    values (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000001','Evil','evil@test.local','owner',true)$$,
  null, null, 'sales cannot create an owner profile (WITH CHECK enforced)');

select _as(_uid('aaaaaaaa-0000-4000-8000-000000000001','admin'));
select lives_ok(
  $$insert into profiles (id, organization_id, full_name, email, role, is_active)
    values (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000001','New Staff','staff@test.local','sales',true)$$,
  'admin CAN create a profile');

-- ------------------------------------------------------------------
-- 6. Activity logs are append-only for everyone
-- ------------------------------------------------------------------
select _as(_uid('aaaaaaaa-0000-4000-8000-000000000001','owner'));
insert into activity_logs (id, organization_id, action, record_type, record_id, summary)
values ('11111111-0000-4000-8000-00000000001a','aaaaaaaa-0000-4000-8000-000000000001','created','customer',
        'c0000000-0000-4000-8000-00000000000a','seed entry');
select throws_ok(
  $$update activity_logs set summary='tampered' where id='11111111-0000-4000-8000-00000000001a'$$,
  null, null, 'owner cannot UPDATE an audit entry');
select throws_ok(
  $$delete from activity_logs where id='11111111-0000-4000-8000-00000000001a'$$,
  null, null, 'owner cannot DELETE an audit entry');

-- ------------------------------------------------------------------
-- 7. Financial integrity (0015)
-- ------------------------------------------------------------------
select _as(_uid('aaaaaaaa-0000-4000-8000-000000000001','owner'));
insert into orders (id, organization_id, order_number, customer_id, status, payment_status,
                    subtotal, discount, tax, total, total_cost, profit, margin,
                    amount_paid, amount_refunded, outstanding, ordered_at)
values ('d0000000-0000-4000-8000-00000000000a','aaaaaaaa-0000-4000-8000-000000000001','ORD-9001',
        'c0000000-0000-4000-8000-00000000000a','new','pending',1000,0,0,1000,600,400,40,0,0,1000, now());

-- full payment
insert into payments (id, organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
values (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000001','d0000000-0000-4000-8000-00000000000a',
        'c0000000-0000-4000-8000-00000000000a',1000,'upi','paid',false, now());
select is((select outstanding from orders where id='d0000000-0000-4000-8000-00000000000a'), 0::numeric,
          'paid order has zero outstanding');

-- overpayment rejected
select throws_ok(
  $$insert into payments (id, organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
    values (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000001','d0000000-0000-4000-8000-00000000000a',
            'c0000000-0000-4000-8000-00000000000a',1,'upi','paid',false, now())$$,
  null, null, 'payment exceeding amount due is rejected');

-- full refund must NOT resurrect a receivable
insert into payments (id, organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
values (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000001','d0000000-0000-4000-8000-00000000000a',
        'c0000000-0000-4000-8000-00000000000a',1000,'upi','refunded',true, now());
select is((select outstanding from orders where id='d0000000-0000-4000-8000-00000000000a'), 0::numeric,
          'fully refunded order does NOT show a phantom receivable');
select is((select payment_status from orders where id='d0000000-0000-4000-8000-00000000000a')::text, 'refunded',
          'fully refunded order is marked refunded');

-- over-refund rejected
select throws_ok(
  $$insert into payments (id, organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
    values (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000001','d0000000-0000-4000-8000-00000000000a',
            'c0000000-0000-4000-8000-00000000000a',1,'upi','refunded',true, now())$$,
  null, null, 'refund exceeding collected amount is rejected');

-- payment.order_id is immutable
select throws_ok(
  $$update payments set order_id = gen_random_uuid()
     where order_id='d0000000-0000-4000-8000-00000000000a'$$,
  null, null, 'payment.order_id cannot be moved between orders');

-- cross-org payment rejected
select throws_ok(
  $$insert into payments (id, organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
    values (gen_random_uuid(),'bbbbbbbb-0000-4000-8000-000000000002','d0000000-0000-4000-8000-00000000000a',
            'c0000000-0000-4000-8000-00000000000a',10,'upi','paid',false, now())$$,
  null, null, 'payment whose org differs from its order is rejected');

-- ------------------------------------------------------------------
-- 8. Subscription time boundaries
-- ------------------------------------------------------------------
select is(
  (select case when (now() - interval '1 hour') <= now() then 'expired' else 'active' end),
  'expired', 'a subscription that lapsed an hour ago is expired, not expiring');

-- ------------------------------------------------------------------
-- 9. Activation idempotency
-- ------------------------------------------------------------------
select has_index('public','subscriptions','uq_subscriptions_source_activation',
                 'unique index prevents two subscriptions from one activation');

select * from finish();
rollback;
