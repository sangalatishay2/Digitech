#!/usr/bin/env bash
# Applies every migration to a clean database, then runs the RLS/finance suite.
# Requires DATABASE_URL to point at a throwaway Postgres 15+ with pgtap available.
set -euo pipefail
: "${DATABASE_URL:?set DATABASE_URL to a disposable Postgres database}"
echo "==> applying migrations"
for f in supabase/migrations/*.sql; do
  echo "    $f"
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -q -f "$f"
done
echo "==> running RLS + financial integrity suite"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f tests/sql/rls_two_org.sql
