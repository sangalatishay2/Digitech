import { describe, it, expect, afterEach } from 'vitest';
import {
  resolveSession, profileCanAct, assertProfileCanAct,
  assertSwitchingAllowed, AuthError, type Session,
} from '@/lib/auth/session';
import type { Profile } from '@/lib/types';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const ORG = 'org-a';

function mk(over: Partial<Profile> = {}): Profile {
  return {
    id: 'p-1', organization_id: ORG, auth_user_id: 'auth-1',
    full_name: 'Active Owner', email: 'owner@test.local', phone: null,
    role: 'owner', is_active: true,
    created_at: '2026-01-01T00:00:00.000Z', updated_at: '2026-01-01T00:00:00.000Z',
    deleted_at: null, ...over,
  } as Profile;
}

const ACTIVE = mk();
const DISABLED = mk({ id: 'p-2', auth_user_id: 'auth-2', full_name: 'Disabled', email: 'd@test.local', is_active: false });
const DELETED = mk({ id: 'p-3', auth_user_id: 'auth-3', full_name: 'Deleted', email: 'x@test.local', deleted_at: '2026-02-01T00:00:00.000Z' });

const setProvider = (v?: string) => {
  if (v === undefined) delete process.env.NEXT_PUBLIC_DATA_PROVIDER;
  else process.env.NEXT_PUBLIC_DATA_PROVIDER = v;
};

afterEach(() => setProvider(undefined));

describe('profileCanAct', () => {
  it('accepts an active, non-deleted profile', () => {
    expect(profileCanAct(ACTIVE)).toBe(true);
  });
  it('rejects disabled, deleted, null and undefined', () => {
    expect(profileCanAct(DISABLED)).toBe(false);
    expect(profileCanAct(DELETED)).toBe(false);
    expect(profileCanAct(null)).toBe(false);
    expect(profileCanAct(undefined)).toBe(false);
  });
  it('assertProfileCanAct explains why it refused', () => {
    expect(() => assertProfileCanAct(DISABLED)).toThrow(/disabled/i);
    expect(() => assertProfileCanAct(DELETED)).toThrow(/removed/i);
    expect(() => assertProfileCanAct(null)).toThrow(/not signed in/i);
  });
});

describe('demo mode identity', () => {
  it('honours the requested user', () => {
    const other = mk({ id: 'p-9', auth_user_id: 'auth-9', full_name: 'Sales', email: 's@test.local', role: 'sales' });
    const r = resolveSession([ACTIVE, other], { requestedUserId: 'p-9' });
    expect(r.profile?.id).toBe('p-9');
    expect(r.session?.source).toBe('demo-switch');
  });

  it('a DISABLED profile is refused even in demo mode', () => {
    const r = resolveSession([ACTIVE, DISABLED], { requestedUserId: 'p-2' });
    expect(r.profile).toBeNull();
    expect(r.reason).toMatch(/disabled/i);
  });

  it('a soft-deleted profile is refused', () => {
    const r = resolveSession([ACTIVE, DELETED], { requestedUserId: 'p-3' });
    expect(r.profile).toBeNull();
    expect(r.reason).toMatch(/removed/i);
  });

  it('falls back to the first ACTABLE profile, never to a disabled one', () => {
    // Disabled profile deliberately placed first: the old `profiles[0]`
    // fallback would have selected it.
    const r = resolveSession([DISABLED, ACTIVE], {});
    expect(r.profile?.id).toBe('p-1');
  });

  it('reports when no profiles exist', () => {
    const r = resolveSession([], {});
    expect(r.profile).toBeNull();
    expect(r.reason).toMatch(/no profiles/i);
  });

  it('allows switching in demo mode', () => {
    expect(() => assertSwitchingAllowed()).not.toThrow();
  });
});

describe('production mode identity', () => {
  // Production requires supabase creds; resolveMode() degrades to demo without
  // them, so these set the flag and assert the *demo* fallback stays safe, plus
  // the explicit production branch via an injected session.
  it('ignores a requested user id when a real session is present', () => {
    const session: Session = { userId: 'auth-1', email: 'owner@test.local', accessToken: 't', source: 'supabase' };
    // In demo mode the requested id wins; assert the production branch directly
    // by checking that a session maps by auth_user_id, not by profile id.
    const r = resolveSession([ACTIVE], { requestedUserId: 'p-9', session });
    // Demo mode is active (no creds), so requested id is used; the important
    // guarantee is that an unknown requested id cannot escalate.
    expect(r.profile === null || r.profile.id === 'p-1').toBe(true);
  });

  it('maps a session to a profile by auth_user_id', () => {
    const session: Session = { userId: 'auth-1', email: null, accessToken: 't', source: 'supabase' };
    const r = resolveSession([ACTIVE], { session });
    expect(r.profile?.auth_user_id).toBe('auth-1');
  });
});

describe('AuthError', () => {
  it('is identifiable', () => {
    const e = new AuthError('nope');
    expect(e).toBeInstanceOf(Error);
    expect(e.name).toBe('AuthError');
  });
});

/** Production requires both the provider request and real credentials. */
function goProduction() {
  process.env.NEXT_PUBLIC_DATA_PROVIDER = 'supabase';
  process.env.NEXT_PUBLIC_SUPABASE_URL = 'https://example.supabase.co';
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = 'anon-key';
}

describe('production identity comes only from a verified session', () => {
  afterEach(() => {
    delete process.env.NEXT_PUBLIC_SUPABASE_URL;
    delete process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  });

  const profiles = [
    {
      id: 'p1',
      organization_id: 'org-a',
      auth_user_id: 'auth-1',
      full_name: 'Asha',
      role: 'sales',
      is_active: true,
      deleted_at: null,
    },
    {
      id: 'p2',
      organization_id: 'org-a',
      auth_user_id: 'auth-2',
      full_name: 'Disabled',
      role: 'admin',
      is_active: false,
      deleted_at: null,
    },
  ] as unknown as Profile[];

  const supa = (userId: string): Session => ({
    userId,
    email: 'x@y.z',
    accessToken: 'tok',
    source: 'supabase',
  });

  it('resolves the profile linked to the session auth_user_id', () => {
    goProduction();
    const r = resolveSession(profiles, { session: supa('auth-1') });
    expect(r.profile?.id).toBe('p1');
  });

  it('yields no identity when there is no session', () => {
    goProduction();
    const r = resolveSession(profiles, { session: null });
    expect(r.profile).toBeNull();
    expect(r.reason).toMatch(/no authenticated session/i);
  });

  it('ignores requestedUserId in production (no switcher escalation)', () => {
    goProduction();
    // Asking to be the admin while holding the sales session must not work.
    const r = resolveSession(profiles, { requestedUserId: 'p2', session: supa('auth-1') });
    expect(r.profile?.id).toBe('p1');
  });

  it('refuses a disabled profile even with a valid session', () => {
    goProduction();
    const r = resolveSession(profiles, { session: supa('auth-2') });
    expect(r.profile).toBeNull();
    expect(r.reason).toMatch(/disabled/i);
  });

  it('refuses a session with no linked profile', () => {
    goProduction();
    const r = resolveSession(profiles, { session: supa('auth-unknown') });
    expect(r.profile).toBeNull();
    expect(r.reason).toMatch(/no profile/i);
  });

  it('the store passes a real session into resolveSession', () => {
    // Guards the defect where the store called resolveSession() without a
    // session, leaving production with no acting identity at all.
    const src = readFileSync(join(__dirname, '../src/lib/store.tsx'), 'utf8');
    expect(src).toMatch(/resolveSession\(db\.profiles,[\s\S]*?session:\s*authSession/);
  });
});
