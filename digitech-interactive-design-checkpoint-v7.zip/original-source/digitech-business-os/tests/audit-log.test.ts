import { describe, it, expect } from 'vitest';
import { buildSeed } from '@/lib/data/seed';
import type { Database, ActivityLog } from '@/lib/types';

/**
 * P2 #17 — the durable audit trail.
 *
 * The store's mutations are React-bound, so rather than mount a provider these
 * assert the invariants the audit trail must satisfy, plus the store source
 * itself: every sensitive mutation must call log(), and deletes must capture
 * what was removed.
 */
import fs from 'node:fs';
import path from 'node:path';

const STORE = fs.readFileSync(path.join(process.cwd(), 'src/lib/store.tsx'), 'utf8');

describe('audit trail is not capped at 500', () => {
  it('the old truncation is gone', () => {
    expect(STORE).not.toMatch(/activity_logs\.length\s*=\s*500/);
    expect(STORE).not.toMatch(/slice\(0,\s*500\)/);
  });

  it('the only limit is an explicit demo-storage safety ceiling', () => {
    expect(STORE).toMatch(/AUDIT_LOG_SAFETY_CEILING\s*=\s*20_000/);
  });

  it('a large trail is retained well past 500 entries', () => {
    const db: Database = buildSeed();
    const logs: ActivityLog[] = [];
    for (let i = 0; i < 5000; i++) {
      logs.push({ id: `l-${i}`, organization_id: 'o', actor_id: null, actor_name: 'System',
        action: 'created', record_type: 'customer', record_id: 'c', summary: `entry ${i}`,
        old_values: null, new_values: null, created_at: new Date().toISOString(),
      } as unknown as ActivityLog);
    }
    db.activity_logs = logs;
    expect(db.activity_logs.length).toBe(5000);
  });
});

describe('sensitive mutations are logged', () => {
  const mustLog: [string, RegExp][] = [
    ['expense create', /log\(d, 'created', 'expense'/],
    ['expense update', /log\(d, 'updated', 'expense'/],
    ['expense delete', /log\(d, 'deleted', 'expense'/],
    ['invoice create', /log\(d, 'created', 'invoice'/],
    ['task create', /log\(d, 'created', 'task'/],
    ['task update', /log\(d, 'updated', 'task'/],
    ['role change', /log\(d, 'role_changed', 'profile'/],
    ['member added', /log\(d, 'created', 'profile'/],
    ['settings update', /log\(d, 'updated', 'settings'/],
    ['order status', /log\(d, 'status_changed', 'order'/],
    ['payment', /log\(d, isRefund \? 'refunded' : 'payment_added'/],
    ['customer archive', /log\(d, 'archived', 'customer'/],
  ];

  for (const [label, re] of mustLog) {
    it(`logs ${label}`, () => {
      expect(STORE, `${label} is not audited`).toMatch(re);
    });
  }
});

describe('deletes and privilege changes capture old values', () => {
  it('expense delete records what was removed', () => {
    const m = STORE.match(/log\(d, 'deleted', 'expense'[\s\S]{0,220}/);
    expect(m).toBeTruthy();
    expect(m![0]).toMatch(/\{\s*old:/);
  });

  it('role change records both old and new', () => {
    const m = STORE.match(/log\(d, 'role_changed', 'profile'[\s\S]{0,260}/);
    expect(m).toBeTruthy();
    expect(m![0]).toMatch(/old:/);
    expect(m![0]).toMatch(/new:/);
  });

  it('settings update records both old and new', () => {
    const m = STORE.match(/log\(d, 'updated', 'settings'[\s\S]{0,200}/);
    expect(m).toBeTruthy();
    expect(m![0]).toMatch(/old: before/);
  });
});

describe('sensitive team mutations are permission-checked', () => {
  for (const fn of ['addTeamMember', 'setMemberRole', 'setMemberActive']) {
    it(`${fn} requires team.manage`, () => {
      // Match the IMPLEMENTATION (which has a body), not the interface
      // declaration that appears earlier in the file.
      const i = STORE.indexOf(`${fn}: (input) => {`) >= 0
        ? STORE.indexOf(`${fn}: (input) => {`)
        : STORE.search(new RegExp(`${fn}: \\([^)]*\\) => \\{`));
      expect(i, `${fn} implementation not found`).toBeGreaterThan(-1);
      expect(STORE.slice(i, i + 220)).toMatch(/assertCan\(toActor\(currentUser\), 'team\.manage'/);
    });
  }

  it('saveOrgSettings requires settings.update', () => {
    const i = STORE.indexOf('saveOrgSettings: (patch) => {');
    expect(i).toBeGreaterThan(-1);
    expect(STORE.slice(i, i + 220)).toMatch(/assertCan\(toActor\(currentUser\), 'settings\.update'/);
  });

  it('expense delete is permission-checked', () => {
    const i = STORE.indexOf('deleteExpense: (id) =>');
    expect(STORE.slice(i, i + 400)).toMatch(/assertCan\(toActor\(currentUser\), 'expenses\.delete'/);
  });
});

describe('the team page no longer mutates profiles directly', () => {
  const TEAM = fs.readFileSync(path.join(process.cwd(), 'src/app/team/page.tsx'), 'utf8');

  it('does not push profiles or flip roles via a raw update()', () => {
    // Raw update() from a page bypasses both the permission check and the audit
    // trail -- which is how role changes went unrecorded.
    expect(TEAM).not.toMatch(/d\.profiles\.push/);
    expect(TEAM).not.toMatch(/p\.role = role/);
    expect(TEAM).not.toMatch(/p\.is_active = !p\.is_active/);
  });

  it('uses the audited store actions', () => {
    expect(TEAM).toMatch(/addTeamMember\(/);
    expect(TEAM).toMatch(/setMemberRole\(/);
    expect(TEAM).toMatch(/setMemberActive\(/);
  });
});

describe('ticket numbering no longer derives from row count', () => {
  it('uses the gap-tolerant numbering service', () => {
    expect(STORE).not.toMatch(/2000 \+ db\.support_tickets\.length/);
    expect(STORE).toMatch(/nextNumber\(db, 'ticket'\)/);
  });
});
