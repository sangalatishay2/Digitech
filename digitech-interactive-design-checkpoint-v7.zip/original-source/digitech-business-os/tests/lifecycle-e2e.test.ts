import { describe, it, expect } from 'vitest';
import { buildSeed } from '@/lib/data/seed';
import {
  buildActivation, buildOrderItem, buildSubscription,
  computeOrderTotals, deriveSubscriptionStatus, newId, nowIso, recalcOrderPayments,
} from '@/lib/services/business';
import { nextNumber } from '@/lib/services/numbering';
import { validateOrderInput } from '@/lib/services/validation';
import type { Database, Order, Payment } from '@/lib/types';

/**
 * Full lifecycle exercised against the real service layer:
 * Customer -> Order -> Payment -> Activation -> Subscription -> Renewal.
 */
function setup() {
  const db = buildSeed();
  const orgId = db.organizations[0].id;
  const customer = db.customers[0];
  const product = db.products.find((p) => p.duration_days > 0)!;
  return { db, orgId, customer, product };
}

describe('E2E: customer -> order -> payment -> activation -> subscription -> renewal', () => {
  it('completes the whole chain with consistent money and state', () => {
    const { db, orgId, customer, product } = setup();

    // 1. Order passes validation
    const input = { customer_id: customer.id, lines: [{ product_id: product.id, quantity: 1, unit_price: product.selling_price, discount: 0 }] };
    expect(validateOrderInput(db, input, orgId)).toEqual([]);

    // 2. Build the order
    const orderId = newId();
    const items = [buildOrderItem(orderId, product, { quantity: 1 })];
    const totals = computeOrderTotals(items);
    const order: Order = {
      id: orderId, organization_id: orgId, created_at: nowIso(), updated_at: nowIso(), deleted_at: null,
      order_number: nextNumber(db, 'order'), customer_id: customer.id, status: 'awaiting_payment',
      payment_status: 'pending', ...totals, amount_paid: 0, amount_refunded: 0,
      outstanding: totals.total, notes: null, source: null, renewal_of_subscription_id: null,
      assigned_to: null, ordered_at: nowIso(), items,
    } as unknown as Order;
    expect(order.total).toBeGreaterThan(0);
    expect(order.order_number).toMatch(/^ORD-\d+$/);

    // 3. Pay in full
    const payments: Payment[] = [{ id: newId(), order_id: orderId, amount: order.total, is_refund: false } as unknown as Payment];
    const paid = recalcOrderPayments(order, payments);
    expect(paid.payment_status).toBe('paid');
    expect(paid.outstanding).toBe(0);

    // 4. Activation created and completed
    const activation = buildActivation(paid, items[0], orgId);
    expect(activation.order_item_id).toBe(items[0].id);
    activation.status = 'delivered';

    // 5. Subscription created, linked to the activation (idempotency key)
    const sub = buildSubscription(paid, items[0], orgId, null, activation.id);
    expect(sub.source_activation_id).toBe(activation.id);
    expect(sub.order_item_id).toBe(items[0].id);
    expect(sub.duration_days).toBe(product.duration_days);
    expect(new Date(sub.expiry_date).getTime()).toBeGreaterThan(new Date(sub.start_date).getTime());
    expect(deriveSubscriptionStatus(sub, 15)).not.toBe('expired');

    // 6. Renewal: a second order referencing the first subscription
    db.subscriptions.unshift(sub);
    const renewalInput = { customer_id: customer.id, lines: [{ product_id: product.id, quantity: 1, unit_price: product.selling_price, discount: 0 }], renewal_of_subscription_id: sub.id };
    expect(validateOrderInput(db, renewalInput, orgId)).toEqual([]);

    const renewOrderId = newId();
    const renewItems = [buildOrderItem(renewOrderId, product, { quantity: 1 })];
    const renewOrder = { ...paid, id: renewOrderId, items: renewItems, renewal_of_subscription_id: sub.id } as Order;
    const renewAct = buildActivation(renewOrder, renewItems[0], orgId);
    const renewSub = buildSubscription(renewOrder, renewItems[0], orgId, sub.id, renewAct.id);

    // chain integrity
    expect(renewSub.previous_subscription_id).toBe(sub.id);
    sub.status = 'renewed';
    sub.renewed_to_subscription_id = renewSub.id;
    expect(deriveSubscriptionStatus(sub, 15)).toBe('renewed');
  });

  it('rejects a renewal pointing at another customer\'s subscription', () => {
    const { db, orgId, product } = setup();
    const a = db.customers[0], b = db.customers[1];
    const foreign = db.subscriptions.find((s) => s.customer_id === b.id);
    if (!foreign) return;
    const issues = validateOrderInput(db, {
      customer_id: a.id,
      lines: [{ product_id: product.id, quantity: 1, unit_price: 100, discount: 0 }],
      renewal_of_subscription_id: foreign.id,
    }, orgId);
    expect(issues.join(' ')).toMatch(/different customer/);
  });
});

describe('order validation rejects malformed input', () => {
  const { db, orgId, customer, product } = setup();
  const line = { product_id: product.id, quantity: 1, unit_price: 100, discount: 0 };

  it('zero-item order', () => {
    expect(validateOrderInput(db, { customer_id: customer.id, lines: [] }, orgId).join(' '))
      .toMatch(/at least one item/);
  });
  it('missing customer', () => {
    expect(validateOrderInput(db, { customer_id: 'nope', lines: [line] }, orgId).join(' '))
      .toMatch(/customer does not exist/);
  });
  it('missing product', () => {
    expect(validateOrderInput(db, { customer_id: customer.id, lines: [{ ...line, product_id: 'nope' }] }, orgId).join(' '))
      .toMatch(/product does not exist/);
  });
  it('non-positive quantity', () => {
    expect(validateOrderInput(db, { customer_id: customer.id, lines: [{ ...line, quantity: 0 }] }, orgId).join(' '))
      .toMatch(/positive whole number/);
  });
  it('fractional quantity', () => {
    expect(validateOrderInput(db, { customer_id: customer.id, lines: [{ ...line, quantity: 1.5 }] }, orgId).join(' '))
      .toMatch(/positive whole number/);
  });
  it('negative price', () => {
    expect(validateOrderInput(db, { customer_id: customer.id, lines: [{ ...line, unit_price: -5 }] }, orgId).join(' '))
      .toMatch(/zero or greater/);
  });
  it('discount exceeding line value', () => {
    expect(validateOrderInput(db, { customer_id: customer.id, lines: [{ ...line, unit_price: 199, discount: 200 }] }, orgId).join(' '))
      .toMatch(/exceeds line value/);
  });
  it('cross-organization customer', () => {
    const foreign = { ...db, customers: db.customers.map((c, i) => i === 0 ? { ...c, organization_id: 'other-org' } : c) } as Database;
    expect(validateOrderInput(foreign, { customer_id: customer.id, lines: [line] }, orgId).join(' '))
      .toMatch(/different organization/);
  });
});

describe('numbering is monotonic and gap-tolerant', () => {
  it('does not reuse a number after a delete', () => {
    const db = buildSeed();
    const first = nextNumber(db, 'order');
    // simulate deleting the most recent order
    db.orders.sort((a, b) => (a.order_number < b.order_number ? 1 : -1));
    db.orders.shift();
    const second = nextNumber(db, 'order');
    // length-based numbering would hand back a already-used value; ours must not
    const used = new Set(db.orders.map((o) => o.order_number));
    expect(used.has(second)).toBe(false);
    expect(first).toMatch(/^ORD-\d+$/);
  });
});
