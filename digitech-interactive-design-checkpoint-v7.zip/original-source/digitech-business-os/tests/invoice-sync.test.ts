import { describe, it, expect } from 'vitest';
import { computeOrderLedger, projectInvoice, reconcileInvoices } from '@/lib/services/business';
import type { Database, Invoice, Order, Payment } from '@/lib/types';

const order = (over: Partial<Order> = {}): Order =>
  ({ id: 'o1', organization_id: 'org', total: 1000, amount_paid: 0, amount_refunded: 0,
     outstanding: 1000, payment_status: 'pending', status: 'new', items: [], ...over } as unknown as Order);

const pay = (amount: number, is_refund = false): Payment =>
  ({ id: Math.random().toString(), order_id: 'o1', amount, is_refund } as unknown as Payment);

const invoice = (over: Partial<Invoice> = {}): Invoice =>
  ({ id: 'i1', organization_id: 'org', order_id: 'o1', invoice_number: 'INV-501',
     total: 1000, amount_paid: 0, status: 'sent',
     due_date: new Date(Date.now() + 7 * 86400000).toISOString(), items: [], ...over } as unknown as Invoice);

const dbOf = (o: Order, ps: Payment[], invs: Invoice[]): Database =>
  ({ orders: [o], payments: ps, invoices: invs } as unknown as Database);

describe('invoice reconciliation with the payment ledger', () => {
  it('invoice created BEFORE any payment starts unpaid', () => {
    const l = computeOrderLedger(order(), []);
    expect(projectInvoice(invoice(), l).status).toBe('sent');
    expect(projectInvoice(invoice(), l).amount_paid).toBe(0);
  });

  it('invoice becomes paid once payments land AFTER creation', () => {
    const o = order(); const ps = [pay(1000)];
    const db = dbOf(o, ps, [invoice()]);
    reconcileInvoices(db);
    expect(db.invoices[0].amount_paid).toBe(1000);
    expect(db.invoices[0].status).toBe('paid');
  });

  it('invoice created AFTER payments already exist is not stale at zero', () => {
    const o = order(); const ps = [pay(600)];
    const db = dbOf(o, ps, [invoice({ amount_paid: 0, status: 'sent' })]);
    reconcileInvoices(db);
    expect(db.invoices[0].amount_paid).toBe(600);
    expect(db.invoices[0].status).toBe('partial');
  });

  it('a refund flows through to the invoice', () => {
    const o = order(); const ps = [pay(1000), pay(1000, true)];
    const db = dbOf(o, ps, [invoice({ amount_paid: 1000, status: 'paid' })]);
    reconcileInvoices(db);
    // fully refunded: nothing collected net, nothing due
    expect(db.invoices[0].amount_paid).toBe(1000);
    expect(db.invoices[0].status).toBe('paid');
  });

  it('partial refund keeps the invoice reconciled with the ledger', () => {
    const o = order(); const ps = [pay(1000), pay(300, true)];
    const db = dbOf(o, ps, [invoice()]);
    reconcileInvoices(db);
    const l = computeOrderLedger(o, ps);
    expect(l.due).toBe(0);
    expect(db.invoices[0].status).toBe('paid');
  });

  it('overdue only when nothing collected and past due date', () => {
    const l = computeOrderLedger(order(), []);
    const past = invoice({ due_date: new Date(Date.now() - 86400000).toISOString() });
    expect(projectInvoice(past, l).status).toBe('overdue');
  });

  it('void invoices are never resurrected by reconciliation', () => {
    const o = order(); const ps = [pay(1000)];
    const db = dbOf(o, ps, [invoice({ status: 'void' })]);
    reconcileInvoices(db);
    expect(db.invoices[0].status).toBe('void');
  });

  it('reconcile reports how many invoices changed', () => {
    const o = order(); const ps = [pay(1000)];
    const db = dbOf(o, ps, [invoice()]);
    expect(reconcileInvoices(db)).toBe(1);
    expect(reconcileInvoices(db)).toBe(0); // idempotent
  });
});
