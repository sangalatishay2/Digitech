import { describe, expect, it } from 'vitest';
import {
  approvalJobKey,
  canReviewApproval,
  inferApprovalRisk,
  payloadContainsSecret,
  validateApprovalInput,
} from '@/lib/services/approvals';
import type { ApprovalRequest } from '@/lib/types';

const pending: ApprovalRequest = {
  id: 'approval-1', organization_id: 'org-1', created_at: '2026-09-01T00:00:00.000Z',
  updated_at: '2026-09-01T00:00:00.000Z', deleted_at: null,
  request_type: 'refund', title: 'Refund customer', description: '', reason: 'Duplicate charge',
  risk_level: 'high', status: 'pending', financial_impact: 1200, payload: {},
  requested_by: 'profile-1', reviewed_by: null, reviewed_at: null, review_note: null,
  expires_at: '2026-09-10T00:00:00.000Z', executed_at: null,
};

describe('approval safety boundary', () => {
  it('infers higher risk for financial, account, and AI actions', () => {
    expect(inferApprovalRisk('discount', 500)).toBe('medium');
    expect(inferApprovalRisk('ai_action', 0)).toBe('high');
    expect(inferApprovalRisk('account_change', 0)).toBe('critical');
    expect(inferApprovalRisk('expense', 50_000)).toBe('critical');
  });

  it('detects nested secret-bearing keys', () => {
    expect(payloadContainsSecret({ config: { api_key: 'do-not-store' } })).toBe(true);
    expect(payloadContainsSecret({ command: 'Use token=super-secret-value to call it' })).toBe(true);
    expect(payloadContainsSecret({ authorization: 'Bearer abcdefghijklmnopqrstuvwxyz' })).toBe(true);
    expect(payloadContainsSecret({ action: 'send reminder', customer_id: 'c1' })).toBe(false);
  });

  it('validates required copy, impact, expiry, and secret-free payloads', () => {
    const errors = validateApprovalInput({
      request_type: 'ai_action', title: 'x', reason: '', financial_impact: -1,
      expires_at: '2020-01-01T00:00:00.000Z', payload: { token: 'secret' },
    });
    expect(errors.join(' ')).toMatch(/Title/);
    expect(errors.join(' ')).toMatch(/Reason/);
    expect(errors.join(' ')).toMatch(/Financial/);
    expect(errors.join(' ')).toMatch(/future/);
    expect(errors.join(' ')).toMatch(/secrets/);
  });

  it('rejects re-review and approval after expiry', () => {
    expect(canReviewApproval({ ...pending, status: 'approved' }, 'rejected')).toMatch(/finalized/);
    expect(canReviewApproval(pending, 'approved', new Date('2026-09-11T00:00:00.000Z'))).toMatch(/expired/);
    expect(canReviewApproval(pending, 'rejected', new Date('2026-09-11T00:00:00.000Z'))).toBeNull();
  });

  it('uses an approval-scoped idempotency key', () => {
    expect(approvalJobKey('approval-1')).toBe('approval:approval-1');
  });
});
