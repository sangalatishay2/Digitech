import { describe, it, expect } from 'vitest';
import {
  computePeriod, refundRateFor, customerValue, averageLifetimeValue,
  topProductsByNet, reconcile, refundEvents, collectionEvents,
} from '@/lib/services/finance';
import { buildSeed } from '@/lib/data/seed';
import type { Database, Order, Payment } from '@/lib/types';
import type { DateRange } from '@/lib/services/analytics';

const ORG = '00000000-0000-4000-8000-000000000001';

function emptyish(): Database {
  const db = buildSeed();
  return { ...db, orders: [], payments: [], expenses: [], customers: [], order_items: [] } as unknown as Database;
}

function mkOrder(over: Partial<Order> = {}): Order {
  return {
    id: 'o-1', organization_id: ORG, order_number: 'ORD-1', customer_id: 'c-1',
    customer_name: 'A', status: 'completed', payment_status: 'paid',
    subtotal: 1000, discount: 0, tax: 0, total: 1000, total_cost: 600,
    profit: 400, margin: 40, amount_paid: 1000, amount_refunded: 0, outstanding: 0,
    ordered_at: '2026-01-15T00:00:00.000Z', items: [],
    created_at: '2026-01-15T00:00:00.000Z', updated_at: '2026-01-15T00:00:00.000Z',
    deleted_at: null, ...over,
  } as unknown as Order;
}

function mkPayment(over: Partial<Payment> = {}): Payment {
  return {
    id: 'p-1', organization_id: ORG, order_id: 'o-1', customer_id: 'c-1',
    amount: 1000, method: 'upi', status: 'paid', is_refund: false,
    paid_at: '2026-01-15T00:00:00.000Z',
    created_at: '2026-01-15T00:00:00.000Z', updated_at: '2026-01-15T00:00:00.000Z',
    deleted_at: null, ...over,
  } as unknown as Payment;
}

const range = (from: string, to: string): DateRange => ({
  from: new Date(from), to: new Date(to), label: `${from}..${to}`,
} as DateRange);

const JAN = range('2026-01-01T00:00:00.000Z', '2026-01-31T23:59:59.999Z');
const MAR = range('2026-03-01T00:00:00.000Z', '2026-03-31T23:59:59.999Z');

describe('date-aware refund accounting', () => {
  /**
   * The core P1 #12 defect: a January order refunded in March used to reduce
   * JANUARY's profit, because refunds were attributed to the order's date.
   * A closed month's reported numbers must never change retroactively.
   */
  const db: Database = {
    ...emptyish(),
    orders: [mkOrder({ amount_refunded: 1000, payment_status: 'refunded' })],
    payments: [
      mkPayment({ id: 'pay-1', amount: 1000, is_refund: false, paid_at: '2026-01-15T00:00:00.000Z' }),
      mkPayment({ id: 'ref-1', amount: 1000, is_refund: true, paid_at: '2026-03-10T00:00:00.000Z' }),
    ],
  };

  it('January keeps its full revenue — the March refund does not reach back', () => {
    const jan = computePeriod(db, JAN);
    expect(jan.grossRevenue).toBe(1000);
    expect(jan.refunds).toBe(0);
    expect(jan.netRevenue).toBe(1000);
  });

  it('the refund lands in March, where the money actually moved', () => {
    const mar = computePeriod(db, MAR);
    expect(mar.refunds).toBe(1000);
    expect(mar.grossRevenue).toBe(0); // no orders placed in March
    expect(mar.netRevenue).toBe(-1000);
  });

  it('refundEvents/collectionEvents are filtered by settlement date', () => {
    expect(refundEvents(db, JAN)).toHaveLength(0);
    expect(refundEvents(db, MAR)).toHaveLength(1);
    expect(collectionEvents(db, JAN)).toHaveLength(1);
    expect(collectionEvents(db, MAR)).toHaveLength(0);
  });

  it('across all time the refund nets out', () => {
    const all = computePeriod(db);
    expect(all.grossRevenue).toBe(1000);
    expect(all.refunds).toBe(1000);
    expect(all.netRevenue).toBe(0);
  });
});

describe('canonical period arithmetic', () => {
  const db: Database = {
    ...emptyish(),
    orders: [
      mkOrder({ id: 'o-1', total: 1000, total_cost: 600 }),
      mkOrder({ id: 'o-2', total: 500, total_cost: 200, order_number: 'ORD-2' }),
      // cancelled orders never count
      mkOrder({ id: 'o-3', total: 9999, total_cost: 9999, status: 'cancelled', order_number: 'ORD-3' }),
    ],
    payments: [
      mkPayment({ id: 'p1', order_id: 'o-1', amount: 1000 }),
      mkPayment({ id: 'p2', order_id: 'o-2', amount: 500 }),
      mkPayment({ id: 'r1', order_id: 'o-2', amount: 200, is_refund: true }),
    ],
    expenses: [
      { id: 'e-1', organization_id: ORG, category: 'office', description: 'rent',
        amount: 300, spent_at: '2026-01-20T00:00:00.000Z',
        created_at: '2026-01-20T00:00:00.000Z', updated_at: '2026-01-20T00:00:00.000Z', deleted_at: null },
    ],
  } as unknown as Database;

  it('excludes cancelled orders from revenue', () => {
    expect(computePeriod(db, JAN).grossRevenue).toBe(1500);
  });

  it('every figure reconciles', () => {
    const p = computePeriod(db, JAN);
    expect(p.grossRevenue).toBe(1500);
    expect(p.refunds).toBe(200);
    expect(p.netRevenue).toBe(1300);
    expect(p.productCost).toBe(800);
    expect(p.grossProfit).toBe(500);      // 1300 - 800
    expect(p.operatingExpenses).toBe(300);
    expect(p.netProfit).toBe(200);        // 500 - 300
    expect(reconcile(db, JAN)).toEqual([]);
  });

  it('AOV uses gross revenue over counted orders only', () => {
    const p = computePeriod(db, JAN);
    expect(p.orderCount).toBe(2);
    expect(p.aov).toBe(750);
  });

  it('refund rate is date-aware and net-based', () => {
    expect(refundRateFor(db, JAN)).toBeCloseTo(13.33, 1);
  });

  it('margins derive from the same numbers as the P&L', () => {
    const p = computePeriod(db, JAN);
    expect(p.grossMargin).toBeCloseTo((500 / 1500) * 100, 2);
    expect(p.netMargin).toBeCloseTo((200 / 1500) * 100, 2);
  });
});

describe('customer value is net of refunds', () => {
  const db: Database = {
    ...emptyish(),
    customers: [
      { id: 'c-1', organization_id: ORG, customer_code: 'DT-1', name: 'A', deleted_at: null },
      { id: 'c-2', organization_id: ORG, customer_code: 'DT-2', name: 'B', deleted_at: null },
    ],
    orders: [
      mkOrder({ id: 'o-1', customer_id: 'c-1', total: 1000 }),
      mkOrder({ id: 'o-2', customer_id: 'c-2', total: 1000, order_number: 'ORD-2' }),
    ],
    payments: [
      mkPayment({ id: 'p1', order_id: 'o-1', customer_id: 'c-1', amount: 1000 }),
      mkPayment({ id: 'p2', order_id: 'o-2', customer_id: 'c-2', amount: 1000 }),
      mkPayment({ id: 'r1', order_id: 'o-2', customer_id: 'c-2', amount: 1000, is_refund: true }),
    ],
  } as unknown as Database;

  it('a fully refunded customer has zero net value', () => {
    const v = customerValue(db, 'c-2');
    expect(v.gross).toBe(1000);
    expect(v.refunded).toBe(1000);
    expect(v.net).toBe(0);
    expect(v.collected).toBe(0);
  });

  it('an unrefunded customer keeps full value', () => {
    expect(customerValue(db, 'c-1').net).toBe(1000);
  });

  it('average CLV subtracts refunds', () => {
    // gross 2000, refunded 1000, 2 customers -> 500 each
    expect(averageLifetimeValue(db)).toBe(500);
  });

  it('a refund is never attributed to the wrong customer', () => {
    expect(customerValue(db, 'c-1').refunded).toBe(0);
  });
});

describe('top products use net revenue', () => {
  const db: Database = {
    ...emptyish(),
    orders: [
      mkOrder({
        id: 'o-1', total: 1000,
        items: [{ id: 'i-1', order_id: 'o-1', product_id: 'prod-A', product_name: 'Netflix',
                  quantity: 1, line_total: 1000 } as unknown as Order['items'][number]],
      }),
      mkOrder({
        id: 'o-2', total: 800, order_number: 'ORD-2',
        items: [{ id: 'i-2', order_id: 'o-2', product_id: 'prod-B', product_name: 'Spotify',
                  quantity: 1, line_total: 800 } as unknown as Order['items'][number]],
      }),
    ],
    payments: [
      // Netflix order fully refunded -> Spotify must outrank it on net.
      mkPayment({ id: 'r1', order_id: 'o-1', amount: 1000, is_refund: true }),
    ],
  } as unknown as Database;

  it('a refunded product drops below an unrefunded one', () => {
    const top = topProductsByNet(db, JAN);
    expect(top[0].name).toBe('Spotify');
    expect(top[0].net).toBe(800);
    const netflix = top.find((t) => t.name === 'Netflix')!;
    expect(netflix.gross).toBe(1000);
    expect(netflix.net).toBe(0);
  });

  it('top-product totals never exceed period revenue', () => {
    expect(reconcile(db, JAN)).toEqual([]);
  });
});

describe('reconciliation over the real seed dataset', () => {
  const db = buildSeed();

  it('all-time figures are internally consistent', () => {
    expect(reconcile(db)).toEqual([]);
  });

  it('every monthly slice of 2026 reconciles', () => {
    for (let m = 0; m < 12; m++) {
      const from = new Date(Date.UTC(2026, m, 1));
      const to = new Date(Date.UTC(2026, m + 1, 0, 23, 59, 59));
      const issues = reconcile(db, { from, to, label: `m${m}` } as DateRange);
      expect(issues, `month ${m + 1}: ${issues.join('; ')}`).toEqual([]);
    }
  });

  it('outstanding is a balance, identical across period slices', () => {
    const a = computePeriod(db, JAN).outstanding;
    const b = computePeriod(db, MAR).outstanding;
    const c = computePeriod(db).outstanding;
    expect(a).toBe(b);
    expect(b).toBe(c);
  });
});
