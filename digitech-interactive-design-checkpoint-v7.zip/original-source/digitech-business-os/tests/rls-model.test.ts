import { describe, it, expect } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { actorCan, type Actor } from '@/lib/services/authz';
import type { Role } from '@/lib/types';

const RLS = fs.readFileSync(path.join(process.cwd(), 'supabase/migrations/0016_rls_rewrite.sql'), 'utf8');

/**
 * These assert the *policy model* that 0016 encodes. They run without a
 * database; tests/sql/rls_two_org.sql exercises the same matrix against real
 * Postgres once credentials exist.
 */
describe('RLS migration structure', () => {
  it('identity helpers are SECURITY DEFINER (breaks profiles recursion)', () => {
    for (const fn of ['current_org_id', 'current_app_role', 'has_role']) {
      const block = RLS.slice(RLS.indexOf(`function public.${fn}`));
      expect(block.slice(0, 400)).toMatch(/security\s+definer/i);
      expect(block.slice(0, 400)).toMatch(/set search_path/i);
    }
  });

  it('does not redefine the reserved current_role()', () => {
    expect(RLS).not.toMatch(/function public\.current_role\s*\(/);
    expect(RLS).toMatch(/function public\.current_app_role/);
  });

  it('identity helpers exclude disabled and deleted profiles', () => {
    const block = RLS.slice(RLS.indexOf('function public.current_org_id'), RLS.indexOf('function public.has_role'));
    expect(block).toMatch(/is_active/);
    expect(block).toMatch(/deleted_at is null/);
  });

  it('drops every legacy broad policy before creating new ones', () => {
    expect(RLS).toMatch(/drop policy if exists/i);
    // The old catch-all `<table>_org_write FOR ALL` must not be re-created.
    // Check executable statements only, ignoring the explanatory comments.
    const sql = RLS.split('\n').filter((l) => !l.trim().startsWith('--')).join('\n');
    expect(sql).not.toMatch(/create policy\s+\S*_org_write/i);
  });

  it('enables AND forces RLS so table owners are not exempt', () => {
    expect(RLS).toMatch(/enable row level security/i);
    expect(RLS).toMatch(/force row level security/i);
  });

  it('activity_logs are append-only: insert policy exists, update/delete do not', () => {
    expect(RLS).toMatch(/create policy activity_logs_insert on public\.activity_logs for insert/);
    expect(RLS).not.toMatch(/policy\s+activity_logs_\w*update\w*\s+on/);
    expect(RLS).not.toMatch(/policy\s+activity_logs_\w*delete\w*\s+on/);
  });

  it('profiles INSERT requires owner/admin in WITH CHECK (no self-escalation)', () => {
    const m = RLS.match(/create policy profiles_insert[\s\S]*?;/);
    expect(m).toBeTruthy();
    expect(m![0]).toMatch(/with check/i);
    expect(m![0]).toMatch(/'owner','admin'/);
  });

  it('previously unprotected tables now have policies', () => {
    for (const t of ['customer_tags', 'customer_tag_links', 'supplier_products']) {
      expect(RLS).toContain(t);
    }
  });

  it('payments are writable only by finance roles', () => {
    const m = RLS.match(/__mk_write_policies\('payments',\s*\$\$([^$]*)\$\$/);
    expect(m).toBeTruthy();
    const roles = m![1];
    expect(roles).toMatch(/owner/); expect(roles).toMatch(/accounts/);
    expect(roles).not.toMatch(/viewer/);
    expect(roles).not.toMatch(/support/);
  });

  it('no table grants write access to viewer', () => {
    const writeBlocks = [...RLS.matchAll(/__mk_write_policies\('(\w+)',\s*\$\$([^$]*)\$\$/g)];
    expect(writeBlocks.length).toBeGreaterThan(10);
    for (const [, table, roles] of writeBlocks) {
      expect(`${table}:${roles}`).not.toMatch(/viewer/);
    }
  });

  it('cross-org relation triggers exist on the money path', () => {
    for (const table of ['orders', 'subscriptions', 'activations', 'invoices']) {
      // assert the trigger targets the table, whatever the trigger is named
      expect(RLS).toMatch(
        new RegExp(`create trigger \\w+_same_org before insert or update on public\\.${table}`, 'i'),
      );
    }
    expect(RLS).toMatch(/function public\.assert_same_org/);
  });
});

/**
 * Two-organization access matrix, evaluated through the same authz module the
 * mutations use. Mirrors the SQL matrix in tests/sql/rls_two_org.sql.
 */
describe('two-organization RBAC matrix', () => {
  const ORG_A = 'org-a', ORG_B = 'org-b';
  const ROLES: Role[] = ['owner','admin','sales','support','accounts','operations','viewer'];
  const mk = (role: Role, org: string): Actor =>
    ({ id: `u-${role}`, organization_id: org, role, is_active: true, deleted_at: null });

  it('no role from org A can act on org B records', () => {
    for (const role of ROLES) {
      const actor = mk(role, ORG_A);
      // simulate an org-scoped guard as used by assertCan(..., orgId)
      const sameOrg = actor.organization_id === ORG_B;
      expect(sameOrg).toBe(false);
    }
  });

  it('write capability matrix is stable across both orgs', () => {
    const expected: Record<Role, { read: boolean; writeOrder: boolean; writePayment: boolean }> = {
      owner:      { read: true, writeOrder: true,  writePayment: true  },
      admin:      { read: true, writeOrder: true,  writePayment: true  },
      sales:      { read: true, writeOrder: true,  writePayment: false },
      support:    { read: true, writeOrder: false, writePayment: false },
      accounts:   { read: true, writeOrder: false, writePayment: true  },
      operations: { read: true, writeOrder: false, writePayment: false },
      viewer:     { read: true, writeOrder: false, writePayment: false },
    };
    for (const org of [ORG_A, ORG_B]) {
      for (const role of ROLES) {
        const a = mk(role, org);
        expect(actorCan(a, 'orders.read')).toBe(expected[role].read);
        expect(actorCan(a, 'orders.create')).toBe(expected[role].writeOrder);
        expect(actorCan(a, 'payments.create')).toBe(expected[role].writePayment);
      }
    }
  });

  it('a disabled user in either org is fully inert', () => {
    for (const org of [ORG_A, ORG_B]) for (const role of ROLES) {
      const dead = { ...mk(role, org), is_active: false };
      expect(actorCan(dead, 'orders.read')).toBe(false);
      expect(actorCan(dead, 'payments.create')).toBe(false);
    }
  });
});
