import { describe, it, expect, beforeAll } from 'vitest';
import type { PGlite } from '@electric-sql/pglite';
import { bootDatabase, actAs } from './helpers/pg';

/**
 * Two-organization RLS integration tests executed against a real PostgreSQL
 * instance with every migration applied. These exercise the policies
 * themselves — tenant isolation, the role write matrix, append-only audit,
 * privilege escalation and cross-org relation rejection.
 */
const ORG_A = 'aaaaaaaa-0000-4000-8000-000000000001';
const ORG_B = 'bbbbbbbb-0000-4000-8000-000000000002';
const ROLES = ['owner','admin','sales','support','accounts','operations','viewer'] as const;
type R = (typeof ROLES)[number];

// Deterministic, valid hex UUIDs: org digit + role index.
const uid = (org: 'a' | 'b', role: R) =>
  `${org === 'a' ? '1' : '2'}0000000-0000-4000-8000-0000000000${String(ROLES.indexOf(role) + 1).padStart(2, '0')}`;

const CUST_A = 'c0000000-0000-4000-8000-00000000000a';
const CUST_B = 'c0000000-0000-4000-8000-00000000000b';
const DISABLED = '99999999-0000-4000-8000-000000000099';

let db: PGlite;

/** true when the statement was rejected OR silently filtered to zero rows. */
let lastError = '';
async function blocked(sql: string, params: unknown[] = []) {
  lastError = '';
  try {
    const r = await db.query(sql, params as never[]);
    if (/^\s*(update|delete)/i.test(sql)) {
      return ((r as { affectedRows?: number }).affectedRows ?? 0) === 0;
    }
    return false;
  } catch (e) {
    lastError = (e as Error).message;
    return true;
  }
}

beforeAll(async () => {
  db = (await bootDatabase()).db;
  // Seeded demo data would pollute isolation counts.
  await db.exec(`set session role none;`);
  await db.exec(`
    delete from payments; delete from order_items; delete from orders;
    delete from customers; delete from profiles; delete from organizations;
  `);
  await db.query(
    `insert into organizations (id, name, currency, timezone) values ($1,'Org A','INR','Asia/Kolkata'), ($2,'Org B','INR','Asia/Kolkata')`,
    [ORG_A, ORG_B],
  );
  // 0003 adds a conditional FK to auth.users when that table exists, so the
  // auth rows must exist first. This also exercises that FK path.
  await db.exec(`delete from auth.users;`);
  for (const org of ['a', 'b'] as const) {
    for (const role of ROLES) {
      await db.query(`insert into auth.users (id, email) values ($1,$2)`, [uid(org, role), `${role}.${org}@test.local`]);
    }
  }
  await db.query(`insert into auth.users (id, email) values ($1,'disabled@test.local')`, [DISABLED]);

  for (const [org, orgId] of [['a', ORG_A], ['b', ORG_B]] as const) {
    for (const role of ROLES) {
      await db.query(
        `insert into profiles (organization_id, auth_user_id, full_name, email, role, is_active)
         values ($1,$2,$3,$4,$5::app_role,true)`,
        [orgId, uid(org, role), `${role} ${org}`, `${role}.${org}@test.local`, role],
      );
    }
  }
  await db.query(
    `insert into profiles (organization_id, auth_user_id, full_name, email, role, is_active)
     values ($1,$2,'Disabled Owner','disabled@test.local','owner',false)`, [ORG_A, DISABLED],
  );
  await db.query(
    `insert into customers (id, organization_id, customer_code, name, phone)
     values ($1,$2,'DT-1','A Customer','9000000001'), ($3,$4,'DT-1','B Customer','9000000002')`,
    [CUST_A, ORG_A, CUST_B, ORG_B],
  );
  // Enforce RLS for the rest of the suite (superuser bypasses it otherwise).
  await db.exec(`set session role authenticated;`);
}, 180_000);

describe('tenant isolation across two organizations', () => {
  it('each role sees only its own organization customers', async () => {
    for (const role of ROLES) {
      await actAs(db, uid('a', role));
      const r = await db.query<{ n: number; name: string }>(`select count(*)::int n from customers`);
      expect(r.rows[0].n, `${role} in org A`).toBe(1);
      const who = await db.query<{ name: string }>(`select name from customers`);
      expect(who.rows[0].name, `${role} in org A`).toBe('A Customer');
    }
    for (const role of ROLES) {
      await actAs(db, uid('b', role));
      const who = await db.query<{ name: string }>(`select name from customers`);
      expect(who.rows.map((x) => x.name), `${role} in org B`).toEqual(['B Customer']);
    }
  });

  it('an unauthenticated session sees nothing', async () => {
    await actAs(db, null);
    const r = await db.query<{ n: number }>(`select count(*)::int n from customers`);
    expect(r.rows[0].n).toBe(0);
  });

  it('org A owner cannot insert a row into org B', async () => {
    await actAs(db, uid('a', 'owner'));
    expect(await blocked(
      `insert into customers (organization_id, customer_code, name) values ($1,'DT-X','Cross')`, [ORG_B],
    )).toBe(true);
  });

  it('org A owner cannot update or delete org B rows', async () => {
    await actAs(db, uid('a', 'owner'));
    expect(await blocked(`update customers set name='hacked' where id=$1`, [CUST_B])).toBe(true);
    expect(await blocked(`delete from customers where id=$1`, [CUST_B])).toBe(true);
    await actAs(db, uid('b', 'owner'));
    const r = await db.query<{ name: string }>(`select name from customers where id=$1`, [CUST_B]);
    expect(r.rows[0].name).toBe('B Customer');
  });
});

describe('role write matrix (enforced in both organizations)', () => {
  const canWriteCustomers: Record<R, boolean> = {
    owner: true, admin: true, sales: true, support: true,
    accounts: false, operations: false, viewer: false,
  };
  const canWritePayments: Record<R, boolean> = {
    owner: true, admin: true, accounts: true,
    sales: false, support: false, operations: false, viewer: false,
  };
  const canWriteProducts: Record<R, boolean> = {
    owner: true, admin: true, operations: true,
    sales: false, support: false, accounts: false, viewer: false,
  };

  it('customers insert follows the matrix in both orgs', async () => {
    for (const [org, orgId] of [['a', ORG_A], ['b', ORG_B]] as const) {
      for (const role of ROLES) {
        await actAs(db, uid(org, role));
        const denied = await blocked(
          `insert into customers (organization_id, customer_code, name) values ($1,$2,'Probe')`,
          [orgId, `PROBE-${org}-${role}`],
        );
        expect(denied, `${role}/${org} customers.insert`).toBe(!canWriteCustomers[role]);
      }
    }
  });

  it('products insert follows the matrix', async () => {
    for (const role of ROLES) {
      await actAs(db, uid('a', role));
      const denied = await blocked(
        `insert into products (organization_id, name, code, product_type, selling_price, cost_price)
         values ($1,$2,$3,'subscription',100,50)`, [ORG_A, `Probe ${role}`, `PRB-${role}`],
      );
      expect(denied, `${role} products.insert`).toBe(!canWriteProducts[role]);
    }
  });

  it('payments insert is restricted to finance roles', async () => {
    await actAs(db, uid('a', 'owner'));
    await db.query(
      `insert into orders (id, organization_id, order_number, customer_id, status, payment_status,
                           subtotal, discount, tax, total, ordered_at)
       values ('d0000000-0000-4000-8000-00000000000a',$1,'ORD-9001',$2,'new','pending',1000,0,0,1000,now())`,
      [ORG_A, CUST_A],
    );
    for (const role of ROLES) {
      await actAs(db, uid('a', role));
      const denied = await blocked(
        `insert into payments (organization_id, order_id, customer_id, amount, method, status, is_refund, paid_at)
         values ($1,'d0000000-0000-4000-8000-00000000000a',$2,1,'upi','paid',false,now())`,
        [ORG_A, CUST_A],
      );
      expect(denied, `${role} payments.insert (${lastError})`).toBe(!canWritePayments[role]);
    }
  });

  it('no role may write to a table it does not own, in either org', async () => {
    for (const org of ['a', 'b'] as const) {
      await actAs(db, uid(org, 'viewer'));
      for (const stmt of [
        `insert into expenses (organization_id, category, description, amount, spent_at) values ($1,'office','x',1,now())`,
        `insert into tasks (organization_id, title, status) values ($1,'x','open')`,
        `insert into support_tickets (organization_id, ticket_number, subject, status) values ($1,'TKT-1','x','open')`,
      ]) {
        expect(await blocked(stmt, [org === 'a' ? ORG_A : ORG_B]), `viewer/${org}: ${stmt.slice(12, 40)}`).toBe(true);
      }
    }
  });
});

describe('disabled profiles are completely inert', () => {
  it('resolve to a null org, read nothing and write nothing', async () => {
    await actAs(db, DISABLED);
    const org = await db.query<{ o: string | null }>(`select public.current_org_id() o`);
    expect(org.rows[0].o).toBeNull();
    const seen = await db.query<{ n: number }>(`select count(*)::int n from customers`);
    expect(seen.rows[0].n).toBe(0);
    expect(await blocked(
      `insert into customers (organization_id, customer_code, name) values ($1,'DT-D','Disabled')`, [ORG_A],
    )).toBe(true);
  });
});

describe('privilege escalation via profiles is impossible', () => {
  it('non-admin roles cannot create any profile', async () => {
    for (const role of ['sales','support','accounts','operations','viewer'] as const) {
      await actAs(db, uid('a', role));
      expect(await blocked(
        `insert into profiles (organization_id, full_name, email, role, is_active)
         values ($1,'Evil',$2,'owner',true)`, [ORG_A, `evil.${role}@test.local`],
      ), `${role} must not create profiles`).toBe(true);
    }
  });

  it('admin can create a profile, but only inside its own org', async () => {
    await actAs(db, uid('a', 'admin'));
    expect(await blocked(
      `insert into profiles (organization_id, full_name, email, role, is_active)
       values ($1,'Staff','staff.ok@test.local','sales',true)`, [ORG_A],
    )).toBe(false);
    expect(await blocked(
      `insert into profiles (organization_id, full_name, email, role, is_active)
       values ($1,'Cross','staff.cross@test.local','sales',true)`, [ORG_B],
    )).toBe(true);
  });
});

describe('activity logs are append-only for everyone', () => {
  it('members may insert but nobody may update or delete', async () => {
    await actAs(db, uid('a', 'owner'));
    await db.query(
      `insert into activity_logs (id, organization_id, action, record_type, record_id, summary)
       values ('11111111-0000-4000-8000-00000000001a',$1,'created','customer',$2,'seed')`,
      [ORG_A, CUST_A],
    );
    for (const role of ROLES) {
      await actAs(db, uid('a', role));
      expect(await blocked(
        `update activity_logs set summary='tampered' where id='11111111-0000-4000-8000-00000000001a'`,
      ), `${role} update audit`).toBe(true);
      expect(await blocked(
        `delete from activity_logs where id='11111111-0000-4000-8000-00000000001a'`,
      ), `${role} delete audit`).toBe(true);
    }
    await actAs(db, uid('a', 'owner'));
    const still = await db.query<{ summary: string }>(
      `select summary from activity_logs where id='11111111-0000-4000-8000-00000000001a'`);
    expect(still.rows[0].summary).toBe('seed');
  });
});

describe('cross-organization relations are rejected at the data layer', () => {
  it('an order cannot reference a customer from another org', async () => {
    await actAs(db, uid('a', 'owner'));
    expect(await blocked(
      `insert into orders (organization_id, order_number, customer_id, status, payment_status,
                           subtotal, discount, tax, total, ordered_at)
       values ($1,'ORD-CROSS',$2,'new','pending',100,0,0,100,now())`,
      [ORG_A, CUST_B],
    )).toBe(true);
  });
});
