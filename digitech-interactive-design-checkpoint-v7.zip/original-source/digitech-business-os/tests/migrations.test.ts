import { describe, it, expect, beforeAll } from 'vitest';
import type { PGlite } from '@electric-sql/pglite';
import fs from 'node:fs';
import path from 'node:path';
import { bootDatabase, MIGRATION_FILES } from './helpers/pg';

let db: PGlite;
let applied: string[] = [];

beforeAll(async () => {
  const booted = await bootDatabase();
  db = booted.db;
  applied = booted.applied;
}, 180_000);

describe('migrations apply to a clean Postgres database', () => {
  it('every migration executes without error', () => {
    expect(applied).toEqual(MIGRATION_FILES);
    expect(applied.length).toBeGreaterThanOrEqual(16);
  });

  it('core tables exist', async () => {
    const r = await db.query<{ table_name: string }>(
      `select table_name from information_schema.tables where table_schema='public'`,
    );
    const names = r.rows.map((x) => x.table_name);
    for (const t of ['organizations','profiles','customers','orders','payments','subscriptions','invoices','approval_requests','action_jobs','activity_logs']) {
      expect(names).toContain(t);
    }
  });

  it('RLS is enabled AND forced on tenant tables', async () => {
    const r = await db.query<{ relname: string; relrowsecurity: boolean; relforcerowsecurity: boolean }>(
      `select relname, relrowsecurity, relforcerowsecurity from pg_class
        where relname in ('customers','orders','payments','approval_requests','action_jobs','activity_logs') and relkind='r'`,
    );
    expect(r.rows.length).toBeGreaterThan(0);
    for (const row of r.rows) {
      expect(row.relrowsecurity).toBe(true);
      expect(row.relforcerowsecurity).toBe(true);
    }
  });

  it('identity helpers are SECURITY DEFINER', async () => {
    const r = await db.query<{ proname: string; prosecdef: boolean }>(
      `select proname, prosecdef from pg_proc p join pg_namespace n on n.oid=p.pronamespace
        where n.nspname='public' and proname in ('current_org_id','current_app_role','has_role')`,
    );
    expect(r.rows.length).toBe(3);
    for (const row of r.rows) expect(row.prosecdef).toBe(true);
  });

  it('activity_logs has an INSERT policy but no UPDATE/DELETE policy', async () => {
    const r = await db.query<{ cmd: string }>(
      `select cmd from pg_policies where schemaname='public' and tablename='activity_logs'`,
    );
    const cmds = r.rows.map((x) => x.cmd);
    expect(cmds).toContain('INSERT');
    expect(cmds).not.toContain('UPDATE');
    expect(cmds).not.toContain('DELETE');
  });

  it('action jobs are visible to reviewers but never client-writable', async () => {
    const r = await db.query<{ cmd: string }>(
      `select cmd from pg_policies where schemaname='public' and tablename='action_jobs'`,
    );
    const cmds = r.rows.map((x) => x.cmd);
    expect(cmds).toEqual(['SELECT']);
  });

  it('no legacy catch-all *_org_write policy survives', async () => {
    const r = await db.query<{ policyname: string }>(
      `select policyname from pg_policies where schemaname='public' and policyname like '%_org_write'`,
    );
    expect(r.rows).toEqual([]);
  });

  it('idempotency indexes exist', async () => {
    const r = await db.query<{ indexname: string }>(
      `select indexname from pg_indexes where schemaname='public'
        and indexname in ('uq_subscriptions_source_activation','uq_subscriptions_order_item')`,
    );
    expect(r.rows.length).toBe(2);
  });

  it('migrations are idempotent enough to re-run the last one', async () => {
    const last = fs.readFileSync(path.join(process.cwd(), 'supabase/migrations/0016_rls_rewrite.sql'), 'utf8');
    await expect(db.exec(last)).resolves.toBeDefined();
  });
});
