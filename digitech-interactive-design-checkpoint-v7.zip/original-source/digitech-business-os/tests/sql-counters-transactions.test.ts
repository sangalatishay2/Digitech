import { describe, it, expect, beforeAll } from 'vitest';
import type { PGlite } from '@electric-sql/pglite';
import { bootDatabase, actAs } from './helpers/pg';

/**
 * Atomic business numbering and transactional/idempotent writes (migration
 * 0017), executed against real Postgres.
 */
const ORG = 'aaaaaaaa-0000-4000-8000-000000000001';
const ORG_B = 'bbbbbbbb-0000-4000-8000-000000000002';
const CUST = 'c0000000-0000-4000-8000-00000000000a';
const OWNER = '10000000-0000-4000-8000-000000000001';
const OWNER_B = '20000000-0000-4000-8000-000000000001';

let db: PGlite;

beforeAll(async () => {
  db = (await bootDatabase()).db;
  await db.exec(`delete from payments; delete from order_items; delete from orders;
                 delete from invoices; delete from support_tickets; delete from customers;
                 delete from profiles; delete from organizations; delete from auth.users;`);
  await db.query(`insert into auth.users (id,email) values ($1,'o@a.local'),($2,'o@b.local')`, [OWNER, OWNER_B]);
  await db.query(
    `insert into organizations (id,name,currency,timezone) values ($1,'A','INR','Asia/Kolkata'),($2,'B','INR','Asia/Kolkata')`,
    [ORG, ORG_B]);
  await db.query(
    `insert into profiles (organization_id, auth_user_id, full_name, email, role, is_active)
     values ($1,$2,'Owner A','o@a.local','owner',true),($3,$4,'Owner B','o@b.local','owner',true)`,
    [ORG, OWNER, ORG_B, OWNER_B]);
  await db.query(
    `insert into customers (id,organization_id,customer_code,name,phone) values ($1,$2,'DT-1','A','9000000001')`,
    [CUST, ORG]);
  await db.exec(`set session role authenticated;`);
  await actAs(db, OWNER);
}, 180_000);

describe('atomic business numbering', () => {
  it('issues strictly increasing, never-duplicated order numbers', async () => {
    const seen = new Set<string>();
    for (let i = 0; i < 25; i++) {
      const r = await db.query<{ n: string }>(`select public.next_business_number('order') n`);
      const n = r.rows[0].n;
      expect(n.startsWith('ORD-')).toBe(true);
      expect(seen.has(n), `duplicate number ${n}`).toBe(false);
      seen.add(n);
    }
    expect(seen.size).toBe(25);
  });

  it('numbering is independent per organization', async () => {
    await actAs(db, OWNER);
    const a = await db.query<{ n: string }>(`select public.next_business_number('invoice') n`);
    await actAs(db, OWNER_B);
    const b = await db.query<{ n: string }>(`select public.next_business_number('invoice') n`);
    // Both orgs start their own invoice series.
    expect(a.rows[0].n).toBe('INV-501');
    expect(b.rows[0].n).toBe('INV-501');
    await actAs(db, OWNER);
  });

  it('seeds from existing data so it never collides with historic codes', async () => {
    await actAs(db, OWNER);
    await db.query(
      `insert into support_tickets (organization_id, ticket_number, customer_id, subject, status)
       values ($1,'TKT-2050',$2,'existing','open')`, [ORG, CUST]);
    const r = await db.query<{ n: string }>(`select public.next_business_number('ticket') n`);
    // Must continue past TKT-2050, not restart at TKT-2000.
    expect(Number(r.rows[0].n.replace('TKT-', ''))).toBeGreaterThan(2050);
  });

  it('rejects an unknown number kind', async () => {
    await expect(db.query(`select public.next_business_number('bogus')`)).rejects.toThrow();
  });

  it('a unique index blocks duplicate order numbers even if app code is bypassed', async () => {
    await db.query(
      `insert into orders (organization_id, order_number, customer_id, status, payment_status,
                           subtotal, discount, tax, total, ordered_at)
       values ($1,'ORD-DUP',$2,'new','pending',10,0,0,10,now())`, [ORG, CUST]);
    await expect(db.query(
      `insert into orders (organization_id, order_number, customer_id, status, payment_status,
                           subtotal, discount, tax, total, ordered_at)
       values ($1,'ORD-DUP',$2,'new','pending',10,0,0,10,now())`, [ORG, CUST],
    )).rejects.toThrow();
  });

  it('counters are not directly writable (no write policy)', async () => {
    let blocked = false;
    try {
      const r = await db.query(`update number_counters set next_value = 1 where organization_id = $1`, [ORG]);
      blocked = ((r as { affectedRows?: number }).affectedRows ?? 0) === 0;
    } catch { blocked = true; }
    expect(blocked).toBe(true);
  });
});

describe('transactional apply with idempotency', () => {
  it('applies every operation in one batch', async () => {
    const ops = [
      { kind: 'insert', table: 'customers',
        row: { organization_id: ORG, customer_code: 'DT-TX1', name: 'Tx One', phone: '9111111111' } },
      { kind: 'insert', table: 'customers',
        row: { organization_id: ORG, customer_code: 'DT-TX2', name: 'Tx Two', phone: '9222222222' } },
    ];
    const r = await db.query<{ apply_transaction: number }>(
      `select public.apply_transaction($1::jsonb, $2)`, [JSON.stringify(ops), 'key-batch-1']);
    expect(Number(r.rows[0].apply_transaction)).toBe(2);
    const c = await db.query<{ n: number }>(
      `select count(*)::int n from customers where customer_code in ('DT-TX1','DT-TX2')`);
    expect(c.rows[0].n).toBe(2);
  });

  it('replaying the same idempotency key does not duplicate work', async () => {
    const ops = [
      { kind: 'insert', table: 'customers',
        row: { organization_id: ORG, customer_code: 'DT-TX1', name: 'Tx One', phone: '9111111111' } },
      { kind: 'insert', table: 'customers',
        row: { organization_id: ORG, customer_code: 'DT-TX2', name: 'Tx Two', phone: '9222222222' } },
    ];
    // Same key as above — must be a no-op returning the original count.
    const r = await db.query<{ apply_transaction: number }>(
      `select public.apply_transaction($1::jsonb, $2)`, [JSON.stringify(ops), 'key-batch-1']);
    expect(Number(r.rows[0].apply_transaction)).toBe(2);
    const c = await db.query<{ n: number }>(
      `select count(*)::int n from customers where customer_code in ('DT-TX1','DT-TX2')`);
    expect(c.rows[0].n).toBe(2); // still 2, not 4
  });

  it('rolls the whole batch back when one operation fails', async () => {
    const before = await db.query<{ n: number }>(`select count(*)::int n from customers`);
    const ops = [
      { kind: 'insert', table: 'customers',
        row: { organization_id: ORG, customer_code: 'DT-OK', name: 'Should Roll Back', phone: '9333333333' } },
      // Duplicate code -> violates (organization_id, customer_code) unique.
      { kind: 'insert', table: 'customers',
        row: { organization_id: ORG, customer_code: 'DT-TX1', name: 'Dup', phone: '9444444444' } },
    ];
    await expect(db.query(
      `select public.apply_transaction($1::jsonb, $2)`, [JSON.stringify(ops), 'key-batch-fail'],
    )).rejects.toThrow();
    const after = await db.query<{ n: number }>(`select count(*)::int n from customers`);
    expect(after.rows[0].n).toBe(before.rows[0].n);
    const orphan = await db.query<{ n: number }>(
      `select count(*)::int n from customers where customer_code='DT-OK'`);
    expect(orphan.rows[0].n).toBe(0);
  });

  it('runs as the caller, so RLS still applies inside the transaction', async () => {
    // A viewer has no insert policy on customers; the batch must be rejected.
    const VIEWER = '10000000-0000-4000-8000-000000000007';
    await db.exec(`set session role none;`);
    await db.query(`insert into auth.users (id,email) values ($1,'v@a.local') on conflict do nothing`, [VIEWER]);
    await db.query(
      `insert into profiles (organization_id, auth_user_id, full_name, email, role, is_active)
       values ($1,$2,'Viewer','v@a.local','viewer',true) on conflict do nothing`, [ORG, VIEWER]);
    await db.exec(`set session role authenticated;`);
    await actAs(db, VIEWER);
    const ops = [{ kind: 'insert', table: 'customers',
      row: { organization_id: ORG, customer_code: 'DT-VIEWER', name: 'Nope', phone: '9555555555' } }];
    await expect(db.query(
      `select public.apply_transaction($1::jsonb, $2)`, [JSON.stringify(ops), 'key-viewer'],
    )).rejects.toThrow();
    await actAs(db, OWNER);
  });

  it('rejects an unknown table', async () => {
    const ops = [{ kind: 'insert', table: 'pg_shadow', row: { a: 1 } }];
    await expect(db.query(
      `select public.apply_transaction($1::jsonb, null)`, [JSON.stringify(ops)],
    )).rejects.toThrow();
  });
});
