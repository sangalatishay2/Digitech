import { describe, expect, it } from 'vitest';
import { buildFinanceSignals, buildInboxThreads, roleFocus } from '@/lib/services/intelligence';
import { buildSeed } from '@/lib/data/seed';

describe('operational intelligence', () => {
  it('groups multi-channel communication by customer and newest activity', () => {
    const db = buildSeed();
    const customer = db.customers[0];
    db.communication_logs = [
      { id: 'm1', organization_id: customer.organization_id, created_at: '2026-01-01T00:00:00Z', updated_at: '2026-01-01T00:00:00Z', deleted_at: null, channel: 'email', direction: 'outbound', customer_id: customer.id, to_address: 'a@example.com', body: 'First', status: 'sent', provider: 'test' },
      { id: 'm2', organization_id: customer.organization_id, created_at: '2026-01-02T00:00:00Z', updated_at: '2026-01-02T00:00:00Z', deleted_at: null, channel: 'whatsapp', direction: 'inbound', customer_id: customer.id, to_address: '+91123', body: 'Latest', status: 'sent', provider: 'test' },
    ];
    const threads = buildInboxThreads(db);
    expect(threads).toHaveLength(1);
    expect(threads[0].messages).toHaveLength(2);
    expect(threads[0].latestBody).toBe('Latest');
  });

  it('flags large receivables and negative-margin orders', () => {
    const db = buildSeed();
    const order = db.orders[0];
    order.outstanding = 60_000;
    order.total = 10;
    order.amount_refunded = 0;
    order.items[0].unit_cost = 1000;
    const signals = buildFinanceSignals(db);
    expect(signals.some((item) => item.id === `receivable-${order.id}` && item.severity === 'critical')).toBe(true);
    expect(signals.some((item) => item.id === `margin-${order.id}`)).toBe(true);
  });

  it('returns different focus links for support and accounts roles', () => {
    expect(roleFocus('support').some((item) => item.href === '/inbox')).toBe(true);
    expect(roleFocus('accounts').some((item) => item.href === '/finance/intelligence')).toBe(true);
  });
});
