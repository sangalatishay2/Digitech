import { beforeAll, describe, expect, it } from 'vitest';
import type { PGlite } from '@electric-sql/pglite';
import { actAs, bootDatabase, denied } from './helpers/pg';

const OWNER_UID = '71000000-0000-4000-8000-000000000001';
const ACCOUNTS_UID = '71000000-0000-4000-8000-000000000002';
let db: PGlite;
let customerId = '';
let productId = '';

beforeAll(async () => {
  db = (await bootDatabase()).db;
  await db.exec('set session role none');
  await db.query(`insert into auth.users (id,email) values ($1,'mobile-owner@test.local'),($2,'mobile-accounts@test.local')`, [OWNER_UID, ACCOUNTS_UID]);
  await db.query(`update profiles set auth_user_id=$1 where email='atishay@digitech.in'`, [OWNER_UID]);
  await db.query(`update profiles set auth_user_id=$1 where email='vivek@digitech.in'`, [ACCOUNTS_UID]);
  customerId = (await db.query<{ id: string }>(`select id::text id from customers order by customer_code limit 1`)).rows[0].id;
  productId = (await db.query<{ id: string }>(`select id::text id from products order by code limit 1`)).rows[0].id;
  await db.exec('set session role authenticated');
}, 180_000);

describe('mobile authoritative business contracts', () => {
  it('creates order, item, activation, and payment atomically and idempotently', async () => {
    await actAs(db, OWNER_UID);
    const params = [customerId, productId, 2, 1000, 100, 'upi', 1900, 'Mobile test', null, 'mobile-order:test-1'];
    const first = await db.query<{ id: string }>(
      `select mobile_create_order($1,$2,$3,$4,$5,$6::payment_method,$7,$8,$9,$10)::text id`, params,
    );
    const second = await db.query<{ id: string }>(
      `select mobile_create_order($1,$2,$3,$4,$5,$6::payment_method,$7,$8,$9,$10)::text id`, params,
    );
    expect(second.rows[0].id).toBe(first.rows[0].id);
    const counts = await db.query<{ orders: number; items: number; activations: number; payments: number }>(
      `select
        (select count(*)::int from orders where id=$1) orders,
        (select count(*)::int from order_items where order_id=$1) items,
        (select count(*)::int from activations where order_id=$1) activations,
        (select count(*)::int from payments where order_id=$1) payments`, [first.rows[0].id],
    );
    expect(counts.rows[0]).toEqual({ orders: 1, items: 1, activations: 1, payments: 1 });
  });

  it('does not let the accounts role create sales orders', async () => {
    await actAs(db, ACCOUNTS_UID);
    expect(await denied(db,
      `select mobile_create_order($1,$2,1,100,0,'upi'::payment_method,0,null,null,'mobile-order:denied')`,
      [customerId, productId],
    )).toBe(true);
  });

  it('rejects a cross-organization or unknown customer before any write', async () => {
    await actAs(db, OWNER_UID);
    const before = (await db.query<{ n: number }>(`select count(*)::int n from orders`)).rows[0].n;
    expect(await denied(db,
      `select mobile_create_order('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',$1,1,100,0,'upi'::payment_method,0,null,null,'mobile-order:missing')`,
      [productId],
    )).toBe(true);
    const after = (await db.query<{ n: number }>(`select count(*)::int n from orders`)).rows[0].n;
    expect(after).toBe(before);
  });
});
