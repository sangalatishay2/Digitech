import { describe, it, expect } from 'vitest';
import { deriveSubscriptionStatus } from '@/lib/services/business';
import type { Subscription } from '@/lib/types';

const sub = (expiryMsFromNow: number, status: Subscription['status'] = 'active'): Subscription =>
  ({ expiry_date: new Date(Date.now() + expiryMsFromNow).toISOString(), status } as Subscription);

const HOUR = 3600_000, DAY = 24 * HOUR;

describe('subscription expiry boundaries (time-accurate)', () => {
  it('already past expiry is expired', () => {
    expect(deriveSubscriptionStatus(sub(-1 * HOUR), 15)).toBe('expired');
    expect(deriveSubscriptionStatus(sub(-30 * DAY), 15)).toBe('expired');
  });

  it('expiring in a few hours is NOT yet expired', () => {
    // The SQL trigger used extract(day from interval) which truncates to 0,
    // so a subscription with 3 hours left was mis-bucketed. Guard that here.
    expect(deriveSubscriptionStatus(sub(3 * HOUR), 15)).not.toBe('expired');
  });

  it('inside the threshold is expiring', () => {
    expect(deriveSubscriptionStatus(sub(5 * DAY), 15)).toBe('expiring');
    expect(deriveSubscriptionStatus(sub(14 * DAY), 15)).toBe('expiring');
  });

  it('outside the threshold is active', () => {
    expect(deriveSubscriptionStatus(sub(60 * DAY), 15)).toBe('active');
  });

  it('threshold is respected per organization', () => {
    expect(deriveSubscriptionStatus(sub(20 * DAY), 30)).toBe('expiring');
    expect(deriveSubscriptionStatus(sub(20 * DAY), 15)).toBe('active');
  });

  it('terminal lifecycle states are never recomputed', () => {
    for (const st of ['renewed','cancelled','paused','pending'] as Subscription['status'][]) {
      expect(deriveSubscriptionStatus(sub(-100 * DAY, st), 15)).toBe(st);
    }
  });
});
