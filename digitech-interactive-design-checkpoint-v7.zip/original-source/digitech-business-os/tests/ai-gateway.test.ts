import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

let sessionOk = true;
const inserted: Array<Record<string, unknown>> = [];

vi.mock('@/lib/auth/server-session', () => ({
  sessionFromRequest: async () =>
    sessionOk
      ? {
          ok: true,
          session: {
            organizationId: 'org-a',
            profile: { id: 'profile-a' },
          },
        }
      : { ok: false, status: 401, reason: 'Missing bearer token.' },
  sessionErrorResponse: (outcome: { status: number; reason: string }) =>
    new Response(JSON.stringify({ error: outcome.reason }), { status: outcome.status }),
}));

vi.mock('@/lib/data/supabase-client', () => ({
  getServiceClient: () => ({
    from: () => ({
      insert: async (row: Record<string, unknown>) => {
        inserted.push(row);
        return { data: null, error: null };
      },
    }),
  }),
}));

const route = await import('@/app/api/ai/chat/route');
const originalEnv = { ...process.env };

function request(body: unknown): Request {
  return new Request('https://example.test/api/ai/chat', {
    method: 'POST',
    headers: { authorization: 'Bearer token', 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
}

beforeEach(() => {
  sessionOk = true;
  inserted.length = 0;
  process.env.OPENROUTER_API_KEY = 'openrouter-secret';
  process.env.GOOGLE_GENERATIVE_AI_API_KEY = 'google-secret';
});

afterEach(() => {
  process.env = { ...originalEnv };
  vi.unstubAllGlobals();
});

describe('AI gateway authorization and configuration', () => {
  it('fails closed without an authenticated business profile', async () => {
    sessionOk = false;
    expect((await route.POST(request({}))).status).toBe(401);
  });

  it('reports provider availability without exposing keys', async () => {
    const response = await route.GET(request({}));
    const body = await response.json();
    expect(body.providers.openrouter.configured).toBe(true);
    expect(JSON.stringify(body)).not.toContain('openrouter-secret');
    expect(JSON.stringify(body)).not.toContain('google-secret');
  });

  it('returns 503 when the selected provider is not configured', async () => {
    delete process.env.OPENROUTER_API_KEY;
    const response = await route.POST(
      request({ provider: 'openrouter', messages: [{ role: 'user', content: 'hello' }] }),
    );
    expect(response.status).toBe(503);
  });
});

describe('AI gateway validation', () => {
  it('supports arbitrary safe OpenRouter model slugs, including Nemotron', () => {
    const parsed = route.parseChatBody({
      provider: 'openrouter',
      model: 'nvidia/nemotron-3-nano-30b-a3b',
      messages: [{ role: 'user', content: 'hello' }],
    });
    expect(parsed.ok).toBe(true);
  });

  it('rejects unsupported providers and malformed roles', () => {
    expect(route.parseChatBody({ provider: 'other', messages: [] }).ok).toBe(false);
    expect(
      route.parseChatBody({ provider: 'google', messages: [{ role: 'system', content: 'x' }] }).ok,
    ).toBe(false);
  });

  it('limits conversation size and output tokens', () => {
    expect(
      route.parseChatBody({
        provider: 'openrouter',
        messages: [{ role: 'user', content: 'x'.repeat(32_001) }],
      }).ok,
    ).toBe(false);
    expect(
      route.parseChatBody({
        provider: 'openrouter',
        messages: [{ role: 'user', content: 'x' }],
        max_output_tokens: 9000,
      }).ok,
    ).toBe(false);
  });
});

describe('provider calls', () => {
  it('calls OpenRouter without returning or logging the key or prompt', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (_url: string, init: RequestInit) => {
        expect((init.headers as Record<string, string>).Authorization).toBe('Bearer openrouter-secret');
        return {
          ok: true,
          status: 200,
          json: async () => ({ choices: [{ message: { content: 'safe answer' } }] }),
        };
      }),
    );
    const response = await route.POST(
      request({
        provider: 'openrouter',
        model: 'nvidia/nemotron-3-nano-30b-a3b',
        messages: [{ role: 'user', content: 'private customer prompt' }],
      }),
    );
    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({ content: 'safe answer', provider: 'openrouter' });
    expect(JSON.stringify(inserted)).not.toContain('private customer prompt');
    expect(JSON.stringify(inserted)).not.toContain('openrouter-secret');
  });

  it('translates the same request shape for Google AI', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (_url: string, init: RequestInit) => {
        expect((init.headers as Record<string, string>)['x-goog-api-key']).toBe('google-secret');
        return {
          ok: true,
          status: 200,
          json: async () => ({ candidates: [{ content: { parts: [{ text: 'google answer' }] } }] }),
        };
      }),
    );
    const response = await route.POST(
      request({ provider: 'google', messages: [{ role: 'user', content: 'hello' }] }),
    );
    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({ content: 'google answer', provider: 'google' });
  });

  it('surfaces provider failures instead of producing a fake answer', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => ({ ok: false, status: 429, json: async () => ({ error: { message: 'rate limited' } }) })),
    );
    const response = await route.POST(
      request({ provider: 'openrouter', messages: [{ role: 'user', content: 'hello' }] }),
    );
    expect(response.status).toBe(502);
    expect((await response.json()).error).toMatch(/rate limited/i);
  });
});
