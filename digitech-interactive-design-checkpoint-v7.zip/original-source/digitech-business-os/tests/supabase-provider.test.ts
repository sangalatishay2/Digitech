import { describe, it, expect, beforeEach } from 'vitest';
import { SupabaseProvider, SECRET_ACTIVATION_COLUMNS } from '@/lib/data/supabase-provider';
import { diffSnapshots, diffToOps, assertOrgScope } from '@/lib/data/diff';
import { emptyDb } from '@/lib/data/seed';
import type { Database } from '@/lib/types';
import type { SupabaseLike } from '@/lib/data/supabase-client';

/**
 * These tests drive the provider against a recording fake rather than a live
 * Supabase project. What matters for correctness here is the *shape* of the
 * traffic the provider emits — which tables, which columns, which filters —
 * because that is exactly where whole-database overwrites, cross-org writes
 * and secret leakage would show up.
 */

interface Call {
  table: string;
  op: string;
  payload?: unknown;
  columns?: string;
  filters: Array<[string, string, unknown]>;
}

function fakeClient(rows: Record<string, unknown[]> = {}) {
  const calls: Call[] = [];

  function builder(table: string, op: string, payload?: unknown, columns?: string) {
    const call: Call = { table, op, payload, columns, filters: [] };
    calls.push(call);
    const api: Record<string, unknown> = {
      select(cols?: string) {
        call.columns = cols;
        return api;
      },
      eq(c: string, v: unknown) {
        call.filters.push(['eq', c, v]);
        return api;
      },
      is(c: string, v: unknown) {
        call.filters.push(['is', c, v]);
        return api;
      },
      in(c: string, v: unknown) {
        call.filters.push(['in', c, v]);
        return api;
      },
      order() {
        return api;
      },
      limit() {
        return api;
      },
      maybeSingle: async () => ({ data: (rows[table] ?? [])[0] ?? null, error: null }),
      single: async () => ({ data: (rows[table] ?? [])[0] ?? null, error: null }),
      then(resolve: (v: { data: unknown[]; error: null }) => unknown) {
        return Promise.resolve({ data: rows[table] ?? [], error: null }).then(resolve);
      },
    };
    return api;
  }

  const client = {
    from(table: string) {
      return {
        select: (cols?: string) => builder(table, 'select', undefined, cols),
        insert: (payload: unknown) => builder(table, 'insert', payload),
        update: (payload: unknown) => builder(table, 'update', payload),
        delete: () => builder(table, 'delete'),
      };
    },
    rpc: async (fn: string, args: unknown) => {
      calls.push({ table: `rpc:${fn}`, op: 'rpc', payload: args, filters: [] });
      return { data: 'ORD-1001', error: null };
    },
  } as unknown as SupabaseLike;

  return { client, calls };
}

function baseDb(): Database {
  const db = emptyDb();
  db.organizations = [
    { id: 'org-a', name: 'A', created_at: 'x', updated_at: 'x' },
  ] as Database['organizations'];
  return db;
}

describe('SupabaseProvider — write path', () => {
  let provider: SupabaseProvider;
  let calls: Call[];

  beforeEach(() => {
    const f = fakeClient();
    provider = new SupabaseProvider(f.client);
    calls = f.calls;
  });

  it('refuses whole-database save (last-writer-wins is the bug we are fixing)', async () => {
    await expect(provider.save()).rejects.toThrow();
  });

  it('refuses reset in production', async () => {
    await expect(provider.reset()).rejects.toThrow();
  });

  it('insert targets exactly one table and sends the row', async () => {
    await provider.insert('customers', { id: 'c1', organization_id: 'org-a', name: 'Asha' });
    const insert = calls.find((c) => c.op === 'insert');
    expect(insert?.table).toBe('customers');
    expect(insert?.payload).toMatchObject({ id: 'c1', name: 'Asha' });
  });

  it('update filters by id so it can never touch another row', async () => {
    await provider.update('customers', 'c1', { name: 'Renamed' });
    const upd = calls.find((c) => c.op === 'update');
    expect(upd?.filters).toContainEqual(['eq', 'id', 'c1']);
  });

  it('optimistic concurrency sends expectedUpdatedAt as a filter', async () => {
    await provider.update('customers', 'c1', { name: 'X' }, { expectedUpdatedAt: '2026-01-01T00:00:00Z' });
    const upd = calls.find((c) => c.op === 'update');
    expect(upd?.filters).toContainEqual(['eq', 'updated_at', '2026-01-01T00:00:00Z']);
  });

  it('archive is a soft delete, not a row removal', async () => {
    await provider.archive('customers', 'c1');
    expect(calls.some((c) => c.op === 'delete')).toBe(false);
    const upd = calls.find((c) => c.op === 'update');
    expect(upd?.payload).toHaveProperty('deleted_at');
  });
});

describe('SupabaseProvider — secret handling', () => {
  it('never selects activation secret columns with a wildcard', async () => {
    const f = fakeClient({ activations: [] });
    const provider = new SupabaseProvider(f.client);
    await provider.select('activations');
    const sel = f.calls.find((c) => c.table === 'activations');
    expect(sel?.columns).toBeTruthy();
    expect(sel?.columns).not.toBe('*');
    for (const col of SECRET_ACTIVATION_COLUMNS) {
      expect(sel?.columns).not.toContain(col);
    }
  });

  it('load() does not pull secrets into the client-side database', async () => {
    const f = fakeClient();
    const provider = new SupabaseProvider(f.client);
    await provider.load();
    const activationSelects = f.calls.filter((c) => c.table === 'activations');
    for (const call of activationSelects) {
      for (const col of SECRET_ACTIVATION_COLUMNS) {
        expect(call.columns ?? '').not.toContain(col);
      }
    }
  });
});

describe('diffSnapshots — per-entity mutation planning', () => {
  it('produces no operations when nothing changed', () => {
    const db = baseDb();
    const diff = diffSnapshots(db, structuredClone(db));
    expect(diffToOps(diff)).toHaveLength(0);
  });

  it('emits a single insert for a single new row', () => {
    const prev = baseDb();
    const next = structuredClone(prev);
    next.customers = [
      { id: 'c1', organization_id: 'org-a', name: 'Asha' },
    ] as Database['customers'];
    const ops = diffToOps(diffSnapshots(prev, next));
    expect(ops).toHaveLength(1);
    expect(ops[0]).toMatchObject({ table: 'customers', kind: 'insert' });
  });

  it('emits an update only for the row that actually changed', () => {
    const prev = baseDb();
    prev.customers = [
      { id: 'c1', organization_id: 'org-a', name: 'Asha' },
      { id: 'c2', organization_id: 'org-a', name: 'Bhavna' },
    ] as Database['customers'];
    const next = structuredClone(prev);
    next.customers[1].name = 'Bhavna Rao';
    const ops = diffToOps(diffSnapshots(prev, next));
    expect(ops).toHaveLength(1);
    expect(ops[0].kind).toBe('update');
    expect((ops[0] as { id: string }).id).toBe('c2');
  });

  it('emits a delete for a removed row', () => {
    const prev = baseDb();
    prev.customers = [
      { id: 'c1', organization_id: 'org-a', name: 'Asha' },
    ] as Database['customers'];
    const next = structuredClone(prev);
    next.customers = [];
    const ops = diffToOps(diffSnapshots(prev, next));
    expect(ops).toHaveLength(1);
    expect(ops[0].kind).toBe('delete');
  });

  it('rejects operations that would write into another organization', () => {
    const prev = baseDb();
    const next = structuredClone(prev);
    next.customers = [
      { id: 'c1', organization_id: 'org-b', name: 'Intruder' },
    ] as Database['customers'];
    const ops = diffToOps(diffSnapshots(prev, next));
    expect(() => assertOrgScope(ops, 'org-a')).toThrow();
  });

  it('accepts operations scoped to the caller organization', () => {
    const prev = baseDb();
    const next = structuredClone(prev);
    next.customers = [
      { id: 'c1', organization_id: 'org-a', name: 'Fine' },
    ] as Database['customers'];
    const ops = diffToOps(diffSnapshots(prev, next));
    expect(() => assertOrgScope(ops, 'org-a')).not.toThrow();
  });

  it('inserts parents before children so foreign keys resolve', () => {
    const prev = baseDb();
    const next = structuredClone(prev);
    next.customers = [{ id: 'c1', organization_id: 'org-a', name: 'A' }] as Database['customers'];
    next.orders = [
      { id: 'o1', organization_id: 'org-a', customer_id: 'c1' },
    ] as unknown as Database['orders'];
    const ops = diffToOps(diffSnapshots(prev, next));
    const customerAt = ops.findIndex((o) => o.table === 'customers');
    const orderAt = ops.findIndex((o) => o.table === 'orders');
    expect(customerAt).toBeLessThan(orderAt);
  });

  it('deletes children before parents (reverse dependency order)', () => {
    const prev = baseDb();
    prev.customers = [{ id: 'c1', organization_id: 'org-a', name: 'A' }] as Database['customers'];
    prev.orders = [
      { id: 'o1', organization_id: 'org-a', customer_id: 'c1' },
    ] as unknown as Database['orders'];
    const next = structuredClone(prev);
    next.customers = [];
    next.orders = [];
    const ops = diffToOps(diffSnapshots(prev, next));
    const orderAt = ops.findIndex((o) => o.table === 'orders');
    const customerAt = ops.findIndex((o) => o.table === 'customers');
    expect(orderAt).toBeLessThan(customerAt);
  });
});

describe('secrets never travel through the generic write path', () => {
  function withActivation(fields: Record<string, unknown>): Database {
    const db = baseDb();
    db.activations = [
      { id: 'act1', organization_id: 'org-a', status: 'ready', ...fields },
    ] as unknown as Database['activations'];
    return db;
  }

  const SECRETS = [
    'activation_email',
    'activation_password',
    'activation_details',
    'internal_instructions',
  ];

  it('strips secret columns from an activation insert', () => {
    const prev = baseDb();
    const next = withActivation({
      activation_email: 'user@vendor.com',
      activation_password: 'hunter2',
      activation_details: 'license XYZ',
      internal_instructions: 'call vendor',
    });
    const ops = diffToOps(diffSnapshots(prev, next));
    const insert = ops.find((o) => o.table === 'activations');
    expect(insert).toBeTruthy();
    const payload = JSON.stringify(insert);
    expect(payload).not.toContain('hunter2');
    expect(payload).not.toContain('user@vendor.com');
    for (const k of SECRETS) expect(payload).not.toContain(k);
  });

  it('emits no update at all when only a secret changed', () => {
    const prev = withActivation({ activation_password: 'old-secret' });
    const next = withActivation({ activation_password: 'new-secret' });
    // The secrets endpoint owns this change; the snapshot diff must ignore it
    // rather than emit a stripped no-op UPDATE that looks like a save.
    expect(diffToOps(diffSnapshots(prev, next))).toHaveLength(0);
  });

  it('still updates non-secret fields on an activation', () => {
    const prev = withActivation({ activation_password: 'x', priority: 'low' });
    const next = withActivation({ activation_password: 'x', priority: 'urgent' });
    const ops = diffToOps(diffSnapshots(prev, next));
    expect(ops).toHaveLength(1);
    expect((ops[0] as { patch: Record<string, unknown> }).patch.priority).toBe('urgent');
  });

  it('carries a secret change alongside a real change without leaking it', () => {
    const prev = withActivation({ activation_password: 'old', priority: 'low' });
    const next = withActivation({ activation_password: 'new', priority: 'urgent' });
    const ops = diffToOps(diffSnapshots(prev, next));
    expect(JSON.stringify(ops)).not.toContain('new');
    expect((ops[0] as { patch: Record<string, unknown> }).patch.priority).toBe('urgent');
  });

  it('does not strip similarly-named columns on other tables', () => {
    const prev = baseDb();
    const next = structuredClone(prev);
    next.customers = [
      { id: 'c1', organization_id: 'org-a', name: 'A', email: 'a@b.c' },
    ] as Database['customers'];
    const ops = diffToOps(diffSnapshots(prev, next));
    expect(JSON.stringify(ops)).toContain('a@b.c');
  });
});
