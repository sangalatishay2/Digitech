import { describe, it, expect } from 'vitest';
import { actorCan, assertCan, roleAllows, AuthorizationError, type Actor } from '@/lib/services/authz';
import type { Role } from '@/lib/types';

const ORG_A = 'org-a', ORG_B = 'org-b';
const actor = (role: Role, over: Partial<Actor> = {}): Actor => ({
  id: 'u1', organization_id: ORG_A, role, is_active: true, deleted_at: null, ...over,
});

const ROLES: Role[] = ['owner', 'admin', 'sales', 'support', 'accounts', 'operations', 'viewer'];

describe('RBAC matrix', () => {
  it('owner and admin can do everything', () => {
    for (const r of ['owner', 'admin'] as Role[]) {
      expect(actorCan(actor(r), 'payments.create')).toBe(true);
      expect(actorCan(actor(r), 'settings.update')).toBe(true);
    }
  });

  it('viewer is read-only across the board', () => {
    const v = actor('viewer');
    expect(actorCan(v, 'orders.read')).toBe(true);
    expect(actorCan(v, 'orders.create')).toBe(false);
    expect(actorCan(v, 'payments.create')).toBe(false);
    expect(actorCan(v, 'customers.delete')).toBe(false);
  });

  it('sales cannot write payments or expenses', () => {
    const s = actor('sales');
    expect(actorCan(s, 'orders.create')).toBe(true);
    expect(actorCan(s, 'payments.read')).toBe(true);
    expect(actorCan(s, 'payments.create')).toBe(false);
    expect(actorCan(s, 'expenses.create')).toBe(false);
  });

  it('support cannot create orders or touch finance', () => {
    const s = actor('support');
    expect(actorCan(s, 'support.update')).toBe(true);
    expect(actorCan(s, 'orders.read')).toBe(true);
    expect(actorCan(s, 'orders.create')).toBe(false);
    expect(actorCan(s, 'invoices.create')).toBe(false);
  });

  it('accounts owns finance but cannot create orders', () => {
    const a = actor('accounts');
    expect(actorCan(a, 'payments.create')).toBe(true);
    expect(actorCan(a, 'invoices.create')).toBe(true);
    expect(actorCan(a, 'orders.create')).toBe(false);
  });

  it('operations owns fulfilment but not payments', () => {
    const o = actor('operations');
    expect(actorCan(o, 'activations.update')).toBe(true);
    expect(actorCan(o, 'products.create')).toBe(true);
    expect(actorCan(o, 'payments.create')).toBe(false);
  });

  it('DISABLED profile can never act, whatever the role', () => {
    for (const r of ROLES) {
      const dead = actor(r, { is_active: false });
      expect(actorCan(dead, 'customers.read')).toBe(false);
      expect(actorCan(dead, 'orders.create')).toBe(false);
    }
  });

  it('soft-deleted profile can never act', () => {
    const gone = actor('owner', { deleted_at: new Date().toISOString() });
    expect(actorCan(gone, 'orders.create')).toBe(false);
  });

  it('null actor is denied', () => {
    expect(actorCan(null, 'orders.read')).toBe(false);
  });
});

describe('cross-organization rejection', () => {
  it('an owner of org A cannot act on org B', () => {
    expect(() => assertCan(actor('owner'), 'orders.create', ORG_B)).toThrow(AuthorizationError);
    expect(() => assertCan(actor('owner'), 'orders.create', ORG_A)).not.toThrow();
  });

  it('assertCan reports why it failed', () => {
    try {
      assertCan(actor('viewer'), 'payments.create');
      throw new Error('should have thrown');
    } catch (e) {
      expect((e as AuthorizationError).name).toBe('AuthorizationError');
      expect((e as Error).message).toMatch(/lacks this capability/);
    }
  });

  it('disabled beats role in assertCan', () => {
    expect(() => assertCan(actor('owner', { is_active: false }), 'orders.create'))
      .toThrow(/disabled/);
  });
});

describe('role matrix is exhaustive', () => {
  it('every role resolves a decision for a sample of actions', () => {
    const actions = ['customers.read','orders.create','payments.create','expenses.create','settings.update'];
    for (const r of ROLES) for (const a of actions) {
      expect(typeof roleAllows(r, a)).toBe('boolean');
    }
  });
});
