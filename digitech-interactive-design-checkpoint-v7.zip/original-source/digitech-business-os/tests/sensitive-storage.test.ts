import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { LocalProvider } from '@/lib/data/local-provider';
import { SENSITIVE_ACTIVATION_FIELDS, resolveMode } from '@/lib/runtime/mode';
import { buildSeed } from '@/lib/data/seed';

/**
 * P0 #4 — no real secret/PII persistence in browser localStorage in production
 * mode. Activation records carry the credentials handed to the customer
 * (account email, password/keys, internal instructions). Those must never be
 * written to a store that any script on the origin can read.
 */

class MemoryStorage implements Storage {
  private m = new Map<string, string>();
  get length() { return this.m.size; }
  clear() { this.m.clear(); }
  getItem(k: string) { return this.m.get(k) ?? null; }
  key(i: number) { return [...this.m.keys()][i] ?? null; }
  removeItem(k: string) { this.m.delete(k); }
  setItem(k: string, v: string) { this.m.set(k, v); }
  /** Everything ever written, for substring scanning. */
  dump() { return [...this.m.values()].join('\n'); }
}

let store: MemoryStorage;
const SECRET = 'SuperSecretPassw0rd-DO-NOT-PERSIST';
const SECRET_EMAIL = 'customer.secret@netflix.example';

const setProvider = (v?: string) => {
  if (v === undefined) delete process.env.NEXT_PUBLIC_DATA_PROVIDER;
  else process.env.NEXT_PUBLIC_DATA_PROVIDER = v;
};
const setCreds = (on: boolean) => {
  if (on) {
    process.env.NEXT_PUBLIC_SUPABASE_URL = 'https://example.supabase.co';
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = 'anon-key';
  } else {
    delete process.env.NEXT_PUBLIC_SUPABASE_URL;
    delete process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  }
};

function dbWithSecrets() {
  const db = buildSeed();
  if (db.activations.length === 0) throw new Error('seed has no activations to test');
  const a = db.activations[0] as unknown as Record<string, unknown>;
  a.activation_email = SECRET_EMAIL;
  a.activation_details = SECRET;
  a.internal_instructions = `admin console pw: ${SECRET}`;
  return db;
}

beforeEach(() => {
  store = new MemoryStorage();
  vi.stubGlobal('window', { localStorage: store } as unknown as Window & typeof globalThis);
  vi.stubGlobal('localStorage', store);
});

afterEach(() => {
  vi.unstubAllGlobals();
  setProvider(undefined);
  setCreds(false);
});

describe('demo mode', () => {
  it('persists activation fields (demo data, no real customers)', async () => {
    setProvider('local');
    expect(resolveMode().mode).toBe('demo');
    const p = new LocalProvider();
    await p.save(dbWithSecrets());
    expect(store.dump()).toContain(SECRET);
  });
});

describe('production mode', () => {
  it('never writes secrets to localStorage', async () => {
    setCreds(true);
    setProvider('supabase');
    const p = new LocalProvider();
    await p.save(dbWithSecrets());
    const written = store.dump();
    expect(written).not.toContain(SECRET);
    expect(written).not.toContain(SECRET_EMAIL);
  });

  it('refuses to persist anything at all outside demo mode', async () => {
    setCreds(true);
    setProvider('supabase');
    const p = new LocalProvider();
    await p.save(dbWithSecrets());
    // Production writes must go through server-side repositories.
    expect(store.getItem('digitech-os:db:v1')).toBeNull();
  });

  it('redaction covers every declared sensitive field', async () => {
    setCreds(true);
    setProvider('supabase');
    // Prove the field list is actually the one enforced, not a stale copy.
    expect(SENSITIVE_ACTIVATION_FIELDS.length).toBeGreaterThan(0);
    for (const f of SENSITIVE_ACTIVATION_FIELDS) {
      expect(typeof f).toBe('string');
    }
    const db = dbWithSecrets();
    const p = new LocalProvider();
    await p.save(db);
    for (const f of SENSITIVE_ACTIVATION_FIELDS) {
      const val = (db.activations[0] as unknown as Record<string, unknown>)[f];
      if (typeof val === 'string' && val.length > 0) {
        expect(store.dump()).not.toContain(val);
      }
    }
  });
});

describe('mode resolution safety', () => {
  it('degrades to demo (never silently to production) when creds are missing', () => {
    setProvider('supabase');
    setCreds(false);
    const m = resolveMode();
    expect(m.mode).toBe('demo');
    expect(m.degraded).toBe(true);
    expect(m.reason).toMatch(/missing/i);
  });

  it('enters production when supabase is requested and credentials exist', () => {
    // The repository layer is implemented (SUPABASE_REPOSITORY_IMPLEMENTED),
    // so this combination must now produce a real production session rather
    // than degrading to the browser-persisted demo store.
    setProvider('supabase');
    setCreds(true);
    const m = resolveMode();
    expect(m.mode).toBe('production');
    expect(m.degraded).toBe(false);
  });

  it('still refuses production when credentials are missing', () => {
    // Degrading is correct here: without credentials there is no backend, and
    // silently treating localStorage as production storage is the dangerous
    // failure this guard exists to prevent.
    setProvider('supabase');
    setCreds(false);
    const m = resolveMode();
    expect(m.mode).toBe('demo');
    expect(m.degraded).toBe(true);
  });

  it('plain demo mode is not flagged as degraded', () => {
    setProvider('local');
    setCreds(false);
    const m = resolveMode();
    expect(m.mode).toBe('demo');
    expect(m.degraded).toBe(false);
  });
});
