# Prompt for Google Studio / Gemini

Continue the attached DigiTech project from its current checkpoint. Do not restart, scaffold a replacement, or rewrite working modules.

First read `GOOGLE_STUDIO_HANDOFF_READ_FIRST.md`, `DIGITECH_REPAIR_AUDIT_AND_STATUS.md`, and `DIGITECH_INTERACTIVE_DESIGN_UPGRADE_V7.md`. Then inspect both projects completely:

- `original-source/digitech-business-os/` is the authoritative Next.js + Supabase DigiTech Business OS and the source of truth for business logic, database schema, roles, permissions, financial calculations, lifecycle rules, approval controls, and AI security.
- `android-latest/` is the Kotlin/Jetpack Compose client/rewrite that needs repair and feature parity.

Preserve all completed work. In particular, preserve Supabase as the single business-data authority, encrypted auth token storage, fail-closed roles, organization-scoped sync, authoritative refresh after writes, server RPC business mutations, secure AI gateway routing, approval-before-consequential-action, and the rule that secrets never enter the APK, Room, logs, or client backups.

The Android UI direction is “Pulse OS”: premium near-black and light surfaces, emerald/mint operational signal, blue intelligence accent, amber urgency, modular bento layout, strong hierarchy, raised central Copilot navigation, purposeful screen transitions, press feedback, staggered entry, animated state changes, and restrained haptics. It must feel modern, attractive, interactive, and fast—not like a generic template. Motion must explain change or confirm action, respect Android system animation settings, maintain 48dp touch targets, and remain smooth on normal mid-range phones.

Important: the latest Android checkpoint contains new motion/navigation components; a live Business Pulse command surface; animated metric changes; tactile quick actions; an interactive Copilot role rail and business launchpad; and restored Orders, Renewal Center, Fulfillment Queue, KPI/status/empty-state components. It also removes hard-coded demo credential auto-fill. Review and compile these changes; do not delete them merely to make errors disappear.

Work phase-by-phase in this exact order:

1. **Build recovery first**
   - Configure JDK 17, Android SDK/API 35, and Google Maven.
   - Run `./gradlew testDebugUnitTest`, `./gradlew lintDebug`, and `./gradlew assembleDebug`.
   - Fix every real compiler/resource error with minimal coherent changes.
   - List each error fixed and the file changed.

2. **Android parity and UX completion**
   - Finish role-aware screens and navigation for Dashboard, Orders, Payments, Activations/Fulfillment, Subscriptions/Renewals, Customers/Customer 360, Products, Suppliers, Leads, Support, Tasks, Approvals, Unified Inbox, Finance Intelligence, and settings/profile.
   - Use real repository/Supabase data only; no fabricated local business authority.
   - Add loading, empty, offline, stale, retry, error, permission-denied, and success states.
   - Preserve the Pulse OS design/motion system consistently.

3. **AI Copilot completion**
   - Support OpenRouter, Google, and custom model IDs, including Nemotron through OpenRouter.
   - Provider keys remain only on the deployed secure server.
   - Business context is opt-in, permission filtered, organization scoped, and never includes activation secrets.
   - Consequential AI actions create approval requests; they do not execute directly.
   - Add provider timeout, rate-limit, malformed-response, outage fallback, retry, and clear user-facing errors.

4. **Security and data completion**
   - Complete the encrypted server-only activation-secret workflow and keep secrets memory-only on Android.
   - Partition or encrypt offline cache by organization.
   - Verify sign-out clears session-bound cached data and prevents cross-account display.
   - Test owner/admin/sales/support/accounts/operations/viewer and unknown-role denial.
   - Do not add Firebase/Firestore back.

5. **Quality gates**
   - Run Android unit tests, lint, debug and release builds.
   - Test two organizations for isolation and every permission-denied path.
   - Test order idempotency, payment duplication, activation duplication, renewal chains, offline/retry, session switching, AI prompt injection, provider failures, and secret leakage.
   - Perform emulator/device smoke tests for login, sync, navigation, create order, payment, activation, renewal, Copilot, dark/light mode, rotation, keyboard, back navigation, and accessibility text scaling.

6. **APK delivery**
   - Produce an actual installable APK. Provide the exact output file, normally `app/build/outputs/apk/debug/app-debug.apk` for testing or a securely signed release APK for final delivery.
   - Never rename a ZIP or source artifact to `.apk`.
   - Report exactly which tests/builds passed and any remaining limitation. Do not claim “production ready” while a critical check is skipped or failing.

Before writing code, return a short checkpoint summary: what already exists, what is missing, and the first build errors. Then begin Phase 1 immediately. Do not ask routine technical questions. Ask only when public backend configuration or signing information is genuinely required.
