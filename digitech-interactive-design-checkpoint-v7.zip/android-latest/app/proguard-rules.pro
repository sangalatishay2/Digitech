# DigiTech Android client rules. Keep application models used by serialization.
-keepattributes *Annotation*
-keep class com.example.digitech.data.model.** { *; }
-keep class com.example.digitech.data.gemini.** { *; }
