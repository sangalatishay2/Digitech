package com.example.digitech

import com.example.digitech.auth.AuthUiState
import com.example.digitech.auth.UserProfileData
import com.example.digitech.auth.RolePermissions
import com.example.digitech.data.export.CsvExportHelper
import com.example.digitech.data.sync.SyncStatus
import com.example.digitech.data.model.CustomerEntity
import com.example.digitech.data.model.OrderEntity
import com.example.digitech.data.model.ProductEntity
import com.example.digitech.data.model.SubscriptionEntity
import com.example.digitech.ui.components.ONBOARDING_STEPS
import com.example.digitech.ui.viewmodel.DashboardMetrics
import com.example.digitech.data.gemini.AiRole
import com.example.digitech.data.gemini.ChatMessage
import com.example.digitech.data.gemini.GeminiModels
import org.junit.Assert.*
import org.junit.Test

class AuthAndBusinessLogicTest {

    @Test
    fun authUiState_handlesTransitionsCorrectly() {
        val idleState: AuthUiState = AuthUiState.Idle
        assertTrue(idleState is AuthUiState.Idle)

        val loadingState: AuthUiState = AuthUiState.Loading
        assertTrue(loadingState is AuthUiState.Loading)

        val errorState: AuthUiState = AuthUiState.Error("Sign in failed")
        assertTrue(errorState is AuthUiState.Error)
        assertEquals("Sign in failed", (errorState as AuthUiState.Error).message)
    }

    @Test
    fun userProfileData_initializesAndSerializesProperly() {
        val profile = UserProfileData(
            name = "Alex Morgan",
            photoUrl = "https://example.com/avatar.jpg",
            rolePreference = "Operations Manager",
            isProfileSetupCompleted = true
        )

        assertEquals("Alex Morgan", profile.name)
        assertEquals("https://example.com/avatar.jpg", profile.photoUrl)
        assertEquals("Operations Manager", profile.rolePreference)
        assertTrue(profile.isProfileSetupCompleted)

        val defaultProfile = UserProfileData()
        assertFalse(defaultProfile.isProfileSetupCompleted)
        assertEquals("no_access", defaultProfile.rolePreference)
    }

    @Test
    fun authoritativeRoles_mapWithoutPrivilegeExpansion() {
        assertEquals("owner", RolePermissions.getRole("owner").id)
        assertEquals("admin", RolePermissions.getRole("admin").id)
        assertEquals("sales", RolePermissions.getRole("sales").id)
        assertEquals("support", RolePermissions.getRole("support").id)
        assertEquals("operations", RolePermissions.getRole("operations").id)
        assertFalse(RolePermissions.getRole("support").canCreateOrders)
        assertFalse(RolePermissions.getRole("sales").canFulfillActivations)
        assertFalse(RolePermissions.getRole("operations").canManageExpenses)
    }

    @Test
    fun unknownRole_isDeniedByDefault() {
        val role = RolePermissions.getRole("unexpected-or-tampered-role")
        assertEquals("no_access", role.id)
        assertFalse(role.canCreateOrders)
        assertFalse(role.canViewFinancialRevenue)
        assertFalse(role.canResetDatabase)
    }

    @Test
    fun onboardingSteps_areConfiguredWithDistinctFeatures() {
        assertEquals(4, ONBOARDING_STEPS.size)
        assertTrue(ONBOARDING_STEPS.all { it.title.isNotBlank() })
        assertTrue(ONBOARDING_STEPS.all { it.description.isNotBlank() })
        assertTrue(ONBOARDING_STEPS.all { it.badge.isNotBlank() })
    }

    @Test
    fun syncStatus_hasDistinctStateRepresentations() {
        val idle: SyncStatus = SyncStatus.Idle
        val syncing: SyncStatus = SyncStatus.Syncing
        val synced: SyncStatus = SyncStatus.Synced
        val error: SyncStatus = SyncStatus.Error("Network timeout")

        assertTrue(idle is SyncStatus.Idle)
        assertTrue(syncing is SyncStatus.Syncing)
        assertTrue(synced is SyncStatus.Synced)
        assertTrue(error is SyncStatus.Error)
        assertEquals("Network timeout", (error as SyncStatus.Error).message)
    }

    @Test
    fun orderCalculation_correctlyComputesProfitAndMargin() {
        val product = ProductEntity(
            id = "prd_canva",
            code = "PRD-CNV",
            name = "Canva Pro 1 Year",
            category = "Design",
            brand = "Annual",
            description = "Canva Team Member Invite",
            productType = "subscription",
            deliveryType = "email_activation",
            durationDays = 365,
            costPrice = 350.0,
            sellingPrice = 999.0,
            stock = 50,
            isActive = true
        )

        val quantity = 2
        val customPrice = 999.0
        val discount = 100.0
        val totalAmount = (customPrice * quantity) - discount
        val totalCost = product.costPrice * quantity
        val profit = totalAmount - totalCost

        assertEquals(1898.0, totalAmount, 0.01)
        assertEquals(700.0, totalCost, 0.01)
        assertEquals(1198.0, profit, 0.01)
    }

    @Test
    fun subscriptionRenewal_correctlyExtendsExpiration() {
        val now = System.currentTimeMillis()
        val originalExpiry = now + 10L * 24 * 60 * 60 * 1000 // 10 days left

        val sub = SubscriptionEntity(
            id = "sub_01",
            customerId = "cust_01",
            customerName = "Rahul Sharma",
            customerPhone = "+919876543210",
            productId = "prd_chatgpt",
            productName = "ChatGPT Plus",
            orderId = "ord_01",
            startDate = now,
            expiryDate = originalExpiry,
            durationDays = 30,
            purchaseAmount = 799.0,
            costAmount = 450.0,
            profit = 349.0,
            status = "active",
            reminderState = "none",
            notes = "Test sub"
        )

        val extendDays = 365
        val extensionMs = extendDays.toLong() * 24 * 60 * 60 * 1000
        val newExpiry = originalExpiry + extensionMs

        assertTrue(newExpiry > originalExpiry)
        assertEquals(395, sub.durationDays + extendDays)
    }

    @Test
    fun aiModels_useGatewayCompatibleModelStrings() {
        assertEquals("gemini-2.5-flash", GeminiModels.GEMINI_3_5_FLASH)
        assertEquals("nvidia/nemotron-3-nano-30b-a3b", GeminiModels.GEMINI_3_1_PRO)
        assertEquals("gemini-2.5-flash", GeminiModels.GEMINI_3_1_FLASH_LITE)
        assertEquals("nvidia/nemotron-3-nano-30b-a3b", GeminiModels.GEMINI_3_1_FLASH_LIVE)
    }

    @Test
    fun aiRoles_haveDistinctSystemInstructionsAndModelRecommendations() {
        val roles = AiRole.values()
        assertTrue(roles.isNotEmpty())
        roles.forEach { role ->
            assertTrue(role.title.isNotBlank())
            assertTrue(role.systemInstruction.isNotBlank())
            assertTrue(role.recommendedModel.isNotBlank())
        }

        assertEquals(GeminiModels.GEMINI_3_1_PRO, AiRole.FINANCIAL_ANALYST.recommendedModel)
        assertEquals(GeminiModels.GEMINI_3_5_FLASH, AiRole.BUSINESS_COPILOT.recommendedModel)
        assertEquals(GeminiModels.GEMINI_3_1_FLASH_LITE, AiRole.SUPPORT_MESSAGING.recommendedModel)
    }

    @Test
    fun authenticatedUser_holdsVerifiedUserDataCorrectly() {
        val user = com.example.digitech.auth.AuthenticatedUser(
            uid = "supabase_uid_123",
            displayName = "Verified User",
            email = "verified@example.com",
            isAnonymous = false,
            accessToken = "short-lived-token",
            organizationId = "org_123",
            serverRole = "owner"
        )
        assertEquals("supabase_uid_123", user.uid)
        assertFalse(user.isAnonymous)
        assertEquals("Verified User", user.displayName)
        val authState = com.example.digitech.auth.AuthUiState.Authenticated(user)
        assertEquals(user, authState.user)
    }

    @Test
    fun csvExport_neutralizesSpreadsheetFormulaInjection() {
        val customer = CustomerEntity(
            id = "cust_1",
            customerCode = "CUS-001",
            name = "=HYPERLINK(\"https://example.com\")",
            email = "+SUM(1,1)",
            phone = "@malicious",
            company = "-1+2"
        )

        val csv = CsvExportHelper.generateCustomersCsv(listOf(customer))
        assertTrue(csv.contains("'=HYPERLINK"))
        assertTrue(csv.contains("'+SUM"))
        assertTrue(csv.contains("'@malicious"))
        assertTrue(csv.contains("'-1+2"))
    }

    @Test
    fun passwordStrengthValidator_evaluatesLevelsCorrectly() {
        val emptyStrength = com.example.digitech.auth.PasswordStrengthValidator.evaluate("")
        assertEquals(com.example.digitech.auth.PasswordStrengthLevel.EMPTY, emptyStrength.level)
        assertEquals(0, emptyStrength.score)

        val weakStrength = com.example.digitech.auth.PasswordStrengthValidator.evaluate("abcdef")
        assertEquals(com.example.digitech.auth.PasswordStrengthLevel.VERY_WEAK, weakStrength.level)
        assertEquals(1, weakStrength.score)

        val mediumStrength = com.example.digitech.auth.PasswordStrengthValidator.evaluate("Abcdefgh")
        assertEquals(com.example.digitech.auth.PasswordStrengthLevel.FAIR, mediumStrength.level)
        assertEquals(3, mediumStrength.score)

        val strongStrength = com.example.digitech.auth.PasswordStrengthValidator.evaluate("P@ssw0rd123!")
        assertEquals(com.example.digitech.auth.PasswordStrengthLevel.STRONG, strongStrength.level)
        assertEquals(5, strongStrength.score)
        assertTrue(strongStrength.requirements.all { it.isMet })
    }
}
