package com.example.digitech.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.data.model.*
import com.example.digitech.ui.components.*
import com.example.digitech.ui.theme.*
import com.example.digitech.ui.viewmodel.DigiTechViewModel
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductsScreen(
    viewModel: DigiTechViewModel
) {
    val products by viewModel.products.collectAsState()
    var selectedCategory by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<ProductEntity?>(null) }

    val categories = remember(products) {
        listOf("All") + products.map { it.category }.distinct()
    }

    val filteredProducts = remember(products, selectedCategory, searchQuery) {
        products.filter { product ->
            val matchesCategory = selectedCategory == "All" || product.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() ||
                    product.name.contains(searchQuery, ignoreCase = true) ||
                    product.code.contains(searchQuery, ignoreCase = true) ||
                    product.brand.contains(searchQuery, ignoreCase = true)

            matchesCategory && matchesSearch
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Product & License Catalog", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(Icons.Default.AddBox, contentDescription = "Add Product", tint = BrandPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = BrandPrimary,
                contentColor = TextPrimaryDark
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Product")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search catalog by product name, code...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Category Filter Tabs
            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                edgePadding = 0.dp,
                containerColor = MaterialTheme.colorScheme.background,
                divider = {}
            ) {
                categories.forEach { cat ->
                    Tab(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        text = {
                            Text(
                                text = cat,
                                fontWeight = if (selectedCategory == cat) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredProducts.isEmpty()) {
                EmptyStateView(
                    title = "No products found",
                    message = "Add software, subscription, or license catalog items.",
                    icon = Icons.Default.Inventory2
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { product ->
                        val margin = if (product.sellingPrice > 0) {
                            ((product.sellingPrice - product.costPrice) / product.sellingPrice) * 100
                        } else 0.0

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { editingProduct = product },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = product.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    StatusBadge(status = product.deliveryType.replace('_', ' '))
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Code: ${product.code} • Category: ${product.category}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (product.stock != null) {
                                        Text(
                                            text = "Stock: ${product.stock}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (product.stock!! < 10) StatusWarning else StatusSuccess
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "Price: ${Formatters.formatCurrency(product.sellingPrice)} (Cost: ${Formatters.formatCurrency(product.costPrice)})",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "Profit: ${Formatters.formatCurrency(product.sellingPrice - product.costPrice)} (${String.format("%.0f%%", margin)} margin)",
                                            fontSize = 12.sp,
                                            color = StatusSuccess
                                        )
                                    }

                                    IconButton(onClick = { editingProduct = product }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit Product", tint = BrandPrimary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Product Dialog
    if (showAddDialog || editingProduct != null) {
        val prod = editingProduct
        var name by remember { mutableStateOf(prod?.name ?: "") }
        var code by remember { mutableStateOf(prod?.code ?: "") }
        var category by remember { mutableStateOf(prod?.category ?: "Design Tools") }
        var costPriceText by remember { mutableStateOf(prod?.costPrice?.toInt()?.toString() ?: "500") }
        var sellPriceText by remember { mutableStateOf(prod?.sellingPrice?.toInt()?.toString() ?: "1200") }
        var durationText by remember { mutableStateOf(prod?.durationDays?.toString() ?: "365") }
        var deliveryType by remember { mutableStateOf(prod?.deliveryType ?: "email_activation") }

        AlertDialog(
            onDismissRequest = {
                showAddDialog = false
                editingProduct = null
            },
            title = { Text(if (prod != null) "Edit Product" else "Add New Product") },
            text = {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product Name *") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Product Code (e.g. CANVA-12M)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = costPriceText, onValueChange = { costPriceText = it }, label = { Text("Cost Price (₹)") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = sellPriceText, onValueChange = { sellPriceText = it }, label = { Text("Selling Price (₹)") }, modifier = Modifier.weight(1f))
                        }
                        OutlinedTextField(value = durationText, onValueChange = { durationText = it }, label = { Text("Duration Days (0=Lifetime)") }, modifier = Modifier.fillMaxWidth())
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cost = costPriceText.toDoubleOrNull() ?: 0.0
                        val sell = sellPriceText.toDoubleOrNull() ?: 0.0
                        val duration = durationText.toIntOrNull() ?: 365

                        val newProduct = ProductEntity(
                            id = prod?.id ?: ("prod-" + UUID.randomUUID().toString().take(8)),
                            code = code.ifBlank { name.take(6).uppercase() },
                            name = name,
                            category = category,
                            brand = name.split(" ").firstOrNull() ?: "Digital",
                            description = "$name Digital License",
                            productType = if (duration > 0) "subscription" else "license",
                            deliveryType = deliveryType,
                            durationDays = duration,
                            costPrice = cost,
                            sellingPrice = sell,
                            stock = 50,
                            isActive = true
                        )
                        viewModel.saveProduct(newProduct)
                        showAddDialog = false
                        editingProduct = null
                    }
                ) {
                    Text("Save Product")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showAddDialog = false
                    editingProduct = null
                }) {
                    Text("Cancel")
                }
            }
        )
    }
}
