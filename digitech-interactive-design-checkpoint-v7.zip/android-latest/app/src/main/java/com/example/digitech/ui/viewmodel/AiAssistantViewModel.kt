package com.example.digitech.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.digitech.data.gemini.*
import com.example.digitech.data.repository.DigiTechRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale

class AiAssistantViewModel(
    application: Application,
    private val repository: DigiTechRepository
) : AndroidViewModel(application) {

    val geminiClient = GeminiClient(application)
    val voiceManager = VoiceManager(application, geminiClient, viewModelScope)

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                role = "model",
                content = "Welcome to DigiTech Copilot. Choose OpenRouter or Google AI, then ask about renewals, operations, margins, or customer communication.",
                modelUsed = AiModels.NEMOTRON
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _selectedRole = MutableStateFlow(AiRole.BUSINESS_COPILOT)
    val selectedRole: StateFlow<AiRole> = _selectedRole.asStateFlow()

    private val _selectedProvider = MutableStateFlow(AiProvider.OPENROUTER)
    val selectedProvider: StateFlow<AiProvider> = _selectedProvider.asStateFlow()

    private val _selectedModel = MutableStateFlow(AiModels.NEMOTRON)
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _includeBusinessContext = MutableStateFlow(false)
    val includeBusinessContext: StateFlow<Boolean> = _includeBusinessContext.asStateFlow()

    fun setRole(role: AiRole) {
        _selectedRole.value = role
        voiceManager.selectedRole = role
    }

    fun setProvider(provider: AiProvider) {
        _selectedProvider.value = provider
        _selectedModel.value = if (provider == AiProvider.OPENROUTER) AiModels.NEMOTRON else AiModels.GEMINI_FLASH
    }

    fun setModel(model: String) {
        _selectedModel.value = model
    }

    fun setIncludeBusinessContext(include: Boolean) {
        _includeBusinessContext.value = include
    }

    fun clearChat() {
        _messages.value = listOf(
            ChatMessage(
                role = "model",
                content = "✨ New conversation started. How can I help your digital software business?",
                modelUsed = _selectedModel.value
            )
        )
    }

    fun sendMessage(userText: String, useStreaming: Boolean = true) {
        val trimmed = userText.trim()
        if (trimmed.isBlank() || _isLoading.value) return

        val userMessage = ChatMessage(
            role = "user",
            content = trimmed
        )

        val updatedList = _messages.value + userMessage
        _messages.value = updatedList
        _isLoading.value = true

        viewModelScope.launch {
            val liveContext = if (_includeBusinessContext.value) {
                generateBusinessContextSnapshot()
            } else null

            val systemInstruction = buildString {
                append(_selectedRole.value.systemInstruction)
                if (!liveContext.isNullOrBlank()) {
                    append("\n\n### Current Live Business Data Context:\n").append(liveContext)
                }
            }

            val assistantMessageId = java.util.UUID.randomUUID().toString()
            val currentModel = _selectedModel.value

            if (useStreaming) {
                val streamingMessage = ChatMessage(
                    id = assistantMessageId,
                    role = "model",
                    content = "...",
                    isStreaming = true,
                    modelUsed = currentModel
                )
                _messages.value = _messages.value + streamingMessage

                val accumulated = StringBuilder()
                geminiClient.streamResponse(
                    provider = _selectedProvider.value,
                    model = currentModel,
                    history = updatedList,
                    systemInstruction = systemInstruction
                ).collect { chunk ->
                    accumulated.append(chunk)
                    _messages.value = _messages.value.map { msg ->
                        if (msg.id == assistantMessageId) {
                            msg.copy(content = accumulated.toString(), isStreaming = true)
                        } else msg
                    }
                }

                _messages.value = _messages.value.map { msg ->
                    if (msg.id == assistantMessageId) {
                        msg.copy(
                            content = if (accumulated.isBlank()) "No response generated." else accumulated.toString(),
                            isStreaming = false
                        )
                    } else msg
                }
            } else {
                val result = geminiClient.generateResponse(
                    provider = _selectedProvider.value,
                    model = currentModel,
                    history = updatedList,
                    systemInstruction = systemInstruction
                )

                result.onSuccess { reply ->
                    _messages.value = _messages.value + ChatMessage(
                        id = assistantMessageId,
                        role = "model",
                        content = reply,
                        modelUsed = currentModel
                    )
                }.onFailure { err ->
                    _messages.value = _messages.value + ChatMessage(
                        id = assistantMessageId,
                        role = "model",
                        content = "⚠️ ${err.localizedMessage ?: "Failed to receive a response from the selected AI provider."}",
                        isError = true,
                        modelUsed = currentModel
                    )
                }
            }

            _isLoading.value = false
        }
    }

    private suspend fun generateBusinessContextSnapshot(): String = withContext(Dispatchers.IO) {
        try {
            val products = repository.products.first()
            val orders = repository.orders.first()
            val subscriptions = repository.subscriptions.first()
            val activations = repository.activations.first()
            val customers = repository.customers.first()

            val formatter = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

            val totalRevenue = orders.sumOf { it.total }
            val totalProfit = orders.sumOf { it.profit }
            val activeSubs = subscriptions.count { it.status == "active" }
            val now = System.currentTimeMillis()
            val expiringSoon = subscriptions.count {
                it.status == "active" && (it.expiryDate - now) in 0..(7L * 24 * 60 * 60 * 1000)
            }
            val pendingActivations = activations.count { it.status == "pending" }

            val topProducts = products.take(5).joinToString(", ") { "${it.name} (${formatter.format(it.sellingPrice)}, Stock: ${it.stock})" }

            """
            - Business: DigiTech Business OS (Software licenses, account invites, activation keys)
            - Total Customers: ${customers.size}
            - Total Orders: ${orders.size}
            - Total Revenue: ${formatter.format(totalRevenue)}
            - Total Profit: ${formatter.format(totalProfit)}
            - Active Subscriptions: $activeSubs
            - Expiring in <=7 Days: $expiringSoon
            - Pending Activations to Fulfill: $pendingActivations
            - Sample Catalog: $topProducts
            """.trimIndent()
        } catch (e: Exception) {
            "Business context unavailable"
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.release()
    }
}

class AiAssistantViewModelFactory(
    private val application: Application,
    private val repository: DigiTechRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AiAssistantViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AiAssistantViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
