package com.example.digitech.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.data.model.CustomerEntity
import com.example.digitech.data.model.ProductEntity
import com.example.digitech.ui.theme.BrandPrimary
import com.example.digitech.ui.theme.StatusSuccess
import com.example.digitech.ui.viewmodel.DigiTechViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateOrderDialog(
    viewModel: DigiTechViewModel,
    onDismiss: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    val products by viewModel.products.collectAsState()

    var selectedCustomer by remember { mutableStateOf(customers.firstOrNull()) }
    var selectedProduct by remember { mutableStateOf(products.firstOrNull()) }
    var quantityText by remember { mutableStateOf("1") }
    var customPriceText by remember { mutableStateOf("") }
    var discountText by remember { mutableStateOf("0") }
    var paymentMethod by remember { mutableStateOf("upi") }
    var paymentStatus by remember { mutableStateOf("paid") }
    var notes by remember { mutableStateOf("") }

    var expandedCustomerDropdown by remember { mutableStateOf(false) }
    var expandedProductDropdown by remember { mutableStateOf(false) }
    var expandedPaymentMethodDropdown by remember { mutableStateOf(false) }
    var expandedPaymentStatusDropdown by remember { mutableStateOf(false) }

    val paymentMethods = listOf("upi", "bank_transfer", "cash", "credit_card", "razorpay")
    val paymentStatuses = listOf("paid", "pending", "partially_paid")

    // Price calculations
    val quantity = quantityText.toIntOrNull()?.coerceAtLeast(1) ?: 1
    val basePrice = selectedProduct?.sellingPrice ?: 0.0
    val effectiveUnitPrice = customPriceText.toDoubleOrNull() ?: basePrice
    val discount = discountText.toDoubleOrNull() ?: 0.0
    val total = (effectiveUnitPrice * quantity - discount).coerceAtLeast(0.0)
    val unitCost = selectedProduct?.costPrice ?: 0.0
    val estimatedProfit = (effectiveUnitPrice - unitCost) * quantity - discount

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AddShoppingCart, contentDescription = null, tint = BrandPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Create New Order & Invoice", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Customer Selector
                item {
                    Text("Select Customer *", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    ExposedDropdownMenuBox(
                        expanded = expandedCustomerDropdown,
                        onExpandedChange = { expandedCustomerDropdown = !expandedCustomerDropdown }
                    ) {
                        OutlinedTextField(
                            value = selectedCustomer?.let { "${it.name} (${it.phone})" } ?: "Select Customer",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCustomerDropdown) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expandedCustomerDropdown,
                            onDismissRequest = { expandedCustomerDropdown = false }
                        ) {
                            customers.forEach { cust ->
                                DropdownMenuItem(
                                    text = { Text("${cust.name} • ${cust.phone.ifEmpty { cust.company }}") },
                                    onClick = {
                                        selectedCustomer = cust
                                        expandedCustomerDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Product Selector
                item {
                    Text("Select Product / Subscription *", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    ExposedDropdownMenuBox(
                        expanded = expandedProductDropdown,
                        onExpandedChange = { expandedProductDropdown = !expandedProductDropdown }
                    ) {
                        OutlinedTextField(
                            value = selectedProduct?.let { "${it.name} - ${Formatters.formatCurrency(it.sellingPrice)}" } ?: "Select Product",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedProductDropdown) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expandedProductDropdown,
                            onDismissRequest = { expandedProductDropdown = false }
                        ) {
                            products.forEach { prod ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(prod.name)
                                            Text(Formatters.formatCurrency(prod.sellingPrice), fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    onClick = {
                                        selectedProduct = prod
                                        customPriceText = prod.sellingPrice.toInt().toString()
                                        expandedProductDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Quantity and Custom Unit Price
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = quantityText,
                            onValueChange = { quantityText = it },
                            label = { Text("Quantity") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = customPriceText,
                            onValueChange = { customPriceText = it },
                            label = { Text("Unit Price (₹)") },
                            placeholder = { Text(selectedProduct?.sellingPrice?.toInt()?.toString() ?: "0") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                // Discount & Payment Mode
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = discountText,
                            onValueChange = { discountText = it },
                            label = { Text("Discount (₹)") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )

                        // Payment Method Dropdown
                        ExposedDropdownMenuBox(
                            expanded = expandedPaymentMethodDropdown,
                            onExpandedChange = { expandedPaymentMethodDropdown = !expandedPaymentMethodDropdown },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = paymentMethod.uppercase(),
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Payment") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedPaymentMethodDropdown) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = expandedPaymentMethodDropdown,
                                onDismissRequest = { expandedPaymentMethodDropdown = false }
                            ) {
                                paymentMethods.forEach { method ->
                                    DropdownMenuItem(
                                        text = { Text(method.replace('_', ' ').uppercase()) },
                                        onClick = {
                                            paymentMethod = method
                                            expandedPaymentMethodDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Payment Status & Notes
                item {
                    ExposedDropdownMenuBox(
                        expanded = expandedPaymentStatusDropdown,
                        onExpandedChange = { expandedPaymentStatusDropdown = !expandedPaymentStatusDropdown }
                    ) {
                        OutlinedTextField(
                            value = paymentStatus.replace('_', ' ').uppercase(),
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Payment Status") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedPaymentStatusDropdown) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expandedPaymentStatusDropdown,
                            onDismissRequest = { expandedPaymentStatusDropdown = false }
                        ) {
                            paymentStatuses.forEach { status ->
                                DropdownMenuItem(
                                    text = { Text(status.replace('_', ' ').uppercase()) },
                                    onClick = {
                                        paymentStatus = status
                                        expandedPaymentStatusDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Order / Activation Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                // Total Summary Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total Amount to Bill:", fontWeight = FontWeight.SemiBold)
                                Text(
                                    Formatters.formatCurrency(total),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = BrandPrimary
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Estimated Profit:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    Formatters.formatCurrency(estimatedProfit),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = StatusSuccess
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val customer = selectedCustomer
                    val product = selectedProduct
                    if (customer != null && product != null) {
                        viewModel.createOrder(
                            customer = customer,
                            product = product,
                            quantity = quantity,
                            customPrice = effectiveUnitPrice,
                            discount = discount,
                            paymentMethod = paymentMethod,
                            paymentStatus = paymentStatus,
                            notes = notes
                        )
                        onDismiss()
                    }
                },
                enabled = selectedCustomer != null && selectedProduct != null
            ) {
                Text("Place Order & Generate Invoice")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
