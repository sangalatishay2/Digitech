package com.example.digitech.auth

import androidx.compose.ui.graphics.Color
import com.example.digitech.ui.theme.StatusDanger
import com.example.digitech.ui.theme.StatusSuccess
import com.example.digitech.ui.theme.StatusWarning

enum class PasswordStrengthLevel(val label: String, val color: Color, val progress: Float) {
    EMPTY("Empty", Color(0xFF6B7280), 0.0f),
    VERY_WEAK("Very Weak", StatusDanger, 0.2f),
    WEAK("Weak", Color(0xFFF97316), 0.4f),
    FAIR("Fair", StatusWarning, 0.6f),
    GOOD("Good", Color(0xFF3B82F6), 0.8f),
    STRONG("Strong", StatusSuccess, 1.0f)
}

data class PasswordRequirement(
    val id: String,
    val label: String,
    val isMet: Boolean
)

data class PasswordStrength(
    val level: PasswordStrengthLevel,
    val score: Int,
    val maxScore: Int = 5,
    val requirements: List<PasswordRequirement>
)

object PasswordStrengthValidator {

    fun evaluate(password: String): PasswordStrength {
        if (password.isEmpty()) {
            return PasswordStrength(
                level = PasswordStrengthLevel.EMPTY,
                score = 0,
                requirements = listOf(
                    PasswordRequirement("length", "At least 8 characters", false),
                    PasswordRequirement("lowercase", "Contains lowercase (a-z)", false),
                    PasswordRequirement("uppercase", "Contains uppercase (A-Z)", false),
                    PasswordRequirement("number", "Contains number (0-9)", false),
                    PasswordRequirement("special", "Contains special symbol (@, #, $, etc.)", false)
                )
            )
        }

        val hasLength = password.length >= 8
        val hasLower = password.any { it.isLowerCase() }
        val hasUpper = password.any { it.isUpperCase() }
        val hasDigit = password.any { it.isDigit() }
        val hasSpecial = password.any { !it.isLetterOrDigit() }

        val requirements = listOf(
            PasswordRequirement("length", "At least 8 characters", hasLength),
            PasswordRequirement("lowercase", "Contains lowercase (a-z)", hasLower),
            PasswordRequirement("uppercase", "Contains uppercase (A-Z)", hasUpper),
            PasswordRequirement("number", "Contains number (0-9)", hasDigit),
            PasswordRequirement("special", "Contains special symbol (@, #, $, etc.)", hasSpecial)
        )

        val score = requirements.count { it.isMet }

        val level = when (score) {
            0, 1 -> PasswordStrengthLevel.VERY_WEAK
            2 -> PasswordStrengthLevel.WEAK
            3 -> PasswordStrengthLevel.FAIR
            4 -> PasswordStrengthLevel.GOOD
            5 -> PasswordStrengthLevel.STRONG
            else -> PasswordStrengthLevel.EMPTY
        }

        return PasswordStrength(
            level = level,
            score = score,
            maxScore = 5,
            requirements = requirements
        )
    }
}
