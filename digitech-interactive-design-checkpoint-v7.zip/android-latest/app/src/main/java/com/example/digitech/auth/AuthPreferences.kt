package com.example.digitech.auth

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.authDataStore: DataStore<Preferences> by preferencesDataStore(name = "auth_preferences")

data class UserProfileData(
    val name: String = "",
    val photoUrl: String = "",
    val rolePreference: String = "no_access",
    val isProfileSetupCompleted: Boolean = false
)

enum class SyncFrequency(val title: String, val description: String, val intervalMinutes: Long) {
    REALTIME("Live Supabase", "Organization-scoped updates from the DigiTech source of truth", 0),
    PERIODIC_15MIN("Every 15 Minutes", "Refresh organization data every 15 minutes", 15),
    PERIODIC_1HR("Hourly Sync", "Optimized for maximum battery and data preservation", 60),
    MANUAL_ONLY("Manual Pull Only", "Syncs exclusively on manual pull-to-refresh gestures", -1);

    companion object {
        fun fromString(value: String): SyncFrequency {
            return values().firstOrNull { it.name.equals(value, ignoreCase = true) } ?: REALTIME
        }
    }
}

class AuthPreferences(private val context: Context) {

    private object PreferencesKeys {
        val REMEMBER_ME = booleanPreferencesKey("remember_me")
        val REMEMBERED_EMAIL = stringPreferencesKey("remembered_email")
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val IS_DARK_THEME = booleanPreferencesKey("is_dark_theme")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val SYNC_FREQUENCY = stringPreferencesKey("sync_frequency")

        // User Profile
        val USER_NAME = stringPreferencesKey("user_name")
        val USER_PHOTO_URL = stringPreferencesKey("user_photo_url")
        val USER_ROLE = stringPreferencesKey("user_role")
        val PROFILE_SETUP_COMPLETED = booleanPreferencesKey("profile_setup_completed")

        // Auto Backup
        val AUTO_BACKUP_ENABLED = booleanPreferencesKey("auto_backup_enabled")
        val LAST_BACKUP_TIMESTAMP = longPreferencesKey("last_backup_timestamp")
        val LAST_BACKUP_SUMMARY = stringPreferencesKey("last_backup_summary")
    }

    val rememberMeFlow: Flow<Boolean> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[PreferencesKeys.REMEMBER_ME] ?: false
        }

    val rememberedEmailFlow: Flow<String> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[PreferencesKeys.REMEMBER_ME].let { isRemembered ->
                if (isRemembered == true) {
                    preferences[PreferencesKeys.REMEMBERED_EMAIL] ?: ""
                } else {
                    ""
                }
            }
        }

    val isDarkThemeFlow: Flow<Boolean> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[PreferencesKeys.IS_DARK_THEME] ?: true // default dark mode
        }

    val isOnboardingCompletedFlow: Flow<Boolean> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[PreferencesKeys.ONBOARDING_COMPLETED] ?: false
        }

    val syncFrequencyFlow: Flow<SyncFrequency> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            val stored = preferences[PreferencesKeys.SYNC_FREQUENCY] ?: SyncFrequency.REALTIME.name
            SyncFrequency.fromString(stored)
        }

    val userProfileFlow: Flow<UserProfileData> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            UserProfileData(
                name = preferences[PreferencesKeys.USER_NAME] ?: "",
                photoUrl = preferences[PreferencesKeys.USER_PHOTO_URL] ?: "",
                rolePreference = preferences[PreferencesKeys.USER_ROLE] ?: "no_access",
                isProfileSetupCompleted = preferences[PreferencesKeys.PROFILE_SETUP_COMPLETED] ?: false
            )
        }

    val autoBackupEnabledFlow: Flow<Boolean> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[PreferencesKeys.AUTO_BACKUP_ENABLED] ?: true
        }

    val lastBackupTimestampFlow: Flow<Long> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[PreferencesKeys.LAST_BACKUP_TIMESTAMP] ?: 0L
        }

    val lastBackupSummaryFlow: Flow<String> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[PreferencesKeys.LAST_BACKUP_SUMMARY] ?: "No backup taken yet"
        }

    suspend fun saveRememberMe(rememberMe: Boolean, email: String) {
        context.authDataStore.edit { preferences ->
            preferences[PreferencesKeys.REMEMBER_ME] = rememberMe
            if (rememberMe) {
                preferences[PreferencesKeys.REMEMBERED_EMAIL] = email.trim()
            } else {
                preferences.remove(PreferencesKeys.REMEMBERED_EMAIL)
            }
        }
    }

    suspend fun clearCredentials() {
        context.authDataStore.edit { preferences ->
            preferences[PreferencesKeys.REMEMBER_ME] = false
            preferences.remove(PreferencesKeys.REMEMBERED_EMAIL)
        }
    }

    suspend fun setDarkTheme(isDark: Boolean) {
        context.authDataStore.edit { preferences ->
            preferences[PreferencesKeys.IS_DARK_THEME] = isDark
        }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.authDataStore.edit { preferences ->
            preferences[PreferencesKeys.ONBOARDING_COMPLETED] = completed
        }
    }

    suspend fun setSyncFrequency(frequency: SyncFrequency) {
        context.authDataStore.edit { preferences ->
            preferences[PreferencesKeys.SYNC_FREQUENCY] = frequency.name
        }
    }

    suspend fun setAutoBackupEnabled(enabled: Boolean) {
        context.authDataStore.edit { preferences ->
            preferences[PreferencesKeys.AUTO_BACKUP_ENABLED] = enabled
        }
    }

    suspend fun recordBackupCompleted(timestamp: Long, summary: String) {
        context.authDataStore.edit { preferences ->
            preferences[PreferencesKeys.LAST_BACKUP_TIMESTAMP] = timestamp
            preferences[PreferencesKeys.LAST_BACKUP_SUMMARY] = summary
        }
    }

    suspend fun saveUserProfile(name: String, photoUrl: String, role: String) {
        context.authDataStore.edit { preferences ->
            preferences[PreferencesKeys.USER_NAME] = name.trim()
            preferences[PreferencesKeys.USER_PHOTO_URL] = photoUrl.trim()
            // The role argument is intentionally ignored. Role changes only arrive
            // through saveTrustedServerProfile after an authenticated server lookup.
            preferences[PreferencesKeys.PROFILE_SETUP_COMPLETED] = true
        }
    }

    suspend fun saveTrustedServerProfile(name: String?, role: String) {
        val trustedRole = RolePermissions.getRole(role).id
        context.authDataStore.edit { preferences ->
            if (!name.isNullOrBlank()) preferences[PreferencesKeys.USER_NAME] = name.trim()
            preferences[PreferencesKeys.USER_ROLE] = trustedRole
        }
    }

    suspend fun clearServerRole() {
        context.authDataStore.edit { preferences ->
            preferences[PreferencesKeys.USER_ROLE] = RolePermissions.NO_ACCESS.id
        }
    }

    suspend fun resetOnboardingAndProfile() {
        context.authDataStore.edit { preferences ->
            preferences[PreferencesKeys.ONBOARDING_COMPLETED] = false
            preferences[PreferencesKeys.PROFILE_SETUP_COMPLETED] = false
        }
    }
}
