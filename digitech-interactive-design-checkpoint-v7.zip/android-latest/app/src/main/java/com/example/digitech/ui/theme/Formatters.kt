package com.example.digitech.ui.theme

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object Formatters {
    private val indiaLocale = Locale("en", "IN")

    fun formatCurrency(value: Double): String =
        NumberFormat.getCurrencyInstance(indiaLocale).apply {
            maximumFractionDigits = if (value % 1.0 == 0.0) 0 else 2
        }.format(value)

    fun formatDate(timestamp: Long): String =
        SimpleDateFormat("dd MMM yyyy", indiaLocale).format(Date(timestamp))

    fun formatDateTime(timestamp: Long): String =
        SimpleDateFormat("dd MMM yyyy, hh:mm a", indiaLocale).format(Date(timestamp))

    fun getDaysRemaining(expiryTimestamp: Long, now: Long = System.currentTimeMillis()): Long {
        val delta = expiryTimestamp - now
        return if (delta <= 0) {
            TimeUnit.MILLISECONDS.toDays(delta)
        } else {
            kotlin.math.ceil(delta.toDouble() / TimeUnit.DAYS.toMillis(1)).toLong()
        }
    }
}
