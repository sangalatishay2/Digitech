package com.example.digitech.data.remote

import com.example.digitech.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

@Serializable
data class SupabaseUser(
    val id: String,
    val email: String? = null,
    @SerialName("user_metadata") val userMetadata: JsonObject = JsonObject(emptyMap())
)

@Serializable
data class SupabaseSession(
    @SerialName("access_token") val accessToken: String,
    @SerialName("refresh_token") val refreshToken: String,
    @SerialName("expires_in") val expiresIn: Long = 3600,
    val user: SupabaseUser
)

@Serializable
data class SupabaseProfile(
    val id: String,
    @SerialName("organization_id") val organizationId: String,
    val role: String,
    @SerialName("is_active") val isActive: Boolean = false,
    @SerialName("deleted_at") val deletedAt: String? = null,
    @SerialName("full_name") val fullName: String? = null
)

@Serializable
private data class EmailCredentials(val email: String, val password: String)

@Serializable
private data class RefreshCredentials(@SerialName("refresh_token") val refreshToken: String)

@Serializable
private data class IdTokenCredentials(
    val provider: String = "google",
    @SerialName("id_token") val idToken: String
)

@Serializable
private data class RecoveryRequest(val email: String)

class SupabaseAuthClient {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val http = OkHttpClient()
    private val baseUrl = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val anonKey = BuildConfig.SUPABASE_ANON_KEY

    val isConfigured: Boolean get() = baseUrl.startsWith("https://") && anonKey.isNotBlank()

    suspend fun signIn(email: String, password: String): SupabaseSession =
        authRequest("/auth/v1/token?grant_type=password", EmailCredentials(email, password))

    suspend fun signUp(email: String, password: String): SupabaseSession =
        authRequest("/auth/v1/signup", EmailCredentials(email, password))

    suspend fun signInWithGoogle(idToken: String): SupabaseSession =
        authRequest("/auth/v1/token?grant_type=id_token", IdTokenCredentials(idToken = idToken))

    suspend fun refresh(refreshToken: String): SupabaseSession =
        authRequest("/auth/v1/token?grant_type=refresh_token", RefreshCredentials(refreshToken))

    suspend fun requestPasswordReset(email: String) = withContext(Dispatchers.IO) {
        execute("/auth/v1/recover", "POST", json.encodeToString(RecoveryRequest.serializer(), RecoveryRequest(email)))
    }

    suspend fun fetchProfile(accessToken: String, userId: String): SupabaseProfile = withContext(Dispatchers.IO) {
        val path = "/rest/v1/profiles?auth_user_id=eq.$userId&select=id,organization_id,role,is_active,deleted_at,full_name&limit=1"
        val response = execute(path, "GET", null, accessToken)
        val profiles = json.decodeFromString<List<SupabaseProfile>>(response)
        profiles.firstOrNull()?.takeIf { it.isActive && it.deletedAt == null }
            ?: throw IllegalStateException("This account has no active DigiTech organization profile.")
    }

    suspend fun signOut(accessToken: String) = withContext(Dispatchers.IO) {
        runCatching { execute("/auth/v1/logout", "POST", "{}", accessToken) }
    }

    private suspend inline fun <reified T> authRequest(path: String, body: T): SupabaseSession =
        withContext(Dispatchers.IO) {
            checkConfigured()
            val encoded = json.encodeToString(kotlinx.serialization.serializer<T>(), body)
            json.decodeFromString<SupabaseSession>(execute(path, "POST", encoded))
        }

    private fun execute(path: String, method: String, body: String?, bearer: String? = null): String {
        checkConfigured()
        val requestBody = body?.toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("$baseUrl$path")
            .header("apikey", anonKey)
            .header("Authorization", "Bearer ${bearer ?: anonKey}")
            .header("Accept", "application/json")
            .method(method, requestBody)
            .build()
        http.newCall(request).execute().use { response ->
            val payload = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val safeReason = runCatching {
                    val obj = json.parseToJsonElement(payload).jsonObject
                    obj["msg"]?.toString()?.trim('"')
                        ?: obj["error_description"]?.toString()?.trim('"')
                }.getOrNull()
                throw IllegalStateException(safeReason ?: "Authentication service returned ${response.code}.")
            }
            return payload
        }
    }

    private fun checkConfigured() {
        check(isConfigured) { "Supabase connection is not configured for this build." }
    }
}
