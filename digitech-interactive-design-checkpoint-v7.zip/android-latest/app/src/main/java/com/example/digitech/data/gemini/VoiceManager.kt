package com.example.digitech.data.gemini

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.*

sealed class VoiceState {
    object Idle : VoiceState()
    object Listening : VoiceState()
    object Processing : VoiceState()
    data class Speaking(val text: String) : VoiceState()
    data class Error(val message: String) : VoiceState()
}

class VoiceManager(
    private val context: Context,
    private val geminiClient: GeminiClient,
    private val scope: CoroutineScope
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _audioAmplitude = MutableStateFlow(0f)
    val audioAmplitude: StateFlow<Float> = _audioAmplitude.asStateFlow()

    private val _recognizedText = MutableStateFlow("")
    val recognizedText: StateFlow<String> = _recognizedText.asStateFlow()

    private val _conversationHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val conversationHistory: StateFlow<List<ChatMessage>> = _conversationHistory.asStateFlow()

    var isHandsFreeMode = false
    var selectedRole: AiRole = AiRole.BUSINESS_COPILOT
    var isMuted = false

    init {
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.let { tts ->
                    tts.language = Locale.US
                    tts.setSpeechRate(1.05f)
                    tts.setPitch(1.0f)
                    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}

                        override fun onDone(utteranceId: String?) {
                            scope.launch(Dispatchers.Main) {
                                if (isHandsFreeMode) {
                                    startListening()
                                } else {
                                    _voiceState.value = VoiceState.Idle
                                }
                            }
                        }

                        override fun onError(utteranceId: String?) {
                            scope.launch(Dispatchers.Main) {
                                _voiceState.value = VoiceState.Idle
                            }
                        }
                    })
                    isTtsInitialized = true
                }
            } else {
                Log.e("VoiceManager", "Failed to initialize TTS")
            }
        }
    }

    fun startListening() {
        stopSpeaking()

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _voiceState.value = VoiceState.Error("Speech recognition is not available on this device.")
            return
        }

        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _voiceState.value = VoiceState.Listening
                    }

                    override fun onBeginningOfSpeech() {
                        _voiceState.value = VoiceState.Listening
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        // Normalize amplitude for wave animation (0.0 to 1.0)
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        _audioAmplitude.value = normalized
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _voiceState.value = VoiceState.Processing
                        _audioAmplitude.value = 0f
                    }

                    override fun onError(error: Int) {
                        _audioAmplitude.value = 0f
                        val errorMessage = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                            SpeechRecognizer.ERROR_CLIENT -> "Client side error"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Audio permission required"
                            SpeechRecognizer.ERROR_NETWORK -> "Network error occurred"
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized"
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognition service busy"
                            SpeechRecognizer.ERROR_SERVER -> "Server error"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
                            else -> "Recognition error: $error"
                        }
                        Log.w("VoiceManager", "Speech error: $errorMessage")
                        _voiceState.value = VoiceState.Idle
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val query = matches?.firstOrNull() ?: ""
                        if (query.isNotBlank()) {
                            _recognizedText.value = query
                            processVoiceInput(query)
                        } else {
                            _voiceState.value = VoiceState.Idle
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        matches?.firstOrNull()?.let {
                            _recognizedText.value = it
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }

            speechRecognizer?.startListening(intent)
            _voiceState.value = VoiceState.Listening
        } catch (e: Exception) {
            Log.e("VoiceManager", "Error starting listening", e)
            _voiceState.value = VoiceState.Error(e.localizedMessage ?: "Failed to start listening")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            _audioAmplitude.value = 0f
            if (_voiceState.value is VoiceState.Listening) {
                _voiceState.value = VoiceState.Idle
            }
        } catch (e: Exception) {
            Log.e("VoiceManager", "Error stopping listening", e)
        }
    }

    fun processVoiceInput(userSpeech: String, liveContext: String? = null) {
        val userMsg = ChatMessage(
            role = "user",
            content = userSpeech
        )

        val updatedHistory = _conversationHistory.value + userMsg
        _conversationHistory.value = updatedHistory
        _voiceState.value = VoiceState.Processing

        scope.launch {
            val systemInstruction = buildString {
                append(selectedRole.systemInstruction)
                append("\n\nYou are in Live Voice Conversation mode with the user. Keep your voice responses concise, conversational, friendly, and natural for spoken audio. Avoid long tables or raw markdown syntax. Speak directly to the point.")
                if (!liveContext.isNullOrBlank()) {
                    append("\n\nCurrent Real-time Business Context Snapshot:\n").append(liveContext)
                }
            }

            // Use gemini-3.1-flash-live-preview for real-time live conversation
            val result = geminiClient.generateResponse(
                model = GeminiModels.GEMINI_3_1_FLASH_LIVE,
                history = updatedHistory,
                systemInstruction = systemInstruction,
                temperature = 0.8f
            )

            result.onSuccess { replyText ->
                val assistantMsg = ChatMessage(
                    role = "model",
                    content = replyText,
                    modelUsed = GeminiModels.GEMINI_3_1_FLASH_LIVE
                )
                _conversationHistory.value = _conversationHistory.value + assistantMsg
                speakText(replyText)
            }.onFailure { error ->
                val errorMsg = error.localizedMessage ?: "Failed to generate voice response"
                _voiceState.value = VoiceState.Error(errorMsg)
            }
        }
    }

    private fun speakText(text: String) {
        if (isMuted) {
            _voiceState.value = VoiceState.Idle
            return
        }

        _voiceState.value = VoiceState.Speaking(text)
        if (isTtsInitialized && textToSpeech != null) {
            // Clean markdown tokens for spoken clarity
            val cleanForVoice = text
                .replace(Regex("\\*\\*|\\*|_|#|>|`"), "")
                .replace(Regex("\\[.*?\\]\\(.*?\\)"), "")

            textToSpeech?.speak(
                cleanForVoice,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "gemini_voice_turn_${System.currentTimeMillis()}"
            )
        } else {
            _voiceState.value = VoiceState.Idle
        }
    }

    fun stopSpeaking() {
        try {
            textToSpeech?.stop()
            if (_voiceState.value is VoiceState.Speaking) {
                _voiceState.value = VoiceState.Idle
            }
        } catch (e: Exception) {
            Log.e("VoiceManager", "Error stopping speech", e)
        }
    }

    fun clearHistory() {
        stopSpeaking()
        stopListening()
        _conversationHistory.value = emptyList()
        _recognizedText.value = ""
        _voiceState.value = VoiceState.Idle
    }

    fun release() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        } catch (e: Exception) {
            Log.e("VoiceManager", "Error releasing voice manager", e)
        }
    }
}
