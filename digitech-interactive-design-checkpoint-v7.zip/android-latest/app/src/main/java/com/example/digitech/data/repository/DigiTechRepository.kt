package com.example.digitech.data.repository

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.digitech.auth.SyncFrequency
import com.example.digitech.auth.UserProfileData
import com.example.digitech.data.db.DigiTechDao
import com.example.digitech.data.export.CsvExportHelper
import com.example.digitech.data.sync.SyncStatus
import com.example.digitech.data.model.*
import com.example.digitech.data.remote.SupabaseBusinessClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class DigiTechRepository(
    private val dao: DigiTechDao,
    private val context: Context,
    private val scope: CoroutineScope,
    private val remote: SupabaseBusinessClient = SupabaseBusinessClient()
) {
    private data class BusinessSession(val accessToken: String, val organizationId: String, val role: String)
    @Volatile private var session: BusinessSession? = null
    private val _syncStatus = MutableStateFlow<SyncStatus>(SyncStatus.Idle)
    val syncStatus: StateFlow<SyncStatus> = _syncStatus

    val customers: Flow<List<CustomerEntity>> = dao.getAllCustomers()
    val products: Flow<List<ProductEntity>> = dao.getAllProducts()
    val orders: Flow<List<OrderEntity>> = dao.getAllOrders()
    val subscriptions: Flow<List<SubscriptionEntity>> = dao.getAllSubscriptions()
    val activations: Flow<List<ActivationEntity>> = dao.getAllActivations()
    val expenses: Flow<List<ExpenseEntity>> = dao.getAllExpenses()
    val suppliers: Flow<List<SupplierEntity>> = dao.getAllSuppliers()
    val leads: Flow<List<LeadEntity>> = dao.getAllLeads()
    val tickets: Flow<List<SupportTicketEntity>> = dao.getAllTickets()
    val tasks: Flow<List<TaskEntity>> = dao.getAllTasks()
    val activityLogs: Flow<List<ActivityLogEntity>> = dao.getAllActivityLogs()

    fun startCloudSync(accessToken: String, organizationId: String, role: String, frequency: SyncFrequency = SyncFrequency.REALTIME) {
        session = BusinessSession(accessToken, organizationId, role)
        scope.launch { forceManualSync() }
    }

    fun updateSyncFrequency(frequency: SyncFrequency) {
        _syncStatus.value = SyncStatus.Idle
    }

    fun stopCloudSync() {
        _syncStatus.value = SyncStatus.Idle
    }

    suspend fun forceManualSync() = withContext(Dispatchers.IO) {
        val active = session ?: run {
            _syncStatus.value = SyncStatus.Error("Sign in before syncing business data.")
            return@withContext
        }
        _syncStatus.value = SyncStatus.Syncing
        runCatching { remote.fetchSnapshot(active.accessToken, active.organizationId) }
            .onSuccess {
                dao.replaceFromServer(it)
                _syncStatus.value = SyncStatus.Synced
            }
            .onFailure { error ->
                _syncStatus.value = SyncStatus.Error(error.message ?: "Secure sync failed.")
            }
    }

    suspend fun logActivity(
        actionType: String,
        title: String,
        description: String,
        actorEmail: String = "",
        role: String = "no_access",
        metadata: String = ""
    ) = withContext(Dispatchers.IO) {
        val email = actorEmail.ifBlank { "authenticated_user" }
        val log = ActivityLogEntity(
            id = "log_${UUID.randomUUID().toString().take(12)}",
            actionType = actionType,
            title = title,
            description = description,
            actorEmail = email,
            role = role,
            timestamp = System.currentTimeMillis(),
            metadata = metadata
        )
        dao.insertActivityLog(log)
    }

    suspend fun exportDataToJson(userProfile: UserProfileData, userEmail: String, syncFreq: SyncFrequency): String = withContext(Dispatchers.IO) {
        val root = JSONObject()

        // Metadata
        val meta = JSONObject().apply {
            put("app", "DigiTech Manager")
            put("version", "2.4.0-enterprise")
            put("exportTimestamp", System.currentTimeMillis())
            put("exportDateFormatted", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))
            put("accountEmail", userEmail.ifBlank { "anonymous_merchant" })
        }
        root.put("exportMetadata", meta)

        // User Profile & Preferences
        val profileJson = JSONObject().apply {
            put("name", userProfile.name)
            put("rolePreference", userProfile.rolePreference)
            put("photoUrl", userProfile.photoUrl)
            put("isProfileSetupCompleted", userProfile.isProfileSetupCompleted)
            put("syncFrequencyPreference", syncFreq.name)
        }
        root.put("userProfile", profileJson)

        // Activity Logs
        val logs = dao.getAllActivityLogs().first()
        val logsArray = JSONArray()
        logs.forEach { log ->
            val logObj = JSONObject().apply {
                put("id", log.id)
                put("actionType", log.actionType)
                put("title", log.title)
                put("description", log.description)
                put("actorEmail", log.actorEmail)
                put("role", log.role)
                put("timestamp", log.timestamp)
                put("formattedTime", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(log.timestamp)))
                put("metadata", log.metadata)
            }
            logsArray.put(logObj)
        }
        root.put("activityLogs", logsArray)

        // Business Summary Snapshot
        val currentOrders = dao.getAllOrders().first()
        val currentCustomers = dao.getAllCustomers().first()
        val currentSubs = dao.getAllSubscriptions().first()
        val currentProducts = dao.getAllProducts().first()

        val summary = JSONObject().apply {
            put("totalCustomers", currentCustomers.size)
            put("totalCatalogProducts", currentProducts.size)
            put("totalOrdersCount", currentOrders.size)
            put("totalRevenue", currentOrders.sumOf { it.total })
            put("totalProfit", currentOrders.sumOf { it.profit })
            put("activeSubscriptionsCount", currentSubs.count { it.status == "active" })
        }
        root.put("businessSummary", summary)

        root.toString(2)
    }

    suspend fun exportDataAndShare(
        context: Context,
        userProfile: UserProfileData,
        userEmail: String,
        syncFreq: SyncFrequency
    ) = withContext(Dispatchers.IO) {
        val jsonContent = exportDataToJson(userProfile, userEmail, syncFreq)
        val filename = "digitech_export_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.json"
        val exportFile = File(context.cacheDir, filename)
        FileOutputStream(exportFile).use { out ->
            out.write(jsonContent.toByteArray(Charsets.UTF_8))
        }

        logActivity(
            actionType = "DATA_EXPORT",
            title = "Exported User Profile & Activity Data",
            description = "Generated JSON portability file: $filename (${exportFile.length()} bytes)",
            actorEmail = userEmail,
            role = userProfile.rolePreference
        )

        withContext(Dispatchers.Main) {
            try {
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    exportFile
                )
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "DigiTech Data Portability Export")
                    putExtra(Intent.EXTRA_TEXT, "Attached is your exported DigiTech Profile & Activity Logs JSON dataset.")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val chooser = Intent.createChooser(shareIntent, "Share / Export JSON Archive").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                // Fallback to text send intent if FileProvider uri launch fails
                val textIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "DigiTech Data Portability Export (JSON)")
                    putExtra(Intent.EXTRA_TEXT, jsonContent)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val chooser = Intent.createChooser(textIntent, "Export JSON Data").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            }
        }
    }

    suspend fun exportOrdersCsv(context: Context, userEmail: String, role: String) = withContext(Dispatchers.IO) {
        val ordersList = dao.getAllOrders().first()
        val csv = CsvExportHelper.generateOrdersCsv(ordersList)
        logActivity(
            actionType = "CSV_EXPORT",
            title = "Exported Orders & Sales CSV",
            description = "Generated spreadsheet with ${ordersList.size} order records for accounting",
            actorEmail = userEmail,
            role = role
        )
        withContext(Dispatchers.Main) {
            CsvExportHelper.shareCsvFile(
                context = context,
                csvContent = csv,
                filePrefix = "digitech_orders_sales",
                subject = "Orders & Sales Report (CSV/Excel)"
            )
        }
    }

    suspend fun exportProductsCsv(context: Context, userEmail: String, role: String) = withContext(Dispatchers.IO) {
        val productsList = dao.getAllProducts().first()
        val csv = CsvExportHelper.generateProductsCsv(productsList)
        logActivity(
            actionType = "CSV_EXPORT",
            title = "Exported Products & Inventory CSV",
            description = "Generated catalog spreadsheet with ${productsList.size} product listings",
            actorEmail = userEmail,
            role = role
        )
        withContext(Dispatchers.Main) {
            CsvExportHelper.shareCsvFile(
                context = context,
                csvContent = csv,
                filePrefix = "digitech_products_inventory",
                subject = "Products & Inventory Catalog (CSV/Excel)"
            )
        }
    }

    suspend fun exportSubscriptionsCsv(context: Context, userEmail: String, role: String) = withContext(Dispatchers.IO) {
        val subsList = dao.getAllSubscriptions().first()
        val csv = CsvExportHelper.generateSubscriptionsCsv(subsList)
        logActivity(
            actionType = "CSV_EXPORT",
            title = "Exported Subscriptions & Renewals CSV",
            description = "Generated recurring subscription spreadsheet with ${subsList.size} client services",
            actorEmail = userEmail,
            role = role
        )
        withContext(Dispatchers.Main) {
            CsvExportHelper.shareCsvFile(
                context = context,
                csvContent = csv,
                filePrefix = "digitech_subscriptions_renewals",
                subject = "Subscriptions & Renewals Report (CSV/Excel)"
            )
        }
    }

    suspend fun exportCustomersCsv(context: Context, userEmail: String, role: String) = withContext(Dispatchers.IO) {
        val customersList = dao.getAllCustomers().first()
        val csv = CsvExportHelper.generateCustomersCsv(customersList)
        logActivity(
            actionType = "CSV_EXPORT",
            title = "Exported Customers Directory CSV",
            description = "Generated customer contacts spreadsheet with ${customersList.size} accounts",
            actorEmail = userEmail,
            role = role
        )
        withContext(Dispatchers.Main) {
            CsvExportHelper.shareCsvFile(
                context = context,
                csvContent = csv,
                filePrefix = "digitech_customers_directory",
                subject = "Customers Directory (CSV/Excel)"
            )
        }
    }

    suspend fun exportExpensesCsv(context: Context, userEmail: String, role: String) = withContext(Dispatchers.IO) {
        val expenseList = dao.getAllExpenses().first()
        val csv = CsvExportHelper.generateExpensesCsv(expenseList)
        logActivity(
            actionType = "CSV_EXPORT",
            title = "Exported Expenses Log CSV",
            description = "Generated expense ledger spreadsheet with ${expenseList.size} entries",
            actorEmail = userEmail,
            role = role
        )
        withContext(Dispatchers.Main) {
            CsvExportHelper.shareCsvFile(
                context = context,
                csvContent = csv,
                filePrefix = "digitech_expenses_ledger",
                subject = "Business Expenses Ledger (CSV/Excel)"
            )
        }
    }

    suspend fun createDriveBackupBundle(
        context: Context,
        userProfile: UserProfileData,
        userEmail: String,
        syncFreq: SyncFrequency
    ): String = withContext(Dispatchers.IO) {
        val jsonContent = exportDataToJson(userProfile, userEmail, syncFreq)
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val filename = "DigiTech_Enterprise_Backup_$timestamp.json"
        val backupFile = File(context.cacheDir, filename)
        FileOutputStream(backupFile).use { out ->
            out.write(jsonContent.toByteArray(Charsets.UTF_8))
        }

        val orders = dao.getAllOrders().first()
        val customers = dao.getAllCustomers().first()
        val products = dao.getAllProducts().first()
        val summaryText = "${orders.size} orders, ${products.size} products, ${customers.size} clients (${backupFile.length() / 1024} KB)"

        logActivity(
            actionType = "CLOUD_BACKUP",
            title = "Created Full Drive & Storage Backup",
            description = "Enterprise archive bundle saved: $filename ($summaryText)",
            actorEmail = userEmail,
            role = userProfile.rolePreference
        )

        withContext(Dispatchers.Main) {
            try {
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    backupFile
                )
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "DigiTech Enterprise Backup - $timestamp")
                    putExtra(Intent.EXTRA_TEXT, "DigiTech Complete Cloud & Local Database Backup Snapshot ($summaryText).\nSave to Google Drive or secure offline storage.")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val chooser = Intent.createChooser(shareIntent, "Save Backup to Google Drive / Cloud / Local").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                val fallback = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "DigiTech Backup Snapshot")
                    putExtra(Intent.EXTRA_TEXT, jsonContent)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val chooser = Intent.createChooser(fallback, "Save Backup Archive").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            }
        }

        summaryText
    }

    suspend fun initializeSeedDataIfEmpty() = withContext(Dispatchers.IO) {
        // Intentionally empty: absence of remote data is not permission to seed demo data.
    }

    suspend fun resetToSeedData() = withContext(Dispatchers.IO) {
        throw IllegalStateException("Demo database reset is disabled in production builds.")
    }

    suspend fun clearLocalSessionData() = withContext(Dispatchers.IO) {
        stopCloudSync()
        session = null
        dao.clearAllSessionData()
    }

    private fun requireSession(): BusinessSession = session
        ?: throw IllegalStateException("Your secure session expired. Sign in again.")

    private suspend fun refreshAfterWrite() {
        val active = requireSession()
        dao.replaceFromServer(remote.fetchSnapshot(active.accessToken, active.organizationId))
        _syncStatus.value = SyncStatus.Synced
    }

    private fun isServerId(id: String) = runCatching { UUID.fromString(id) }.isSuccess

    // Customer actions
    suspend fun saveCustomer(customer: CustomerEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        val body = JSONObject().apply {
            put("organization_id", active.organizationId); put("customer_code", customer.customerCode)
            put("name", customer.name); put("email", customer.email.ifBlank { JSONObject.NULL })
            put("phone", customer.phone.ifBlank { JSONObject.NULL }); put("whatsapp", customer.whatsapp.ifBlank { JSONObject.NULL })
            put("company", customer.company.ifBlank { JSONObject.NULL }); put("city", customer.city.ifBlank { JSONObject.NULL })
            put("state", customer.state.ifBlank { JSONObject.NULL }); put("status", customer.status)
            put("source", customer.source.ifBlank { JSONObject.NULL }); put("notes", customer.notes.ifBlank { JSONObject.NULL })
            put("tags", JSONArray(customer.tags.split(',').map { it.trim() }.filter { it.isNotEmpty() }))
        }
        if (isServerId(customer.id)) remote.patch(active.accessToken, "customers", customer.id, body)
        else remote.insert(active.accessToken, "customers", body)
        refreshAfterWrite()
    }

    suspend fun deleteCustomer(customer: CustomerEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        check(isServerId(customer.id)) { "Customer has not been synced." }
        remote.archive(active.accessToken, "customers", customer.id)
        refreshAfterWrite()
    }

    // Product actions
    suspend fun saveProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        val body = JSONObject().apply {
            put("organization_id", active.organizationId); put("code", product.code); put("name", product.name)
            put("brand", product.brand.ifBlank { JSONObject.NULL }); put("description", product.description.ifBlank { JSONObject.NULL })
            put("product_type", product.productType); put("delivery_type", product.deliveryType); put("duration_days", product.durationDays)
            put("cost_price", product.costPrice); put("selling_price", product.sellingPrice)
            put("stock", product.stock ?: JSONObject.NULL); put("is_active", product.isActive)
        }
        if (isServerId(product.id)) remote.patch(active.accessToken, "products", product.id, body)
        else remote.insert(active.accessToken, "products", body)
        refreshAfterWrite()
    }

    suspend fun deleteProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        check(isServerId(product.id)) { "Product has not been synced." }
        remote.archive(active.accessToken, "products", product.id)
        refreshAfterWrite()
    }

    // Order actions & Business Logic
    suspend fun createOrder(
        customer: CustomerEntity,
        product: ProductEntity,
        quantity: Int,
        customPrice: Double,
        discount: Double,
        paymentMethod: String,
        paymentStatus: String,
        notes: String
    ) = withContext(Dispatchers.IO) {
        val active = requireSession()
        val total = (customPrice * quantity) - discount
        remote.createOrder(
            accessToken = active.accessToken,
            customerId = customer.id,
            productId = product.id,
            quantity = quantity,
            unitPrice = customPrice,
            discount = discount,
            paymentMethod = paymentMethod,
            paymentAmount = if (paymentStatus == "paid") total else 0.0,
            notes = notes,
            idempotencyKey = "android-order:${UUID.randomUUID()}"
        )
        refreshAfterWrite()
    }

    suspend fun updateOrderStatus(order: OrderEntity, newStatus: String, newPaymentStatus: String? = null) = withContext(Dispatchers.IO) {
        val active = requireSession()
        if (newPaymentStatus == "paid" && order.paymentStatus != "paid") {
            remote.addPayment(active.accessToken, order.id, (order.total - order.amountPaid).coerceAtLeast(0.0), order.paymentMethod.takeUnless { it == "server-ledger" } ?: "upi", "android-payment:${order.id}:${UUID.randomUUID()}")
        } else {
            remote.transitionOrder(active.accessToken, order.id, newStatus)
        }
        refreshAfterWrite()
    }

    // Subscription & Renew Actions
    suspend fun saveSubscription(subscription: SubscriptionEntity) = withContext(Dispatchers.IO) {
        throw IllegalStateException("Subscriptions are created only by the authoritative fulfilment workflow.")
    }

    suspend fun renewSubscription(subscription: SubscriptionEntity, days: Int = 365, renewAmount: Double) = withContext(Dispatchers.IO) {
        val active = requireSession()
        remote.createOrder(
            accessToken = active.accessToken, customerId = subscription.customerId,
            productId = subscription.productId, quantity = 1, unitPrice = renewAmount,
            discount = 0.0, paymentMethod = "upi", paymentAmount = renewAmount,
            notes = "Renewal requested from Android (${days} day plan)",
            renewalOfSubscriptionId = subscription.id,
            idempotencyKey = "android-renewal:${subscription.id}:${UUID.randomUUID()}"
        )
        refreshAfterWrite()
    }

    suspend fun updateSubscriptionReminder(subscription: SubscriptionEntity, reminderState: String) = withContext(Dispatchers.IO) {
        val active = requireSession()
        remote.patch(active.accessToken, "subscriptions", subscription.id, JSONObject()
            .put("reminder_state", reminderState).put("last_contacted_at", java.time.Instant.now().toString()))
        refreshAfterWrite()
    }

    // Activation actions
    suspend fun saveActivation(activation: ActivationEntity) = withContext(Dispatchers.IO) {
        throw IllegalStateException("Activation records are created only by the authoritative order workflow.")
    }

    suspend fun markActivationFulfilled(activation: ActivationEntity, details: String) = withContext(Dispatchers.IO) {
        val active = requireSession()
        // Delivery secrets/details are deliberately not accepted here. They use
        // the separate encrypted server workflow and are never cached in Room.
        remote.completeActivation(active.accessToken, activation.id, "android-activation:${activation.id}")
        refreshAfterWrite()
    }

    // Expenses
    suspend fun saveExpense(expense: ExpenseEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        val body = JSONObject().apply {
            put("organization_id", active.organizationId); put("category", expense.category)
            put("description", expense.description); put("amount", expense.amount)
            put("vendor", expense.vendor.ifBlank { JSONObject.NULL }); put("spent_at", java.time.Instant.ofEpochMilli(expense.spentAt).toString())
            put("method", expense.paymentMethod); put("is_recurring", expense.isRecurring)
        }
        if (isServerId(expense.id)) remote.patch(active.accessToken, "expenses", expense.id, body)
        else remote.insert(active.accessToken, "expenses", body)
        refreshAfterWrite()
    }

    suspend fun deleteExpense(expense: ExpenseEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        remote.archive(active.accessToken, "expenses", expense.id)
        refreshAfterWrite()
    }

    // Suppliers
    suspend fun saveSupplier(supplier: SupplierEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        val body = JSONObject().apply {
            put("organization_id", active.organizationId); put("name", supplier.name)
            put("contact_person", supplier.contactPerson.ifBlank { JSONObject.NULL }); put("email", supplier.email.ifBlank { JSONObject.NULL })
            put("phone", supplier.phone.ifBlank { JSONObject.NULL }); put("website", supplier.website.ifBlank { JSONObject.NULL })
            put("payment_terms", supplier.paymentTerms); put("is_active", supplier.isActive)
        }
        if (isServerId(supplier.id)) remote.patch(active.accessToken, "suppliers", supplier.id, body)
        else remote.insert(active.accessToken, "suppliers", body)
        refreshAfterWrite()
    }

    // Leads
    suspend fun saveLead(lead: LeadEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        val body = JSONObject().apply {
            put("organization_id", active.organizationId); put("name", lead.name); put("phone", lead.phone.ifBlank { JSONObject.NULL })
            put("email", lead.email.ifBlank { JSONObject.NULL }); put("company", lead.company.ifBlank { JSONObject.NULL })
            put("source", lead.source.ifBlank { JSONObject.NULL }); put("value", lead.estimatedValue); put("probability", lead.probability)
            put("status", lead.status); put("follow_up_at", lead.followUpAt?.let { java.time.Instant.ofEpochMilli(it).toString() } ?: JSONObject.NULL)
            put("notes", lead.notes.ifBlank { JSONObject.NULL })
        }
        if (isServerId(lead.id)) remote.patch(active.accessToken, "leads", lead.id, body)
        else remote.insert(active.accessToken, "leads", body)
        refreshAfterWrite()
    }

    suspend fun deleteLead(lead: LeadEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        remote.archive(active.accessToken, "leads", lead.id)
        refreshAfterWrite()
    }

    // Support Tickets
    suspend fun saveTicket(ticket: SupportTicketEntity) = withContext(Dispatchers.IO) {
        throw IllegalStateException("Open support tickets from Customer 360 so the authoritative customer ID is retained.")
    }

    // Tasks
    suspend fun saveTask(task: TaskEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        val body = JSONObject().apply {
            put("organization_id", active.organizationId); put("title", task.title)
            put("description", task.description.ifBlank { JSONObject.NULL }); put("entity_type", "general")
            put("priority", task.priority); put("status", task.status)
            put("due_at", task.dueAt?.let { java.time.Instant.ofEpochMilli(it).toString() } ?: JSONObject.NULL)
        }
        if (isServerId(task.id)) remote.patch(active.accessToken, "tasks", task.id, body)
        else remote.insert(active.accessToken, "tasks", body)
        refreshAfterWrite()
    }

    suspend fun toggleTaskStatus(task: TaskEntity) = withContext(Dispatchers.IO) {
        val active = requireSession()
        val newStatus = if (task.status == "done") "open" else "done"
        remote.patch(active.accessToken, "tasks", task.id, JSONObject().put("status", newStatus)
            .put("completed_at", if (newStatus == "done") java.time.Instant.now().toString() else JSONObject.NULL))
        refreshAfterWrite()
    }
}
