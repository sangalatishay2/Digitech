package com.example.digitech.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.data.model.*
import com.example.digitech.ui.components.*
import com.example.digitech.ui.theme.*
import com.example.digitech.ui.viewmodel.DigiTechViewModel
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
    viewModel: DigiTechViewModel
) {
    val metrics by viewModel.dashboardMetrics.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    var showAddExpenseDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Finance & Expenses", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showAddExpenseDialog = true }) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Add Expense", tint = BrandPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddExpenseDialog = true },
                containerColor = BrandPrimary,
                contentColor = TextPrimaryDark
            ) {
                Icon(Icons.Default.Add, contentDescription = "Record Expense")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            item {
                Text(
                    text = "Financial Overview",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricKpiCard(
                        title = "Gross Revenue",
                        value = Formatters.formatCurrency(metrics.totalRevenue),
                        icon = Icons.Default.AccountBalanceWallet,
                        accentColor = StatusSuccess,
                        modifier = Modifier.weight(1f)
                    )
                    MetricKpiCard(
                        title = "Total Expenses",
                        value = Formatters.formatCurrency(metrics.totalExpenses),
                        icon = Icons.Default.MoneyOff,
                        accentColor = StatusDanger,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Net Operating Profit", fontWeight = FontWeight.SemiBold)
                            Text(
                                Formatters.formatCurrency(metrics.netProfit),
                                fontWeight = FontWeight.Bold,
                                color = if (metrics.netProfit >= 0) StatusSuccess else StatusDanger,
                                fontSize = 16.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { (metrics.marginPercentage / 100).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = StatusSuccess,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = String.format("Net Margin: %.1f%% of revenue", metrics.marginPercentage),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Expense Log (${expenses.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (expenses.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "No expenses recorded",
                        message = "Track supplier purchases, software licenses, salaries, and operating expenses.",
                        icon = Icons.Default.Receipt
                    )
                }
            } else {
                items(expenses, key = { it.id }) { expense ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(14.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = expense.description,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    StatusBadge(status = expense.category)
                                }
                                if (expense.vendor.isNotBlank()) {
                                    Text(
                                        text = "Vendor: ${expense.vendor} • ${expense.paymentMethod.uppercase()}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = Formatters.formatDate(expense.spentAt),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = Formatters.formatCurrency(expense.amount),
                                    fontWeight = FontWeight.Bold,
                                    color = StatusDanger,
                                    fontSize = 15.sp
                                )
                                IconButton(onClick = { viewModel.deleteExpense(expense) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = StatusDanger.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Expense Dialog
    if (showAddExpenseDialog) {
        var description by remember { mutableStateOf("") }
        var amountText by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("software") }
        var vendor by remember { mutableStateOf("") }
        var paymentMethod by remember { mutableStateOf("upi") }

        AlertDialog(
            onDismissRequest = { showAddExpenseDialog = false },
            title = { Text("Record Business Expense") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Expense Description *") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount (₹) *") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = vendor, onValueChange = { vendor = it }, label = { Text("Vendor / Supplier Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category (supplier/software/office/etc)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = paymentMethod, onValueChange = { paymentMethod = it }, label = { Text("Payment Method (upi/bank_transfer/card)") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = amountText.toDoubleOrNull() ?: 0.0
                        val newExpense = ExpenseEntity(
                            id = "exp-" + UUID.randomUUID().toString().take(8),
                            category = category.lowercase(),
                            description = description,
                            amount = amount,
                            vendor = vendor,
                            paymentMethod = paymentMethod.lowercase(),
                            spentAt = System.currentTimeMillis()
                        )
                        viewModel.saveExpense(newExpense)
                        showAddExpenseDialog = false
                    }
                ) {
                    Text("Save Expense")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddExpenseDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
