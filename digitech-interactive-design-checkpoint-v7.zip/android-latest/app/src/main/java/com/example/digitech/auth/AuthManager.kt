package com.example.digitech.auth

import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.example.digitech.BuildConfig
import com.example.digitech.data.remote.SecureSessionStore
import com.example.digitech.data.remote.SupabaseAuthClient
import com.example.digitech.data.remote.SupabaseProfile
import com.example.digitech.data.remote.SupabaseSession
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.jsonPrimitive

data class AuthenticatedUser(
    val uid: String,
    val displayName: String? = null,
    val email: String? = null,
    val isAnonymous: Boolean = false,
    val accessToken: String,
    val organizationId: String,
    val serverRole: String
)

sealed interface AuthUiState {
    object Idle : AuthUiState
    object Loading : AuthUiState
    data class Authenticated(val user: AuthenticatedUser) : AuthUiState
    data class Error(val message: String) : AuthUiState
}

/** Supabase is the single identity authority for the Android client. */
class AuthManager(
    private val context: Context,
    val authPreferences: AuthPreferences = AuthPreferences(context),
    private val client: SupabaseAuthClient = SupabaseAuthClient(),
    private val sessionStore: SecureSessionStore = SecureSessionStore(context)
) {
    private val credentialManager = CredentialManager.create(context)
    private var currentSession: SupabaseSession? = null

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun cleanUp() = Unit

    fun attemptAutoSignIn(scope: CoroutineScope) {
        val refreshToken = sessionStore.readRefreshToken() ?: return
        _uiState.value = AuthUiState.Loading
        scope.launch {
            runCatching { client.refresh(refreshToken) }
                .onSuccess { completeSession(it) }
                .onFailure {
                    sessionStore.clear()
                    authPreferences.clearServerRole()
                    _uiState.value = AuthUiState.Idle
                }
        }
    }

    fun signInWithGoogle(contextActivity: Context, scope: CoroutineScope) {
        _uiState.value = AuthUiState.Loading
        scope.launch {
            try {
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID.ifBlank {
                        throw IllegalStateException("Google sign-in is not configured for this build.")
                    })
                    .setAutoSelectEnabled(false)
                    .build()
                val result = credentialManager.getCredential(
                    request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build(),
                    context = contextActivity
                )
                val credential = result.credential
                if (credential !is CustomCredential || credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    throw IllegalStateException("Unsupported Google credential.")
                }
                val idToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                completeSession(client.signInWithGoogle(idToken))
            } catch (_: GetCredentialCancellationException) {
                _uiState.value = AuthUiState.Idle
            } catch (error: GetCredentialException) {
                Log.w("AuthManager", "Google credential failed", error)
                _uiState.value = AuthUiState.Error("Google sign-in failed. Please try again.")
            } catch (error: Exception) {
                Log.w("AuthManager", "Supabase Google sign-in failed", error)
                _uiState.value = AuthUiState.Error(error.safeAuthMessage())
            }
        }
    }

    fun signInWithEmail(email: String, password: String, rememberMe: Boolean, scope: CoroutineScope) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.value = AuthUiState.Error("Please enter both email and password.")
            return
        }
        _uiState.value = AuthUiState.Loading
        scope.launch {
            if (rememberMe) authPreferences.saveRememberMe(true, email) else authPreferences.clearCredentials()
            runCatching { client.signIn(email.trim(), password) }
                .onSuccess { completeSession(it) }
                .onFailure {
                    Log.w("AuthManager", "Supabase email sign-in failed", it)
                    _uiState.value = AuthUiState.Error("Email or password is incorrect, or sign-in is unavailable.")
                }
        }
    }

    fun signUpWithEmail(email: String, password: String, rememberMe: Boolean, scope: CoroutineScope) {
        if (email.isBlank() || password.length < 8) {
            _uiState.value = AuthUiState.Error("Enter a valid email and a password of at least 8 characters.")
            return
        }
        _uiState.value = AuthUiState.Loading
        scope.launch {
            if (rememberMe) authPreferences.saveRememberMe(true, email) else authPreferences.clearCredentials()
            runCatching { client.signUp(email.trim(), password) }
                .onSuccess { completeSession(it) }
                .onFailure {
                    Log.w("AuthManager", "Supabase sign-up failed", it)
                    _uiState.value = AuthUiState.Error(it.safeAuthMessage())
                }
        }
    }

    fun signInWithBiometrics(savedEmail: String?, scope: CoroutineScope) {
        if (savedEmail.isNullOrBlank()) {
            _uiState.value = AuthUiState.Error("Sign in once before enabling biometric unlock.")
            return
        }
        if (sessionStore.readRefreshToken() == null) {
            _uiState.value = AuthUiState.Error("Your secure session expired. Sign in with your password.")
            return
        }
        attemptAutoSignIn(scope)
    }

    fun resetPassword(email: String, scope: CoroutineScope, onSent: () -> Unit, onError: (String) -> Unit) {
        val trimmed = email.trim()
        if (!trimmed.contains('@')) {
            onError("Please enter a valid email address.")
            return
        }
        scope.launch {
            runCatching { client.requestPasswordReset(trimmed) }
            withContext(Dispatchers.Main) { onSent() }
        }
    }

    fun signInGuest(scope: CoroutineScope) {
        _uiState.value = AuthUiState.Error("Guest access is disabled for organization data. Please use an assigned account.")
    }

    fun clearError() {
        if (_uiState.value is AuthUiState.Error) _uiState.value = AuthUiState.Idle
    }

    fun accessToken(): String? = currentSession?.accessToken

    fun signOut(scope: CoroutineScope? = null, onSignedOut: () -> Unit = {}) {
        val targetScope = scope ?: CoroutineScope(Dispatchers.IO)
        targetScope.launch {
            currentSession?.accessToken?.let { client.signOut(it) }
            currentSession = null
            sessionStore.clear()
            authPreferences.clearServerRole()
            runCatching { credentialManager.clearCredentialState(ClearCredentialStateRequest()) }
            _uiState.value = AuthUiState.Idle
            withContext(Dispatchers.Main) { onSignedOut() }
        }
    }

    private suspend fun completeSession(session: SupabaseSession) {
        val profile = client.fetchProfile(session.accessToken, session.user.id)
        currentSession = session
        sessionStore.save(session.accessToken, session.refreshToken)
        authPreferences.saveTrustedServerProfile(profile.fullName, profile.role)
        _uiState.value = AuthUiState.Authenticated(session.toAuthenticatedUser(profile))
    }

    private fun SupabaseSession.toAuthenticatedUser(profile: SupabaseProfile) = AuthenticatedUser(
        uid = user.id,
        displayName = profile.fullName ?: user.userMetadata["full_name"]?.jsonPrimitive?.content ?: "DigiTech User",
        email = user.email,
        accessToken = accessToken,
        organizationId = profile.organizationId,
        serverRole = profile.role
    )

    private fun Throwable.safeAuthMessage(): String =
        message?.takeIf { it.length in 1..180 } ?: "Secure sign-in is temporarily unavailable."
}
