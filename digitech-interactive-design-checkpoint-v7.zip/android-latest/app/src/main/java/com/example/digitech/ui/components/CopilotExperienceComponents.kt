package com.example.digitech.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.data.gemini.AiProvider
import com.example.digitech.data.gemini.AiRole
import com.example.digitech.ui.theme.BrandAccent
import com.example.digitech.ui.theme.BrandPrimary
import com.example.digitech.ui.theme.BrandSecondary
import com.example.digitech.ui.theme.DigiTechMotion
import com.example.digitech.ui.theme.pressScale

@Composable
fun CopilotModeRail(
    selectedRole: AiRole,
    onSelectRole: (AiRole) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptics = LocalHapticFeedback.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AiRole.values().forEach { role ->
            val selected = role == selectedRole
            val interactionSource = remember(role) { MutableInteractionSource() }
            Surface(
                modifier = Modifier
                    .pressScale(interactionSource, 0.96f)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        role = Role.RadioButton
                    ) {
                        if (!selected) {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSelectRole(role)
                        }
                    },
                shape = RoundedCornerShape(16.dp),
                color = if (selected) BrandPrimary.copy(alpha = 0.16f)
                else MaterialTheme.colorScheme.surfaceContainer,
                contentColor = if (selected) BrandPrimary else MaterialTheme.colorScheme.onSurfaceVariant
            ) {
                AnimatedContent(
                    targetState = selected,
                    transitionSpec = {
                        (fadeIn(tween(DigiTechMotion.Quick)) + scaleIn(initialScale = 0.96f))
                            .togetherWith(fadeOut(tween(DigiTechMotion.Instant)))
                    },
                    label = "copilotRole"
                ) { isSelected ->
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isSelected) {
                            Icon(Icons.Default.AutoAwesome, null, Modifier.size(14.dp))
                            Spacer(Modifier.width(6.dp))
                        }
                        Text(role.title, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CopilotLaunchpad(
    provider: AiProvider,
    model: String,
    onPrompt: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val pulse = rememberInfiniteTransition(label = "copilotLaunchpadPulse")
    val glow by pulse.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.72f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = DigiTechMotion.EmphasizedDecelerate),
            repeatMode = RepeatMode.Reverse
        ),
        label = "copilotLaunchpadGlow"
    )
    val prompts = listOf(
        CopilotPrompt(
            title = "Profit leak audit",
            subtitle = "Find margin and cash-flow gaps",
            prompt = "Audit my live business data for profit leaks, margin risks, and the three highest-impact actions I should take today.",
            icon = Icons.Default.Payments,
            color = BrandPrimary
        ),
        CopilotPrompt(
            title = "Renewal sprint",
            subtitle = "Prioritize expiring customers",
            prompt = "Create a prioritized renewal sprint for subscriptions expiring soon, including a practical follow-up sequence.",
            icon = Icons.Default.Sync,
            color = BrandAccent
        ),
        CopilotPrompt(
            title = "Fulfillment check",
            subtitle = "Clear pending deliveries faster",
            prompt = "Review the fulfillment workload and give me a concise priority plan for pending activations and customer deliveries.",
            icon = Icons.Default.Inventory2,
            color = BrandSecondary
        ),
        CopilotPrompt(
            title = "Customer message",
            subtitle = "Draft a ready WhatsApp reply",
            prompt = "Draft a warm, professional WhatsApp message for a DigiTech customer. Ask me only for the missing customer and product details.",
            icon = Icons.Default.Campaign,
            color = Color(0xFFE86AA8)
        )
    )

    Column(
        modifier = modifier.padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(BrandPrimary.copy(alpha = glow * 0.18f))
            )
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(17.dp))
                    .background(Brush.linearGradient(listOf(BrandPrimary, BrandSecondary, BrandAccent))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(25.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            text = "What should we improve today?",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "${provider.label} · ${model.substringAfterLast('/')} · secure business context",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(14.dp))
        prompts.chunked(2).forEach { rowPrompts ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rowPrompts.forEach { prompt ->
                    CopilotPromptCard(
                        prompt = prompt,
                        onClick = { onPrompt(prompt.prompt) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

private data class CopilotPrompt(
    val title: String,
    val subtitle: String,
    val prompt: String,
    val icon: ImageVector,
    val color: Color
)

@Composable
private fun CopilotPromptCard(
    prompt: CopilotPrompt,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val haptics = LocalHapticFeedback.current
    Surface(
        modifier = modifier
            .pressScale(interactionSource, 0.96f)
            .clip(RoundedCornerShape(18.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button
            ) {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Surface(shape = RoundedCornerShape(10.dp), color = prompt.color.copy(alpha = 0.15f)) {
                Icon(
                    imageVector = prompt.icon,
                    contentDescription = null,
                    tint = prompt.color,
                    modifier = Modifier.padding(7.dp).size(17.dp)
                )
            }
            Spacer(Modifier.height(9.dp))
            Text(
                text = prompt.title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = prompt.subtitle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 9.5.sp,
                lineHeight = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
