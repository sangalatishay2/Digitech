package com.example.digitech.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.digitech.auth.SyncFrequency
import com.example.digitech.auth.UserProfileData
import com.example.digitech.data.model.*
import com.example.digitech.data.repository.DigiTechRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class DashboardMetrics(
    val totalRevenue: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val totalGrossProfit: Double = 0.0,
    val netProfit: Double = 0.0,
    val marginPercentage: Double = 0.0,
    val activeSubscriptionsCount: Int = 0,
    val expiringSoonCount: Int = 0,
    val pendingActivationsCount: Int = 0,
    val openOrdersCount: Int = 0,
    val openTicketsCount: Int = 0,
    val totalCustomersCount: Int = 0
)

class DigiTechViewModel(private val repository: DigiTechRepository) : ViewModel() {

    val customers: StateFlow<List<CustomerEntity>> = repository.customers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val products: StateFlow<List<ProductEntity>> = repository.products
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<OrderEntity>> = repository.orders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val subscriptions: StateFlow<List<SubscriptionEntity>> = repository.subscriptions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activations: StateFlow<List<ActivationEntity>> = repository.activations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<ExpenseEntity>> = repository.expenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val suppliers: StateFlow<List<SupplierEntity>> = repository.suppliers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val leads: StateFlow<List<LeadEntity>> = repository.leads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<SupportTicketEntity>> = repository.tickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasks: StateFlow<List<TaskEntity>> = repository.tasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activityLogs: StateFlow<List<ActivityLogEntity>> = repository.activityLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val syncStatus = repository.syncStatus

    fun startCloudSync(accessToken: String, organizationId: String, role: String, frequency: SyncFrequency = SyncFrequency.REALTIME) {
        repository.startCloudSync(accessToken, organizationId, role, frequency)
    }

    fun updateSyncFrequency(frequency: SyncFrequency) {
        repository.updateSyncFrequency(frequency)
    }

    fun forceManualSync() {
        viewModelScope.launch {
            repository.forceManualSync()
        }
    }

    suspend fun clearLocalSessionData() {
        repository.clearLocalSessionData()
    }

    fun logActivity(
        actionType: String,
        title: String,
        description: String,
        actorEmail: String = "",
        role: String = "no_access",
        metadata: String = ""
    ) {
        viewModelScope.launch {
            repository.logActivity(actionType, title, description, actorEmail, role, metadata)
        }
    }

    fun exportDataAndShare(
        context: Context,
        userProfile: UserProfileData,
        userEmail: String,
        syncFreq: SyncFrequency
    ) {
        viewModelScope.launch {
            repository.exportDataAndShare(context, userProfile, userEmail, syncFreq)
        }
    }

    fun exportOrdersCsv(context: Context, userEmail: String, role: String) {
        viewModelScope.launch {
            repository.exportOrdersCsv(context, userEmail, role)
        }
    }

    fun exportProductsCsv(context: Context, userEmail: String, role: String) {
        viewModelScope.launch {
            repository.exportProductsCsv(context, userEmail, role)
        }
    }

    fun exportSubscriptionsCsv(context: Context, userEmail: String, role: String) {
        viewModelScope.launch {
            repository.exportSubscriptionsCsv(context, userEmail, role)
        }
    }

    fun exportCustomersCsv(context: Context, userEmail: String, role: String) {
        viewModelScope.launch {
            repository.exportCustomersCsv(context, userEmail, role)
        }
    }

    fun exportExpensesCsv(context: Context, userEmail: String, role: String) {
        viewModelScope.launch {
            repository.exportExpensesCsv(context, userEmail, role)
        }
    }

    fun createDriveBackup(
        context: Context,
        userProfile: UserProfileData,
        userEmail: String,
        syncFreq: SyncFrequency,
        onBackupCompleted: (summary: String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val summary = repository.createDriveBackupBundle(context, userProfile, userEmail, syncFreq)
            onBackupCompleted(summary)
        }
    }

    fun stopCloudSync() {
        repository.stopCloudSync()
    }

    // Combined Live Dashboard Metrics
    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(
        combine(orders, subscriptions, activations) { o, s, a -> Triple(o, s, a) },
        combine(expenses, tickets, customers) { e, t, c -> Triple(e, t, c) }
    ) { (orderList, subList, actList), (expList, ticketList, custList) ->
        val now = System.currentTimeMillis()
        val fifteenDaysMs = 15L * 24 * 60 * 60 * 1000

        val revenue = orderList.filter { it.paymentStatus == "paid" }.sumOf { it.total }
        val grossProfit = orderList.filter { it.paymentStatus == "paid" }.sumOf { it.profit }
        val totalExpense = expList.sumOf { it.amount }
        val net = grossProfit - totalExpense
        val margin = if (revenue > 0) (grossProfit / revenue) * 100 else 0.0

        val activeSubs = subList.count { it.status == "active" || it.status == "expiring" }
        val expiring = subList.count { it.expiryDate > now && (it.expiryDate - now) <= fifteenDaysMs }
        val pendingActs = actList.count { it.status != "delivered" && it.status != "cancelled" }
        val openOrders = orderList.count { it.status != "completed" && it.status != "cancelled" }
        val openTkts = ticketList.count { it.status == "open" || it.status == "in_progress" }

        DashboardMetrics(
            totalRevenue = revenue,
            totalExpenses = totalExpense,
            totalGrossProfit = grossProfit,
            netProfit = net,
            marginPercentage = margin,
            activeSubscriptionsCount = activeSubs,
            expiringSoonCount = expiring,
            pendingActivationsCount = pendingActs,
            openOrdersCount = openOrders,
            openTicketsCount = openTkts,
            totalCustomersCount = custList.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    // Actions
    fun createOrder(
        customer: CustomerEntity,
        product: ProductEntity,
        quantity: Int,
        customPrice: Double,
        discount: Double,
        paymentMethod: String,
        paymentStatus: String,
        notes: String
    ) {
        viewModelScope.launch {
            repository.createOrder(
                customer = customer,
                product = product,
                quantity = quantity,
                customPrice = customPrice,
                discount = discount,
                paymentMethod = paymentMethod,
                paymentStatus = paymentStatus,
                notes = notes
            )
        }
    }

    fun markOrderPaid(order: OrderEntity) {
        viewModelScope.launch {
            repository.updateOrderStatus(order, newStatus = "processing", newPaymentStatus = "paid")
        }
    }

    fun completeOrder(order: OrderEntity) {
        viewModelScope.launch {
            repository.updateOrderStatus(order, newStatus = "completed")
        }
    }

    fun cancelOrder(order: OrderEntity) {
        viewModelScope.launch {
            repository.updateOrderStatus(order, newStatus = "cancelled")
        }
    }

    fun renewSubscription(subscription: SubscriptionEntity, days: Int, renewAmount: Double) {
        viewModelScope.launch {
            repository.renewSubscription(subscription, days, renewAmount)
        }
    }

    fun updateSubscriptionReminder(subscription: SubscriptionEntity, reminderState: String) {
        viewModelScope.launch {
            repository.updateSubscriptionReminder(subscription, reminderState)
        }
    }

    fun fulfillActivation(activation: ActivationEntity, details: String) {
        viewModelScope.launch {
            repository.markActivationFulfilled(activation, details)
        }
    }

    fun saveCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.saveCustomer(customer)
        }
    }

    fun deleteCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
        }
    }

    fun saveProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.saveProduct(product)
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }

    fun saveExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.saveExpense(expense)
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
        }
    }

    fun saveSupplier(supplier: SupplierEntity) {
        viewModelScope.launch {
            repository.saveSupplier(supplier)
        }
    }

    fun saveLead(lead: LeadEntity) {
        viewModelScope.launch {
            repository.saveLead(lead)
        }
    }

    fun deleteLead(lead: LeadEntity) {
        viewModelScope.launch {
            repository.deleteLead(lead)
        }
    }

    fun saveTicket(ticket: SupportTicketEntity) {
        viewModelScope.launch {
            repository.saveTicket(ticket)
        }
    }

    fun saveTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.saveTask(task)
        }
    }

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.toggleTaskStatus(task)
        }
    }

    fun resetToDemoData() {
        viewModelScope.launch {
            repository.resetToSeedData()
        }
    }
}

class DigiTechViewModelFactory(private val repository: DigiTechRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DigiTechViewModel::class.java)) {
            return DigiTechViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
