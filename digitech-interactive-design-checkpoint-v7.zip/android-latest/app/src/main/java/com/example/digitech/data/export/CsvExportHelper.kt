package com.example.digitech.data.export

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.digitech.data.model.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExportHelper {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private val dateOnlyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val fileTimestampFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    private fun escapeCsv(value: String): String {
        val neutralized = if (value.firstOrNull() in setOf('=', '+', '-', '@')) "'$value" else value
        val sanitized = neutralized.replace("\"", "\"\"")
        return if (sanitized.contains(",") || sanitized.contains("\n") || sanitized.contains("\"")) {
            "\"$sanitized\""
        } else {
            sanitized
        }
    }

    fun generateOrdersCsv(orders: List<OrderEntity>): String {
        val sb = StringBuilder()
        sb.append("Order ID,Order Number,Date,Customer ID,Customer Name,Product ID,Product Name,Quantity,Unit Price (INR),Unit Cost (INR),Discount (INR),Total Amount (INR),Amount Paid (INR),Profit (INR),Payment Status,Payment Method,Order Status,Notes\n")

        orders.forEach { order ->
            sb.append(escapeCsv(order.id)).append(",")
            sb.append(escapeCsv(order.orderNumber)).append(",")
            sb.append(escapeCsv(dateFormat.format(Date(order.orderedAt)))).append(",")
            sb.append(escapeCsv(order.customerId)).append(",")
            sb.append(escapeCsv(order.customerName)).append(",")
            sb.append(escapeCsv(order.productId)).append(",")
            sb.append(escapeCsv(order.productName)).append(",")
            sb.append(order.quantity).append(",")
            sb.append(String.format(Locale.US, "%.2f", order.unitPrice)).append(",")
            sb.append(String.format(Locale.US, "%.2f", order.unitCost)).append(",")
            sb.append(String.format(Locale.US, "%.2f", order.discount)).append(",")
            sb.append(String.format(Locale.US, "%.2f", order.total)).append(",")
            sb.append(String.format(Locale.US, "%.2f", order.amountPaid)).append(",")
            sb.append(String.format(Locale.US, "%.2f", order.profit)).append(",")
            sb.append(escapeCsv(order.paymentStatus)).append(",")
            sb.append(escapeCsv(order.paymentMethod)).append(",")
            sb.append(escapeCsv(order.status)).append(",")
            sb.append(escapeCsv(order.notes))
            sb.append("\n")
        }
        return sb.toString()
    }

    fun generateProductsCsv(products: List<ProductEntity>): String {
        val sb = StringBuilder()
        sb.append("Product ID,Code,Name,Category,Brand,Product Type,Delivery Type,Duration Days,Selling Price (INR),Cost Price (INR),Stock,Is Active,Description\n")

        products.forEach { prod ->
            sb.append(escapeCsv(prod.id)).append(",")
            sb.append(escapeCsv(prod.code)).append(",")
            sb.append(escapeCsv(prod.name)).append(",")
            sb.append(escapeCsv(prod.category)).append(",")
            sb.append(escapeCsv(prod.brand)).append(",")
            sb.append(escapeCsv(prod.productType)).append(",")
            sb.append(escapeCsv(prod.deliveryType)).append(",")
            sb.append(prod.durationDays).append(",")
            sb.append(String.format(Locale.US, "%.2f", prod.sellingPrice)).append(",")
            sb.append(String.format(Locale.US, "%.2f", prod.costPrice)).append(",")
            sb.append(prod.stock?.toString() ?: "").append(",")
            sb.append(if (prod.isActive) "YES" else "NO").append(",")
            sb.append(escapeCsv(prod.description))
            sb.append("\n")
        }
        return sb.toString()
    }

    fun generateSubscriptionsCsv(subscriptions: List<SubscriptionEntity>): String {
        val sb = StringBuilder()
        sb.append("Subscription ID,Order ID,Product ID,Product Name,Customer ID,Customer Name,Customer Phone,Start Date,Expiry Date,Duration Days,Purchase Amount (INR),Cost Amount (INR),Profit (INR),Status,Reminder State,Notes\n")

        subscriptions.forEach { sub ->
            sb.append(escapeCsv(sub.id)).append(",")
            sb.append(escapeCsv(sub.orderId)).append(",")
            sb.append(escapeCsv(sub.productId)).append(",")
            sb.append(escapeCsv(sub.productName)).append(",")
            sb.append(escapeCsv(sub.customerId)).append(",")
            sb.append(escapeCsv(sub.customerName)).append(",")
            sb.append(escapeCsv(sub.customerPhone)).append(",")
            sb.append(escapeCsv(dateOnlyFormat.format(Date(sub.startDate)))).append(",")
            sb.append(escapeCsv(dateOnlyFormat.format(Date(sub.expiryDate)))).append(",")
            sb.append(sub.durationDays).append(",")
            sb.append(String.format(Locale.US, "%.2f", sub.purchaseAmount)).append(",")
            sb.append(String.format(Locale.US, "%.2f", sub.costAmount)).append(",")
            sb.append(String.format(Locale.US, "%.2f", sub.profit)).append(",")
            sb.append(escapeCsv(sub.status)).append(",")
            sb.append(escapeCsv(sub.reminderState)).append(",")
            sb.append(escapeCsv(sub.notes))
            sb.append("\n")
        }
        return sb.toString()
    }

    fun generateCustomersCsv(customers: List<CustomerEntity>): String {
        val sb = StringBuilder()
        sb.append("Customer ID,Customer Code,Name,Email,Phone,WhatsApp,Company,City,State,Status,Source,Tags,Created Date,Updated Date\n")

        customers.forEach { cust ->
            sb.append(escapeCsv(cust.id)).append(",")
            sb.append(escapeCsv(cust.customerCode)).append(",")
            sb.append(escapeCsv(cust.name)).append(",")
            sb.append(escapeCsv(cust.email)).append(",")
            sb.append(escapeCsv(cust.phone)).append(",")
            sb.append(escapeCsv(cust.whatsapp)).append(",")
            sb.append(escapeCsv(cust.company)).append(",")
            sb.append(escapeCsv(cust.city)).append(",")
            sb.append(escapeCsv(cust.state)).append(",")
            sb.append(escapeCsv(cust.status)).append(",")
            sb.append(escapeCsv(cust.source)).append(",")
            sb.append(escapeCsv(cust.tags)).append(",")
            sb.append(escapeCsv(dateOnlyFormat.format(Date(cust.createdAt)))).append(",")
            sb.append(escapeCsv(dateOnlyFormat.format(Date(cust.updatedAt))))
            sb.append("\n")
        }
        return sb.toString()
    }

    fun generateExpensesCsv(expenses: List<ExpenseEntity>): String {
        val sb = StringBuilder()
        sb.append("Expense ID,Description,Category,Amount (INR),Vendor,Payment Method,Date\n")

        expenses.forEach { exp ->
            sb.append(escapeCsv(exp.id)).append(",")
            sb.append(escapeCsv(exp.description)).append(",")
            sb.append(escapeCsv(exp.category)).append(",")
            sb.append(String.format(Locale.US, "%.2f", exp.amount)).append(",")
            sb.append(escapeCsv(exp.vendor)).append(",")
            sb.append(escapeCsv(exp.paymentMethod)).append(",")
            sb.append(escapeCsv(dateFormat.format(Date(exp.spentAt))))
            sb.append("\n")
        }
        return sb.toString()
    }

    fun shareCsvFile(
        context: Context,
        csvContent: String,
        filePrefix: String,
        subject: String
    ) {
        val timestamp = fileTimestampFormat.format(Date())
        val filename = "${filePrefix}_$timestamp.csv"
        val file = File(context.cacheDir, filename)

        FileOutputStream(file).use { out ->
            out.write(csvContent.toByteArray(Charsets.UTF_8))
        }

        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, "Exported $subject Spreadsheet from DigiTech Enterprise OS.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(shareIntent, "Export to Excel / Google Drive / WhatsApp").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            val fallbackIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, csvContent)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(fallbackIntent, "Export Spreadsheet Data").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        }
    }
}
