package com.example.digitech.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.data.gemini.AiRole
import com.example.digitech.data.gemini.AiModels
import com.example.digitech.data.gemini.AiProvider
import com.example.digitech.data.gemini.ChatMessage
import com.example.digitech.ui.components.CopilotLaunchpad
import com.example.digitech.ui.components.CopilotModeRail
import com.example.digitech.ui.theme.*
import com.example.digitech.ui.viewmodel.AiAssistantViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeminiChatScreen(
    viewModel: AiAssistantViewModel,
    onOpenVoiceMode: () -> Unit = {}
) {
    val context = LocalContext.current
    val listState = rememberLazyListState()

    val messages by viewModel.messages.collectAsState()
    val selectedRole by viewModel.selectedRole.collectAsState()
    val selectedProvider by viewModel.selectedProvider.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val includeBusinessContext by viewModel.includeBusinessContext.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var showModelMenu by remember { mutableStateOf(false) }
    var showCustomModelDialog by remember { mutableStateOf(false) }
    var customModelInput by remember(selectedModel) { mutableStateOf(selectedModel) }

    // Scroll to bottom on new message
    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    if (showCustomModelDialog) {
        AlertDialog(
            onDismissRequest = { showCustomModelDialog = false },
            title = { Text("Custom model") },
            text = {
                Column {
                    Text(
                        text = "Enter a model ID supported by ${selectedProvider.label}. Provider keys stay securely on the DigiTech server.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = customModelInput,
                        onValueChange = { customModelInput = it },
                        label = { Text("Model ID") },
                        placeholder = { Text("provider/model-name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("ai_custom_model_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setModel(customModelInput.trim())
                        showCustomModelDialog = false
                    }
                ) {
                    Text("Use model")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomModelDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("DigiTech Copilot", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = BrandAccent.copy(alpha = 0.15f)
                            ) {
                                AnimatedContent(
                                    targetState = selectedProvider.label,
                                    transitionSpec = {
                                        (fadeIn(tween(DigiTechMotion.Quick)) + scaleIn(initialScale = 0.92f))
                                            .togetherWith(fadeOut(tween(DigiTechMotion.Instant)))
                                    },
                                    label = "providerBadge"
                                ) { providerLabel ->
                                    Text(
                                        text = providerLabel,
                                        color = BrandAccent,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = selectedRole.title,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    // Voice Mode Button
                    IconButton(
                        onClick = onOpenVoiceMode,
                        modifier = Modifier.testTag("open_voice_mode_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Voice Conversation",
                            tint = BrandPrimary
                        )
                    }

                    // Model Selector Dropdown
                    Box {
                        IconButton(onClick = { showModelMenu = true }) {
                            Icon(Icons.Default.Tune, contentDescription = "Select Model & Options")
                        }

                        DropdownMenu(
                            expanded = showModelMenu,
                            onDismissRequest = { showModelMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text("Nemotron via OpenRouter", fontWeight = FontWeight.SemiBold)
                                        Text("Flexible OpenRouter model routing", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                leadingIcon = { Icon(Icons.Default.Bolt, contentDescription = null, tint = BrandPrimary) },
                                onClick = {
                                    viewModel.setProvider(AiProvider.OPENROUTER)
                                    viewModel.setModel(AiModels.NEMOTRON)
                                    showModelMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text("Gemini Flash via Google", fontWeight = FontWeight.SemiBold)
                                        Text("Google AI provider option", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                leadingIcon = { Icon(Icons.Default.Psychology, contentDescription = null, tint = BrandAccent) },
                                onClick = {
                                    viewModel.setProvider(AiProvider.GOOGLE)
                                    viewModel.setModel(AiModels.GEMINI_FLASH)
                                    showModelMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text("Custom model ID", fontWeight = FontWeight.SemiBold)
                                        Text("Use any model supported by the provider", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                leadingIcon = { Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = StatusSuccess) },
                                onClick = {
                                    showModelMenu = false
                                    customModelInput = selectedModel
                                    showCustomModelDialog = true
                                }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Clear Chat History") },
                                leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = StatusDanger) },
                                onClick = {
                                    showModelMenu = false
                                    viewModel.clearChat()
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            CopilotModeRail(
                selectedRole = selectedRole,
                onSelectRole = viewModel::setRole
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Chat Messages Thread
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                if (messages.size <= 1) {
                    item(key = "copilot_launchpad") {
                        CopilotLaunchpad(
                            provider = selectedProvider,
                            model = selectedModel,
                            onPrompt = { prompt -> viewModel.sendMessage(prompt) }
                        )
                    }
                }

                items(messages, key = { it.id }) { msg ->
                    ChatBubble(
                        message = msg,
                        onCopy = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("DigiTech Copilot", msg.content))
                            Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                        }
                    )
                }

                if (isLoading && messages.lastOrNull()?.isStreaming != true) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = BrandPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Copilot is thinking...",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Bottom Input Bar
            Surface(
                tonalElevation = 6.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Live Business context indicator toggle
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable {
                                viewModel.setIncludeBusinessContext(!includeBusinessContext)
                            }
                        ) {
                            Icon(
                                imageVector = if (includeBusinessContext) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = if (includeBusinessContext) StatusSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (includeBusinessContext) "Business context enabled" else "Business context off",
                                fontSize = 11.sp,
                                color = if (includeBusinessContext) StatusSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Text(
                            text = "${selectedProvider.label} · keys secured server-side",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = { Text("Ask Copilot about your business...", fontSize = 13.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("gemini_chat_input"),
                            shape = RoundedCornerShape(24.dp),
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BrandPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        // Mic button for quick voice input or Voice Mode
                        FilledIconButton(
                            onClick = onOpenVoiceMode,
                            shape = CircleShape,
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = BrandAccent.copy(alpha = 0.15f),
                                contentColor = BrandAccent
                            ),
                            modifier = Modifier.testTag("gemini_mic_button")
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = "Voice Conversation")
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // Send Button
                        FilledIconButton(
                            onClick = {
                                if (inputText.isNotBlank()) {
                                    val textToSend = inputText
                                    inputText = ""
                                    viewModel.sendMessage(textToSend)
                                }
                            },
                            enabled = inputText.isNotBlank() && !isLoading,
                            shape = CircleShape,
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = BrandPrimary,
                                contentColor = Color.White,
                                disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.testTag("gemini_send_button")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send Message")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatBubble(
    message: ChatMessage,
    onCopy: () -> Unit
) {
    val isUser = message.role == "user"
    var visible by remember(message.id) { mutableStateOf(false) }

    LaunchedEffect(message.id) { visible = true }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(DigiTechMotion.Standard)) +
            slideInHorizontally(
                animationSpec = spring(dampingRatio = 0.82f, stiffness = 430f),
                initialOffsetX = { if (isUser) it / 4 else -it / 4 }
            ) + scaleIn(initialScale = 0.96f),
        exit = fadeOut(tween(DigiTechMotion.Instant))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(
                            androidx.compose.ui.graphics.Brush.linearGradient(
                                listOf(BrandPrimary, BrandSecondary, BrandAccent)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
            }

            Surface(
                shape = RoundedCornerShape(
                    topStart = 18.dp,
                    topEnd = 18.dp,
                    bottomStart = if (isUser) 18.dp else 5.dp,
                    bottomEnd = if (isUser) 5.dp else 18.dp
                ),
                color = when {
                    message.isError -> StatusDanger.copy(alpha = 0.15f)
                    isUser -> BrandPrimaryDark
                    else -> MaterialTheme.colorScheme.surfaceVariant
                },
                modifier = Modifier.widthIn(max = 310.dp),
                tonalElevation = if (isUser) 3.dp else 1.dp
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    if (!isUser && message.modelUsed != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = message.modelUsed,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = BrandAccent
                            )

                            IconButton(onClick = onCopy, modifier = Modifier.size(20.dp)) {
                                Icon(
                                    imageVector = Icons.Outlined.ContentCopy,
                                    contentDescription = "Copy message",
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    Text(
                        text = message.content,
                        fontSize = 14.sp,
                        color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                        lineHeight = 20.sp
                    )

                    if (message.isStreaming) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "● streaming response...",
                            fontSize = 10.sp,
                            color = BrandPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
