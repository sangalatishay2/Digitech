package com.example.digitech.data.gemini

import android.content.Context
import com.example.digitech.BuildConfig
import com.example.digitech.data.remote.SecureSessionStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@Serializable
private data class GatewayMessage(val role: String, val content: String)

@Serializable
private data class GatewayRequest(
    val provider: String,
    val model: String,
    val messages: List<GatewayMessage>,
    val system: String? = null,
    val temperature: Float = 0.5f,
    @SerialName("max_output_tokens") val maxOutputTokens: Int = 1200
)

@Serializable
private data class GatewayResponse(
    val provider: String? = null,
    val model: String? = null,
    val content: String? = null,
    val error: String? = null
)

/**
 * Provider-neutral AI client. It only calls the authenticated DigiTech server;
 * OpenRouter and Google keys never exist in app storage or the APK.
 */
class GeminiClient(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val sessionStore = SecureSessionStore(context)
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateResponse(
        provider: AiProvider = AiProvider.OPENROUTER,
        model: String = AiModels.NEMOTRON,
        history: List<ChatMessage>,
        systemInstruction: String? = null,
        temperature: Float = 0.5f
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = BuildConfig.DIGITECH_API_BASE_URL.trimEnd('/')
            require(baseUrl.startsWith("https://")) { "DigiTech secure API URL is not configured." }
            val accessToken = sessionStore.readAccessToken()
                ?: error("Your session expired. Sign in again.")
            val requestPayload = GatewayRequest(
                provider = provider.wireName,
                model = model,
                messages = history.takeLast(40).map {
                    GatewayMessage(
                        role = if (it.role == "user") "user" else "assistant",
                        content = it.content
                    )
                },
                system = systemInstruction,
                temperature = temperature
            )
            val request = Request.Builder()
                .url("$baseUrl/api/ai/chat")
                .header("Authorization", "Bearer $accessToken")
                .header("Accept", "application/json")
                .post(
                    json.encodeToString(GatewayRequest.serializer(), requestPayload)
                        .toRequestBody("application/json".toMediaType())
                )
                .build()
            http.newCall(request).execute().use { response ->
                val payload = response.body?.string().orEmpty()
                val parsed = runCatching { json.decodeFromString<GatewayResponse>(payload) }.getOrNull()
                if (!response.isSuccessful) {
                    error(parsed?.error ?: "AI gateway returned ${response.code}.")
                }
                parsed?.content?.takeIf { it.isNotBlank() }
                    ?: error("AI provider returned an empty response.")
            }
        }
    }

    fun streamResponse(
        provider: AiProvider = AiProvider.OPENROUTER,
        model: String = AiModels.NEMOTRON,
        history: List<ChatMessage>,
        systemInstruction: String? = null,
        temperature: Float = 0.5f
    ): Flow<String> = flow {
        val result = generateResponse(provider, model, history, systemInstruction, temperature)
        result.onSuccess { emit(it) }
            .onFailure { emit("[AI unavailable: ${it.message ?: "request failed"}]") }
    }.flowOn(Dispatchers.IO)
}
