package com.example.digitech.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.digitech.data.model.*

@Database(
    entities = [
        CustomerEntity::class,
        ProductEntity::class,
        OrderEntity::class,
        SubscriptionEntity::class,
        ActivationEntity::class,
        ExpenseEntity::class,
        SupplierEntity::class,
        LeadEntity::class,
        SupportTicketEntity::class,
        TaskEntity::class,
        ActivityLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun digiTechDao(): DigiTechDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "digitech_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
