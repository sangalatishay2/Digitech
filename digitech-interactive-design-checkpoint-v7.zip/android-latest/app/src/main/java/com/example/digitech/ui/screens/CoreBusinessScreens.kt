package com.example.digitech.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.data.model.ActivationEntity
import com.example.digitech.data.model.OrderEntity
import com.example.digitech.data.model.SubscriptionEntity
import com.example.digitech.ui.components.ActionHelpers
import com.example.digitech.ui.components.EmptyStateView
import com.example.digitech.ui.components.StatusBadge
import com.example.digitech.ui.theme.BrandAccent
import com.example.digitech.ui.theme.BrandPrimary
import com.example.digitech.ui.theme.DigiTechMotion
import com.example.digitech.ui.theme.Formatters
import com.example.digitech.ui.theme.StatusDanger
import com.example.digitech.ui.theme.StatusInfo
import com.example.digitech.ui.theme.StatusSuccess
import com.example.digitech.ui.theme.StatusWarning
import com.example.digitech.ui.viewmodel.DigiTechViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersScreen(
    viewModel: DigiTechViewModel,
    onOpenCreateOrder: () -> Unit
) {
    val orders by viewModel.orders.collectAsState()
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    var selected by remember { mutableStateOf<OrderEntity?>(null) }
    var revealed by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(40)
        revealed = true
    }

    val visibleOrders = remember(orders, query, filter) {
        orders.filter { order ->
            val matchesQuery = query.isBlank() || listOf(
                order.orderNumber,
                order.customerName,
                order.productName
            ).any { it.contains(query, ignoreCase = true) }
            val matchesFilter = filter == "All" || when (filter) {
                "Open" -> order.status !in listOf("completed", "cancelled")
                "Paid" -> order.paymentStatus == "paid"
                "Pending" -> order.paymentStatus in listOf("pending", "partial")
                else -> true
            }
            matchesQuery && matchesFilter
        }.sortedByDescending { it.orderedAt }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Orders", fontWeight = FontWeight.Bold)
                        Text(
                            "${orders.size} orders • ${orders.count { it.status !in listOf("completed", "cancelled") }} open",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.forceManualSync() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh orders")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onOpenCreateOrder,
                containerColor = BrandPrimary,
                contentColor = Color(0xFF06241B)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create order")
            }
        }
    ) { padding ->
        AnimatedVisibility(
            visible = revealed,
            enter = fadeIn(tween(DigiTechMotion.Standard)) +
                slideInVertically(tween(DigiTechMotion.Standard)) { it / 5 }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    placeholder = { Text("Search order, customer or product") },
                    shape = RoundedCornerShape(14.dp)
                )
                Row(
                    modifier = Modifier.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("All", "Open", "Paid", "Pending").forEach { option ->
                        FilterChip(
                            selected = filter == option,
                            onClick = { filter = option },
                            label = { Text(option) }
                        )
                    }
                }
                if (visibleOrders.isEmpty()) {
                    EmptyStateView(
                        title = "No matching orders",
                        message = "Create a new order or change your search filters.",
                        icon = Icons.Default.ReceiptLong
                    )
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 108.dp)
                    ) {
                        items(visibleOrders, key = { it.id }) { order ->
                            BusinessListCard(
                                iconColor = when (order.paymentStatus) {
                                    "paid" -> StatusSuccess
                                    "partial" -> StatusWarning
                                    else -> StatusDanger
                                },
                                icon = Icons.Default.ReceiptLong,
                                title = order.orderNumber,
                                subtitle = "${order.customerName} • ${order.productName}",
                                value = Formatters.formatCurrency(order.total),
                                status = order.status,
                                supporting = Formatters.formatDateTime(order.orderedAt),
                                onClick = { selected = order }
                            )
                        }
                    }
                }
            }
        }
    }

    selected?.let { order ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(order.orderNumber, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(order.customerName, fontWeight = FontWeight.SemiBold)
                    Text(order.productName, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(Formatters.formatCurrency(order.total), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        StatusBadge(order.status)
                        StatusBadge(order.paymentStatus)
                    }
                    if (order.paymentStatus != "paid") {
                        Button(
                            onClick = {
                                viewModel.markOrderPaid(order)
                                selected = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Payments, contentDescription = null)
                            Spacer(Modifier.width(7.dp))
                            Text("Record full payment")
                        }
                    }
                }
            },
            confirmButton = {
                if (order.paymentStatus == "paid" && order.status != "completed") {
                    Button(onClick = { viewModel.completeOrder(order); selected = null }) {
                        Text("Complete")
                    }
                } else {
                    TextButton(onClick = { selected = null }) { Text("Close") }
                }
            },
            dismissButton = {
                if (order.status !in listOf("completed", "cancelled")) {
                    TextButton(onClick = { viewModel.cancelOrder(order); selected = null }) {
                        Text("Cancel order", color = StatusDanger)
                    }
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionsScreen(viewModel: DigiTechViewModel) {
    val context = LocalContext.current
    val subscriptions by viewModel.subscriptions.collectAsState()
    var filter by remember { mutableStateOf("Priority") }
    var selected by remember { mutableStateOf<SubscriptionEntity?>(null) }
    val now = System.currentTimeMillis()
    val fifteenDays = 15L * 24 * 60 * 60 * 1000

    val visible = remember(subscriptions, filter, now) {
        subscriptions.filter { sub ->
            when (filter) {
                "Priority" -> sub.expiryDate <= now + fifteenDays && sub.status !in listOf("renewed", "cancelled")
                "Active" -> sub.status == "active"
                "Expired" -> sub.expiryDate < now || sub.status == "expired"
                else -> true
            }
        }.sortedBy { it.expiryDate }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Renewal Center", fontWeight = FontWeight.Bold)
                        Text(
                            "Act before customer access expires",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Priority", "All", "Active", "Expired").forEach { option ->
                    FilterChip(
                        selected = filter == option,
                        onClick = { filter = option },
                        label = { Text(option) }
                    )
                }
            }
            if (visible.isEmpty()) {
                EmptyStateView(
                    title = "Renewal queue is clear",
                    message = "Subscriptions needing attention will appear here automatically.",
                    icon = Icons.Default.CheckCircle
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 108.dp)
                ) {
                    items(visible, key = { it.id }) { sub ->
                        val days = Formatters.getDaysRemaining(sub.expiryDate)
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(13.dp))
                                            .background(
                                                (if (days <= 3) StatusDanger else StatusWarning).copy(alpha = 0.13f)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.WarningAmber,
                                            contentDescription = null,
                                            tint = if (days <= 3) StatusDanger else StatusWarning
                                        )
                                    }
                                    Spacer(Modifier.width(11.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(sub.productName, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Text(
                                            sub.customerName,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Text(
                                        if (days < 0) "Expired" else "$days days",
                                        color = if (days <= 3) StatusDanger else StatusWarning,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                                Spacer(Modifier.height(11.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(
                                        onClick = {
                                            val message = "Hi ${sub.customerName}, your ${sub.productName} plan expires ${if (days < 0) "soon" else "in $days days"}. Shall I prepare your renewal?"
                                            ActionHelpers.openWhatsApp(context, sub.customerPhone, message)
                                            viewModel.updateSubscriptionReminder(sub, "contacted")
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(17.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("WhatsApp")
                                    }
                                    Button(onClick = { selected = sub }, modifier = Modifier.weight(1f)) {
                                        Text("Renew now")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    selected?.let { sub ->
        var amount by remember(sub.id) { mutableStateOf(sub.purchaseAmount.toInt().toString()) }
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text("Prepare renewal", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(sub.customerName, fontWeight = FontWeight.SemiBold)
                    Text(sub.productName, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it.filter { char -> char.isDigit() || char == '.' } },
                        label = { Text("Renewal amount") },
                        prefix = { Text("₹") },
                        singleLine = true
                    )
                    Text(
                        "A new renewal order will be created. Delivery remains in the secure activation queue.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = amount.toDoubleOrNull() != null,
                    onClick = {
                        viewModel.renewSubscription(sub, sub.durationDays, amount.toDoubleOrNull() ?: sub.purchaseAmount)
                        selected = null
                    }
                ) { Text("Create renewal") }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Cancel") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivationsScreen(viewModel: DigiTechViewModel) {
    val activations by viewModel.activations.collectAsState()
    var filter by remember { mutableStateOf("Queue") }
    var selected by remember { mutableStateOf<ActivationEntity?>(null) }

    val visible = remember(activations, filter) {
        activations.filter { activation ->
            when (filter) {
                "Queue" -> activation.status !in listOf("delivered", "cancelled")
                "Ready" -> activation.status == "ready"
                "Delivered" -> activation.status == "delivered"
                else -> true
            }
        }.sortedWith(compareBy<ActivationEntity> { it.status == "delivered" }.thenByDescending { it.createdAt })
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Fulfillment Queue", fontWeight = FontWeight.Bold)
                        Text(
                            "Secure activation delivery",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Queue", "All", "Ready", "Delivered").forEach { option ->
                    FilterChip(
                        selected = filter == option,
                        onClick = { filter = option },
                        label = { Text(option) }
                    )
                }
            }
            if (visible.isEmpty()) {
                EmptyStateView(
                    title = "Fulfillment queue is clear",
                    message = "New paid orders will create secure activation work here.",
                    icon = Icons.Default.Key
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 108.dp)
                ) {
                    items(visible, key = { it.id }) { activation ->
                        BusinessListCard(
                            iconColor = when (activation.priority) {
                                "urgent", "high" -> StatusDanger
                                "medium" -> StatusWarning
                                else -> StatusInfo
                            },
                            icon = Icons.Default.Key,
                            title = activation.productName,
                            subtitle = "${activation.customerName} • ${activation.orderNumber}",
                            value = activation.deliveryType.replace('_', ' '),
                            status = activation.status,
                            supporting = Formatters.formatDateTime(activation.createdAt),
                            onClick = { selected = activation }
                        )
                    }
                }
            }
        }
    }

    selected?.let { activation ->
        AlertDialog(
            onDismissRequest = { selected = null },
            icon = { Icon(Icons.Default.Key, contentDescription = null, tint = BrandPrimary) },
            title = { Text("Confirm secure delivery", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(activation.productName, fontWeight = FontWeight.SemiBold)
                    Text("${activation.customerName} • ${activation.orderNumber}")
                    StatusBadge(activation.status)
                    Text(
                        "Passwords, license keys and account credentials are never stored in the Android offline database. Complete secret entry through the encrypted server workflow.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = activation.status !in listOf("delivered", "cancelled"),
                    onClick = {
                        viewModel.fulfillActivation(activation, "")
                        selected = null
                    }
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Mark delivered")
                }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Close") } }
        )
    }
}

@Composable
private fun BusinessListCard(
    iconColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    value: String,
    status: String,
    supporting: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(iconColor.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(21.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(6.dp))
                    StatusBadge(status)
                }
                Text(
                    text = subtitle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = supporting,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f),
                    fontSize = 9.5.sp,
                    maxLines = 1
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = value,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1
                )
                Spacer(Modifier.height(5.dp))
                Icon(
                    Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
