package com.example.digitech.auth

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.digitech.ui.theme.*

data class RoleDefinition(
    val id: String,
    val title: String,
    val badgeLabel: String,
    val description: String,
    val icon: ImageVector,
    val color: Color,
    val canViewFinancialRevenue: Boolean,
    val canViewProfitAndMargins: Boolean,
    val canViewCostPrices: Boolean,
    val canManageExpenses: Boolean,
    val canCreateOrders: Boolean,
    val canFulfillActivations: Boolean,
    val canManageSupportTickets: Boolean,
    val canManageProducts: Boolean,
    val canResetDatabase: Boolean,
    val canExportFinancialReports: Boolean
)

object RolePermissions {

    val NO_ACCESS = RoleDefinition(
        id = "no_access",
        title = "Access Pending",
        badgeLabel = "Access Pending",
        description = "Your organization administrator must assign a role before business data is available.",
        icon = Icons.Filled.Block,
        color = StatusDanger,
        canViewFinancialRevenue = false,
        canViewProfitAndMargins = false,
        canViewCostPrices = false,
        canManageExpenses = false,
        canCreateOrders = false,
        canFulfillActivations = false,
        canManageSupportTickets = false,
        canManageProducts = false,
        canResetDatabase = false,
        canExportFinancialReports = false
    )

    val STORE_OWNER = RoleDefinition(
        id = "owner",
        title = "Store Owner",
        badgeLabel = "👑 Store Owner (Super Admin)",
        description = "Full unrestricted administrative access: all financial revenue, net profits, expense management, database resets, and full cloud control.",
        icon = Icons.Filled.AdminPanelSettings,
        color = BrandPrimary,
        canViewFinancialRevenue = true,
        canViewProfitAndMargins = true,
        canViewCostPrices = true,
        canManageExpenses = true,
        canCreateOrders = true,
        canFulfillActivations = true,
        canManageSupportTickets = true,
        canManageProducts = true,
        canResetDatabase = false,
        canExportFinancialReports = true
    )

    val OPERATIONS_MANAGER = RoleDefinition(
        id = "operations",
        title = "Operations Manager",
        badgeLabel = "💼 Operations Manager",
        description = "Full operational control: orders, customer accounts, activations fulfillment, subscriptions, and inventory. Restricted from database wipe.",
        icon = Icons.Filled.ManageAccounts,
        color = BrandSecondary,
        canViewFinancialRevenue = false,
        canViewProfitAndMargins = false,
        canViewCostPrices = true,
        canManageExpenses = false,
        canCreateOrders = false,
        canFulfillActivations = true,
        canManageSupportTickets = false,
        canManageProducts = true,
        canResetDatabase = false,
        canExportFinancialReports = false
    )

    val SALES_STAFF = RoleDefinition(
        id = "sales",
        title = "Sales & Staff Executive",
        badgeLabel = "🎯 Sales & Staff",
        description = "Order creation, customer lookup, catalog price check, and CRM leads. Financial profits, gross margins, and cost prices are securely masked.",
        icon = Icons.Filled.Storefront,
        color = BrandAccent,
        canViewFinancialRevenue = false,
        canViewProfitAndMargins = false,
        canViewCostPrices = false,
        canManageExpenses = false,
        canCreateOrders = true,
        canFulfillActivations = false,
        canManageSupportTickets = false,
        canManageProducts = false,
        canResetDatabase = false,
        canExportFinancialReports = false
    )

    val SUPPORT_SPECIALIST = RoleDefinition(
        id = "support",
        title = "Support Specialist",
        badgeLabel = "🎧 Support Specialist",
        description = "Customer issue ticketing, renewal reminders, digital license dispatch, and AI Copilot assistance with financial privacy protection.",
        icon = Icons.Filled.SupportAgent,
        color = StatusInfo,
        canViewFinancialRevenue = false,
        canViewProfitAndMargins = false,
        canViewCostPrices = false,
        canManageExpenses = false,
        canCreateOrders = false,
        canFulfillActivations = false,
        canManageSupportTickets = true,
        canManageProducts = false,
        canResetDatabase = false,
        canExportFinancialReports = false
    )

    val INVENTORY_LEAD = RoleDefinition(
        id = "operations",
        title = "Inventory Lead",
        badgeLabel = "📦 Inventory Lead",
        description = "Product catalog maintenance, vendor relationships, stock adjustments, and supplier expenses with restricted profit analytics.",
        icon = Icons.Filled.Inventory,
        color = StatusWarning,
        canViewFinancialRevenue = false,
        canViewProfitAndMargins = false,
        canViewCostPrices = true,
        canManageExpenses = true,
        canCreateOrders = true,
        canFulfillActivations = true,
        canManageSupportTickets = false,
        canManageProducts = true,
        canResetDatabase = false,
        canExportFinancialReports = false
    )

    val ACCOUNTS = RoleDefinition(
        id = "accounts",
        title = "Accounts",
        badgeLabel = "Accounts & Finance",
        description = "Financial operations, payments, expenses and reporting with no database administration.",
        icon = Icons.Filled.AccountBalance,
        color = StatusSuccess,
        canViewFinancialRevenue = true,
        canViewProfitAndMargins = true,
        canViewCostPrices = true,
        canManageExpenses = true,
        canCreateOrders = false,
        canFulfillActivations = false,
        canManageSupportTickets = false,
        canManageProducts = false,
        canResetDatabase = false,
        canExportFinancialReports = true
    )

    val VIEWER = RoleDefinition(
        id = "viewer",
        title = "Viewer",
        badgeLabel = "Read only",
        description = "Read-only workspace access. All mutations remain disabled by server RLS.",
        icon = Icons.Filled.Visibility,
        color = StatusInfo,
        canViewFinancialRevenue = true,
        canViewProfitAndMargins = false,
        canViewCostPrices = false,
        canManageExpenses = false,
        canCreateOrders = false,
        canFulfillActivations = false,
        canManageSupportTickets = false,
        canManageProducts = false,
        canResetDatabase = false,
        canExportFinancialReports = false
    )

    val ADMIN = STORE_OWNER.copy(
        id = "admin",
        title = "Administrator",
        badgeLabel = "Administrator",
        description = "Full workspace administration under server RLS.",
        canResetDatabase = false
    )

    val ALL_ROLES = listOf(
        STORE_OWNER,
        ADMIN,
        OPERATIONS_MANAGER,
        SALES_STAFF,
        SUPPORT_SPECIALIST,
        ACCOUNTS,
        VIEWER
    )

    fun getRole(roleName: String): RoleDefinition {
        val serverMapped = when (roleName.lowercase()) {
            "owner" -> STORE_OWNER
            "admin" -> ADMIN
            "operations" -> OPERATIONS_MANAGER
            "sales" -> SALES_STAFF
            "support" -> SUPPORT_SPECIALIST
            "accounts" -> ACCOUNTS
            "viewer" -> VIEWER
            else -> null
        }
        if (serverMapped != null) return serverMapped
        return ALL_ROLES.firstOrNull {
            it.title.equals(roleName, ignoreCase = true) ||
            it.id.equals(roleName, ignoreCase = true)
        } ?: NO_ACCESS
    }
}
