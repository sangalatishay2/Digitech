package com.example.digitech.data.gemini

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

enum class AiProvider(val wireName: String, val label: String) {
    OPENROUTER("openrouter", "OpenRouter"),
    GOOGLE("google", "Google AI")
}

object AiModels {
    const val NEMOTRON = "nvidia/nemotron-3-nano-30b-a3b"
    const val GEMINI_FLASH = "gemini-2.5-flash"
}

/** Legacy name retained only to avoid a breaking source migration. */
object GeminiModels {
    const val GEMINI_3_5_FLASH = AiModels.GEMINI_FLASH
    const val GEMINI_3_1_PRO = AiModels.NEMOTRON
    const val GEMINI_3_1_FLASH_LITE = AiModels.GEMINI_FLASH
    const val GEMINI_3_1_FLASH_LIVE = AiModels.NEMOTRON
}

enum class AiRole(
    val title: String,
    val subtitle: String,
    val recommendedModel: String,
    val systemInstruction: String
) {
    BUSINESS_COPILOT(
        title = "Business Copilot",
        subtitle = "General digital goods operations & advisory",
        recommendedModel = AiModels.NEMOTRON,
        systemInstruction = """You are the DigiTech Business OS Copilot. You are an expert digital agency & software licensing business consultant.
You assist the owner in managing their software subscriptions, digital license keys (Canva, Office, Adobe, ChatGPT, Antivirus, Streaming), customer relationships, order fulfillment, and profit maximization.
Provide structured, concise, highly actionable responses with bullet points where appropriate. Always be professional, helpful, and data-informed."""
    ),
    FINANCIAL_ANALYST(
        title = "Financial Analyst",
        subtitle = "Deep margin analysis, cashflow & auditing",
        recommendedModel = AiModels.NEMOTRON,
        systemInstruction = """You are the DigiTech Chief Financial Analyst.
You specialize in digital commerce unit economics, gross margins, customer acquisition costs, renewal lifetime value (LTV), expense tracking, and supplier negotiation.
Break down complex numbers methodically, show formulas, and recommend specific strategies to increase profitability and eliminate cash leaks."""
    ),
    SUPPORT_MESSAGING(
        title = "Customer Support Rep",
        subtitle = "Draft WhatsApp, email & delivery notes",
        recommendedModel = AiModels.GEMINI_FLASH,
        systemInstruction = """You are the DigiTech Customer Support & Messaging Assistant.
You craft polite, persuasive, and friendly WhatsApp messages, email receipts, renewal reminder alerts, and step-by-step activation guides for customers buying digital software keys and account upgrades.
Keep messages warm, formatted with emojis for mobile chat, and clear with next steps."""
    ),
    LICENSE_OPERATIONS(
        title = "License & Keys Specialist",
        subtitle = "Troubleshoot activations & renewals",
        recommendedModel = AiModels.NEMOTRON,
        systemInstruction = """You are the DigiTech Software License & Provisioning Specialist.
You handle activation errors, license key allocations, subscription renewal timelines, email invite workflows, and churn reduction tactics for B2B and retail software buyers."""
    )
}

@Serializable
data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: String, // "user" or "model"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    val modelUsed: String? = null
)

@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val tools: List<JsonObject>? = null,
    val systemInstruction: Content? = null
)

@Serializable
data class Content(
    val role: String? = null,
    val parts: List<Part>
)

@Serializable
data class Part(
    val text: String? = null,
    val inlineData: InlineData? = null
)

@Serializable
data class InlineData(
    val mimeType: String,
    val data: String
)

@Serializable
data class GenerationConfig(
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null,
    val candidateCount: Int? = null,
    val maxOutputTokens: Int? = null,
    val responseModalities: List<String>? = null
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null,
    val usageMetadata: UsageMetadata? = null,
    val error: GeminiApiError? = null
)

@Serializable
data class Candidate(
    val content: Content? = null,
    val finishReason: String? = null
)

@Serializable
data class UsageMetadata(
    val promptTokenCount: Int? = null,
    val candidatesTokenCount: Int? = null,
    val totalTokenCount: Int? = null
)

@Serializable
data class GeminiApiError(
    val code: Int? = null,
    val message: String? = null,
    val status: String? = null
)
