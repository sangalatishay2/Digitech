package com.example.digitech

import android.app.Application
import com.example.digitech.data.db.AppDatabase
import com.example.digitech.data.repository.DigiTechRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class DigiTechApp : Application() {
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { DigiTechRepository(database.digiTechDao(), this, applicationScope) }

    override fun onCreate() {
        super.onCreate()
        // Business data comes from the authenticated organization backend.
        // Never create demo records merely because remote data is unavailable.
    }
}
