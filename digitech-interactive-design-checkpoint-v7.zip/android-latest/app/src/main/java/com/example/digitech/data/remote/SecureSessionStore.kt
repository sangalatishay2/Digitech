package com.example.digitech.data.remote

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Stores refresh credentials encrypted by a non-exportable Android Keystore key. */
class SecureSessionStore(context: Context) {
    private val preferences = context.getSharedPreferences("digitech_secure_session", Context.MODE_PRIVATE)

    fun save(accessToken: String, refreshToken: String) {
        saveEncrypted("access", accessToken)
        saveEncrypted("refresh", refreshToken)
    }

    private fun saveEncrypted(name: String, value: String) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        preferences.edit()
            .putString("${name}_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("${name}_value", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .apply()
    }

    fun readRefreshToken(): String? = readEncrypted("refresh")

    fun readAccessToken(): String? = readEncrypted("access")

    private fun readEncrypted(name: String): String? = runCatching {
        val iv = Base64.decode(preferences.getString("${name}_iv", null), Base64.NO_WRAP)
        val encrypted = Base64.decode(preferences.getString("${name}_value", null), Base64.NO_WRAP)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        cipher.doFinal(encrypted).toString(Charsets.UTF_8)
    }.getOrNull()

    fun clear() {
        preferences.edit().clear().apply()
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").run {
            init(
                KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .build()
            )
            generateKey()
        }
    }

    private companion object {
        const val KEY_ALIAS = "digitech_supabase_refresh_v1"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
