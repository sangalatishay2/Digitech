package com.example.digitech.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.ui.theme.BrandAccent
import com.example.digitech.ui.theme.BrandPrimary
import com.example.digitech.ui.theme.DigiTechMotion
import com.example.digitech.ui.theme.StatusDanger
import com.example.digitech.ui.theme.StatusInfo
import com.example.digitech.ui.theme.StatusSuccess
import com.example.digitech.ui.theme.StatusWarning
import com.example.digitech.ui.theme.pressScale

@Composable
fun MetricKpiCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    Card(
        modifier = modifier
            .pressScale(interactionSource)
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = LocalIndication.current,
                        onClick = onClick
                    )
                } else Modifier
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(accentColor.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(19.dp)
                )
            }
            Spacer(modifier = Modifier.size(10.dp))
            Text(
                text = title.uppercase(),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.6.sp,
                maxLines = 1
            )
            AnimatedContent(
                targetState = value,
                transitionSpec = {
                    (slideInVertically(tween(DigiTechMotion.Standard)) { it / 2 } +
                        fadeIn(tween(DigiTechMotion.Standard)))
                        .togetherWith(
                            slideOutVertically(tween(DigiTechMotion.Quick)) { -it / 2 } +
                                fadeOut(tween(DigiTechMotion.Quick))
                        )
                },
                label = "metricValue"
            ) { animatedValue ->
                Text(
                    text = animatedValue,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
            Text(
                text = subtitle,
                color = accentColor,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}

@Composable
fun StatusBadge(status: String, modifier: Modifier = Modifier) {
    val normalized = status.trim().lowercase().replace(' ', '_')
    val color = when (normalized) {
        "active", "paid", "completed", "delivered", "won", "success", "vip" -> StatusSuccess
        "cancelled", "failed", "overdue", "lost", "rejected", "critical", "high" -> StatusDanger
        "pending", "awaiting_payment", "waiting_payment", "expiring", "medium", "follow_up" -> StatusWarning
        "processing", "in_progress", "ready", "new", "open", "digital_code" -> StatusInfo
        "owner", "admin", "priority" -> BrandPrimary
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val label = normalized
        .split('_')
        .joinToString(" ") { word -> word.replaceFirstChar { it.uppercase() } }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.12f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = color,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

@Composable
fun EmptyStateView(
    title: String,
    message: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 38.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(RoundedCornerShape(19.dp))
                .background(BrandPrimary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = BrandPrimary, modifier = Modifier.size(28.dp))
        }
        Spacer(modifier = Modifier.size(14.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.size(5.dp))
        Text(
            text = message,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            textAlign = TextAlign.Center
        )
    }
}

object ActionHelpers {
    fun dialPhone(context: Context, phone: String) {
        val safePhone = phone.filter { it.isDigit() || it == '+' }
        if (safePhone.isBlank()) return
        launch(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(safePhone)}")))
    }

    fun openWhatsApp(context: Context, phone: String, message: String) {
        val digits = phone.filter(Char::isDigit)
        val intent = if (digits.isBlank()) {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
            }
        } else {
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/$digits?text=${Uri.encode(message)}")
            )
        }
        launch(context, intent)
    }

    private fun launch(context: Context, intent: Intent) {
        runCatching {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }
}
