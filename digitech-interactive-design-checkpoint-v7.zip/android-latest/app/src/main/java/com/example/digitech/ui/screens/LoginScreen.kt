package com.example.digitech.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.auth.AuthUiState
import com.example.digitech.auth.PasswordStrengthValidator
import com.example.digitech.auth.PasswordStrengthLevel
import com.example.digitech.ui.theme.*
import kotlinx.coroutines.launch

enum class AuthMode {
    SIGN_IN,
    SIGN_UP
}

@Composable
fun LoginScreen(
    authState: AuthUiState,
    initialRememberMe: Boolean = false,
    initialEmail: String = "",
    isBiometricAvailable: Boolean = false,
    onBiometricSignInClicked: () -> Unit = {},
    onGoogleSignInClicked: () -> Unit,
    onEmailSignInClicked: (String, String, Boolean) -> Unit = { _, _, _ -> },
    onEmailSignUpClicked: (String, String, Boolean) -> Unit = { _, _, _ -> },
    onPasswordResetClicked: (String, (Boolean, String) -> Unit) -> Unit = { _, _ -> },
    onGuestSignInClicked: () -> Unit = {},
    onClearError: () -> Unit = {}
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var authMode by remember { mutableStateOf(AuthMode.SIGN_IN) }
    var email by remember { mutableStateOf(initialEmail) }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var rememberMe by remember { mutableStateOf(initialRememberMe) }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isConfirmPasswordVisible by remember { mutableStateOf(false) }

    // Sync initialEmail / initialRememberMe when loaded
    LaunchedEffect(initialEmail, initialRememberMe) {
        if (email.isBlank() && initialEmail.isNotBlank()) {
            email = initialEmail
        }
        if (initialRememberMe) {
            rememberMe = true
        }
    }

    var showResetDialog by remember { mutableStateOf(false) }
    var resetEmail by remember { mutableStateOf("") }
    var isResetting by remember { mutableStateOf(false) }
    var resetSuccessMessage by remember { mutableStateOf<String?>(null) }
    var resetErrorMessage by remember { mutableStateOf<String?>(null) }

    val isLoading = authState is AuthUiState.Loading

    // Evaluate Real-Time Password Strength
    val passwordStrength = remember(password) {
        PasswordStrengthValidator.evaluate(password)
    }

    // Trigger Snackbar on AuthUiState.Error
    LaunchedEffect(authState) {
        if (authState is AuthUiState.Error) {
            snackbarHostState.showSnackbar(
                message = authState.message,
                actionLabel = "Dismiss",
                duration = SnackbarDuration.Short
            )
        }
    }

    // Helper to display localized feedback
    fun showSnackbarMessage(message: String) {
        coroutineScope.launch {
            snackbarHostState.showSnackbar(
                message = message,
                actionLabel = "OK",
                duration = SnackbarDuration.Short
            )
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = {
                if (!isResetting) {
                    showResetDialog = false
                    resetSuccessMessage = null
                    resetErrorMessage = null
                }
            },
            icon = {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(BrandPrimary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.LockReset,
                        contentDescription = null,
                        tint = BrandPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    text = "Reset Account Password",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Enter your business email. Supabase will send password reset instructions without revealing whether an account exists.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    if (resetSuccessMessage != null) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = StatusSuccess.copy(alpha = 0.15f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .testTag("reset_success_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = StatusSuccess,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = resetSuccessMessage ?: "",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = StatusSuccess,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                            }
                        }
                    }

                    if (resetErrorMessage != null) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = StatusDanger.copy(alpha = 0.15f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .testTag("reset_error_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = StatusDanger,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = resetErrorMessage ?: "",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = StatusDanger,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = resetEmail,
                        onValueChange = {
                            resetEmail = it
                            resetErrorMessage = null
                        },
                        label = { Text("Account Email") },
                        placeholder = { Text("name@domain.com") },
                        leadingIcon = {
                            Icon(Icons.Outlined.Email, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        },
                        singleLine = true,
                        enabled = !isResetting,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                if (resetEmail.isNotBlank() && !isResetting) {
                                    isResetting = true
                                    resetErrorMessage = null
                                    resetSuccessMessage = null
                                    onPasswordResetClicked(resetEmail.trim()) { success, message ->
                                        isResetting = false
                                        if (success) {
                                            resetSuccessMessage = message
                                        } else {
                                            resetErrorMessage = message
                                        }
                                    }
                                }
                            }
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reset_email_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandPrimary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        )
                    )
                }
            },
            confirmButton = {
                if (resetSuccessMessage != null) {
                    Button(
                        onClick = {
                            showResetDialog = false
                            resetSuccessMessage = null
                            resetErrorMessage = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                        modifier = Modifier.testTag("dismiss_reset_success_button")
                    ) {
                        Text("Back to Sign In")
                    }
                } else {
                    Button(
                        onClick = {
                            if (resetEmail.isBlank()) {
                                resetErrorMessage = "Please enter your account email."
                                return@Button
                            }
                            isResetting = true
                            resetErrorMessage = null
                            resetSuccessMessage = null
                            onPasswordResetClicked(resetEmail.trim()) { success, message ->
                                isResetting = false
                                if (success) {
                                    resetSuccessMessage = message
                                } else {
                                    resetErrorMessage = message
                                }
                            }
                        },
                        enabled = !isResetting && resetEmail.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                        modifier = Modifier.testTag("submit_reset_password_button")
                    ) {
                        if (isResetting) {
                            CircularProgressIndicator(
                                modifier = Modifier
                                    .size(16.dp)
                                    .testTag("reset_loading_indicator"),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sending...")
                        } else {
                            Text("Send Reset Link")
                        }
                    }
                }
            },
            dismissButton = {
                if (resetSuccessMessage == null) {
                    TextButton(
                        onClick = {
                            showResetDialog = false
                            resetErrorMessage = null
                        },
                        enabled = !isResetting,
                        modifier = Modifier.testTag("cancel_reset_password_button")
                    ) {
                        Text("Cancel")
                    }
                }
            }
        )
    }

    Scaffold(
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier
                    .padding(16.dp)
                    .testTag("auth_snackbar_host")
            ) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = DarkSurfaceContainerHigh,
                    contentColor = TextPrimaryDark,
                    actionColor = BrandPrimaryLight,
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        containerColor = Color.Transparent
    ) { scaffoldPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(scaffoldPadding)
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            DarkBackground,
                            Color(0xFF0F172A),
                            DarkBackground
                        )
                    )
                )
                .testTag("login_screen")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 24.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header & App Logo
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(BrandPrimary, BrandAccent)
                            )
                        )
                        .border(1.5.dp, BrandPrimary.copy(alpha = 0.5f), RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Business,
                        contentDescription = "DigiTech Logo",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "DigiTech Business OS",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    ),
                    color = TextPrimaryDark,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Enterprise Digital Subscriptions & Cloud Licensing",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryDark,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Auth Card Container
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = DarkSurfaceContainerHigh
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Sign In / Sign Up Mode Tabs
                        TabRow(
                            selectedTabIndex = if (authMode == AuthMode.SIGN_IN) 0 else 1,
                            containerColor = Color.Transparent,
                            contentColor = BrandPrimary,
                            divider = {}
                        ) {
                            Tab(
                                selected = authMode == AuthMode.SIGN_IN,
                                onClick = {
                                    authMode = AuthMode.SIGN_IN
                                    onClearError()
                                },
                                text = {
                                    Text(
                                        "Sign In",
                                        fontWeight = if (authMode == AuthMode.SIGN_IN) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                }
                            )
                            Tab(
                                selected = authMode == AuthMode.SIGN_UP,
                                onClick = {
                                    authMode = AuthMode.SIGN_UP
                                    onClearError()
                                },
                                text = {
                                    Text(
                                        "Create Account",
                                        fontWeight = if (authMode == AuthMode.SIGN_UP) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Error Alert Banner
                        if (authState is AuthUiState.Error) {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = StatusDanger.copy(alpha = 0.15f)
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 14.dp)
                                    .testTag("login_error_card")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ErrorOutline,
                                        contentDescription = "Error",
                                        tint = StatusDanger,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = authState.message,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextPrimaryDark,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        // Processing Loading Banner
                        AnimatedVisibility(
                            visible = isLoading,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = BrandPrimary.copy(alpha = 0.12f)
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 14.dp)
                                    .testTag("auth_processing_banner")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .testTag("banner_loading_indicator"),
                                        color = BrandPrimary,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "Authenticating securely with Supabase...",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontWeight = FontWeight.Medium
                                        ),
                                        color = BrandPrimaryLight
                                    )
                                }
                            }
                        }

                        // Email Field
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Business Email") },
                            placeholder = { Text("you@company.com") },
                            leadingIcon = {
                                Icon(Icons.Outlined.Email, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Email,
                                imeAction = ImeAction.Next
                            ),
                            keyboardActions = KeyboardActions(
                                onNext = { focusManager.moveFocus(FocusDirection.Down) }
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_email_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BrandPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Password Field with Visibility Toggle
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            placeholder = { Text("••••••••") },
                            leadingIcon = {
                                Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            },
                            trailingIcon = {
                                IconButton(
                                    onClick = { isPasswordVisible = !isPasswordVisible },
                                    modifier = Modifier.testTag("password_visibility_toggle")
                                ) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (isPasswordVisible) "Hide password" else "Show password",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            },
                            singleLine = true,
                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = if (authMode == AuthMode.SIGN_UP) ImeAction.Next else ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onNext = { focusManager.moveFocus(FocusDirection.Down) },
                                onDone = {
                                    focusManager.clearFocus()
                                    if (authMode == AuthMode.SIGN_IN) {
                                        if (email.isBlank() || password.isBlank()) {
                                            showSnackbarMessage("Please provide both email and password")
                                        } else {
                                            onEmailSignInClicked(email, password, rememberMe)
                                        }
                                    }
                                }
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_password_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BrandPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            )
                        )

                        // Real-time Password Strength Validation Cues (Active during Sign Up or whenever typing password)
                        AnimatedVisibility(
                            visible = authMode == AuthMode.SIGN_UP || (password.isNotEmpty() && authMode == AuthMode.SIGN_IN),
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 10.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(DarkSurfaceVariant.copy(alpha = 0.7f))
                                    .border(1.dp, DarkBorder.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                    .padding(12.dp)
                                    .testTag("password_strength_card")
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Password Strength",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextSecondaryDark
                                        )
                                    )
                                    // Strength Level Badge
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(passwordStrength.level.color.copy(alpha = 0.2f))
                                            .border(1.dp, passwordStrength.level.color.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                            .testTag("password_strength_badge")
                                    ) {
                                        Text(
                                            text = passwordStrength.level.label,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = passwordStrength.level.color,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Multi-segment visual progress indicator
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    repeat(5) { index ->
                                        val isSegmentActive = index < passwordStrength.score
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .fillMaxHeight()
                                                .background(
                                                    if (isSegmentActive) passwordStrength.level.color else Color(0xFF334155)
                                                )
                                        )
                                    }
                                }

                                // Visual Checklist of Requirements
                                if (authMode == AuthMode.SIGN_UP) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        passwordStrength.requirements.forEach { req ->
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.fillMaxWidth().testTag("req_${req.id}")
                                            ) {
                                                Icon(
                                                    imageVector = if (req.isMet) Icons.Default.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                                                    contentDescription = null,
                                                    tint = if (req.isMet) StatusSuccess else Color(0xFF64748B),
                                                    modifier = Modifier.size(13.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = req.label,
                                                    fontSize = 11.sp,
                                                    color = if (req.isMet) TextPrimaryDark else TextSecondaryDark
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Confirm Password Field (Sign-Up Mode)
                        if (authMode == AuthMode.SIGN_UP) {
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = confirmPassword,
                                onValueChange = { confirmPassword = it },
                                label = { Text("Confirm Password") },
                                placeholder = { Text("••••••••") },
                                leadingIcon = {
                                    Icon(Icons.Outlined.LockClock, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                },
                                trailingIcon = {
                                    IconButton(
                                        onClick = { isConfirmPasswordVisible = !isConfirmPasswordVisible },
                                        modifier = Modifier.testTag("confirm_password_visibility_toggle")
                                    ) {
                                        Icon(
                                            imageVector = if (isConfirmPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = if (isConfirmPasswordVisible) "Hide password" else "Show password",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                singleLine = true,
                                visualTransformation = if (isConfirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Password,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        focusManager.clearFocus()
                                        if (password != confirmPassword) {
                                            showSnackbarMessage("Passwords do not match")
                                        } else if (passwordStrength.score < 2) {
                                            showSnackbarMessage("Please choose a stronger password before creating account")
                                        } else {
                                            onEmailSignUpClicked(email, password, rememberMe)
                                        }
                                    }
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("login_confirm_password_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BrandPrimary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 'Remember Me' Checkbox & Forgot Password Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Remember Me Checkbox (DataStore Local Persistence)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { rememberMe = !rememberMe }
                                    .padding(vertical = 4.dp, horizontal = 2.dp)
                                    .testTag("remember_me_container")
                            ) {
                                Checkbox(
                                    checked = rememberMe,
                                    onCheckedChange = { rememberMe = it },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = BrandPrimary,
                                        uncheckedColor = MaterialTheme.colorScheme.outline
                                    ),
                                    modifier = Modifier
                                        .size(24.dp)
                                        .testTag("remember_me_checkbox")
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Remember Me",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Medium,
                                        color = TextPrimaryDark,
                                        fontSize = 12.sp
                                    )
                                )
                            }

                            // Forgot Password Link (Sign-In Mode)
                            if (authMode == AuthMode.SIGN_IN) {
                                TextButton(
                                    onClick = {
                                        resetEmail = email
                                        showResetDialog = true
                                    },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                    modifier = Modifier.testTag("forgot_password_button")
                                ) {
                                    Text(
                                        "Forgot Password?",
                                        fontSize = 12.sp,
                                        color = BrandPrimaryLight
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Primary Email Auth Button
                        Button(
                            onClick = {
                                focusManager.clearFocus()
                                if (authMode == AuthMode.SIGN_IN) {
                                    if (email.isBlank() || password.isBlank()) {
                                        showSnackbarMessage("Please enter your email and password.")
                                        return@Button
                                    }
                                    onEmailSignInClicked(email, password, rememberMe)
                                } else {
                                    if (email.isBlank() || password.isBlank()) {
                                        showSnackbarMessage("Please enter email and password.")
                                        return@Button
                                    }
                                    if (password != confirmPassword) {
                                        showSnackbarMessage("Passwords do not match. Please verify.")
                                        return@Button
                                    }
                                    if (passwordStrength.score < 2) {
                                        showSnackbarMessage("Password is too weak. Please include letters and numbers.")
                                        return@Button
                                    }
                                    onEmailSignUpClicked(email, password, rememberMe)
                                }
                            },
                            enabled = !isLoading && email.isNotBlank() && password.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("login_primary_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BrandPrimary,
                                contentColor = Color.White
                            )
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Text(
                                    text = if (authMode == AuthMode.SIGN_IN) "Sign In to Dashboard" else "Register Business Account",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }

                        // Biometric Authentication Button
                        if (isBiometricAvailable && authMode == AuthMode.SIGN_IN) {
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = onBiometricSignInClicked,
                                enabled = !isLoading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp)
                                    .testTag("biometric_sign_in_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = BrandPrimaryLight
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, BrandPrimary.copy(alpha = 0.5f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Fingerprint,
                                    contentDescription = "Biometric Login",
                                    tint = BrandPrimaryLight,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Unlock with Biometrics / Face ID",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Divider with "OR"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            HorizontalDivider(modifier = Modifier.weight(1f), color = DarkBorder)
                            Text(
                                text = "OR CONTINUE WITH",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondaryDark,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            HorizontalDivider(modifier = Modifier.weight(1f), color = DarkBorder)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Google Sign In Button
                        Button(
                            onClick = onGoogleSignInClicked,
                            enabled = !isLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("google_sign_in_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color(0xFF1F2937),
                                disabledContainerColor = Color.White.copy(alpha = 0.85f),
                                disabledContentColor = Color(0xFF1F2937)
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .testTag("google_loading_indicator"),
                                    color = Color(0xFF4285F4),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Connecting with Google...",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF1F2937)
                                    )
                                )
                            } else {
                                // Google Brand Logo
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF4285F4)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "G",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            color = Color.White,
                                            fontSize = 12.sp
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Sign in with Google",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1F2937)
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Guest / Fast Demo Access Button
                        OutlinedButton(
                            onClick = onGuestSignInClicked,
                            enabled = !isLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("guest_sign_in_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.onSurface
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .testTag("guest_loading_indicator"),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    strokeWidth = 1.5.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Loading Session...", fontSize = 12.sp)
                            } else {
                                Icon(
                                    imageVector = Icons.Default.PersonOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Continue as Guest / Demo Mode", fontSize = 12.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Identity and device security status
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = StatusSuccess,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Supabase Auth & Android Keystore Protected",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryDark
                    )
                }
            }
        }
    }
}
