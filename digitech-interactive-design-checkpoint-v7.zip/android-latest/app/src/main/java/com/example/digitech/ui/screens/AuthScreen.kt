package com.example.digitech.ui.screens

import androidx.compose.runtime.Composable
import com.example.digitech.auth.AuthUiState

/**
 * Backward-compatible wrapper for LoginScreen.
 */
@Composable
fun AuthScreen(
    authState: AuthUiState,
    onSignInClicked: () -> Unit
) {
    LoginScreen(
        authState = authState,
        onGoogleSignInClicked = onSignInClicked
    )
}
