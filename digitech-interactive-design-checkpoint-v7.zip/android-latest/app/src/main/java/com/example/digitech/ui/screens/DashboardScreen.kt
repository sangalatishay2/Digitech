package com.example.digitech.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.data.sync.SyncStatus
import com.example.digitech.data.model.*
import com.example.digitech.ui.components.*
import com.example.digitech.ui.theme.*
import com.example.digitech.ui.viewmodel.DigiTechViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DigiTechViewModel,
    isDarkTheme: Boolean = true,
    onToggleTheme: () -> Unit = {},
    onOpenProfile: () -> Unit = {},
    onOpenTour: () -> Unit = {},
    onNavigateToOrders: () -> Unit,
    onNavigateToSubscriptions: () -> Unit,
    onNavigateToActivations: () -> Unit,
    onNavigateToCustomers: () -> Unit,
    onOpenCreateOrder: () -> Unit,
    onOpenAddCustomer: () -> Unit,
    onNavigateToAiCopilot: () -> Unit = {},
    onNavigateToVoiceMode: () -> Unit = {}
) {
    val context = LocalContext.current
    val metrics by viewModel.dashboardMetrics.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val subscriptions by viewModel.subscriptions.collectAsState()
    val activations by viewModel.activations.collectAsState()
    val activityLogs by viewModel.activityLogs.collectAsState()
    val syncStatus by viewModel.syncStatus.collectAsState()

    val isRefreshing = syncStatus is SyncStatus.Syncing
    val heroPulse = rememberInfiniteTransition(label = "copilotHeroPulse")
    val heroGlowAlpha by heroPulse.animateFloat(
        initialValue = 0.32f,
        targetValue = 0.72f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = DigiTechMotion.EmphasizedDecelerate),
            repeatMode = RepeatMode.Reverse
        ),
        label = "copilotHeroGlow"
    )
    var revealStage by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        repeat(4) { index ->
            delay(if (index == 0) 40 else 85)
            revealStage = index + 1
        }
    }

    val pendingActivations = remember(activations) {
        activations.filter { it.status != "delivered" && it.status != "cancelled" }.take(3)
    }

    val expiringSubscriptions = remember(subscriptions) {
        val now = System.currentTimeMillis()
        val fifteenDaysMs = 15L * 24 * 60 * 60 * 1000
        subscriptions.filter { it.expiryDate > now && (it.expiryDate - now) <= fifteenDaysMs }
    }

    var selectedOrderForDetail by remember { mutableStateOf<OrderEntity?>(null) }
    var selectedSubForRenew by remember { mutableStateOf<SubscriptionEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(BrandPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = BrandPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "DigiTech Business OS",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Digital Subscriptions & ERP Hub",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = StatusSuccess.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, StatusSuccess.copy(alpha = 0.28f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(StatusSuccess.copy(alpha = heroGlowAlpha))
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "SECURE",
                                color = StatusSuccess,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.7.sp
                            )
                        }
                    }

                    // Global Dark / Light Theme Toggle
                    ThemeToggleIconButton(
                        isDarkTheme = isDarkTheme,
                        onToggleTheme = onToggleTheme
                    )

                    // Profile / Account Setup Shortcut
                    IconButton(
                        onClick = onOpenProfile,
                        modifier = Modifier.testTag("dashboard_profile_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Profile Setup",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = { viewModel.forceManualSync() },
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
            item {
                BusinessPulseHero(
                    revenue = Formatters.formatCurrency(metrics.totalRevenue),
                    margin = metrics.marginPercentage,
                    openOrders = metrics.openOrdersCount,
                    expiringSoon = metrics.expiringSoonCount,
                    pendingFulfillment = metrics.pendingActivationsCount,
                    openTickets = metrics.openTicketsCount,
                    onNewOrder = onOpenCreateOrder,
                    onAddCustomer = onOpenAddCustomer,
                    onOpenRenewals = onNavigateToSubscriptions,
                    onOpenCopilot = onNavigateToAiCopilot
                )
            }

            // Detailed financial snapshot remains below the daily decision surface.
            item {
                AnimatedVisibility(
                    visible = revealStage >= 2,
                    enter = fadeIn(tween(DigiTechMotion.Standard)) +
                        slideInVertically(tween(DigiTechMotion.Standard)) { it / 4 }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Performance snapshot",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "LIVE",
                            color = StatusSuccess,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.8.sp
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricKpiCard(
                            title = "Total Revenue",
                            value = Formatters.formatCurrency(metrics.totalRevenue),
                            subtitle = "${orders.size} Total Orders",
                            icon = Icons.Default.Payments,
                            accentColor = StatusSuccess,
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToOrders
                        )
                        MetricKpiCard(
                            title = "Net Profit",
                            value = Formatters.formatCurrency(metrics.netProfit),
                            subtitle = String.format("%.1f%% Margin", metrics.marginPercentage),
                            icon = Icons.Default.TrendingUp,
                            accentColor = BrandPrimary,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricKpiCard(
                            title = "Active Subs",
                            value = metrics.activeSubscriptionsCount.toString(),
                            subtitle = "${metrics.expiringSoonCount} Expiring Soon",
                            icon = Icons.Default.Sync,
                            accentColor = BrandAccent,
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToSubscriptions
                        )
                        MetricKpiCard(
                            title = "Pending Fulfill",
                            value = metrics.pendingActivationsCount.toString(),
                            subtitle = "Digital Deliveries",
                            icon = Icons.Default.LocalShipping,
                            accentColor = StatusWarning,
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToActivations
                        )
                    }
                    }
                }
            }

            // Expiring Subscriptions Banner
            if (expiringSubscriptions.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = StatusWarning.copy(alpha = 0.12f)),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StatusWarning.copy(alpha = 0.4f)))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.WarningAmber,
                                        contentDescription = null,
                                        tint = StatusWarning,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${expiringSubscriptions.size} Subscriptions Expiring Soon",
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontSize = 14.sp
                                    )
                                }
                                TextButton(
                                    onClick = onNavigateToSubscriptions,
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Text("View All", fontSize = 12.sp, color = StatusWarning)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            expiringSubscriptions.take(2).forEach { sub ->
                                val daysLeft = Formatters.getDaysRemaining(sub.expiryDate)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = sub.productName,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "${sub.customerName} • in $daysLeft days",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        IconButton(
                                            onClick = {
                                                val msg = "Hi ${sub.customerName}, your ${sub.productName} subscription with DigiTech is expiring in $daysLeft days (${Formatters.formatDate(sub.expiryDate)}). Would you like to renew now at our special rate?"
                                                ActionHelpers.openWhatsApp(context, sub.customerPhone, msg)
                                                viewModel.updateSubscriptionReminder(sub, "contacted")
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Chat,
                                                contentDescription = "WhatsApp Reminder",
                                                tint = StatusSuccess,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Button(
                                            onClick = { selectedSubForRenew = sub },
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(30.dp)
                                        ) {
                                            Text("Renew", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Pending Activations Queue Preview
            if (pendingActivations.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Pending Activations (${pendingActivations.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        TextButton(onClick = onNavigateToActivations) {
                            Text("Queue", fontSize = 12.sp)
                        }
                    }
                }

                items(pendingActivations) { activation ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToActivations() },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = activation.productName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    StatusBadge(status = activation.priority)
                                }
                                Text(
                                    text = "For: ${activation.customerName} • ${activation.orderNumber}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusBadge(status = activation.status)
                        }
                    }
                }
            }

            // Recent Orders Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Orders",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    TextButton(onClick = onNavigateToOrders) {
                        Text("View All", fontSize = 12.sp)
                    }
                }
            }

            items(orders.take(5)) { order ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedOrderForDetail = order },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = order.orderNumber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = BrandPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                StatusBadge(status = order.status)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${order.customerName} • ${order.productName}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = Formatters.formatDateTime(order.orderedAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = Formatters.formatCurrency(order.total),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            StatusBadge(status = order.paymentStatus)
                        }
                    }
                }
            }

            // Real-time Activity Audit Logs Stream
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.HistoryEdu,
                            contentDescription = null,
                            tint = BrandAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Recent Activity & Audit Log",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        text = "${activityLogs.size} Events",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (activityLogs.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "No recent user activity recorded yet",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Actions like profile updates, theme changes, and orders will sync here in real-time.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            } else {
                items(activityLogs.take(6)) { log ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (log.actionType) {
                                            "PROFILE_UPDATE" -> BrandPrimary.copy(alpha = 0.15f)
                                            "THEME_CHANGE" -> BrandSecondary.copy(alpha = 0.15f)
                                            "SYNC_FREQUENCY_CHANGE" -> StatusWarning.copy(alpha = 0.15f)
                                            "MANUAL_SYNC" -> StatusSuccess.copy(alpha = 0.15f)
                                            "DATA_EXPORT" -> BrandAccent.copy(alpha = 0.15f)
                                            else -> MaterialTheme.colorScheme.primaryContainer
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (log.actionType) {
                                        "PROFILE_UPDATE" -> Icons.Default.ManageAccounts
                                        "THEME_CHANGE" -> Icons.Default.Palette
                                        "SYNC_FREQUENCY_CHANGE" -> Icons.Default.BatterySaver
                                        "MANUAL_SYNC" -> Icons.Default.Sync
                                        "DATA_EXPORT" -> Icons.Default.FileDownload
                                        else -> Icons.Default.History
                                    },
                                    contentDescription = null,
                                    tint = when (log.actionType) {
                                        "PROFILE_UPDATE" -> BrandPrimary
                                        "THEME_CHANGE" -> BrandSecondary
                                        "SYNC_FREQUENCY_CHANGE" -> StatusWarning
                                        "MANUAL_SYNC" -> StatusSuccess
                                        "DATA_EXPORT" -> BrandAccent
                                        else -> MaterialTheme.colorScheme.primary
                                    },
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = log.title,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = Formatters.formatDateTime(log.timestamp),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 10.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = log.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (log.actorEmail.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "By ${log.actorEmail} (${log.role})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = BrandPrimary,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

    // Renew Modal Dialog
    if (selectedSubForRenew != null) {
        val sub = selectedSubForRenew!!
        var daysText by remember { mutableStateOf("365") }
        var amountText by remember { mutableStateOf(sub.purchaseAmount.toInt().toString()) }

        AlertDialog(
            onDismissRequest = { selectedSubForRenew = null },
            title = { Text("⚡ Fast Renew Subscription") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(text = "Customer: ${sub.customerName}", fontWeight = FontWeight.SemiBold)
                    Text(text = "Product: ${sub.productName}", fontSize = 13.sp)
                    Text(text = "Current Expiry: ${Formatters.formatDate(sub.expiryDate)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    OutlinedTextField(
                        value = daysText,
                        onValueChange = { daysText = it },
                        label = { Text("Extend Duration (Days)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = { Text("Renewal Amount (₹)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val days = daysText.toIntOrNull() ?: 365
                        val amount = amountText.toDoubleOrNull() ?: sub.purchaseAmount
                        viewModel.renewSubscription(sub, days, amount)
                        selectedSubForRenew = null
                    }
                ) {
                    Text("Confirm Renewal")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedSubForRenew = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Order Detail Modal Dialog
    if (selectedOrderForDetail != null) {
        val order = selectedOrderForDetail!!
        AlertDialog(
            onDismissRequest = { selectedOrderForDetail = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(order.orderNumber)
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusBadge(status = order.status)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Customer: ${order.customerName}", fontWeight = FontWeight.Bold)
                    Text("Product: ${order.productName} (x${order.quantity})")
                    Text("Total: ${Formatters.formatCurrency(order.total)} (Cost: ${Formatters.formatCurrency(order.totalCost)} | Profit: ${Formatters.formatCurrency(order.profit)})")
                    Text("Payment: ${order.paymentMethod.uppercase()} • ${order.paymentStatus.uppercase()}")
                    Text("Date: ${Formatters.formatDateTime(order.orderedAt)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (order.notes.isNotEmpty()) {
                        Text("Notes: ${order.notes}", fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            val msg = "🧾 *DigiTech Invoice Confirmation*\nOrder: ${order.orderNumber}\nCustomer: ${order.customerName}\nProduct: ${order.productName}\nAmount: ${Formatters.formatCurrency(order.total)}\nStatus: ${order.status.uppercase()}\nPayment: ${order.paymentStatus.uppercase()}\n\nThank you for choosing DigiTech Business OS!"
                            ActionHelpers.openWhatsApp(context, "", msg)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share Invoice WhatsApp")
                    }
                }
            },
            confirmButton = {
                if (order.paymentStatus != "paid") {
                    Button(onClick = {
                        viewModel.markOrderPaid(order)
                        selectedOrderForDetail = null
                    }) {
                        Text("Mark Paid")
                    }
                } else if (order.status != "completed") {
                    Button(onClick = {
                        viewModel.completeOrder(order)
                        selectedOrderForDetail = null
                    }) {
                        Text("Mark Completed")
                    }
                } else {
                    TextButton(onClick = { selectedOrderForDetail = null }) {
                        Text("Close")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedOrderForDetail = null }) {
                    Text("Close")
                }
            }
        )
    }
}
