package com.example.digitech

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.example.digitech.auth.AuthManager
import com.example.digitech.auth.AuthUiState
import com.example.digitech.auth.BiometricAuthHelper
import com.example.digitech.auth.RolePermissions
import com.example.digitech.auth.SyncFrequency
import com.example.digitech.auth.UserProfileData
import com.example.digitech.data.sync.SyncStatus
import com.example.digitech.ui.components.AddCustomerDialog
import com.example.digitech.ui.components.CreateOrderDialog
import com.example.digitech.ui.components.ExpressiveBottomBar
import com.example.digitech.ui.components.OnboardingCarouselDialog
import com.example.digitech.ui.screens.*
import com.example.digitech.ui.theme.DigiTechMotion
import com.example.digitech.ui.theme.DigiTechTheme
import com.example.digitech.ui.viewmodel.AiAssistantViewModel
import com.example.digitech.ui.viewmodel.AiAssistantViewModelFactory
import com.example.digitech.ui.viewmodel.DigiTechViewModel
import com.example.digitech.ui.viewmodel.DigiTechViewModelFactory
import kotlinx.coroutines.launch

enum class AppDestination(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    DASHBOARD("Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard),
    AI_COPILOT("AI Copilot", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome),
    ORDERS("Orders", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong),
    SUBSCRIPTIONS("Renewals", Icons.Filled.Autorenew, Icons.Outlined.Autorenew),
    ACTIVATIONS("Fulfill", Icons.Filled.Key, Icons.Outlined.KeyOff),
    CUSTOMERS("Customers", Icons.Filled.People, Icons.Outlined.PeopleOutline),
    PRODUCTS("Catalog", Icons.Filled.Inventory2, Icons.Outlined.Inventory2),
    FINANCE("Finance", Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
    OPERATIONS("More", Icons.Filled.MoreHoriz, Icons.Outlined.MoreHoriz),
    VOICE_MODE("Live Voice", Icons.Filled.GraphicEq, Icons.Outlined.GraphicEq)
}

class MainActivity : FragmentActivity() {

    private val viewModel: DigiTechViewModel by viewModels {
        DigiTechViewModelFactory((application as DigiTechApp).repository)
    }

    private val aiViewModel: AiAssistantViewModel by viewModels {
        AiAssistantViewModelFactory(application, (application as DigiTechApp).repository)
    }

    private lateinit var authManager: AuthManager
    private lateinit var biometricHelper: BiometricAuthHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        authManager = AuthManager(applicationContext)
        biometricHelper = BiometricAuthHelper(this)

        setContent {
            val isDarkTheme by authManager.authPreferences.isDarkThemeFlow.collectAsState(initial = true)
            val authState by authManager.uiState.collectAsState()
            val rememberMePreference by authManager.authPreferences.rememberMeFlow.collectAsState(initial = false)
            val rememberedEmailPreference by authManager.authPreferences.rememberedEmailFlow.collectAsState(initial = "")
            val isOnboardingCompleted by authManager.authPreferences.isOnboardingCompletedFlow.collectAsState(initial = false)
            val userProfile by authManager.authPreferences.userProfileFlow.collectAsState(initial = UserProfileData())
            val syncFrequency by authManager.authPreferences.syncFrequencyFlow.collectAsState(initial = SyncFrequency.REALTIME)
            val syncStatus by viewModel.syncStatus.collectAsState()

            val isBiometricAvailable = remember { biometricHelper.isBiometricAvailable() }
            val coroutineScope = rememberCoroutineScope()

            var manualShowProfileSetup by remember { mutableStateOf(false) }
            var manualShowOnboarding by remember { mutableStateOf(false) }

            LaunchedEffect(Unit) {
                authManager.attemptAutoSignIn(coroutineScope)
            }

            DigiTechTheme(darkTheme = isDarkTheme) {
                LaunchedEffect(authState) {
                    val authenticated = authState as? AuthUiState.Authenticated
                    if (authenticated != null) {
                        viewModel.startCloudSync(
                            accessToken = authenticated.user.accessToken,
                            organizationId = authenticated.user.organizationId,
                            role = authenticated.user.serverRole,
                            frequency = syncFrequency
                        )
                    } else {
                        viewModel.clearLocalSessionData()
                    }
                }

                Crossfade(
                    targetState = authState,
                    label = "AuthCrossfade"
                ) { state ->
                    when (state) {
                        is AuthUiState.Authenticated -> {
                            // Check if Profile Setup should be shown (first-time initial login or manual edit)
                            val isFirstTimeProfilePending = !userProfile.isProfileSetupCompleted && !manualShowProfileSetup
                            if (syncStatus !is SyncStatus.Synced) {
                                SecureSyncGate(
                                    status = syncStatus,
                                    onRetry = { viewModel.forceManualSync() },
                                    onSignOut = {
                                        coroutineScope.launch {
                                            viewModel.clearLocalSessionData()
                                            authManager.signOut()
                                        }
                                    }
                                )
                            } else if (manualShowProfileSetup || isFirstTimeProfilePending) {
                                ProfileSetupScreen(
                                    initialProfile = userProfile,
                                    defaultEmail = state.user.email ?: "",
                                    defaultDisplayName = state.user.displayName ?: "",
                                    onSaveProfile = { name, photoUrl, _ ->
                                        coroutineScope.launch {
                                            authManager.authPreferences.saveUserProfile(name, photoUrl, "no_access")
                                            viewModel.logActivity(
                                                actionType = "PROFILE_UPDATE",
                                                title = "Profile Configured",
                                                description = "Updated display name to $name; role remains server-managed",
                                                actorEmail = state.user.email ?: "",
                                                role = "no_access"
                                            )
                                            manualShowProfileSetup = false
                                        }
                                    },
                                    onSkip = {
                                        coroutineScope.launch {
                                            // Mark profile setup completed with defaults if skipped
                                            val defaultName = state.user.displayName ?: "Merchant Partner"
                                            authManager.authPreferences.saveUserProfile(
                                                defaultName,
                                                "",
                                                "no_access"
                                            )
                                            viewModel.logActivity(
                                                actionType = "PROFILE_UPDATE",
                                                title = "Default Profile Selected",
                                                description = "Profile initialized; role remains server-managed",
                                                actorEmail = state.user.email ?: "",
                                                role = "no_access"
                                            )
                                            manualShowProfileSetup = false
                                        }
                                    }
                                )
                            } else if (userProfile.rolePreference == RolePermissions.NO_ACCESS.id) {
                                AccessPendingScreen(
                                    email = state.user.email.orEmpty(),
                                    onSignOut = {
                                        coroutineScope.launch {
                                            viewModel.clearLocalSessionData()
                                            authManager.signOut()
                                        }
                                    }
                                )
                            } else {
                                MainApp(
                                    viewModel = viewModel,
                                    aiViewModel = aiViewModel,
                                    isDarkTheme = isDarkTheme,
                                    syncFrequency = syncFrequency,
                                    userProfile = userProfile,
                                    userEmail = state.user.email.orEmpty(),
                                    onToggleTheme = {
                                        coroutineScope.launch {
                                            authManager.authPreferences.setDarkTheme(!isDarkTheme)
                                        }
                                    },
                                    onUpdateSyncFrequency = { newFreq ->
                                        coroutineScope.launch {
                                            authManager.authPreferences.setSyncFrequency(newFreq)
                                            viewModel.updateSyncFrequency(newFreq)
                                        }
                                    },
                                    onOpenProfileSetup = {
                                        manualShowProfileSetup = true
                                    },
                                    onOpenTour = {
                                        manualShowOnboarding = true
                                    },
                                    onSignOut = {
                                        coroutineScope.launch {
                                            viewModel.clearLocalSessionData()
                                            authManager.signOut()
                                        }
                                    }
                                )

                                // Multi-step Onboarding Carousel: shows automatically upon first login, or via menu
                                val shouldShowTour = !isOnboardingCompleted || manualShowOnboarding
                                if (shouldShowTour) {
                                    OnboardingCarouselDialog(
                                        onDismiss = {
                                            coroutineScope.launch {
                                                authManager.authPreferences.setOnboardingCompleted(true)
                                                manualShowOnboarding = false
                                            }
                                        },
                                        onComplete = {
                                            coroutineScope.launch {
                                                authManager.authPreferences.setOnboardingCompleted(true)
                                                manualShowOnboarding = false
                                            }
                                        }
                                    )
                                }
                            }
                        }
                        else -> {
                            LoginScreen(
                                authState = state,
                                initialRememberMe = rememberMePreference,
                                initialEmail = rememberedEmailPreference,
                                isBiometricAvailable = isBiometricAvailable,
                                onBiometricSignInClicked = {
                                    biometricHelper.authenticate(
                                        onSuccess = {
                                            authManager.signInWithBiometrics(
                                                savedEmail = rememberedEmailPreference.takeIf { it.isNotBlank() },
                                                scope = coroutineScope
                                            )
                                        },
                                        onError = { errorMsg ->
                                            // Handled via auth state error or snackbar
                                        }
                                    )
                                },
                                onGoogleSignInClicked = {
                                    authManager.signInWithGoogle(this@MainActivity, coroutineScope)
                                },
                                onEmailSignInClicked = { email, password, rememberMe ->
                                    authManager.signInWithEmail(email, password, rememberMe, coroutineScope)
                                },
                                onEmailSignUpClicked = { email, password, rememberMe ->
                                    authManager.signUpWithEmail(email, password, rememberMe, coroutineScope)
                                },
                                onPasswordResetClicked = { email, onResult ->
                                    authManager.resetPassword(
                                        email = email,
                                        scope = coroutineScope,
                                        onSent = {
                                            onResult(true, "Password reset instructions sent to $email. Please check your inbox.")
                                        },
                                        onError = { errorMsg ->
                                            onResult(false, errorMsg)
                                        }
                                    )
                                },
                                onGuestSignInClicked = {
                                    authManager.signInGuest(coroutineScope)
                                },
                                onClearError = {
                                    authManager.clearError()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SecureSyncGate(status: SyncStatus, onRetry: () -> Unit, onSignOut: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp),
            verticalArrangement = Arrangement.Center
        ) {
            if (status is SyncStatus.Error) {
                Icon(Icons.Filled.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(34.dp))
                Spacer(Modifier.height(18.dp))
                Text("Workspace sync blocked", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Text(status.message, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(22.dp))
                Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text("Try secure sync again") }
                TextButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) { Text("Sign out") }
            } else {
                CircularProgressIndicator()
                Spacer(Modifier.height(22.dp))
                Text("Opening your workspace", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(8.dp))
                Text("Verifying organization scope and refreshing authoritative data…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AccessPendingScreen(
    email: String,
    onSignOut: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = MaterialTheme.shapes.extraLarge
            ) {
                Icon(
                    imageVector = Icons.Filled.LockClock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(18.dp).size(32.dp)
                )
            }
            Spacer(Modifier.height(24.dp))
            Text("Workspace access pending", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(10.dp))
            Text(
                "Your account is signed in, but an organization administrator must assign your role before DigiTech data can be loaded.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (email.isNotBlank()) {
                Spacer(Modifier.height(18.dp))
                Text(email, style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(28.dp))
            OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) {
                Text("Sign out")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    viewModel: DigiTechViewModel,
    aiViewModel: AiAssistantViewModel,
    isDarkTheme: Boolean,
    syncFrequency: SyncFrequency = SyncFrequency.REALTIME,
    userProfile: UserProfileData = UserProfileData(),
    userEmail: String = "",
    onToggleTheme: () -> Unit,
    onUpdateSyncFrequency: (SyncFrequency) -> Unit = {},
    onOpenProfileSetup: () -> Unit,
    onOpenTour: () -> Unit,
    onSignOut: () -> Unit = {}
) {
    var currentDestination by remember { mutableStateOf(AppDestination.DASHBOARD) }
    var showCreateOrderDialog by remember { mutableStateOf(false) }
    var showAddCustomerDialog by remember { mutableStateOf(false) }

    val primaryDestinations = remember {
        listOf(
            AppDestination.DASHBOARD,
            AppDestination.ORDERS,
            AppDestination.AI_COPILOT,
            AppDestination.SUBSCRIPTIONS,
            AppDestination.OPERATIONS
        )
    }

    val metrics by viewModel.dashboardMetrics.collectAsState()

    // Dialogs
    if (showCreateOrderDialog) {
        CreateOrderDialog(
            viewModel = viewModel,
            onDismiss = { showCreateOrderDialog = false }
        )
    }

    if (showAddCustomerDialog) {
        AddCustomerDialog(
            viewModel = viewModel,
            onDismiss = { showAddCustomerDialog = false }
        )
    }

    Scaffold(
        bottomBar = {
            if (currentDestination != AppDestination.VOICE_MODE) {
                ExpressiveBottomBar(
                    currentDestination = currentDestination,
                    destinations = primaryDestinations,
                    badgeFor = { destination ->
                        when (destination) {
                            AppDestination.SUBSCRIPTIONS -> metrics.expiringSoonCount
                            AppDestination.OPERATIONS -> metrics.pendingActivationsCount
                            else -> 0
                        }
                    },
                    onSelect = { currentDestination = it }
                )
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentDestination,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            transitionSpec = {
                val direction = if (targetState.ordinal >= initialState.ordinal) 1 else -1
                (
                    fadeIn(
                        animationSpec = tween(
                            DigiTechMotion.Standard,
                            easing = DigiTechMotion.EmphasizedDecelerate
                        )
                    ) + slideInHorizontally(
                        animationSpec = tween(
                            DigiTechMotion.Standard,
                            easing = DigiTechMotion.EmphasizedDecelerate
                        ),
                        initialOffsetX = { direction * (it / 7) }
                    )
                ).togetherWith(
                    fadeOut(
                        animationSpec = tween(
                            DigiTechMotion.Quick,
                            easing = DigiTechMotion.EmphasizedAccelerate
                        )
                    ) + slideOutHorizontally(
                        animationSpec = tween(
                            DigiTechMotion.Quick,
                            easing = DigiTechMotion.EmphasizedAccelerate
                        ),
                        targetOffsetX = { -direction * (it / 9) }
                    )
                )
            },
            label = "PrimaryScreenTransition"
        ) { destination ->
            when (destination) {
                AppDestination.DASHBOARD -> DashboardScreen(
                    viewModel = viewModel,
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = onToggleTheme,
                    onOpenProfile = onOpenProfileSetup,
                    onOpenTour = onOpenTour,
                    onNavigateToOrders = { currentDestination = AppDestination.ORDERS },
                    onNavigateToSubscriptions = { currentDestination = AppDestination.SUBSCRIPTIONS },
                    onNavigateToActivations = { currentDestination = AppDestination.ACTIVATIONS },
                    onNavigateToCustomers = { currentDestination = AppDestination.CUSTOMERS },
                    onOpenCreateOrder = { showCreateOrderDialog = true },
                    onOpenAddCustomer = { showAddCustomerDialog = true },
                    onNavigateToAiCopilot = { currentDestination = AppDestination.AI_COPILOT },
                    onNavigateToVoiceMode = { currentDestination = AppDestination.VOICE_MODE }
                )
                AppDestination.AI_COPILOT -> GeminiChatScreen(
                    viewModel = aiViewModel,
                    onOpenVoiceMode = { currentDestination = AppDestination.VOICE_MODE }
                )
                AppDestination.VOICE_MODE -> VoiceConversationScreen(
                    viewModel = aiViewModel,
                    onBackToChat = { currentDestination = AppDestination.AI_COPILOT }
                )
                AppDestination.ORDERS -> OrdersScreen(
                    viewModel = viewModel,
                    onOpenCreateOrder = { showCreateOrderDialog = true }
                )
                AppDestination.SUBSCRIPTIONS -> SubscriptionsScreen(
                    viewModel = viewModel
                )
                AppDestination.ACTIVATIONS -> ActivationsScreen(
                    viewModel = viewModel
                )
                AppDestination.CUSTOMERS -> CustomersScreen(
                    viewModel = viewModel,
                    onOpenAddCustomer = { showAddCustomerDialog = true }
                )
                AppDestination.PRODUCTS -> ProductsScreen(
                    viewModel = viewModel
                )
                AppDestination.FINANCE -> FinanceScreen(
                    viewModel = viewModel
                )
                AppDestination.OPERATIONS -> OperationsScreen(
                    viewModel = viewModel,
                    isDarkTheme = isDarkTheme,
                    syncFrequency = syncFrequency,
                    userProfile = userProfile,
                    userEmail = userEmail,
                    onToggleTheme = onToggleTheme,
                    onUpdateSyncFrequency = onUpdateSyncFrequency,
                    onOpenProfile = onOpenProfileSetup,
                    onOpenTour = onOpenTour,
                    onNavigateToProducts = { currentDestination = AppDestination.PRODUCTS },
                    onNavigateToFinance = { currentDestination = AppDestination.FINANCE },
                    onNavigateToAiCopilot = { currentDestination = AppDestination.AI_COPILOT },
                    onNavigateToVoiceMode = { currentDestination = AppDestination.VOICE_MODE },
                    onSignOut = onSignOut
                )
            }
        }
    }
}
