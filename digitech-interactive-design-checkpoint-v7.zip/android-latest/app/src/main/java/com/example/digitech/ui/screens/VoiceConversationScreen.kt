package com.example.digitech.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.digitech.data.gemini.AiRole
import com.example.digitech.data.gemini.GeminiModels
import com.example.digitech.data.gemini.VoiceState
import com.example.digitech.ui.theme.*
import com.example.digitech.ui.viewmodel.AiAssistantViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceConversationScreen(
    viewModel: AiAssistantViewModel,
    onBackToChat: () -> Unit = {}
) {
    val context = LocalContext.current
    val voiceManager = viewModel.voiceManager

    val voiceState by voiceManager.voiceState.collectAsState()
    val audioAmplitude by voiceManager.audioAmplitude.collectAsState()
    val recognizedText by voiceManager.recognizedText.collectAsState()
    val history by voiceManager.conversationHistory.collectAsState()
    val selectedRole by viewModel.selectedRole.collectAsState()

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasAudioPermission = isGranted
        if (isGranted) {
            voiceManager.startListening()
        }
    }

    // Pulsing animation for active speech
    val infiniteTransition = rememberInfiniteTransition(label = "VoicePulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (voiceState is VoiceState.Listening || voiceState is VoiceState.Speaking) 1.25f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Gemini Live Voice", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = BrandPrimary.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "Live API",
                                    color = BrandPrimaryLight,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = GeminiModels.GEMINI_3_1_FLASH_LIVE,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        voiceManager.stopSpeaking()
                        voiceManager.stopListening()
                        onBackToChat()
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back to Chat")
                    }
                },
                actions = {
                    // Mute / Speaker output toggle
                    IconButton(onClick = {
                        voiceManager.isMuted = !voiceManager.isMuted
                        if (voiceManager.isMuted) voiceManager.stopSpeaking()
                    }) {
                        Icon(
                            imageVector = if (voiceManager.isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                            contentDescription = "Toggle Mute",
                            tint = if (voiceManager.isMuted) StatusDanger else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Clear transcript
                    IconButton(onClick = { voiceManager.clearHistory() }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Clear conversation")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surface,
                            DarkBackground
                        )
                    )
                )
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Role selection dropdown banner
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Active Voice Persona", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(selectedRole.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        AiRole.values().forEach { role ->
                            IconButton(
                                onClick = { viewModel.setRole(role) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = when (role) {
                                        AiRole.BUSINESS_COPILOT -> Icons.Default.BusinessCenter
                                        AiRole.FINANCIAL_ANALYST -> Icons.Default.TrendingUp
                                        AiRole.SUPPORT_MESSAGING -> Icons.Default.ChatBubble
                                        AiRole.LICENSE_OPERATIONS -> Icons.Default.Key
                                    },
                                    contentDescription = role.title,
                                    tint = if (selectedRole == role) BrandPrimary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Central Glowing Voice Orb & Audio Waveform Visualizer
            Box(
                modifier = Modifier
                    .size(190.dp)
                    .scale(pulseScale),
                contentAlignment = Alignment.Center
            ) {
                // Outer Aura
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = when (voiceState) {
                                    is VoiceState.Listening -> listOf(BrandPrimary.copy(alpha = 0.4f), Color.Transparent)
                                    is VoiceState.Speaking -> listOf(BrandAccent.copy(alpha = 0.45f), Color.Transparent)
                                    is VoiceState.Processing -> listOf(StatusWarning.copy(alpha = 0.35f), Color.Transparent)
                                    else -> listOf(BrandPrimary.copy(alpha = 0.15f), Color.Transparent)
                                }
                            )
                        )
                )

                // Inner Main Sphere
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = when (voiceState) {
                                    is VoiceState.Listening -> listOf(BrandPrimary, BrandPrimaryLight)
                                    is VoiceState.Speaking -> listOf(BrandAccentDark, BrandAccentLight)
                                    is VoiceState.Processing -> listOf(StatusWarning, StatusPurple)
                                    else -> listOf(DarkSurfaceContainerHigh, BrandPrimaryDark)
                                }
                            )
                        )
                        .clickable {
                            if (!hasAudioPermission) {
                                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            } else {
                                if (voiceState is VoiceState.Listening) {
                                    voiceManager.stopListening()
                                } else {
                                    voiceManager.startListening()
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (voiceState) {
                            is VoiceState.Listening -> Icons.Default.Mic
                            is VoiceState.Speaking -> Icons.Default.GraphicEq
                            is VoiceState.Processing -> Icons.Default.Psychology
                            else -> Icons.Default.MicNone
                        },
                        contentDescription = "Voice Action",
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Audio Wave Amplitude Bars
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.height(28.dp)
            ) {
                val barCount = 7
                for (i in 0 until barCount) {
                    val factor = when (i) {
                        0, 6 -> 0.3f
                        1, 5 -> 0.6f
                        2, 4 -> 0.85f
                        else -> 1f
                    }
                    val height = if (voiceState is VoiceState.Listening || voiceState is VoiceState.Speaking) {
                        (8.dp + (20.dp * audioAmplitude.coerceIn(0.1f, 1f) * factor))
                    } else 4.dp

                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(height)
                            .clip(RoundedCornerShape(2.dp))
                            .background(
                                if (voiceState is VoiceState.Speaking) BrandAccent else BrandPrimary
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Status message
            Text(
                text = when (val state = voiceState) {
                    is VoiceState.Listening -> "Listening... Speak naturally"
                    is VoiceState.Processing -> "Gemini is reasoning & generating response..."
                    is VoiceState.Speaking -> "Gemini speaking live..."
                    is VoiceState.Error -> "⚠️ ${state.message}"
                    else -> "Tap the orb to start talking"
                },
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = when (voiceState) {
                    is VoiceState.Listening -> BrandPrimaryLight
                    is VoiceState.Speaking -> BrandAccentLight
                    is VoiceState.Processing -> StatusWarning
                    is VoiceState.Error -> StatusDanger
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                },
                textAlign = TextAlign.Center
            )

            if (recognizedText.isNotBlank() && voiceState is VoiceState.Listening) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "\"$recognizedText\"",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Conversation History Transcript
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (history.isEmpty()) {
                    item {
                        Text(
                            text = "Live conversation transcript will appear here. Ask about your inventory, orders, revenue, or customer replies.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp)
                        )
                    }
                } else {
                    items(history) { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (msg.role == "user") BrandPrimary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.widthIn(max = 280.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = if (msg.role == "user") "You (Voice)" else "Gemini Live",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (msg.role == "user") BrandPrimaryLight else BrandAccentLight
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = msg.content,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom Voice Action Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Hands-Free Mode Toggle
                FilterChip(
                    selected = voiceManager.isHandsFreeMode,
                    onClick = { voiceManager.isHandsFreeMode = !voiceManager.isHandsFreeMode },
                    label = { Text("Continuous Mode", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = if (voiceManager.isHandsFreeMode) Icons.Default.Autorenew else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                )

                // Push to Talk / Toggle Button
                Button(
                    onClick = {
                        if (!hasAudioPermission) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            if (voiceState is VoiceState.Listening) {
                                voiceManager.stopListening()
                            } else {
                                voiceManager.startListening()
                            }
                        }
                    },
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (voiceState is VoiceState.Listening) StatusDanger else BrandPrimary
                    ),
                    modifier = Modifier.testTag("voice_talk_button")
                ) {
                    Icon(
                        imageVector = if (voiceState is VoiceState.Listening) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (voiceState is VoiceState.Listening) "Stop Listening" else "Tap to Speak")
                }
            }
        }
    }
}
