package com.example.digitech.ui.theme

import androidx.compose.ui.graphics.Color

// Midnight Ledger: calm operations surfaces with a precise mint signal.
val BrandPrimary = Color(0xFF18D8A0)
val BrandPrimaryDark = Color(0xFF087E60)
val BrandPrimaryLight = Color(0xFF75F2CE)
val BrandPrimaryContainerDark = Color(0xFF123E34)
val BrandPrimaryContainerLight = Color(0xFFD8F8EE)

val BrandSecondary = Color(0xFF4F7CFF)
val BrandSecondaryDark = Color(0xFF3159C9)
val BrandSecondaryLight = Color(0xFF9AB4FF)
val BrandSecondaryContainerDark = Color(0xFF1A2B55)
val BrandSecondaryContainerLight = Color(0xFFE1E9FF)

val BrandAccent = Color(0xFFF5A524)
val BrandAccentDark = Color(0xFFAA6500)
val BrandAccentLight = Color(0xFFFFD78A)
val BrandAccentContainerDark = Color(0xFF4A310F)
val BrandAccentContainerLight = Color(0xFFFFEFD0)

// Dark Theme Surfaces & Backgrounds
val DarkBackground = Color(0xFF090D0C)
val DarkSurface = Color(0xFF101615)
val DarkSurfaceVariant = Color(0xFF19211F)
val DarkSurfaceContainer = Color(0xFF141C1A)
val DarkSurfaceContainerHigh = Color(0xFF202A27)
val DarkBorder = Color(0xFF34413D)
val DarkBorderSubtle = Color(0xFF222D2A)

// Light Theme Surfaces & Backgrounds
val LightBackground = Color(0xFFF4F7F5)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEDF2EF)
val LightSurfaceContainer = Color(0xFFF7FAF8)
val LightSurfaceContainerHigh = Color(0xFFE4ECE8)
val LightBorder = Color(0xFFD7E1DC)
val LightBorderSubtle = Color(0xFFE9EFEC)

// Semantic Status Indicators
val StatusSuccess = Color(0xFF10B981)        // Emerald 500
val StatusSuccessContainer = Color(0xFFD1FAE5)
val StatusWarning = Color(0xFFF59E0B)        // Amber 500
val StatusWarningContainer = Color(0xFFFEF3C7)
val StatusDanger = Color(0xFFEF4444)         // Rose 500
val StatusDangerDark = Color(0xFFB91C1C)     // Rose 700
val StatusDangerContainerDark = Color(0xFF450A0A)
val StatusDangerContainerLight = Color(0xFFFEE2E2)
val StatusInfo = Color(0xFF3B82F6)           // Blue 500
val StatusInfoContainer = Color(0xFFDBEAFE)
val StatusPurple = Color(0xFF8B5CF6)         // Violet 500

// Text & Content Contrast Colors
val TextPrimaryDark = Color(0xFFF9FAFB)
val TextSecondaryDark = Color(0xFF9CA3AF)
val TextTertiaryDark = Color(0xFF6B7280)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)
val TextTertiaryLight = Color(0xFF94A3B8)
