package com.example.digitech.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.AppDestination
import com.example.digitech.ui.theme.BrandAccent
import com.example.digitech.ui.theme.BrandPrimary
import com.example.digitech.ui.theme.BrandSecondary

/**
 * Thumb-friendly navigation with a distinctive raised Copilot action.
 * Motion is limited to selection and press feedback so repeated use remains calm.
 */
@Composable
fun ExpressiveBottomBar(
    currentDestination: AppDestination,
    destinations: List<AppDestination>,
    badgeFor: (AppDestination) -> Int,
    onSelect: (AppDestination) -> Unit
) {
    val haptics = LocalHapticFeedback.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        shadowElevation = 18.dp,
        tonalElevation = 4.dp,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(78.dp)
                .padding(horizontal = 8.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            destinations.forEach { destination ->
                val selected = currentDestination == destination
                val isCopilot = destination == AppDestination.AI_COPILOT
                val interactionSource = remember(destination) { MutableInteractionSource() }
                val isPressed by interactionSource.collectIsPressedAsState()
                val scale by animateFloatAsState(
                    targetValue = if (isPressed) 0.92f else if (selected) 1.05f else 1f,
                    animationSpec = spring(dampingRatio = 0.72f, stiffness = 520f),
                    label = "navScale"
                )
                val foreground by animateColorAsState(
                    targetValue = if (selected) BrandPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    label = "navForeground"
                )
                val indicatorWidth by animateDpAsState(
                    targetValue = if (selected && !isCopilot) 43.dp else 36.dp,
                    animationSpec = spring(dampingRatio = 0.78f, stiffness = 500f),
                    label = "navIndicator"
                )
                val badgeCount = badgeFor(destination)

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null,
                            role = Role.Tab
                        ) {
                            if (!selected) {
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onSelect(destination)
                            }
                        }
                        .semantics { this.selected = selected }
                        .padding(vertical = 2.dp)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    BadgedBox(
                        badge = {
                            if (badgeCount > 0) {
                                Badge(containerColor = BrandAccent, contentColor = Color(0xFF251600)) {
                                    Text(
                                        text = if (badgeCount > 99) "99+" else badgeCount.toString(),
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    ) {
                        if (isCopilot) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .shadow(12.dp, CircleShape)
                                    .background(
                                        brush = Brush.linearGradient(
                                            listOf(BrandPrimary, BrandSecondary, BrandAccent)
                                        ),
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                                    contentDescription = destination.title,
                                    tint = Color.White,
                                    modifier = Modifier.size(23.dp)
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .width(indicatorWidth)
                                    .height(34.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (selected) BrandPrimary.copy(alpha = 0.14f)
                                        else Color.Transparent
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                                    contentDescription = destination.title,
                                    tint = foreground,
                                    modifier = Modifier.size(21.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(if (isCopilot) 1.dp else 3.dp))

                    Text(
                        text = if (isCopilot) "Copilot" else destination.title,
                        color = if (isCopilot) {
                            if (selected) BrandPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        } else foreground,
                        fontSize = 10.sp,
                        fontWeight = if (selected || isCopilot) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        modifier = Modifier.widthIn(max = 76.dp)
                    )
                }
            }
        }
    }
}
