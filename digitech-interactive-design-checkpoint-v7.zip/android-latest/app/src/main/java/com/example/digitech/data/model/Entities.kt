package com.example.digitech.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val customerCode: String,
    val name: String,
    val email: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val company: String = "",
    val city: String = "",
    val state: String = "",
    val status: String = "active", // lead, active, vip, inactive, lost
    val source: String = "Direct",
    val notes: String = "",
    val tags: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val category: String,
    val brand: String = "",
    val description: String = "",
    val productType: String = "subscription", // subscription, license, digital_product, service
    val deliveryType: String = "email_activation", // email_activation, account_activation, license_key, invite_link, manual
    val durationDays: Int = 365,
    val costPrice: Double,
    val sellingPrice: Double,
    val stock: Int? = null,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String,
    val orderNumber: String,
    val customerId: String,
    val customerName: String,
    val productId: String,
    val productName: String,
    val quantity: Int = 1,
    val unitPrice: Double,
    val unitCost: Double,
    val discount: Double = 0.0,
    val total: Double,
    val totalCost: Double,
    val profit: Double,
    val status: String = "new", // new, processing, activated, completed, cancelled
    val paymentStatus: String = "paid", // paid, partial, pending, refunded
    val paymentMethod: String = "upi", // upi, bank_transfer, cash, credit_card, wallet
    val amountPaid: Double,
    val orderedAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Serializable
@Entity(tableName = "subscriptions")
data class SubscriptionEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val customerName: String,
    val customerPhone: String = "",
    val productId: String,
    val productName: String,
    val orderId: String = "",
    val startDate: Long,
    val expiryDate: Long,
    val durationDays: Int,
    val purchaseAmount: Double,
    val costAmount: Double,
    val profit: Double,
    val status: String = "active", // active, expiring, expired, renewed, cancelled
    val reminderState: String = "none", // none, contacted, interested, follow_up, not_interested, lost
    val lastContactedAt: Long? = null,
    val notes: String = ""
)

@Serializable
@Entity(tableName = "activations")
data class ActivationEntity(
    @PrimaryKey val id: String,
    val orderId: String,
    val orderNumber: String,
    val customerId: String,
    val customerName: String,
    val customerPhone: String = "",
    val productName: String,
    val deliveryType: String = "email_activation",
    val status: String = "ready", // waiting_payment, ready, processing, waiting_supplier, activated, delivered, failed
    val priority: String = "medium", // low, medium, high, urgent
    val activationDetails: String = "",
    val instructions: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val activatedAt: Long? = null
)

@Serializable
@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey val id: String,
    val category: String, // software, supplier, salary, office, internet, tools, miscellaneous
    val description: String,
    val amount: Double,
    val vendor: String = "",
    val spentAt: Long = System.currentTimeMillis(),
    val paymentMethod: String = "upi",
    val isRecurring: Boolean = false
)

@Serializable
@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey val id: String,
    val name: String,
    val contactPerson: String = "",
    val email: String = "",
    val phone: String = "",
    val website: String = "",
    val paymentTerms: String = "Prepaid", // Prepaid, Net 15, Net 30
    val isActive: Boolean = true
)

@Serializable
@Entity(tableName = "leads")
data class LeadEntity(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String = "",
    val email: String = "",
    val company: String = "",
    val source: String = "Instagram",
    val interestedProduct: String = "",
    val estimatedValue: Double = 0.0,
    val probability: Int = 50,
    val status: String = "new", // new, contacted, qualified, interested, negotiation, won, lost
    val followUpAt: Long? = null,
    val notes: String = ""
)

@Serializable
@Entity(tableName = "support_tickets")
data class SupportTicketEntity(
    @PrimaryKey val id: String,
    val ticketNumber: String,
    val customerName: String,
    val customerPhone: String = "",
    val subject: String,
    val description: String = "",
    val category: String = "Account Issue",
    val priority: String = "medium", // low, medium, high, urgent
    val status: String = "open", // open, in_progress, waiting_customer, resolved, closed
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String = "",
    val priority: String = "medium", // low, medium, high, urgent
    val status: String = "open", // open, in_progress, done
    val dueAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "activity_logs")
data class ActivityLogEntity(
    @PrimaryKey val id: String,
    val actionType: String, // PROFILE_UPDATE, THEME_CHANGE, SYNC_FREQUENCY_CHANGE, ORDER_CREATED, SUBSCRIPTION_RENEWAL, ACTIVATION_DELIVERED, DATA_EXPORT, MANUAL_SYNC
    val title: String,
    val description: String,
    val actorEmail: String = "",
    val role: String = "no_access",
    val timestamp: Long = System.currentTimeMillis(),
    val metadata: String = ""
)
