package com.example.digitech.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.data.model.*
import com.example.digitech.ui.components.*
import com.example.digitech.ui.theme.*
import com.example.digitech.ui.viewmodel.DigiTechViewModel
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomersScreen(
    viewModel: DigiTechViewModel,
    onOpenAddCustomer: () -> Unit
) {
    val context = LocalContext.current
    val customers by viewModel.customers.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val subscriptions by viewModel.subscriptions.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }
    var selectedCustomerForDetail by remember { mutableStateOf<CustomerEntity?>(null) }
    var editingCustomer by remember { mutableStateOf<CustomerEntity?>(null) }

    val filterOptions = listOf("All", "VIP", "Active", "Lead")

    val filteredCustomers = remember(customers, selectedFilter, searchQuery) {
        customers.filter { customer ->
            val matchesFilter = when (selectedFilter) {
                "All" -> true
                else -> customer.status.equals(selectedFilter, ignoreCase = true)
            }
            val matchesSearch = searchQuery.isBlank() ||
                    customer.name.contains(searchQuery, ignoreCase = true) ||
                    customer.phone.contains(searchQuery, ignoreCase = true) ||
                    customer.company.contains(searchQuery, ignoreCase = true) ||
                    customer.city.contains(searchQuery, ignoreCase = true) ||
                    customer.tags.contains(searchQuery, ignoreCase = true)

            matchesFilter && matchesSearch
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Customer Directory & CRM", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onOpenAddCustomer) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "Add Customer", tint = BrandPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onOpenAddCustomer,
                containerColor = BrandPrimary,
                contentColor = TextPrimaryDark
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add Customer")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search by name, phone, city, company...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Tabs
            ScrollableTabRow(
                selectedTabIndex = filterOptions.indexOf(selectedFilter).coerceAtLeast(0),
                edgePadding = 0.dp,
                containerColor = MaterialTheme.colorScheme.background,
                divider = {}
            ) {
                filterOptions.forEach { filter ->
                    Tab(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        text = {
                            Text(
                                text = filter,
                                fontWeight = if (selectedFilter == filter) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredCustomers.isEmpty()) {
                EmptyStateView(
                    title = "No customers found",
                    message = "Add a new customer to start recording orders and subscriptions.",
                    icon = Icons.Default.PeopleOutline
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(filteredCustomers, key = { it.id }) { customer ->
                        val customerOrders = orders.filter { it.customerId == customer.id }
                        val customerTotalSpent = customerOrders.sumOf { it.total }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedCustomerForDetail = customer },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Avatar circle
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(if (customer.status == "vip") StatusPurple.copy(alpha = 0.2f) else BrandPrimary.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = customer.name.take(2).uppercase(),
                                        fontWeight = FontWeight.Bold,
                                        color = if (customer.status == "vip") StatusPurple else BrandPrimary,
                                        fontSize = 16.sp
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = customer.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        StatusBadge(status = customer.status)
                                    }

                                    if (customer.company.isNotBlank()) {
                                        Text(
                                            text = customer.company + if (customer.city.isNotBlank()) " • ${customer.city}" else "",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Text(
                                        text = "${customerOrders.size} Orders • ${Formatters.formatCurrency(customerTotalSpent)} spent",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = StatusSuccess
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    if (customer.phone.isNotBlank()) {
                                        IconButton(onClick = { ActionHelpers.dialPhone(context, customer.phone) }) {
                                            Icon(Icons.Default.Phone, contentDescription = "Call", tint = BrandPrimary)
                                        }
                                    }
                                    val wa = customer.whatsapp.ifEmpty { customer.phone }
                                    if (wa.isNotBlank()) {
                                        IconButton(onClick = { ActionHelpers.openWhatsApp(context, wa, "Hi ${customer.name}, greeting from DigiTech!") }) {
                                            Icon(Icons.Default.Chat, contentDescription = "WhatsApp", tint = StatusSuccess)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Customer Detail Sheet
    if (selectedCustomerForDetail != null) {
        val cust = selectedCustomerForDetail!!
        val customerOrders = orders.filter { it.customerId == cust.id }
        val customerSubs = subscriptions.filter { it.customerId == cust.id }

        AlertDialog(
            onDismissRequest = { selectedCustomerForDetail = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(cust.name, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusBadge(status = cust.status)
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text("Code: ${cust.customerCode} • Source: ${cust.source}")
                        if (cust.company.isNotBlank()) Text("Company: ${cust.company}")
                        if (cust.phone.isNotBlank()) Text("Phone: ${cust.phone}")
                        if (cust.email.isNotBlank()) Text("Email: ${cust.email}")
                        if (cust.city.isNotBlank()) Text("Location: ${cust.city}, ${cust.state}")
                        if (cust.tags.isNotBlank()) Text("Tags: ${cust.tags}", color = BrandPrimary, fontSize = 12.sp)
                        if (cust.notes.isNotBlank()) Text("Notes: ${cust.notes}", fontSize = 12.sp)

                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                        Text("Subscriptions (${customerSubs.size})", fontWeight = FontWeight.Bold)
                    }

                    items(customerSubs) { sub ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(sub.productName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("Expiry: ${Formatters.formatDate(sub.expiryDate)}", fontSize = 11.sp)
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Recent Orders (${customerOrders.size})", fontWeight = FontWeight.Bold)
                    }

                    items(customerOrders.take(3)) { ord ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(8.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("${ord.orderNumber} • ${ord.productName}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                    Text(Formatters.formatDate(ord.orderedAt), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(Formatters.formatCurrency(ord.total), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    editingCustomer = cust
                    selectedCustomerForDetail = null
                }) {
                    Text("Edit")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedCustomerForDetail = null }) {
                    Text("Close")
                }
            }
        )
    }

    // Edit Customer Modal
    if (editingCustomer != null) {
        val cust = editingCustomer!!
        var name by remember { mutableStateOf(cust.name) }
        var phone by remember { mutableStateOf(cust.phone) }
        var email by remember { mutableStateOf(cust.email) }
        var company by remember { mutableStateOf(cust.company) }
        var city by remember { mutableStateOf(cust.city) }
        var status by remember { mutableStateOf(cust.status) }
        var notes by remember { mutableStateOf(cust.notes) }

        AlertDialog(
            onDismissRequest = { editingCustomer = null },
            title = { Text("Edit Customer Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name *") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone / WhatsApp") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = company, onValueChange = { company = it }, label = { Text("Company Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.saveCustomer(
                        cust.copy(
                            name = name,
                            phone = phone,
                            whatsapp = phone,
                            email = email,
                            company = company,
                            city = city,
                            status = status,
                            notes = notes,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    editingCustomer = null
                }) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingCustomer = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
