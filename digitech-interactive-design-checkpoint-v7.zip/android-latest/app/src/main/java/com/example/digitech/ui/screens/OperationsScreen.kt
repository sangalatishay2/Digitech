package com.example.digitech.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.auth.SyncFrequency
import com.example.digitech.auth.UserProfileData
import com.example.digitech.data.sync.SyncStatus
import com.example.digitech.data.model.*
import com.example.digitech.ui.components.*
import com.example.digitech.ui.theme.*
import com.example.digitech.ui.viewmodel.DigiTechViewModel
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperationsScreen(
    viewModel: DigiTechViewModel,
    isDarkTheme: Boolean = true,
    syncFrequency: SyncFrequency = SyncFrequency.REALTIME,
    userProfile: UserProfileData = UserProfileData(),
    userEmail: String = "",
    onToggleTheme: () -> Unit = {},
    onUpdateSyncFrequency: (SyncFrequency) -> Unit = {},
    onOpenProfile: () -> Unit = {},
    onOpenTour: () -> Unit = {},
    onNavigateToProducts: () -> Unit = {},
    onNavigateToFinance: () -> Unit = {},
    onNavigateToAiCopilot: () -> Unit = {},
    onNavigateToVoiceMode: () -> Unit = {},
    onSignOut: () -> Unit = {}
) {
    val context = LocalContext.current
    val tickets by viewModel.tickets.collectAsState()
    val leads by viewModel.leads.collectAsState()
    val suppliers by viewModel.suppliers.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val activityLogs by viewModel.activityLogs.collectAsState()
    val syncStatus by viewModel.syncStatus.collectAsState()

    var showSignOutConfirmDialog by remember { mutableStateOf(false) }

    var selectedSection by remember { mutableStateOf("Support Tickets") }
    val sections = listOf("Support Tickets", "CRM Leads", "Suppliers", "Tasks & Daily", "Settings & Audit")

    var showAddTicketDialog by remember { mutableStateOf(false) }
    var showAddLeadDialog by remember { mutableStateOf(false) }
    var showAddSupplierDialog by remember { mutableStateOf(false) }
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Operations & CRM Hub", fontWeight = FontWeight.Bold) },
                actions = {
                    SyncStatusBadge(
                        syncStatus = syncStatus,
                        showLabel = false,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    IconButton(onClick = onNavigateToProducts) {
                        Icon(Icons.Default.Inventory2, contentDescription = "Catalog", tint = BrandPrimary)
                    }
                    IconButton(onClick = onNavigateToFinance) {
                        Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Finance", tint = StatusSuccess)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Section Tab Selector
            ScrollableTabRow(
                selectedTabIndex = sections.indexOf(selectedSection).coerceAtLeast(0),
                edgePadding = 0.dp,
                containerColor = MaterialTheme.colorScheme.background,
                divider = {}
            ) {
                sections.forEach { section ->
                    Tab(
                        selected = selectedSection == section,
                        onClick = { selectedSection = section },
                        text = {
                            Text(
                                text = section,
                                fontWeight = if (selectedSection == section) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (selectedSection) {
                "Support Tickets" -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Active Support Issues (${tickets.size})", fontWeight = FontWeight.SemiBold)
                        Button(
                            onClick = { showAddTicketDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Ticket", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (tickets.isEmpty()) {
                        EmptyStateView(
                            title = "No support tickets",
                            message = "Everything is running smoothly! Log any key replacement or login issue here.",
                            icon = Icons.Default.SupportAgent
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 96.dp)
                        ) {
                            items(tickets, key = { it.id }) { ticket ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(ticket.subject, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                StatusBadge(status = ticket.priority)
                                                StatusBadge(status = ticket.status)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Customer: ${ticket.customerName} • ${ticket.category}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(ticket.description, fontSize = 13.sp)

                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            if (ticket.status != "resolved") {
                                                Button(
                                                    onClick = {
                                                        viewModel.saveTicket(ticket.copy(status = "resolved"))
                                                    },
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(30.dp)
                                                ) {
                                                    Text("Mark Resolved", fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "CRM Leads" -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Sales Pipeline (${leads.size})", fontWeight = FontWeight.SemiBold)
                        Button(
                            onClick = { showAddLeadDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Lead", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (leads.isEmpty()) {
                        EmptyStateView(
                            title = "No leads in pipeline",
                            message = "Capture prospective buyers from WhatsApp, Telegram, or referrals.",
                            icon = Icons.Default.FilterAlt
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 96.dp)
                        ) {
                            items(leads, key = { it.id }) { lead ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(lead.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                            StatusBadge(status = lead.status)
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Interested in: ${lead.interestedProduct}", fontSize = 13.sp, color = BrandPrimary, fontWeight = FontWeight.Medium)
                                        Text("Source: ${lead.source.uppercase()} • Value: ${Formatters.formatCurrency(lead.estimatedValue)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        if (lead.notes.isNotBlank()) {
                                            Text("Notes: ${lead.notes}", fontSize = 12.sp)
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(
                                                onClick = {
                                                    val msg = "Hi ${lead.name}, saw you were interested in ${lead.interestedProduct}! We currently have an exclusive discount. Would you like a demo?"
                                                    ActionHelpers.openWhatsApp(context, lead.phone, msg)
                                                }
                                            ) {
                                                Icon(Icons.Default.Chat, contentDescription = "WhatsApp", tint = StatusSuccess)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "Suppliers" -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("License Vendors & Suppliers (${suppliers.size})", fontWeight = FontWeight.SemiBold)
                        Button(
                            onClick = { showAddSupplierDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Vendor", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 96.dp)
                    ) {
                        items(suppliers, key = { it.id }) { supplier ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(supplier.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        Text(supplier.paymentTerms, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = BrandPrimary)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Contact: ${supplier.contactPerson} • ${supplier.phone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    if (supplier.website.isNotBlank()) {
                                        Text("Website: ${supplier.website}", fontSize = 12.sp, color = BrandPrimary)
                                    }
                                }
                            }
                        }
                    }
                }

                "Tasks & Tools" -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 96.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Daily Checklist & Reminders", fontWeight = FontWeight.SemiBold)
                                Button(
                                    onClick = { showAddTaskDialog = true },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Task", fontSize = 12.sp)
                                }
                            }
                        }

                        items(tasks, key = { it.id }) { task ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.toggleTask(task) },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(12.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = task.status == "done",
                                        onCheckedChange = { viewModel.toggleTask(task) }
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = task.title,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 14.sp
                                        )
                                        if (task.description.isNotBlank()) {
                                            Text(
                                                text = task.description,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    StatusBadge(status = task.priority)
                                }
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Gemini AI Intelligence & Voice", fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(8.dp))

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onNavigateToAiCopilot() },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(BrandPrimary.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = BrandPrimary)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Gemini Chat Assistant", fontWeight = FontWeight.Bold)
                                        Text("Multi-turn strategic business chat with 3.5 Flash, 3.1 Pro & 3.1 Lite", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onNavigateToVoiceMode() },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(BrandAccent.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.GraphicEq, contentDescription = null, tint = BrandAccent)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Live Voice Conversations", fontWeight = FontWeight.Bold)
                                        Text("Hands-free real-time voice mode with gemini-3.1-flash-live-preview", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Database Management", fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(8.dp))

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Reset Sample Business Data", fontWeight = FontWeight.Bold)
                                    Text(
                                        "Restore realistic initial sample data with 12+ subscriptions, verified orders, activations queue, and customer records.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    OutlinedButton(
                                        onClick = { showResetConfirmDialog = true },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger)
                                    ) {
                                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Restore Default Seed Data")
                                    }
                                }
                            }
                        }
                    }
                }

                "Settings & Audit" -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(bottom = 96.dp)
                    ) {
                        // User Profile & Role Card
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().testTag("user_profile_card"),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(46.dp)
                                                    .clip(CircleShape)
                                                    .background(BrandPrimary.copy(alpha = 0.15f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.ManageAccounts,
                                                    contentDescription = null,
                                                    tint = BrandPrimary,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(
                                                    text = userProfile.name.ifBlank { "DigiTech User" },
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 16.sp
                                                )
                                                Text(
                                                    text = "${userProfile.rolePreference} • ${userEmail.ifBlank { "Signed-in account" }}",
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        OutlinedButton(
                                            onClick = onOpenProfile,
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("Edit Profile", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }

                        // Sync Frequency & Battery Saver Setting
                        item {
                            Text("Cloud Sync & Battery Optimization", fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("Sync Frequency", fontWeight = FontWeight.Bold)
                                            Text(
                                                "Adjust organization refresh frequency",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        SyncStatusBadge(syncStatus = syncStatus, showLabel = true)
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    val syncOptions = listOf(
                                        Triple(
                                            SyncFrequency.REALTIME,
                                            "⚡ Real-Time (Continuous)",
                                            "Live organization records protected by Supabase RLS."
                                        ),
                                        Triple(
                                            SyncFrequency.PERIODIC_15MIN,
                                            "⏱️ Balanced (Every 15 mins)",
                                            "Background sync every 15 minutes. Great battery balance."
                                        ),
                                        Triple(
                                            SyncFrequency.PERIODIC_1HR,
                                            "🔋 Battery Saver (Every 1 hour)",
                                            "Background sync hourly. Maximizes device battery life."
                                        ),
                                        Triple(
                                            SyncFrequency.MANUAL_ONLY,
                                            "🔒 Manual Refresh Only",
                                            "Only syncs on pull-to-refresh or explicit manual triggers."
                                        )
                                    )

                                    syncOptions.forEach { (option, title, desc) ->
                                        val isSelected = syncFrequency == option
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .clickable {
                                                    onUpdateSyncFrequency(option)
                                                    viewModel.logActivity(
                                                        actionType = "SYNC_FREQUENCY_CHANGE",
                                                        title = "Sync Frequency Updated",
                                                        description = "Sync frequency changed to $title",
                                                        actorEmail = userEmail,
                                                        role = userProfile.rolePreference
                                                    )
                                                }
                                                .border(
                                                    width = if (isSelected) 1.5.dp else 1.dp,
                                                    color = if (isSelected) BrandPrimary else MaterialTheme.colorScheme.outlineVariant,
                                                    shape = RoundedCornerShape(8.dp)
                                                ),
                                            color = if (isSelected) BrandPrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                RadioButton(
                                                    selected = isSelected,
                                                    onClick = {
                                                        onUpdateSyncFrequency(option)
                                                        viewModel.logActivity(
                                                            actionType = "SYNC_FREQUENCY_CHANGE",
                                                            title = "Sync Frequency Updated",
                                                            description = "Sync frequency changed to $title",
                                                            actorEmail = userEmail,
                                                            role = userProfile.rolePreference
                                                        )
                                                    },
                                                    colors = RadioButtonDefaults.colors(selectedColor = BrandPrimary)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = title,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                        fontSize = 13.sp,
                                                        color = if (isSelected) BrandPrimary else MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Text(
                                                        text = desc,
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            viewModel.forceManualSync()
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary)
                                    ) {
                                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Force Manual Sync Now")
                                    }
                                }
                            }
                        }

                        // Data Portability & JSON Export
                        item {
                            Text("Data Portability & JSON Export", fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))

                            Card(
                                modifier = Modifier.fillMaxWidth().testTag("data_export_card"),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(BrandAccent.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.FileDownload,
                                                contentDescription = null,
                                                tint = BrandAccent,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text("Export Profile & Activity JSON", fontWeight = FontWeight.Bold)
                                            Text(
                                                "Port your complete business state, orders, profile, and audit logs.",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "Exports a validated, portable JSON document conforming to open DigiTech ERP schema with user profile metadata, role configuration, activity logs, and summary statistics.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = {
                                            viewModel.exportDataAndShare(
                                                context = context,
                                                userProfile = userProfile,
                                                userEmail = userEmail,
                                                syncFreq = syncFrequency
                                            )
                                        },
                                        modifier = Modifier.fillMaxWidth().testTag("export_json_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = BrandAccent)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Export & Share JSON Data")
                                    }
                                }
                            }
                        }

                        // App Preferences & Theme
                        item {
                            Text("Preferences & Interface", fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    // Theme Toggle Row
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(38.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isDarkTheme) BrandPrimary.copy(alpha = 0.15f) else StatusWarning.copy(alpha = 0.15f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = if (isDarkTheme) Icons.Filled.DarkMode else Icons.Filled.LightMode,
                                                    contentDescription = null,
                                                    tint = if (isDarkTheme) BrandPrimary else StatusWarning
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text("App Theme Mode", fontWeight = FontWeight.Bold)
                                                Text(
                                                    if (isDarkTheme) "Dark mode active (Persistent DataStore)" else "Light mode active (Persistent DataStore)",
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        Switch(
                                            checked = isDarkTheme,
                                            onCheckedChange = {
                                                onToggleTheme()
                                                viewModel.logActivity(
                                                    actionType = "THEME_CHANGE",
                                                    title = "Theme Preference Changed",
                                                    description = if (isDarkTheme) "Switched to Light Theme" else "Switched to Dark Theme",
                                                    actorEmail = userEmail,
                                                    role = userProfile.rolePreference
                                                )
                                            },
                                            modifier = Modifier.testTag("operations_theme_switch")
                                        )
                                    }

                                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                                    // Onboarding Tour
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onOpenTour() },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(BrandSecondary.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Filled.AutoStories, contentDescription = null, tint = BrandSecondary)
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Feature Tour & Walkthrough", fontWeight = FontWeight.Bold)
                                            Text("Replay the interactive 4-step dashboard guide carousel", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                                    // Sign Out
                                    OutlinedButton(
                                        onClick = { showSignOutConfirmDialog = true },
                                        modifier = Modifier.fillMaxWidth().testTag("sign_out_button"),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger)
                                    ) {
                                        Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Sign Out of Account")
                                    }
                                }
                            }
                        }

                        // Complete Activity & Audit Trail
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Full Activity Audit Trail", fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "${activityLogs.size} Total Events",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (activityLogs.isEmpty()) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("No audit logs recorded yet", fontWeight = FontWeight.Medium)
                                        Text(
                                            "Actions like logins, theme toggles, profile adjustments, and order updates will be securely audited here.",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                    }
                                }
                            }
                        } else {
                            items(activityLogs) { log ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .padding(12.dp)
                                            .fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when (log.actionType) {
                                                        "PROFILE_UPDATE" -> BrandPrimary.copy(alpha = 0.15f)
                                                        "THEME_CHANGE" -> BrandSecondary.copy(alpha = 0.15f)
                                                        "SYNC_FREQUENCY_CHANGE" -> StatusWarning.copy(alpha = 0.15f)
                                                        "MANUAL_SYNC" -> StatusSuccess.copy(alpha = 0.15f)
                                                        "DATA_EXPORT" -> BrandAccent.copy(alpha = 0.15f)
                                                        else -> MaterialTheme.colorScheme.primaryContainer
                                                    }
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = when (log.actionType) {
                                                    "PROFILE_UPDATE" -> Icons.Default.ManageAccounts
                                                    "THEME_CHANGE" -> Icons.Default.Palette
                                                    "SYNC_FREQUENCY_CHANGE" -> Icons.Default.BatterySaver
                                                    "MANUAL_SYNC" -> Icons.Default.Sync
                                                    "DATA_EXPORT" -> Icons.Default.FileDownload
                                                    else -> Icons.Default.History
                                                },
                                                contentDescription = null,
                                                tint = when (log.actionType) {
                                                    "PROFILE_UPDATE" -> BrandPrimary
                                                    "THEME_CHANGE" -> BrandSecondary
                                                    "SYNC_FREQUENCY_CHANGE" -> StatusWarning
                                                    "MANUAL_SYNC" -> StatusSuccess
                                                    "DATA_EXPORT" -> BrandAccent
                                                    else -> MaterialTheme.colorScheme.primary
                                                },
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = log.title,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = Formatters.formatDateTime(log.timestamp),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontSize = 10.sp
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = log.description,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            if (log.actorEmail.isNotEmpty()) {
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = "By ${log.actorEmail} (${log.role})",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = BrandPrimary,
                                                    fontSize = 10.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Ticket Dialog
    if (showAddTicketDialog) {
        var subject by remember { mutableStateOf("") }
        var customerName by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("Account Issue") }
        var description by remember { mutableStateOf("") }
        var priority by remember { mutableStateOf("high") }

        AlertDialog(
            onDismissRequest = { showAddTicketDialog = false },
            title = { Text("Create Support Ticket") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Subject (e.g. License Key Invalid)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = customerName, onValueChange = { customerName = it }, label = { Text("Customer Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Issue Category") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Issue Details") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ticket = SupportTicketEntity(
                            id = "tkt-" + UUID.randomUUID().toString().take(8),
                            ticketNumber = "TKT-" + (1000..9999).random(),
                            customerName = customerName,
                            customerPhone = "",
                            subject = subject,
                            description = description,
                            category = category,
                            priority = priority,
                            status = "open",
                            createdAt = System.currentTimeMillis()
                        )
                        viewModel.saveTicket(ticket)
                        showAddTicketDialog = false
                    }
                ) {
                    Text("Create Ticket")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTicketDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Add Lead Dialog
    if (showAddLeadDialog) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var interestedProduct by remember { mutableStateOf("") }
        var valueText by remember { mutableStateOf("1500") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddLeadDialog = false },
            title = { Text("Add CRM Sales Lead") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Lead / Prospect Name *") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("WhatsApp Phone") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = interestedProduct, onValueChange = { interestedProduct = it }, label = { Text("Interested In (e.g. Canva Pro)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = valueText, onValueChange = { valueText = it }, label = { Text("Estimated Value (₹)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val lead = LeadEntity(
                            id = "lead-" + UUID.randomUUID().toString().take(8),
                            name = name,
                            phone = phone,
                            email = "",
                            company = "",
                            source = "WhatsApp",
                            interestedProduct = interestedProduct,
                            estimatedValue = valueText.toDoubleOrNull() ?: 1500.0,
                            probability = 60,
                            status = "new",
                            followUpAt = System.currentTimeMillis() + 86400000L * 2,
                            notes = notes
                        )
                        viewModel.saveLead(lead)
                        showAddLeadDialog = false
                    }
                ) {
                    Text("Save Lead")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddLeadDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Add Supplier Dialog
    if (showAddSupplierDialog) {
        var name by remember { mutableStateOf("") }
        var contact by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var website by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddSupplierDialog = false },
            title = { Text("Add License Supplier") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Supplier / Agency Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = contact, onValueChange = { contact = it }, label = { Text("Contact Person") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone / Telegram") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = website, onValueChange = { website = it }, label = { Text("Website / Portal") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val supplier = SupplierEntity(
                            id = "sup-" + UUID.randomUUID().toString().take(8),
                            name = name,
                            contactPerson = contact,
                            email = "",
                            phone = phone,
                            website = website,
                            paymentTerms = "Prepaid",
                            isActive = true
                        )
                        viewModel.saveSupplier(supplier)
                        showAddSupplierDialog = false
                    }
                ) {
                    Text("Save Supplier")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddSupplierDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Add Task Dialog
    if (showAddTaskDialog) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddTaskDialog = false },
            title = { Text("Add Daily Task") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task Title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description / Details") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val task = TaskEntity(
                            id = "task-" + UUID.randomUUID().toString().take(8),
                            title = title,
                            description = description,
                            priority = "medium",
                            status = "open",
                            dueAt = System.currentTimeMillis() + 86400000L,
                            createdAt = System.currentTimeMillis()
                        )
                        viewModel.saveTask(task)
                        showAddTaskDialog = false
                    }
                ) {
                    Text("Save Task")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTaskDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Reset Confirmation Dialog
    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmDialog = false },
            title = { Text("Reset Sample Data?") },
            text = { Text("This will reload clean default catalog items, customer orders, expiring subscriptions, and financial metrics.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetToDemoData()
                        showResetConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDanger)
                ) {
                    Text("Reset Data")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Sign Out Confirmation Dialog
    if (showSignOutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showSignOutConfirmDialog = false },
            title = { Text("Sign Out of DigiTech?") },
            text = { Text("Are you sure you want to sign out? Your organization data remains safely stored in Supabase.") },
            confirmButton = {
                Button(
                    onClick = {
                        showSignOutConfirmDialog = false
                        onSignOut()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDanger)
                ) {
                    Text("Sign Out")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutConfirmDialog = false }) { Text("Cancel") }
            }
        )
    }
}
