package com.example.digitech.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = BrandPrimary,
    onPrimary = DarkBackground,
    primaryContainer = BrandPrimaryContainerDark,
    onPrimaryContainer = BrandPrimaryLight,
    inversePrimary = BrandPrimaryLight,

    secondary = BrandSecondary,
    onSecondary = TextPrimaryDark,
    secondaryContainer = BrandSecondaryContainerDark,
    onSecondaryContainer = BrandSecondaryLight,

    tertiary = BrandAccent,
    onTertiary = DarkBackground,
    tertiaryContainer = BrandAccentContainerDark,
    onTertiaryContainer = BrandAccentLight,

    background = DarkBackground,
    onBackground = TextPrimaryDark,

    surface = DarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainer = DarkSurfaceContainer,
    surfaceContainerHigh = DarkSurfaceContainerHigh,
    surfaceTint = BrandPrimary,

    error = StatusDanger,
    onError = TextPrimaryDark,
    errorContainer = StatusDangerContainerDark,
    onErrorContainer = StatusDanger,

    outline = DarkBorder,
    outlineVariant = DarkBorderSubtle
)

private val LightColorScheme = lightColorScheme(
    primary = BrandPrimary,
    onPrimary = TextPrimaryLight,
    primaryContainer = BrandPrimaryContainerLight,
    onPrimaryContainer = BrandPrimaryDark,
    inversePrimary = BrandPrimary,

    secondary = BrandSecondary,
    onSecondary = TextPrimaryDark,
    secondaryContainer = BrandSecondaryContainerLight,
    onSecondaryContainer = BrandSecondaryDark,

    tertiary = BrandAccent,
    onTertiary = TextPrimaryDark,
    tertiaryContainer = BrandAccentContainerLight,
    onTertiaryContainer = BrandAccentDark,

    background = LightBackground,
    onBackground = TextPrimaryLight,

    surface = LightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainer = LightSurfaceContainer,
    surfaceContainerHigh = LightSurfaceContainerHigh,
    surfaceTint = BrandPrimary,

    error = StatusDanger,
    onError = TextPrimaryDark,
    errorContainer = StatusDangerContainerLight,
    onErrorContainer = StatusDangerDark,

    outline = LightBorder,
    outlineVariant = LightBorderSubtle
)

@Composable
fun DigiTechTheme(
    darkTheme: Boolean = true, // Default to sleek modern dark theme for business dashboard
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = !darkTheme
            insetsController.isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = Shapes,
        content = content
    )
}
