package com.example.digitech.data.remote

import com.example.digitech.BuildConfig
import com.example.digitech.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

data class BusinessSnapshot(
    val customers: List<CustomerEntity>,
    val products: List<ProductEntity>,
    val orders: List<OrderEntity>,
    val subscriptions: List<SubscriptionEntity>,
    val activations: List<ActivationEntity>,
    val expenses: List<ExpenseEntity>,
    val suppliers: List<SupplierEntity>,
    val leads: List<LeadEntity>,
    val tickets: List<SupportTicketEntity>,
    val tasks: List<TaskEntity>,
    val activityLogs: List<ActivityLogEntity>
)

/**
 * RLS-preserving business client for the authoritative Supabase schema.
 * Every call carries the signed-in user's JWT. Organization IDs are checked
 * again before records enter Room, and activation secret columns are never
 * requested or cached.
 */
class SupabaseBusinessClient {
    private val baseUrl = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val anonKey = BuildConfig.SUPABASE_ANON_KEY
    private val http = OkHttpClient()

    suspend fun fetchSnapshot(accessToken: String, organizationId: String): BusinessSnapshot = withContext(Dispatchers.IO) {
        checkConfigured()
        val customersJson = get("customers?select=*&deleted_at=is.null", accessToken)
        val productsJson = get("products?select=*&deleted_at=is.null", accessToken)
        val suppliersJson = get("suppliers?select=*&deleted_at=is.null", accessToken)
        val ordersJson = get("orders?select=*&deleted_at=is.null", accessToken)
        val orderItemsJson = get("order_items?select=*", accessToken)
        val subscriptionsJson = get("subscriptions?select=*&deleted_at=is.null", accessToken)
        val activationFields = "id,organization_id,order_id,order_item_id,customer_id,product_name,status,priority,assigned_to,supplier_id,activated_at,delivered_at,expiry_date,created_at,updated_at,deleted_at"
        val activationsJson = get("activations?select=$activationFields&deleted_at=is.null", accessToken)
        val expensesJson = get("expenses?select=*&deleted_at=is.null", accessToken)
        val leadsJson = get("leads?select=*&deleted_at=is.null", accessToken)
        val ticketsJson = get("support_tickets?select=*&deleted_at=is.null", accessToken)
        val tasksJson = get("tasks?select=*&deleted_at=is.null", accessToken)
        val logsJson = get("activity_logs?select=*&order=created_at.desc&limit=100", accessToken)

        val customers = customersJson.objects(organizationId).associateBy { it.string("id") }
        val products = productsJson.objects(organizationId).associateBy { it.string("id") }
        val suppliers = suppliersJson.objects(organizationId).associateBy { it.string("id") }
        val itemsByOrder = orderItemsJson.objects(organizationId).groupBy { it.string("order_id") }

        BusinessSnapshot(
            customers = customers.values.map { row ->
                CustomerEntity(
                    id = row.string("id"), customerCode = row.string("customer_code"), name = row.string("name"),
                    email = row.string("email"), phone = row.string("phone"), whatsapp = row.string("whatsapp"),
                    company = row.string("company"), city = row.string("city"), state = row.string("state"),
                    status = row.string("status", "active"), source = row.string("source"), notes = row.string("notes"),
                    tags = row.optJSONArray("tags")?.let { array -> (0 until array.length()).joinToString(",") { array.optString(it) } }.orEmpty(),
                    createdAt = row.epoch("created_at"), updatedAt = row.epoch("updated_at")
                )
            },
            products = products.values.map { row ->
                ProductEntity(
                    id = row.string("id"), code = row.string("code"), name = row.string("name"),
                    category = row.string("category_id", "Uncategorized"), brand = row.string("brand"),
                    description = row.string("description"), productType = row.string("product_type", "subscription"),
                    deliveryType = row.string("delivery_type", "email_activation"), durationDays = row.optInt("duration_days", 0),
                    costPrice = row.optDouble("cost_price", 0.0), sellingPrice = row.optDouble("selling_price", 0.0),
                    stock = if (row.isNull("stock")) null else row.optInt("stock"), isActive = row.optBoolean("is_active", true),
                    createdAt = row.epoch("created_at")
                )
            },
            suppliers = suppliers.values.map { row ->
                SupplierEntity(
                    id = row.string("id"), name = row.string("name"), contactPerson = row.string("contact_person"),
                    email = row.string("email"), phone = row.string("phone"), website = row.string("website"),
                    paymentTerms = row.string("payment_terms", "Prepaid"), isActive = row.optBoolean("is_active", true)
                )
            },
            orders = ordersJson.objects(organizationId).map { row ->
                val first = itemsByOrder[row.string("id")]?.firstOrNull()
                val customer = customers[row.string("customer_id")]
                OrderEntity(
                    id = row.string("id"), orderNumber = row.string("order_number"), customerId = row.string("customer_id"),
                    customerName = customer?.string("name").orEmpty(), productId = first?.string("product_id").orEmpty(),
                    productName = first?.string("product_name") ?: "${itemsByOrder[row.string("id")]?.size ?: 0} items",
                    quantity = first?.optInt("quantity", 1) ?: 1, unitPrice = first?.optDouble("unit_price", 0.0) ?: 0.0,
                    unitCost = first?.optDouble("unit_cost", 0.0) ?: 0.0, discount = row.optDouble("discount", 0.0),
                    total = row.optDouble("total", 0.0), totalCost = row.optDouble("total_cost", 0.0),
                    profit = row.optDouble("profit", 0.0), status = row.string("status", "new"),
                    paymentStatus = row.string("payment_status", "pending"), paymentMethod = "server-ledger",
                    amountPaid = row.optDouble("amount_paid", 0.0), orderedAt = row.epoch("ordered_at"), notes = row.string("notes")
                )
            },
            subscriptions = subscriptionsJson.objects(organizationId).map { row ->
                val customer = customers[row.string("customer_id")]
                SubscriptionEntity(
                    id = row.string("id"), customerId = row.string("customer_id"), customerName = customer?.string("name").orEmpty(),
                    customerPhone = customer?.string("phone").orEmpty(), productId = row.string("product_id"),
                    productName = row.string("product_name"), orderId = row.string("order_id"), startDate = row.epoch("start_date"),
                    expiryDate = row.epoch("expiry_date"), durationDays = row.optInt("duration_days", 0),
                    purchaseAmount = row.optDouble("purchase_amount", 0.0), costAmount = row.optDouble("cost_amount", 0.0),
                    profit = row.optDouble("profit", 0.0), status = row.string("status", "active"),
                    reminderState = row.string("reminder_state", "none"),
                    lastContactedAt = row.nullableEpoch("last_contacted_at"), notes = row.string("notes")
                )
            },
            activations = activationsJson.objects(organizationId).map { row ->
                val customer = customers[row.string("customer_id")]
                val order = ordersJson.findById(row.string("order_id"))
                ActivationEntity(
                    id = row.string("id"), orderId = row.string("order_id"), orderNumber = order?.string("order_number").orEmpty(),
                    customerId = row.string("customer_id"), customerName = customer?.string("name").orEmpty(),
                    customerPhone = customer?.string("phone").orEmpty(), productName = row.string("product_name"),
                    deliveryType = "server-managed", status = row.string("status", "waiting_payment"),
                    priority = row.string("priority", "medium"), activationDetails = "Protected on server",
                    instructions = "Open the secure fulfilment workflow", createdAt = row.epoch("created_at"),
                    activatedAt = row.nullableEpoch("activated_at")
                )
            },
            expenses = expensesJson.objects(organizationId).map { row ->
                ExpenseEntity(
                    id = row.string("id"), category = row.string("category", "miscellaneous"),
                    description = row.string("description"), amount = row.optDouble("amount", 0.0),
                    vendor = row.string("vendor"), spentAt = row.epoch("spent_at"),
                    paymentMethod = row.string("method", "upi"), isRecurring = row.optBoolean("is_recurring", false)
                )
            },
            leads = leadsJson.objects(organizationId).map { row ->
                LeadEntity(
                    id = row.string("id"), name = row.string("name"), phone = row.string("phone"), email = row.string("email"),
                    company = row.string("company"), source = row.string("source"), interestedProduct = products[row.string("interested_product_id")]?.string("name").orEmpty(),
                    estimatedValue = row.optDouble("value", 0.0), probability = row.optInt("probability", 0),
                    status = row.string("status", "new"), followUpAt = row.nullableEpoch("follow_up_at"), notes = row.string("notes")
                )
            },
            tickets = ticketsJson.objects(organizationId).map { row ->
                SupportTicketEntity(
                    id = row.string("id"), ticketNumber = row.string("ticket_number"),
                    customerName = customers[row.string("customer_id")]?.string("name").orEmpty(),
                    customerPhone = customers[row.string("customer_id")]?.string("phone").orEmpty(),
                    subject = row.string("subject"), description = row.string("description"), category = row.string("category", "General"),
                    priority = row.string("priority", "medium"), status = row.string("status", "open"), createdAt = row.epoch("created_at")
                )
            },
            tasks = tasksJson.objects(organizationId).map { row ->
                TaskEntity(
                    id = row.string("id"), title = row.string("title"), description = row.string("description"),
                    priority = row.string("priority", "medium"), status = row.string("status", "open"),
                    dueAt = row.nullableEpoch("due_at"), createdAt = row.epoch("created_at")
                )
            },
            activityLogs = logsJson.objects(organizationId).map { row ->
                ActivityLogEntity(
                    id = row.string("id"), actionType = row.string("action"), title = row.string("summary"),
                    description = row.string("record_type"), actorEmail = row.string("actor_name"),
                    role = "server-audited", timestamp = row.epoch("created_at"), metadata = ""
                )
            }
        )
    }

    suspend fun patch(accessToken: String, table: String, id: String, body: JSONObject) = withContext(Dispatchers.IO) {
        require(table in setOf("customers", "products", "subscriptions", "expenses", "leads", "support_tickets", "tasks"))
        execute("$table?id=eq.${id.urlPart()}", "PATCH", body.toString(), accessToken, "return=minimal")
    }

    suspend fun insert(accessToken: String, table: String, body: JSONObject) = withContext(Dispatchers.IO) {
        require(table in setOf("customers", "products", "suppliers", "expenses", "leads", "support_tickets", "tasks"))
        execute(table, "POST", body.toString(), accessToken, "return=representation")
    }

    suspend fun archive(accessToken: String, table: String, id: String) =
        patch(accessToken, table, id, JSONObject().put("deleted_at", Instant.now().toString()))

    suspend fun createOrder(
        accessToken: String,
        customerId: String,
        productId: String,
        quantity: Int,
        unitPrice: Double,
        discount: Double,
        paymentMethod: String,
        paymentAmount: Double,
        notes: String,
        renewalOfSubscriptionId: String? = null,
        idempotencyKey: String
    ): String = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("p_customer_id", customerId); put("p_product_id", productId); put("p_quantity", quantity)
            put("p_unit_price", unitPrice); put("p_discount", discount); put("p_payment_method", paymentMethod)
            put("p_payment_amount", paymentAmount); put("p_notes", notes.ifBlank { JSONObject.NULL })
            put("p_renewal_of_subscription_id", renewalOfSubscriptionId ?: JSONObject.NULL)
            put("p_idempotency_key", idempotencyKey)
        }
        execute("rpc/mobile_create_order", "POST", body.toString(), accessToken).trim().trim('"')
    }

    suspend fun addPayment(accessToken: String, orderId: String, amount: Double, method: String, idempotencyKey: String) = withContext(Dispatchers.IO) {
        val body = JSONObject().put("p_order_id", orderId).put("p_amount", amount).put("p_method", method)
            .put("p_reference", "Android payment").put("p_idempotency_key", idempotencyKey)
        execute("rpc/mobile_add_payment", "POST", body.toString(), accessToken)
    }

    suspend fun completeActivation(accessToken: String, activationId: String, idempotencyKey: String) = withContext(Dispatchers.IO) {
        val body = JSONObject().put("p_activation_id", activationId).put("p_idempotency_key", idempotencyKey)
        execute("rpc/mobile_complete_activation", "POST", body.toString(), accessToken)
    }

    suspend fun transitionOrder(accessToken: String, orderId: String, status: String) = withContext(Dispatchers.IO) {
        execute("rpc/mobile_transition_order", "POST", JSONObject().put("p_order_id", orderId).put("p_status", status).toString(), accessToken)
    }

    private fun get(path: String, token: String) = JSONArray(execute(path, "GET", null, token))

    private fun execute(path: String, method: String, body: String?, token: String, prefer: String? = null): String {
        checkConfigured()
        val builder = Request.Builder().url("$baseUrl/rest/v1/$path")
            .header("apikey", anonKey).header("Authorization", "Bearer $token").header("Accept", "application/json")
        prefer?.let { builder.header("Prefer", it) }
        builder.method(method, body?.toRequestBody("application/json".toMediaType()))
        http.newCall(builder.build()).execute().use { response ->
            val payload = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("Server rejected $method ${path.substringBefore('?')} (${response.code}).")
            return payload
        }
    }

    private fun checkConfigured() = check(baseUrl.startsWith("https://") && anonKey.isNotBlank()) {
        "Supabase connection is not configured for this build."
    }
}

private fun JSONArray.objects(orgId: String): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
    .onEach { row -> check(row.optString("organization_id") == orgId) { "Cross-organization response rejected." } }
private fun JSONArray.findById(id: String): JSONObject? = (0 until length()).asSequence().map { getJSONObject(it) }.firstOrNull { it.optString("id") == id }
private fun JSONObject.string(key: String, default: String = ""): String = if (isNull(key)) default else optString(key, default)
private fun JSONObject.epoch(key: String): Long = runCatching { Instant.parse(string(key)).toEpochMilli() }.getOrDefault(0L)
private fun JSONObject.nullableEpoch(key: String): Long? = if (isNull(key) || !has(key)) null else epoch(key)
private fun String.urlPart(): String = java.net.URLEncoder.encode(this, Charsets.UTF_8.name())
