package com.example.digitech.data.db

import androidx.room.*
import com.example.digitech.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DigiTechDao {

    @Transaction
    suspend fun replaceFromServer(snapshot: com.example.digitech.data.remote.BusinessSnapshot) {
        clearAllSessionData()
        insertCustomers(snapshot.customers)
        insertProducts(snapshot.products)
        insertOrders(snapshot.orders)
        insertSubscriptions(snapshot.subscriptions)
        insertActivations(snapshot.activations)
        insertExpenses(snapshot.expenses)
        insertSuppliers(snapshot.suppliers)
        insertLeads(snapshot.leads)
        insertTickets(snapshot.tickets)
        insertTasks(snapshot.tasks)
        insertActivityLogs(snapshot.activityLogs)
    }

    // Customers
    @Query("SELECT * FROM customers ORDER BY createdAt DESC")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomers(customers: List<CustomerEntity>)

    @Delete
    suspend fun deleteCustomer(customer: CustomerEntity)

    // Products
    @Query("SELECT * FROM products ORDER BY category ASC, name ASC")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    // Orders
    @Query("SELECT * FROM orders ORDER BY orderedAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrders(orders: List<OrderEntity>)

    @Delete
    suspend fun deleteOrder(order: OrderEntity)

    // Subscriptions
    @Query("SELECT * FROM subscriptions ORDER BY expiryDate ASC")
    fun getAllSubscriptions(): Flow<List<SubscriptionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscription(subscription: SubscriptionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscriptions(subscriptions: List<SubscriptionEntity>)

    @Delete
    suspend fun deleteSubscription(subscription: SubscriptionEntity)

    // Activations
    @Query("SELECT * FROM activations ORDER BY createdAt DESC")
    fun getAllActivations(): Flow<List<ActivationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivation(activation: ActivationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivations(activations: List<ActivationEntity>)

    @Delete
    suspend fun deleteActivation(activation: ActivationEntity)

    // Expenses
    @Query("SELECT * FROM expenses ORDER BY spentAt DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpenses(expenses: List<ExpenseEntity>)

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    // Suppliers
    @Query("SELECT * FROM suppliers ORDER BY name ASC")
    fun getAllSuppliers(): Flow<List<SupplierEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplier(supplier: SupplierEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSuppliers(suppliers: List<SupplierEntity>)

    @Delete
    suspend fun deleteSupplier(supplier: SupplierEntity)

    // Leads
    @Query("SELECT * FROM leads ORDER BY status ASC, probability DESC")
    fun getAllLeads(): Flow<List<LeadEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLead(lead: LeadEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeads(leads: List<LeadEntity>)

    @Delete
    suspend fun deleteLead(lead: LeadEntity)

    // Support Tickets
    @Query("SELECT * FROM support_tickets ORDER BY createdAt DESC")
    fun getAllTickets(): Flow<List<SupportTicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: SupportTicketEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTickets(tickets: List<SupportTicketEntity>)

    @Delete
    suspend fun deleteTicket(ticket: SupportTicketEntity)

    // Tasks
    @Query("SELECT * FROM tasks ORDER BY status ASC, priority DESC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<TaskEntity>)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    // Activity Logs
    @Query("SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAllActivityLogs(): Flow<List<ActivityLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivityLog(log: ActivityLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivityLogs(logs: List<ActivityLogEntity>)

    @Delete
    suspend fun deleteActivityLog(log: ActivityLogEntity)

    // Clear all tables for fresh reset
    @Query("DELETE FROM customers")
    suspend fun clearCustomers()

    @Query("DELETE FROM products")
    suspend fun clearProducts()

    @Query("DELETE FROM orders")
    suspend fun clearOrders()

    @Query("DELETE FROM subscriptions")
    suspend fun clearSubscriptions()

    @Query("DELETE FROM activations")
    suspend fun clearActivations()

    @Query("DELETE FROM expenses")
    suspend fun clearExpenses()

    @Query("DELETE FROM suppliers")
    suspend fun clearSuppliers()

    @Query("DELETE FROM leads")
    suspend fun clearLeads()

    @Query("DELETE FROM support_tickets")
    suspend fun clearTickets()

    @Query("DELETE FROM tasks")
    suspend fun clearTasks()

    @Query("DELETE FROM activity_logs")
    suspend fun clearActivityLogs()

    @Transaction
    suspend fun clearAllSessionData() {
        clearActivityLogs()
        clearTasks()
        clearTickets()
        clearLeads()
        clearSuppliers()
        clearExpenses()
        clearActivations()
        clearSubscriptions()
        clearOrders()
        clearProducts()
        clearCustomers()
    }
}
