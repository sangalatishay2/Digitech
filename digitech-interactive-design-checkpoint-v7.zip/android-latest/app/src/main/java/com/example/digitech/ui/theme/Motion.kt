package com.example.digitech.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer

/**
 * A restrained motion language for a high-frequency operations app.
 * Android's system animator-duration scale is respected by Compose automatically.
 */
object DigiTechMotion {
    const val Instant = 90
    const val Quick = 160
    const val Standard = 260
    const val Deliberate = 420

    val EmphasizedDecelerate = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)
    val EmphasizedAccelerate = CubicBezierEasing(0.7f, 0f, 0.84f, 0f)
}

/** Adds tactile visual feedback without changing the component's click semantics. */
@Composable
fun Modifier.pressScale(
    interactionSource: MutableInteractionSource,
    pressedScale: Float = 0.975f
): Modifier {
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) pressedScale else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "pressScale"
    )

    return graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}
