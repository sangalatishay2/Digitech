package com.example.digitech.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.digitech.ui.theme.BrandAccent
import com.example.digitech.ui.theme.BrandPrimary
import com.example.digitech.ui.theme.BrandSecondary
import com.example.digitech.ui.theme.DigiTechMotion
import com.example.digitech.ui.theme.StatusSuccess
import com.example.digitech.ui.theme.StatusWarning
import com.example.digitech.ui.theme.pressScale
import kotlinx.coroutines.delay
import kotlin.math.min

/**
 * The dashboard's main decision surface. It turns live counts into a truthful
 * priority summary instead of presenting another generic row of statistics.
 */
@Composable
fun BusinessPulseHero(
    revenue: String,
    margin: Double,
    openOrders: Int,
    expiringSoon: Int,
    pendingFulfillment: Int,
    openTickets: Int,
    onNewOrder: () -> Unit,
    onAddCustomer: () -> Unit,
    onOpenRenewals: () -> Unit,
    onOpenCopilot: () -> Unit,
    modifier: Modifier = Modifier
) {
    val attentionCount = expiringSoon + pendingFulfillment + openTickets
    val attentionProgress = min(attentionCount / 10f, 1f)
    val headline = when {
        expiringSoon > 0 -> "$expiringSoon renewal${if (expiringSoon == 1) "" else "s"} need attention"
        pendingFulfillment > 0 -> "$pendingFulfillment deliver${if (pendingFulfillment == 1) "y is" else "ies are"} ready to move"
        openTickets > 0 -> "$openTickets support request${if (openTickets == 1) "" else "s"} waiting"
        else -> "Your workspace is under control"
    }
    val statusLabel = when {
        attentionCount == 0 -> "ALL CLEAR"
        attentionCount <= 3 -> "STEADY"
        attentionCount <= 7 -> "BUSY"
        else -> "ACTION"
    }
    val signalColor = when {
        attentionCount == 0 -> StatusSuccess
        attentionCount <= 3 -> BrandPrimary
        else -> StatusWarning
    }
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(45)
        visible = true
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(DigiTechMotion.Standard)) +
            slideInVertically(tween(DigiTechMotion.Deliberate, easing = DigiTechMotion.EmphasizedDecelerate)) { it / 5 } +
            scaleIn(initialScale = 0.985f)
    ) {
        Surface(
            modifier = modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            color = Color.Transparent,
            shadowElevation = 10.dp
        ) {
            Box(
                modifier = Modifier
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.surfaceContainerHigh,
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
                                MaterialTheme.colorScheme.surfaceContainer
                            )
                        )
                    )
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(signalColor)
                                )
                                Spacer(Modifier.width(7.dp))
                                Text(
                                    text = "BUSINESS PULSE · $statusLabel",
                                    color = signalColor,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 0.9.sp
                                )
                            }
                            Spacer(Modifier.height(9.dp))
                            AnimatedContent(
                                targetState = headline,
                                transitionSpec = {
                                    (fadeIn(tween(DigiTechMotion.Standard)) +
                                        slideInVertically { it / 3 })
                                        .togetherWith(fadeOut(tween(DigiTechMotion.Instant)))
                                },
                                label = "businessPulseHeadline"
                            ) { currentHeadline ->
                                Text(
                                    text = currentHeadline,
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    lineHeight = 25.sp
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "$openOrders open orders · $pendingFulfillment pending deliveries",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        Spacer(Modifier.width(14.dp))
                        AttentionRing(
                            count = attentionCount,
                            progress = attentionProgress,
                            color = signalColor
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "REVENUE",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )
                            AnimatedContent(
                                targetState = revenue,
                                transitionSpec = {
                                    (fadeIn(tween(DigiTechMotion.Standard)) + slideInVertically { it / 2 })
                                        .togetherWith(fadeOut(tween(DigiTechMotion.Quick)))
                                },
                                label = "revenueValue"
                            ) { currentRevenue ->
                                Text(
                                    text = currentRevenue,
                                    fontSize = 25.sp,
                                    lineHeight = 29.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Surface(
                            shape = CircleShape,
                            color = if (margin >= 0) StatusSuccess.copy(alpha = 0.14f)
                            else MaterialTheme.colorScheme.errorContainer
                        ) {
                            Text(
                                text = "${String.format("%.1f", margin)}% margin",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                color = if (margin >= 0) StatusSuccess else MaterialTheme.colorScheme.error,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CommandAction(
                            label = "New order",
                            icon = { Icon(Icons.Default.AddShoppingCart, null, Modifier.size(18.dp)) },
                            accent = BrandPrimary,
                            onClick = onNewOrder,
                            modifier = Modifier.weight(1f)
                        )
                        CommandAction(
                            label = "Customer",
                            icon = { Icon(Icons.Default.PersonAdd, null, Modifier.size(18.dp)) },
                            accent = BrandSecondary,
                            onClick = onAddCustomer,
                            modifier = Modifier.weight(1f)
                        )
                        CommandAction(
                            label = "Renewals",
                            icon = { Icon(Icons.Default.Autorenew, null, Modifier.size(18.dp)) },
                            accent = BrandAccent,
                            onClick = onOpenRenewals,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    CopilotCommand(
                        onClick = onOpenCopilot,
                        prompt = when {
                            expiringSoon > 0 -> "Create my renewal action plan"
                            pendingFulfillment > 0 -> "Prioritize today's fulfillment queue"
                            else -> "Find today's best growth opportunity"
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AttentionRing(count: Int, progress: Float, color: Color) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(DigiTechMotion.Deliberate, easing = DigiTechMotion.EmphasizedDecelerate),
        label = "attentionRing"
    )
    Box(
        modifier = Modifier
            .size(72.dp)
            .semantics { contentDescription = "$count items need attention" },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(72.dp)) {
            drawArc(
                color = color.copy(alpha = 0.14f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
            )
            if (count == 0) {
                drawArc(
                    color = color,
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
                )
            } else {
                drawArc(
                    brush = Brush.sweepGradient(listOf(color.copy(alpha = 0.45f), color)),
                    startAngle = -90f,
                    sweepAngle = 360f * animatedProgress,
                    useCenter = false,
                    style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = count.toString(),
                fontSize = 19.sp,
                lineHeight = 20.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = "ATTENTION",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 7.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.4.sp
            )
        }
    }
}

@Composable
private fun CommandAction(
    label: String,
    icon: @Composable () -> Unit,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val haptics = LocalHapticFeedback.current
    Surface(
        modifier = modifier
            .pressScale(interactionSource, pressedScale = 0.955f)
            .clip(RoundedCornerShape(18.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button
            ) {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.82f),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 11.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(shape = CircleShape, color = accent.copy(alpha = 0.16f)) {
                Box(
                    modifier = Modifier.padding(7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.runtime.CompositionLocalProvider(
                        androidx.compose.material3.LocalContentColor provides accent,
                        content = icon
                    )
                }
            }
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun CopilotCommand(onClick: () -> Unit, prompt: String) {
    val interactionSource = remember { MutableInteractionSource() }
    val haptics = LocalHapticFeedback.current
    val iconColor by animateColorAsState(
        targetValue = BrandPrimary,
        animationSpec = spring(),
        label = "copilotIconColor"
    )
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .pressScale(interactionSource, 0.97f)
            .clip(RoundedCornerShape(20.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button
            ) {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.76f)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(Brush.linearGradient(listOf(BrandPrimary, BrandSecondary, BrandAccent))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "ASK DIGITECH COPILOT",
                    color = iconColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.7.sp
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = prompt,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                Icons.Default.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
