# DigiTech Business OS — Android client

This directory is the repaired Android client for the authoritative Next.js +
Supabase DigiTech Business OS. It is not a separate Firebase database.

## Security and architecture

- Supabase Auth is the identity authority. A profile and organization role are
  resolved from the server before business access is opened.
- Refresh and access tokens are encrypted with an Android Keystore AES-GCM key.
- Unknown or missing roles fail closed at the Access Pending screen.
- Demo identities, automatic Store Owner assignment, destructive Room migration
  fallback, startup seed data, and APK-embedded AI provider keys are disabled.
- AI requests go to the authenticated `/api/ai/chat` route in the DigiTech web
  app. OpenRouter, Nemotron, Google AI, and custom model IDs use server-side keys.
- The legacy Firebase/Firestore runtime, dependencies, configuration, and sync
  manager have been removed; Supabase remains the only approved source of truth.

## Configure a local build

Copy `gradle.properties.example` values into the user-level
`~/.gradle/gradle.properties` file. The Supabase anon/publishable key is a public
client identifier; provider keys such as `OPENROUTER_API_KEY` must only be set on
the Next.js server.

```sh
./gradlew testDebugUnitTest assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Reproducible CI build

`.github/workflows/android.yml` installs JDK 17 and Android API 35, runs unit
tests, builds the debug APK, and uploads it as a workflow artifact. Add the four
named repository secrets used by that workflow before running it.

## Current delivery boundary

The authoritative web app and secure AI gateway are production-build verified.
Android dependency compilation requires access to Google's Maven repository and
an Android SDK. Do not distribute an APK until the workflow is green and the
live Supabase organization/RLS tests have been run against the deployment.
