@echo off
setlocal
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.9"
set "GRADLE_SHA256=d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_CACHE_DIR=%GRADLE_USER_HOME%\wrapper\dists\gradle-%GRADLE_VERSION%-bin\digitech"
set "GRADLE_BIN=%GRADLE_CACHE_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat"
if not exist "%GRADLE_BIN%" (
  if not exist "%GRADLE_CACHE_DIR%" mkdir "%GRADLE_CACHE_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$archive='%GRADLE_CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $archive; if ((Get-FileHash $archive -Algorithm SHA256).Hash.ToLower() -ne '%GRADLE_SHA256%') { throw 'Gradle distribution checksum mismatch' }; Expand-Archive -Force $archive '%GRADLE_CACHE_DIR%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
