# DigiTech Business OS — Google Studio Continuation Handoff

## Read this first

This package is a continuation checkpoint. **Do not restart, regenerate, or replace the project.**

The original **Next.js + Supabase DigiTech Business OS** is the source of truth for business rules, database schema, roles, permissions, finance calculations, order lifecycle, renewal chains, approval controls, and AI gateway security.

The **Android/Kotlin Compose app** is a client/rewrite that must continue to be repaired until it reaches safe feature parity and produces a tested installable APK.

## Package map

- `original-source/digitech-business-os/` — authoritative Next.js + Supabase application.
- `android-latest/` — current Android client checkpoint.
- `DIGITECH_REPAIR_AUDIT_AND_STATUS.md` — deep audit, completed work, risks, and blockers.
- `DIGITECH_INTERACTIVE_DESIGN_UPGRADE_V7.md` — latest Pulse Command Center and Copilot UI changes.
- `digitech-android-preview.png` — current visual direction preview.
- `GOOGLE_STUDIO_CONTINUATION_PROMPT.md` — exact prompt to paste into Google Studio/Gemini.

## Current verified state

### Authoritative web app

- Supabase-first multi-tenant Business OS with RLS and exact server roles.
- Secure OpenRouter/Google/custom-model AI gateway; provider secrets remain server-side.
- Today Command Center, global search, Quick Add, Customer 360 next actions, bulk renewals.
- Approval Center with durable action-job queue and human review.
- Unified Inbox and Finance Intelligence.
- Mobile transaction RPCs for order creation, payment, activation completion, and order transitions.
- Last completed web verification: TypeScript, ESLint, 328 tests, and Next.js production build passed; 17 live Supabase tests were skipped because deployment credentials were unavailable.

### Android client

- Firebase/Firestore was removed as the business-data authority.
- Supabase Auth and organization-scoped data sync are the authority.
- Tokens use encrypted storage; unknown roles fail closed.
- Server writes are followed by authoritative refresh.
- Local creation of subscriptions/activations is blocked; critical mutations use server RPCs.
- Stale cached business data is hidden until organization-scoped sync succeeds.
- Multi-provider AI UI supports OpenRouter, Google, and custom model IDs.
- New motion system, press feedback, staggered dashboard reveal, animated chat messages, screen transitions, and raised Copilot navigation are present.
- Latest V7 adds a live Business Pulse hero, metric-driven attention ring, tactile command actions, animated KPI changes, an interactive Copilot role rail, and a four-workflow Copilot launchpad.
- Missing shared components and Orders/Renewal/Fulfillment screens were restored in the current checkpoint.
- Hard-coded Quick Demo emails/password auto-fill was removed from the login screen.

## Important verification warning

The Android app has **not yet completed a real Android compilation** in the current environment. The Gradle wrapper works, but Android Gradle Plugin `8.7.3` cannot be fetched from Google Maven here, and the Android SDK is unavailable. Treat recent Compose changes as syntax-reviewed but not compiler/device-verified.

Google Studio must make the Android build pass before adding more features. Do not report success based only on static inspection.

## Non-negotiable security rules

1. Never restore Firebase/Firestore as a second source of truth.
2. Never put OpenRouter, Google AI, Supabase service-role, or any private provider key in the APK.
3. Only Supabase public URL and anon/publishable key may be compiled as public client configuration.
4. Never cache passwords, license keys, activation secrets, or customer credentials in Room/logs.
5. Every business query and mutation must remain organization-scoped and server-authorized.
6. Roles must come from the server. Do not add role selection or client-side privilege escalation.
7. Do not restore demo password auto-fill or hard-coded production credentials.
8. AI may prepare consequential actions, but approval/server-side validation must execute them.

## Next work order

1. Run Android compilation and fix every concrete compiler/resource error without deleting completed security work.
2. Finish Compose parity for approvals, unified inbox, finance intelligence, Customer 360, tasks/support/leads, and role-aware navigation.
3. Complete encrypted server-only activation-secret workflow; keep secrets memory-only on Android.
4. Partition or encrypt offline storage by organization and test sign-out/session switching.
5. Add loading, empty, offline, retry, permission-denied, success, and error states for every critical flow.
6. Run unit, integration, lint, release build, emulator/device smoke, two-organization isolation, and AI-provider failure tests.
7. Produce a real installable APK and state whether it is debug or signed release.

## Required public configuration before a functional final APK

- `DIGITECH_SUPABASE_URL`
- `DIGITECH_SUPABASE_ANON_KEY` (public anon/publishable key only)
- `DIGITECH_API_BASE_URL` (deployed Next.js secure API)
- `DIGITECH_GOOGLE_WEB_CLIENT_ID` (optional, only if Google sign-in is enabled)

Do not ask for or embed provider secrets in the Android project.
